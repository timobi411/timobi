# 入力契約と実データ接続

このアダプターは受領したv0.5診断版／bridgeが参照する保存データのコードを調査して作成しました。v0.4クラスタリング本体の実行や変更は行いません。全上流結果に対応済みという意味ではありません。

## 必須データ

| 入力 | 契約 |
|---|---|
| `pixels` | NPZ。`xyz`=HxWx3数値、メートル。`valid`=HxW bool。`labels`=HxW整数、負値は候補対象外、非負値は断片ID |
| `clusters` | JSONの `clusters` 配列。各行に非負整数 `id` と整数 `point_count`。ラベルのID集合・点数と一致。`MODEL_INFERRED` は未指定または0 |
| 有効点 | `valid` の点はfinite。非負labelsの点はvalid必須。未観測点の補間なし |
| 名前空間 | run_id / case / window / boundary / time / fragment_id。画素IDは時刻ごとのC順flat index |

## 任意データ

`canonical_mask` は `{"path":"mask.npz","key":"canonical"}`。真の画素が構造除去対象で、labels>=0との重なりをエラーにします。

`feature_arrays` は `{"path":"features.npz","keys":{"source_kind":"kind",...}}`。keysの左が本エンジンの役割、右が実ファイル中の配列名です。すべてHxW、pickle/object配列は受け付けません。

| 役割 | 処理 |
|---|---|
| source_kind | CURRENT/TEMPORAL等の上流値ごとの代表画素数。独立支持点数とみなさない |
| sample_id + measurement_time | (元時刻,sample)の重複排除数。両方なければUNAVAILABLE |
| confidence | finite数値。min/mean/max。値の意味や校正は上流依存 |
| range_m / mad_m | finite数値、メートル。min/mean/max |
| missing_classification | 元の欠測分類配列をそのまま保存。欠測を同一性の支持に自動変換しない |

履歴やlocal modelの実スキーマは未受領のため推測しません。利用不能な特徴は `available=UNAVAILABLE,value=null` とします。保存済みの原配列・関係はコピーとhashを残します。保存辺の距離/β/理由は元payloadにある場合そのまま残しますが、未受領の辺スキーマを特徴値へ自動展開しません。`saved_edge_geometry` はその場合UNAVAILABLE、`saved_relations_reference` が原本を指します。

`source_code` にソースファイルの明示的パス配列を渡すと、読取り専用の参照資料としてコピー・hashを保存します。実行した新エンジンのhashは別途 `environment.json` に保存します。

## 保存関係の明示的な正規化契約

`relations` はJSONLです。これは新たに定義した交換形式であり、未受領のv0.4生スキーマと同一と仮定しません。上流の形式が異なる場合、元データを変更せず別ファイルへ変換して指定してください。

```json
{"schema":"ylm051.evidence.v1","evidence_id":"saved-edge-1","fragment_ids":[10,60],"kind":"DIRECT_HELD","target":"SURFACE_CONTINUATION","state":"HOLD","family":"GEOMETRY_DISTANCE","source_samples":["bagA/time123/sample7"],"source_pixels":[12,13],"source_candidate_id":"upstream-candidate-1","upstream_search_complete":false,"conditions":{"upstream_reason":"preserved verbatim"},"saved_geometry":{"distance_m":0.14,"beta":null,"reason":"saved by upstream"}}
```

- 種別はDIRECT_HELD、IMAGE_GAP、SPATIAL_NEAR、CHAIN_REVIEW。
- 対象はSURFACE_CONTINUATIONまたはOBJECT_PART_ASSOCIATION。両方の仮説がある場合は別record。
- 未校正のSUPPORTED/REJECTED申告はHOLDへ落とし、`original_state` と `original_payload` に元値を残す。
- SUPPORTEDには `validated_rule_id` がprofileの明示的 `validated_rule_ids` に含まれ、独立性ルールと元sample/pixel来歴が必要。規則名の指定だけで実データ校正を自動証明する機能はない。
- semanticなREJECTEDにも検証済み規則と `rejection_scope` が必要。候補全体の矛盾として扱うのはOBJECT_PART_ASSOCIATIONかつ `same_object_for_endpoints` の範囲だけ。
- 独立支持はfamilyと明示された元測定tokenで重複排除する。sample tokenはbag/時刻/sampleを含む衝突しない識別子にする。異なる来歴表現を比較できなければ独立認定しない。
- 元graph欠落、元探索未完了、今回の予算打切りを別項目に残す。辺がないことを負の証拠にしない。

## 事後評価契約

`ylm051.evaluation.v1` は生成CLIでは受理しません。実例は `validation/fixture/evaluation.json`、正式schemaは `schemas/evaluation.schema.json` です。

proxyにはNPYのNx3点群またはPCD、units=m、old_to_observationの4x4剛体変換、coordinate_evidence、正のradius_mを指定します。GTは `gt_labels` にHxW NPYを指定し、coverage_threshold / purity_threshold / false_merge_min_fraction / recall_kを明示します。

`dataset_role` と `selection_disclosure` に対象選定の経緯を記録します。exp01/exp02は開発データ、exp08は過去に開発参照済みの追加確認と表記します。frame_id一致や同一原点だけでbag間姿勢一致を保証しません。姿勢未検証ならFRAME_UNVERIFIEDを維持してください。

## Schemaと意味検査

`schemas/*.schema.json` はJSON Schema draft 2020-12です。profile、input、正規化evidence、hypothesis、fragment_features、evaluationを定義しています。`schemas/build_schemas.py` で再生成できます。設定ひな型のnull値は「未設定」なので実行可能profileのschemaに合格しません。

schemaが確認するのはJSONの構造です。配列shape・dtype・座標・点数・ID対応・深さの整合・入力/出力hash・候補の全断片和集合は実行時とverifyで別途検査します。生の上流関係の追加属性は証拠として推測解釈せずpayloadに保持します。
