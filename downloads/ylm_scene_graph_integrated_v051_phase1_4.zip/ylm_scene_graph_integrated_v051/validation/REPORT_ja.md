# 検証結果 — 2026-10-19 UTC

26件の自動テストに合格しました（失敗0、skip0）。詳細は `unittest.log`。ソースと結果schemaの整合も試験しています。これは合成動作試験の合格であり、実データ精度改善の合格ではありません。

## CLIでの別プロセス実測

すべて生成・事後評価CLIの終了コードは0。候補数はsingletonを含みます。時間はmanifest確定前までの生成パイプライン計測、RSSはそのPythonプロセス全体のLinux高水位です。CLIの起動前後の全経過時間やブラウザのメモリは含みません。

| 軸 | profile | 候補T0/T1 | 到達断片T0/T1 | 秒 | peak RSS MiB | 状態 |
|---|---|---:|---:|---:|---:|---|
| evidence | B0 | 12/12 | 1/1 | 0.104 | 69.60 | COMPLETED_CONFIGURED_SCOPE |
| evidence | B1 | 268/118 | 10/7 | 0.718 | 77.35 | BUDGET_TRUNCATED |
| evidence | B2 | 268/118 | 10/7 | 0.826 | 77.39 | BUDGET_TRUNCATED |
| evidence | B3 | 268/118 | 10/7 | 0.822 | 77.71 | BUDGET_TRUNCATED |
| beam | greedy_width1 | 162/162 | 10/10 | 0.482 | 76.52 | BUDGET_TRUNCATED |
| beam | B3 | 268/118 | 10/7 | 0.654 | 77.70 | BUDGET_TRUNCATED |
| depth | fragments16 | 80/80 | 16/16 | 4.730 | 168.30 | BUDGET_TRUNCATED |
| depth | fragments32 | 96/96 | 32/32 | 4.707 | 169.43 | BUDGET_TRUNCATED |
| depth | fragments64 | 128/128 | 64/64 | 5.566 | 171.48 | BUDGET_TRUNCATED |

evidenceとbeamは12断片・74代表点/時刻の同一fixture、depthは65個の1点断片/時刻という別fixtureです。fixtureのcase欄はexp02という名前空間ですが、dataset_kindは明示的にSYNTHETICです。実exp02の計測値ではありません。

B1～B3は全体展開上限600などに達しました。t0→t1で同じglobal予算を共有するためt1が少なくなっています。B1～B3の候補件数が同じことだけで同じ候補集合・同じ精度とは判断しません。補完haloが異なるセルをつなぐ効果は専用テストで検証しています。greedyもbeam等の局所枠で未展開があり、全探索完了とは扱いません。

depthの16/32/64到達を実測しました。最大深さを超える後続拡張は残るためBUDGET_TRUNCATEDです。予算を増やせば実データの175断片を回収できるという保証はありません。

## ブラウザ

Chromium + Playwrightで、候補一覧、断片ID検索、結合候補選択、organized・XZ・3D表示、色分け、T0/T1切替、JS例外0を確認しました。画像は `browser/viewer.png`、機械可読結果は `browser/result.json`。ページとJSは同梱の相対パスです。

この環境のブラウザはfile://への移動をERR_BLOCKED_BY_ADMINISTRATORで拒否しました。管理ポリシーは変更せず、ローカルHTTPで操作を検証しました。PCでのfile://操作自体は未検証です。file protocolの失敗ログも区別して同梱しています。HTTPログのfavicon.icoの404はブラウザのアイコン要求で、ViewerのJS/データ読込みは成功しています。

## 保全・再現

元vendor ZIPは受領SHA-256に一致。生成入力はそのまま保存し、元hashとコピーhashを比較。候補の全画素IDが元断片の和集合であること、元座標・labels不変、原本と候補の参照破損検出、移動後再生、入力列挙順不変を検査しました。旧PCDとGTを別内容に変更しても生成候補ID・順位・断片集合が変わらないことを確認しました。

`sample_B3` には完全な結果と入力コピーがあります。他比較のフォルダはmanifest・設定・資源・summary・実行ログの抜粋です。他比較の全点集合を再生成する場合は、同梱fixtureとREADMEの比較コマンドを使います。

## 未検証・未実装

正式v0.4の実exp02 T0/T1、実床ID 8、実データGT、実シーン8 GiB運用は未検証です。旧solverの新接続、追加ICP初期化、ScenarioはNOT_RUN。旧ZIP内の過去の旧ICP再現試験は今回再実行していません。元同一性はUNKNOWN、更新はHELD、既存graph書込は0です。

事後評価の代理入力は今回NumPy形式で試験しました。Open3DのPCD読込経路は実装していますが、この版の比較試験ではPCD形式を使っていません。

## ZIP展開後の確認

ZIPを別フォルダへ展開し、原本の入力パスを一時的に移動して利用不能にした状態でverifyとreplayを実行しました。両方が終了コード0で、候補ID・断片集合・rank_tupleが全件一致しました。元入力は確認後に元の場所へ戻しています。詳細は `relocation_check.json` です。同ログのarchive hashは検証時点のZIPを表し、このログを追加した最終ZIPのhashは外付け `.zip.sha256` に記録します。最終ZIPもCRCと全収録ファイルhashを再確認します。
