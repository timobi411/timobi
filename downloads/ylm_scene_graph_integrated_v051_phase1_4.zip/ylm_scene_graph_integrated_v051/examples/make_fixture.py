"""Explicit synthetic exploration profile and GT. Never a tuned real-data profile."""
import argparse
import copy
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ylm051.config import template
from ylm051.io import Output


def profile():
    p = template(); p['name'] = 'synthetic_assumptions_v1'
    p['geometry'] = {'grid_origin_m': [-1, -1, -1], 'cell_size_m': 2., 'halo_m': .3,
                     'spatial_radius_m': .19, 'pixel_gap': 1, 'normalization_scale_m': .05,
                     'max_added_gap_m': .25, 'max_diameter_m': 3., 'max_growth_ratio': 100., 'bridge_min_support': 2}
    p['budgets'].update(max_expanded_states=600, max_pair_checks=1500, max_point_copies=300000,
                        max_saved_bytes=64 * 1024 ** 2, max_regions=300, max_region_memberships=3000,
                        max_input_bytes=32 * 1024 ** 2, wall_seconds=60, rss_limit_mib=8192,
                        virtual_address_limit_mib=8192, seeds_per_region=8, max_fragments=32, max_depth=31)
    p['parameter_sources'] = {k: 'EXPLICIT SYNTHETIC FIXTURE ASSUMPTION; uncalibrated for real scenes' for k in p['geometry']}
    return p


def make(destination, chain_length=None, empty=False):
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=False)
    out = Output(destination)
    rng = np.random.default_rng(51803)
    if chain_length is not None:
        fragments = {i: np.array([[.02 * i, 0, .2]]) for i in range(chain_length)}
        gt_map = {i: 1 for i in fragments}
    else:
        fragments = {10 + i: np.array([[i * .07, 0, .2], [i * .07, .02, .2]])[:1 + (i % 2)] for i in range(5)}
        fragments.update({20: rng.uniform([.33, -.03, .15], [.40, .06, .30], (8, 3)),
                          21: np.array([[.46, .02, .22], [.47, .03, .22]]),
                          30: np.array([[.31, .02, .2]]),  # one-point bridge risk
                          40: rng.uniform([1.1, -.1, .0], [7., .2, .8], (50, 3)),  # whole giant cluster
                          50: np.array([[.245, .01, .2]]),  # third fragment near a bridge
                          60: np.array([[.08, .08, .35], [.10, .08, .35], [.08, .1, .35], [.1, .1, .35]]),
                          70: np.array([[4., 4., .1]])})  # tiny-only region
        gt_map = {fid: (1 if 10 <= fid <= 14 else 2 if fid in (20, 21) else 3 if fid == 40 else 0) for fid in fragments}
    if empty:
        fragments = {}; gt_map = {}
    height = max(1, len(fragments)); width = max([len(p) for p in fragments.values()] + [1]) + 2
    config = {'schema': 'ylm051.input.v1', 'run_id': 'synthetic_fixture_v1', 'case': 'exp02', 'window': 'fixed11',
              'boundary': 'boundary_false', 'units': 'm', 'dataset_kind': 'SYNTHETIC_WITH_SEPARATE_GT',
              'development_selection': 'synthetic topology chosen to exercise specified failure modes',
              'frame_status': 'FRAME_UNVERIFIED', 'times': {}}
    evaluation = {'schema': 'ylm051.evaluation.v1', 'dataset_role': 'synthetic',
                  'selection_disclosure': 'fixture designed with known GT for behavior testing, not independent accuracy benchmarking',
                  'gt_metrics': {'coverage_threshold': .5, 'purity_threshold': .8, 'false_merge_min_fraction': .1, 'recall_k': 20}, 'times': {}}
    for time in ('t0', 't1'):
        xyz = np.zeros((height, width, 3), np.float32); valid = np.zeros((height, width), bool)
        labels = np.full((height, width), -1, np.int32); gt = np.full((height, width), -1, np.int32)
        clusters = []
        for row, (fid, points) in enumerate(sorted(fragments.items())):
            points = points + ([.015, 0, 0] if time == 't1' else [0, 0, 0])
            n = len(points); xyz[row, :n] = points; valid[row, :n] = True; labels[row, :n] = fid; gt[row, :n] = gt_map[fid]
            clusters.append({'id': fid, 'point_count': n, 'MODEL_INFERRED': 0})
        folder = out.path(time + '/pixels.npz').parent
        np.savez_compressed(folder / 'pixels.npz', xyz=xyz, valid=valid, labels=labels)
        np.savez_compressed(folder / 'mask.npz', canonical=np.zeros(valid.shape, bool))
        pixels = np.arange(valid.size).reshape(valid.shape)
        np.savez_compressed(folder / 'features.npz', kind=np.where(pixels % 2, 'CURRENT', 'TEMPORAL'),
                            sample=pixels % 3, time=np.full(valid.shape, 'sample-frame-shared'),
                            confidence=np.full(valid.shape, .7), range=np.linalg.norm(xyz, axis=2),
                            mad=np.full(valid.shape, .01), missing=np.where(valid, 'OBSERVED', 'NO_RETURN'))
        out.json(time + '/clusters.json', {'clusters': clusters})
        np.save(folder / 'gt.npy', gt)
        old = xyz[(gt == 1) & valid]
        np.save(folder / 'proxy.npy', old)
        relation_path = out.path(time + '/relations.jsonl'); relation_path.write_text('')
        if chain_length is None and not empty:
            for eid, a, b, kind, target, state in [('surface-step', 10, 60, 'DIRECT_HELD', 'SURFACE_CONTINUATION', 'REJECTED'),
                                                 ('part-hypothesis', 10, 60, 'IMAGE_GAP', 'OBJECT_PART_ASSOCIATION', 'HOLD'),
                                                 ('far-giant', 10, 40, 'CHAIN_REVIEW', 'OBJECT_PART_ASSOCIATION', 'HOLD')]:
                out.event(time + '/relations.jsonl', {'schema': 'ylm051.evidence.v1', 'evidence_id': eid,
                    'fragment_ids': [a, b], 'kind': kind, 'target': target, 'state': state,
                    'family': 'GEOMETRY_DISTANCE', 'source_samples': ['same_sample'], 'source_pixels': [0],
                    'conditions': {'upstream_label': 'PART_ASSOCIATION_CANDIDATE'}, 'upstream_search_complete': False,
                    'rejection_scope': 'surface_only' if target == 'SURFACE_CONTINUATION' else None})
        config['times'][time] = {'pixels': time + '/pixels.npz', 'clusters': time + '/clusters.json',
                                'canonical_mask': {'path': time + '/mask.npz', 'key': 'canonical'},
                                'feature_arrays': {'path': time + '/features.npz', 'keys': {'source_kind': 'kind', 'sample_id': 'sample',
                                    'measurement_time': 'time', 'confidence': 'confidence', 'range_m': 'range', 'mad_m': 'mad', 'missing_classification': 'missing'}},
                                'relations': time + '/relations.jsonl', 'source_code': []}
        evaluation['times'][time] = {'gt_labels': time + '/gt.npy', 'proxy': {'points': time + '/proxy.npy', 'units': 'm',
                                    'old_to_observation': np.eye(4).tolist(), 'coordinate_evidence': 'synthetic same-frame construction', 'radius_m': .03}}
    out.json('input.json', config); out.json('evaluation.json', evaluation)
    base = profile()
    if chain_length is not None:
        base['geometry'].update(spatial_radius_m=.021, max_added_gap_m=.021, max_diameter_m=10., max_growth_ratio=1000., cell_size_m=10.)
        base['budgets'].update(seeds_per_region=1, expansions_per_state=2, max_pair_checks=10000, max_point_copies=1000000,
                               max_expanded_states=2000, max_saved_bytes=256 * 1024 ** 2)
    for variant in ('B0', 'B1', 'B2', 'B3'):
        p = copy.deepcopy(base); p['variant'] = variant
        out.json('profiles/' + variant + '.json', p)
    greedy = copy.deepcopy(base); greedy['budgets']['beam_per_seed'] = 1
    out.json('profiles/greedy_width1.json', greedy)
    for count in (16, 32, 64):
        p = copy.deepcopy(base); p['budgets'].update(max_fragments=count, max_depth=count - 1)
        out.json(f'profiles/fragments{count}.json', p)
    lightweight = copy.deepcopy(base); lightweight['budgets'].update(max_fragments=17, max_depth=16)
    out.json('profiles/lightweight_depth16.json', lightweight)
    return destination


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--out', required=True); parser.add_argument('--chain-length', type=int); parser.add_argument('--empty', action='store_true')
    args = parser.parse_args(); print(make(args.out, args.chain_length, args.empty))
