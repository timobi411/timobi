"""A bounded comparison axis. Never changes structural masks or combines all axes."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ylm051.io import read, Output, rows


def main():
    p = argparse.ArgumentParser(); p.add_argument('--fixture', required=True); p.add_argument('--out', required=True)
    p.add_argument('--axis', choices=['evidence', 'beam', 'fragment_budget'], required=True)
    args = p.parse_args(); source = Path(args.fixture).resolve(); dest = Path(args.out).resolve()
    dest.mkdir(parents=True, exist_ok=False); out = Output(dest)
    profiles = {'evidence': ['B0', 'B1', 'B2', 'B3'], 'beam': ['greedy_width1', 'B3'],
                'fragment_budget': ['fragments16', 'fragments32', 'fragments64']}[args.axis]
    rows_out = []
    for name in profiles:
        run = dest / name
        command = [sys.executable, '-m', 'ylm051', 'generate', '--input', str(source / 'input.json'),
                   '--profile', str(source / 'profiles' / (name + '.json')), '--out', str(run)]
        with (dest / (name + '.log')).open('w') as log:
            result = subprocess.run(command, cwd=ROOT, env=os.environ.copy(), stdout=log, stderr=subprocess.STDOUT)
        manifest = read(run / 'run_manifest.json')
        eval_path = dest / (name + '_evaluation')
        if result.returncode == 0:
            command = [sys.executable, '-m', 'ylm051', 'evaluate', '--run', str(run), '--evaluation', str(source / 'evaluation.json'), '--out', str(eval_path)]
            with (dest / (name + '_evaluation.log')).open('w') as log:
                er = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
            evaluation = read(eval_path / 'evaluation.json') if er.returncode == 0 else None
        else:
            evaluation = None
        rows_out.append({'profile': name, 'returncode': result.returncode,
                         'processing_complete': manifest['processing_complete'], 'exploration_state': manifest.get('exploration_state'),
                         'resource_measurement': manifest['resources'],
                         'candidate_counts': {t: sum(c['namespace']['time'] == t for c in rows(run / 'hypotheses.jsonl')) for t in ('t0', 't1')},
                         'evaluation': {t: {'proxy': value['proxy'], 'gt': value['gt']} for t, value in evaluation['times'].items()} if evaluation else 'NOT_EVALUATED'})
    out.json('comparison.json', {'axis': args.axis, 'changes': profiles, 'runs': rows_out,
                                 'performance_improvement': 'NOT_CLAIMED', 'candidate_identity': 'UNKNOWN',
                                 'interpretation': 'synthetic checks; truncation and output size are not object-accuracy success'})
    print(json.dumps({'comparison': str(dest / 'comparison.json'), 'runs': len(rows_out)}))
    return 0 if all(r['returncode'] == 0 for r in rows_out) else 2


if __name__ == '__main__': sys.exit(main())
