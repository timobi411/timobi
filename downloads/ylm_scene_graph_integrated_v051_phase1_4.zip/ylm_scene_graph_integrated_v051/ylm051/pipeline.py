import copy
import importlib.util
import importlib.metadata
from pathlib import Path
import platform
import sys
import traceback
import numpy as np
from .io import Output, Budget, BudgetStop, read, rows, sha, digest, canonical, safe_ref, ROOT
from .config import validate_profile, load_input
from .features import snapshot_inputs, build_scene
from .graph import build_graph, Graph
from .search import search_scene, stable_id


def runtime():
    mods = {}
    for name in ('numpy', 'scipy', 'plotly', 'open3d', 'rclpy', 'rosbag2_py'):
        spec = importlib.util.find_spec(name)
        try:
            version = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            version = None
        mods[name] = {'available': bool(spec), 'path': spec.origin if spec else None, 'version': version}
    return {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(),
            'modules': mods, 'workers': 1, 'numerical_threads': 1, 'ros_processing': 'NOT_RUN',
            'source_modules': {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted((ROOT / 'ylm051').glob('*.py'))}}


def hashes(root):
    return {p.relative_to(root).as_posix(): sha(p) for p in sorted(root.rglob('*'))
            if p.is_file() and p.name != 'artifact_hashes.json'}


def verify(run, check_originals=True):
    run = Path(run).resolve()
    manifest = read(run / 'run_manifest.json')
    for rel, expected in read(run / 'artifact_hashes.json').items():
        if sha(safe_ref(run, rel)) != expected:
            raise ValueError('output content hash mismatch: ' + rel)
    records = read(run / 'source_hashes.json')
    for record in records:
        if sha(safe_ref(run, record['snapshot'])) != record['sha256']:
            raise ValueError('input snapshot changed')
        p = Path(record['original_path'])
        if check_originals and p.exists() and sha(p) != record['sha256']:
            raise ValueError('original input changed: ' + record['role'])
    config, profile = read(run / 'input_contract.json'), read(run / 'resolved_config.json')
    scenes = {}
    # Verify only union membership, immutable coordinates/labels and candidate IDs; do not rerun search.
    for time, spec in config['times'].items():
        with np.load(safe_ref(run, spec['pixels']), allow_pickle=False) as z:
            labels, valid, xyz = z['labels'], z['valid'], z['xyz']
        fingerprint = digest({'context': dict({k: config[k] for k in ('run_id', 'case', 'window', 'boundary')}, time=time),
                              'schema': config['schema'], 'units': config['units'],
                              'sources': sorted((r['role'], r['index'], r['sha256']) for r in records if r['time'] == time),
                              'optional_mapping': spec.get('feature_arrays', {}).get('keys'),
                              'canonical_mask_key': spec.get('canonical_mask', {}).get('key')})
        scenes[time] = (labels, valid, xyz, fingerprint)
    seen = set(); counts = {}
    for c in rows(run / 'hypotheses.jsonl'):
        cid = c['candidate_id']
        if cid in seen:
            raise ValueError('duplicate candidate ID')
        seen.add(cid)
        labels, valid, xyz, fingerprint = scenes[c['namespace']['time']]
        ids = np.load(safe_ref(run, c['source_point_ids']), allow_pickle=False)
        expected = np.flatnonzero(np.isin(labels.ravel(), c['fragment_ids']))
        if not np.array_equal(ids, expected) or len(ids) != c['point_count']:
            raise ValueError('candidate is not the whole measured fragment union')
        if not valid.ravel()[ids].all() or not np.isfinite(xyz.reshape(-1, 3)[ids]).all():
            raise ValueError('invalid candidate points')
        expected_id = 'H-' + digest({'schema': 'ylm051.hypothesis.v1', 'input': fingerprint,
                                    'profile': profile, 'namespace': c['namespace'], 'fragments': sorted(c['fragment_ids'])})[:32]
        if cid != expected_id or c['identity_status'] != 'UNKNOWN' or c['update_status'] != 'HELD':
            raise ValueError('invalid candidate ID or unsafe status')
        counts[c['namespace']['time']] = counts.get(c['namespace']['time'], 0) + 1
    if read(run / 'registration/status.json')['status'] != 'NOT_RUN':
        raise ValueError('Phase 5 must remain NOT_RUN in this release')
    return {'integrity_passed': True, 'candidate_counts': counts,
            'processing_complete': manifest['processing_complete'], 'identity_evaluation': 'UNKNOWN',
            'precision_evaluation': manifest['precision_evaluation']}


def generate(input_path, profile_path, destination, replay=None):
    destination = Path(destination).expanduser().resolve()
    if destination.exists():
        raise FileExistsError('new output directory required')
    profile = validate_profile(read(profile_path))
    if replay:
        previous = Path(replay).resolve(); verify(previous)
        config = read(previous / 'input_contract.json')
        # Saved snapshots are sufficient even after relocation/deletion of original sources.
        for spec in config['times'].values():
            for k in ('pixels', 'clusters', 'relations'):
                if spec.get(k): spec[k] = str(safe_ref(previous, spec[k]))
            for k in ('canonical_mask', 'feature_arrays'):
                if spec.get(k): spec[k]['path'] = str(safe_ref(previous, spec[k]['path']))
            spec['source_code'] = [str(safe_ref(previous, p)) for p in spec.get('source_code', [])]
    else:
        config = load_input(input_path)
    for spec in config['times'].values():
        for k in ('pixels', 'clusters'):
            parent = Path(spec[k]).resolve().parent
            if destination == parent or destination.is_relative_to(parent):
                raise ValueError('output must be outside input data directories')
    budget = Budget(profile['budgets']); output = Output(destination, budget)
    destination.mkdir(parents=True)
    state = {'version': '0.5.1', 'scope': 'Phase 1-4 candidate formation', 'processing_complete': False,
             'stages': {}, 'identity_status': 'UNKNOWN', 'frame_status': config['frame_status'], 'update_status': 'HELD',
             'precision_evaluation': 'NOT_EVALUATED', 'dataset_kind': config['dataset_kind'],
             'development_selection': config['development_selection'], 'existing_graph_write_count': 0,
             'schemas': {'input': 'ylm051.input.v1', 'profile': 'ylm051.profile.v1', 'hypothesis': 'ylm051.hypothesis.v1'},
             'units': 'm', 'registration': 'NOT_RUN', 'scenario_assignment': 'NOT_RUN',
             'window_caution': 'all may have expired temporal integration; not only a frame-count difference',
             'source_inventory': read(ROOT / 'source_inventory.json')}
    output.json('run_manifest.json', state, essential=True)
    # Empty ledgers are deliberate, so failure/empty-input runs still have inspectable schemas.
    for name in ('fragment_features.jsonl', 'pair_evidence.jsonl', 'hypotheses.jsonl', 'singletons.jsonl',
                 'search_trace.jsonl', 'regions.jsonl', 'seeds.jsonl', 'graph_status.jsonl',
                 'supplemental_graph.jsonl', 'archive_exclusions.jsonl'):
        output.text(name, '', essential=True)
    results = []; summary = {}; stage = 'snapshot'
    try:
        config, records = snapshot_inputs(config, output, budget)
        output.json('resolved_config.json', profile)
        output.json('environment.json', runtime())
        output.json('registration/status.json', {'status': 'NOT_RUN', 'reason': 'Phase 5 outside this delivery'}, essential=True)
        output.json('matching_scenarios.json', {'status': 'NOT_RUN', 'scenarios': [], 'reason': 'Phase 6 outside this delivery'}, essential=True)
        output.json('scene_graph_proposals.json', {'status': 'HELD', 'proposals': [], 'existing_graph_write_count': 0,
                                                 'reason': 'candidate formation does not determine identity or modify graph'}, essential=True)
        output.json('evaluation.json', {'status': 'NOT_EVALUATED', 'input_boundary': 'old PCD and GT only accepted by separate evaluate CLI'}, essential=True)
        scenes = []
        for time in sorted(config['times']):
            stage = f'{time}:phase1'
            scene = build_scene(config, time, destination, records, output, budget); scenes.append(scene)
            state['stages'][stage] = 'COMPLETED'
            stage = f'{time}:phase2'
            try:
                graph = build_graph(scene, profile, output, budget)
            except BudgetStop as exc:
                # Preserve singleton inventory when region/pair enumeration hits a count budget.
                # Hard wall/RSS/storage stops still propagate during subsequent writes.
                graph = Graph({}, {f: set() for f in scene.fragments}, {},
                              {'time': time, 'original_graph': 'AVAILABLE' if scene.relation_path else 'UNAVAILABLE',
                               'exploration_state': 'BUDGET_TRUNCATED', 'stop_reason': exc.reason,
                               'unseen_pair_count': 'UNKNOWN', 'enumerated_unprocessed_pairs': 'UNKNOWN'})
                output.text('graph_status.jsonl', canonical(graph.status) + '\n', append=True, essential=True)
            state['stages'][stage] = 'BUDGET_TRUNCATED' if graph.status['exploration_state'] == 'BUDGET_TRUNCATED' else 'COMPLETED'
            stage = f'{time}:phase3_4'
            candidates, stat = search_scene(scene, graph, profile, output, budget, config['frame_status'])
            results.extend(candidates); summary[time] = stat
            state['stages'][stage] = 'BUDGET_TRUNCATED' if stat['exploration_state'] == 'BUDGET_TRUNCATED' else 'COMPLETED'
            output.json('run_manifest.json', state)
        stage = 'viewer'
        from .viewer import build_viewer
        build_viewer(destination, output, profile['viewer_max_points_per_time'])
        state['stages'][stage] = 'COMPLETED'
        state['processing_complete'] = all(v in ('COMPLETED', 'BUDGET_TRUNCATED') for v in state['stages'].values())
        state['exploration_state'] = 'BUDGET_TRUNCATED' if any(v == 'BUDGET_TRUNCATED' for v in state['stages'].values()) else 'COMPLETED_CONFIGURED_SCOPE'
    except (Exception, MemoryError) as exc:
        status = 'BUDGET_TRUNCATED' if isinstance(exc, BudgetStop) else 'FAILED_RESOURCE_LIMIT' if isinstance(exc, MemoryError) else 'FAILED'
        state['stages'][stage] = status
        state['processing_complete'] = False
        state['error'] = {'type': type(exc).__name__, 'message': str(exc)}
        state['exploration_state'] = status
        # Diagnostics use a reserved part of the total storage quota.
        output.text('failure.txt', traceback.format_exc()[-12000:], essential=True)
        output.text('index.html', '<!doctype html><meta charset="utf-8"><h1>Partial YLM run</h1><p>See run_manifest.json and failure.txt.</p><a href="run_manifest.json">manifest</a>', essential=True)
    try:
        state['originals_unchanged'] = all(sha(safe_ref(destination, r['snapshot'])) == r['sha256'] and
                                         (not Path(r['original_path']).exists() or sha(r['original_path']) == r['sha256'])
                                         for r in read(destination / 'source_hashes.json'))
    except Exception:
        state['originals_unchanged'] = False
    state['integrity_passed'] = state['originals_unchanged']
    state['resources'] = budget.report()
    state['search_exhaustive'] = state.get('exploration_state') == 'COMPLETED_CONFIGURED_SCOPE'
    state['processing_complete_definition'] = 'planned Phase1-4 outputs produced under the explicit search caps; not exhaustive search or accuracy success'
    state['output_total_limit_bytes'] = profile['budgets']['max_saved_bytes']
    state['diagnostic_reserve_bytes_included_in_total'] = budget.diagnostic_reserve
    output.json('search_summary.json', {'times': summary, 'resources': state['resources'],
                                        'precision_evaluation': 'NOT_EVALUATED', 'frontier_meaning': 'unexplored is not rejected'}, essential=True)
    output.json('run_manifest.json', state, essential=True)
    output.text('artifact_hashes.json', canonical(hashes(destination)) + '\n', essential=True)
    state['actual_saved_bytes'] = sum(p.stat().st_size for p in destination.rglob('*') if p.is_file())
    # Actual size is reported externally; manifest/hash content remains immutable after signing.
    return state
