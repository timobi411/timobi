import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read(path):
    with Path(path).open(encoding='utf-8') as f:
        return json.load(f)


def rows(path):
    with Path(path).open(encoding='utf-8') as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


class BudgetStop(RuntimeError):
    def __init__(self, reason):
        self.reason = reason
        super().__init__(reason)


class Budget:
    """Counters apply to the whole generation, not separately to each region/seed/time."""
    def __init__(self, limits):
        self.limits = limits
        self.started = time.monotonic()
        self.counts = {'expanded_states': 0, 'pair_checks': 0, 'point_copies': 0,
                       'regions': 0, 'region_memberships': 0, 'saved_bytes': 0}
        self.stop_reasons = set()
        self.diagnostic_reserve = min(1024 ** 2, int(limits['max_saved_bytes']) // 2)
        self.diagnostic_bytes = 0

    def stop(self, reason):
        self.stop_reasons.add(reason)
        raise BudgetStop(reason)

    def check(self):
        if time.monotonic() - self.started >= self.limits['wall_seconds']:
            self.stop('WALL_TIME_LIMIT')
        if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024 > self.limits['rss_limit_mib']:
            self.stop('RSS_LIMIT')

    def take(self, counter, amount=1):
        self.check()
        key = 'max_' + counter
        ceiling = self.limits[key] - self.diagnostic_reserve if counter == 'saved_bytes' else self.limits[key]
        if self.counts[counter] + amount > ceiling:
            self.stop(key.upper())
        self.counts[counter] += amount

    def report(self):
        return {'wall_seconds': time.monotonic() - self.started,
                'peak_rss_mib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024,
                'rss_method': 'Linux ru_maxrss / 1024; whole process high-water mark',
                'virtual_address_limit_mib': self.limits['virtual_address_limit_mib'],
                'counts': dict(self.counts), 'stop_reasons': sorted(self.stop_reasons),
                'scope': 'entire run across both times and all seeds/regions',
                'storage_quota': {'total_limit_bytes': self.limits['max_saved_bytes'],
                                  'reserved_diagnostic_bytes_inside_total': self.diagnostic_reserve,
                                  'diagnostic_bytes_written_so_far': self.diagnostic_bytes,
                                  'accounting': 'conservative cumulative bytes, including overwritten payload; actual bytes also returned by CLI'},
                'workers': 1, 'numerical_threads': 1}


class Output:
    def __init__(self, root, budget=None):
        self.root, self.budget = Path(root), budget

    def path(self, rel):
        p = (self.root / rel).resolve()
        if not p.is_relative_to(self.root.resolve()):
            raise ValueError('output path escapes run')
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    def text(self, rel, value, append=False, essential=False):
        encoded = value.encode('utf-8')
        if self.budget:
            if essential:
                if self.budget.diagnostic_bytes + len(encoded) > self.budget.diagnostic_reserve:
                    raise BudgetStop('DIAGNOSTIC_RESERVE_LIMIT')
                self.budget.diagnostic_bytes += len(encoded)
            else:
                self.budget.take('saved_bytes', len(encoded))
        with self.path(rel).open('ab' if append else 'wb') as f:
            f.write(encoded)

    def json(self, rel, value, essential=False):
        self.text(rel, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', essential=essential)

    def event(self, rel, value):
        self.text(rel, canonical(value) + '\n', append=True)

    def npy(self, rel, value):
        if self.budget:
            self.budget.take('saved_bytes', value.nbytes + 256)
        with self.path(rel).open('wb') as f:
            np.save(f, value, allow_pickle=False)

    def copy(self, src, rel):
        if self.budget:
            self.budget.take('saved_bytes', Path(src).stat().st_size)
        dest = self.path(rel)
        before = sha(src)
        shutil.copyfile(src, dest)
        if sha(src) != before or sha(dest) != before:
            raise ValueError('source changed during snapshot')
        return before


def safe_ref(root, rel):
    p = (Path(root) / rel).resolve()
    if not p.is_relative_to(Path(root).resolve()) or not p.is_file():
        raise ValueError('broken or unsafe saved reference: ' + str(rel))
    return p
