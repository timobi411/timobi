import copy
import math
from pathlib import Path
from .io import read

REQUIRED_GEOMETRY = ['grid_origin_m', 'cell_size_m', 'halo_m', 'spatial_radius_m', 'pixel_gap',
                     'normalization_scale_m', 'max_added_gap_m', 'max_diameter_m', 'max_growth_ratio',
                     'bridge_min_support']
GLOBAL_LIMITS = ['max_expanded_states', 'max_pair_checks', 'max_point_copies', 'max_saved_bytes',
                 'max_regions', 'max_region_memberships', 'max_input_bytes', 'wall_seconds',
                 'rss_limit_mib', 'virtual_address_limit_mib']
LOCAL_LIMITS = ['seeds_per_region', 'expansions_per_state', 'beam_per_seed', 'combined_per_time',
                'max_fragments', 'max_depth']


def template():
    return {
        'schema': 'ylm051.profile.v1', 'name': 'user_uncalibrated', 'variant': 'B3',
        'geometry': {key: None for key in REQUIRED_GEOMETRY},
        'budgets': dict({key: None for key in GLOBAL_LIMITS}, seeds_per_region=32, expansions_per_state=12,
                        beam_per_seed=8, combined_per_time=256, max_fragments=32, max_depth=31,
                        rss_limit_mib=8192, virtual_address_limit_mib=None),
        'calibration': {'status': 'UNCALIBRATED', 'independence_rule': None, 'validated_rule_ids': []},
        'viewer_max_points_per_time': 12000,
        'parameter_sources': {key: 'UNSET; choose exploration parameters explicitly, not identity thresholds'
                              for key in REQUIRED_GEOMETRY},
        'budget_scope': {'global': 'both times and all regions/seeds', 'combined_per_time': 'combined hypotheses only; singletons separate',
                         'beam_per_seed': 'additional hypotheses at each depth', 'seeds_per_region': 'each occupied local region'},
    }


def inspect_profile(p):
    missing = [f'geometry.{k}' for k in REQUIRED_GEOMETRY if p.get('geometry', {}).get(k) is None]
    missing += [f'budgets.{k}' for k in GLOBAL_LIMITS + LOCAL_LIMITS
                if k not in p.get('budgets', {}) or (k != 'virtual_address_limit_mib' and p['budgets'][k] is None)]
    return {'missing': missing, 'current_values': p, 'assumptions': p.get('parameter_sources', {}),
            'ready_to_generate': not missing, 'calibration': 'UNCALIBRATED unless explicit validated rules supplied'}


def validate_profile(p):
    missing = inspect_profile(p)['missing']
    if missing:
        raise ValueError('required settings are unset: ' + ', '.join(missing))
    if set(p) - set(template()):
        raise ValueError('unknown profile fields: ' + str(sorted(set(p) - set(template()))))
    if p.get('schema') != 'ylm051.profile.v1' or p.get('variant') not in ('B0', 'B1', 'B2', 'B3'):
        raise ValueError('unsupported profile schema/variant')
    g, b = p['geometry'], p['budgets']
    if set(g) != set(REQUIRED_GEOMETRY) or set(b) != set(GLOBAL_LIMITS + LOCAL_LIMITS):
        raise ValueError('geometry/budget fields must match schema exactly')
    origin = g['grid_origin_m']
    if not isinstance(origin, list) or len(origin) != 3 or not all(isinstance(v, (int, float)) and math.isfinite(v) for v in origin):
        raise ValueError('grid_origin_m must be finite xyz')
    for key in REQUIRED_GEOMETRY[1:]:
        v = g[key]
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0:
            raise ValueError('invalid nonnegative exploration parameter: ' + key)
    for k in ('cell_size_m', 'normalization_scale_m', 'max_diameter_m', 'max_growth_ratio', 'bridge_min_support'):
        if g[k] <= 0:
            raise ValueError(k + ' must be positive')
    if g['pixel_gap'] != int(g['pixel_gap']) or g['bridge_min_support'] != int(g['bridge_min_support']):
        raise ValueError('pixel_gap and bridge_min_support must be integers')
    for key, value in b.items():
        if key == 'virtual_address_limit_mib' and value is None:
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise ValueError('invalid positive budget: ' + key)
        if key not in ('wall_seconds', 'rss_limit_mib', 'virtual_address_limit_mib') and int(value) != value:
            raise ValueError('count budget must be integer: ' + key)
    if b['max_saved_bytes'] < 65536:
        raise ValueError('max_saved_bytes must allow at least 64 KiB including failure diagnostics')
    if b['max_depth'] != b['max_fragments'] - 1:
        raise ValueError('max_depth must equal max_fragments-1 (lightweight depth16 uses max_fragments17)')
    if not 1 <= p.get('viewer_max_points_per_time', 0) <= 100000:
        raise ValueError('viewer point budget required, range 1..100000')
    if p.get('calibration', {}).get('independence_rule') not in (None, 'family_and_disjoint_measurement_v1'):
        raise ValueError('unknown independence certification rule')
    if not isinstance(p.get('calibration', {}).get('validated_rule_ids'), list):
        raise ValueError('validated_rule_ids must be explicit')
    if not isinstance(p.get('parameter_sources'), dict) or any(not p['parameter_sources'].get(k) for k in REQUIRED_GEOMETRY):
        raise ValueError('record each exploration parameter source/assumption')
    return p


INPUT_KEYS = {'schema', 'run_id', 'case', 'window', 'boundary', 'units', 'dataset_kind',
              'development_selection', 'frame_status', 'times'}
TIME_KEYS = {'pixels', 'clusters', 'canonical_mask', 'feature_arrays', 'relations', 'source_code'}


def load_input(path):
    path = Path(path).resolve(); config = read(path)
    if set(config) - INPUT_KEYS:
        raise ValueError('generation input rejects evaluation/unknown fields: ' + str(sorted(set(config) - INPUT_KEYS)))
    if config.get('schema') != 'ylm051.input.v1' or config.get('units') != 'm':
        raise ValueError('input schema and explicit meter units required')
    for k in ('run_id', 'case', 'window', 'boundary', 'dataset_kind', 'development_selection', 'frame_status'):
        if k not in config:
            raise ValueError('missing input metadata ' + k)
    if config['window'] not in ('fixed11', 'all'):
        raise ValueError('unknown time window')
    if not config['times'] or set(config['times']) - {'t0', 't1'}:
        raise ValueError('times must contain t0 and/or t1')
    def resolve(v):
        p = Path(v).expanduser()
        return str((path.parent / p).resolve() if not p.is_absolute() else p.resolve())
    for time, spec in sorted(config['times'].items()):
        if set(spec) - TIME_KEYS:
            raise ValueError('generation time input rejects unknown fields')
        for k in ('pixels', 'clusters'):
            spec[k] = resolve(spec[k])
        for k in ('canonical_mask', 'feature_arrays'):
            if spec.get(k):
                spec[k]['path'] = resolve(spec[k]['path'])
        if spec.get('relations'):
            spec['relations'] = resolve(spec['relations'])
        spec['source_code'] = sorted(resolve(p) for p in spec.get('source_code', []))
    return config
