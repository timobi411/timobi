"""Deterministic bounded search. Points remain immutable fragment unions."""
import itertools
import numpy as np
from .io import digest, BudgetStop
from .features import shape
from .graph import independent_families


def size_bin(n):
    return 0 if n == 1 else 1 if n <= 4 else 2 if n <= 16 else 3


def diverse(values, limit):
    buckets = {}
    for item in sorted(values, key=lambda c: c['rank_tuple']):
        buckets.setdefault(size_bin(len(item['fragment_ids'])), []).append(item)
    selected = []
    quota = limit // max(1, len(buckets))
    for key in sorted(buckets):
        selected.extend(buckets[key][:quota]); buckets[key] = buckets[key][quota:]
    remaining = sorted((c for values in buckets.values() for c in values), key=lambda c: c['rank_tuple'])
    selected.extend(remaining[:max(0, limit - len(selected))])
    return sorted(selected, key=lambda c: c['rank_tuple'])


def pick_seeds(scene, fids, maximum, scale):
    bins = {}
    for fid in sorted(fids):
        n = len(scene.fragments[fid].ids)
        level = 0 if n <= 2 else 1 if n < 50 else 2 if n < 500 else 3
        bins.setdefault(level, []).append(fid)
    picked = []
    def position(fid):
        f = scene.fragments[fid]
        bbox = f.record['features']['pixel_bbox']['value']
        pixel = np.array([(bbox[0] + bbox[2]) / 2 / max(1, scene.labels.shape[0]),
                          (bbox[1] + bbox[3]) / 2 / max(1, scene.labels.shape[1])])
        return np.r_[f.centroid / scale, pixel]
    while bins and len(picked) < maximum:
        for level in sorted(list(bins)):
            if len(picked) >= maximum:
                break
            candidates = bins[level]
            if picked:
                key = lambda fid: (-min(float(np.linalg.norm(position(fid) - position(p))) for p in picked), fid)
                selected = min(candidates, key=key)
            else:
                selected = min(candidates)
            picked.append(selected); candidates.remove(selected)
            if not candidates:
                del bins[level]
    return picked, sorted(set(fids) - set(picked))


def components(nodes, edges, omit=None):
    adj = {n: set() for n in nodes}
    for a, b in edges:
        if omit == (a, b):
            continue
        adj[a].add(b); adj[b].add(a)
    remaining = set(nodes); count = 0
    while remaining:
        count += 1; stack = [min(remaining)]
        while stack:
            n = stack.pop()
            if n not in remaining:
                continue
            remaining.remove(n); stack.extend(sorted(adj[n] & remaining))
    return count


def audit_candidate(scene, graph, fids, profile, budget):
    fids = tuple(sorted(fids)); ids, pts = scene.points(fids, budget)
    low, high = pts.min(0), pts.max(0)
    diagonal = float(np.linalg.norm(high - low))
    reference = max(profile['geometry']['normalization_scale_m'],
                    max(float(np.linalg.norm(scene.fragments[f].high - scene.fragments[f].low)) for f in fids))
    growth = diagonal / reference
    pairs = [graph.pairs[p] for p in itertools.combinations(fids, 2) if p in graph.pairs]
    connected_edges = [tuple(p['fragment_ids']) for p in pairs if p['exploration_state'] == 'ELIGIBLE_FOR_HYPOTHESIS']
    original_edges = [tuple(p['fragment_ids']) for p in pairs if any(e['origin'] == 'original_saved_relation' for e in p['evidence'])]
    evidence = [e for p in pairs for e in p['evidence']]
    contradictions = [e['evidence_id'] for e in evidence if e['state'] == 'REJECTED'
                      and e['target'] == 'OBJECT_PART_ASSOCIATION' and e.get('rejection_scope') == 'same_object_for_endpoints']
    supported_pairs = 0; known_pairs = 0
    for pair in pairs:
        relevant = [e for e in pair['evidence'] if e['target'] == 'OBJECT_PART_ASSOCIATION'
                    and e['state'] in ('SUPPORTED', 'REJECTED')]
        if relevant:
            known_pairs += 1
            supported_pairs += int(any(e['state'] == 'SUPPORTED' for e in relevant))
    rate = supported_pairs / known_pairs if known_pairs else None
    cc = components(fids, connected_edges)
    bridge_edges = [list(p) for p in connected_edges if components(fids, connected_edges, omit=p) > cc]
    weak_bridges = []
    for edge in bridge_edges:
        p = graph.pairs[tuple(edge)]
        if min(p['geometry']['source_support_points'], p['geometry']['target_support_points']) < profile['geometry']['bridge_min_support']:
            weak_bridges.append(edge)
    third = sorted({f for p in pairs for f in p['geometry']['third_fragments_near_midpoint_aabb'] if f not in fids})
    independence = independent_families(evidence, profile)
    risks = []
    if not known_pairs and len(fids) > 1:
        risks.append('RELATION_SUPPORT_UNAVAILABLE')
    if len(fids) > 1 and independence['available'] == 'UNAVAILABLE':
        risks.append('INDEPENDENCE_UNAVAILABLE')
    if bridge_edges:
        risks.append('SINGLE_LINK_DEPENDENCE')
    if weak_bridges:
        risks.append('LOW_SUPPORT_BRIDGE')
    if third:
        risks.append('THIRD_FRAGMENT_NEAR_BRIDGE')
    if cc > 1:
        risks.append('DISCONNECTED_IN_EXPLORATION_GRAPH')
    if any(e['target'] == 'SURFACE_CONTINUATION' and e['state'] == 'REJECTED' for e in evidence):
        risks.append('SURFACE_REJECTED_OBJECT_PART_UNDECIDED')
    if len(fids) > 1 and any(e['kind'] == 'CHAIN_REVIEW' for e in evidence):
        risks.append('UNVERIFIED_CHAIN_RELATION')
    if diagonal > profile['geometry']['max_diameter_m']:
        risks.append('DIAMETER_EXPLORATION_LIMIT')
    if growth > profile['geometry']['max_growth_ratio']:
        risks.append('GROWTH_EXPLORATION_LIMIT')
    conf = scene.optional.get('confidence')
    confidence = {'available': 'UNAVAILABLE', 'mean': None, 'denominator': len(ids)} if conf is None else {
        'available': 'AVAILABLE', 'mean': float(conf.ravel()[ids].mean()), 'denominator': len(ids), 'calibration': 'upstream scale'}
    if conf is None:
        risks.append('OBSERVATION_CONFIDENCE_UNAVAILABLE')
    # Neither point count nor proxy coverage appears in the ranking.
    rank = (int(bool(contradictions)), len(risks), int(rate is None), -rate if rate is not None else 0.0,
            int(independence['available'] == 'UNAVAILABLE'), -int(bool(independence.get('count'))),
            growth, len(bridge_edges), len(fids), fids)
    geometry = shape(pts)
    return {'fragment_ids': list(fids), 'point_count': len(ids), 'rank_tuple': rank,
            'risk_flags': sorted(set(risks)), 'validated_contradictions': contradictions,
            'aabb_m': [low.tolist(), high.tolist()], 'shape': geometry,
            'diameter_upper_bound_m': diagonal, 'diameter_method': 'AABB diagonal upper bound, not exact pairwise diameter',
            'growth_ratio': growth, 'growth_denominator_m': reference,
            'known_relation_support': {'numerator': supported_pairs, 'denominator': known_pairs, 'ratio': rate,
                                       'available': 'AVAILABLE' if known_pairs else 'UNAVAILABLE',
                                       'unit': 'distinct fragment pair with calibrated object-part evidence'},
            'independent_evidence': independence, 'hold_relation_count': sum(e['state'] == 'HOLD' for e in evidence),
            'unverified_bridge_count': len(weak_bridges), 'bridge_edges': bridge_edges,
            'third_fragment_ids': third, 'observation_confidence': confidence,
            'original_graph_components': components(fids, original_edges) if scene.relation_path else None,
            'original_graph_available': bool(scene.relation_path), 'exploration_graph_components': cc,
            'candidate_state': 'DIAGNOSTIC_HYPOTHESIS', 'geometry_state': geometry['state'],
            'identity_status': 'UNKNOWN', 'update_status': 'HELD'}


def stable_id(scene, profile, fids):
    return 'H-' + digest({'schema': 'ylm051.hypothesis.v1', 'input': scene.fingerprint,
                           'profile': profile, 'namespace': scene.namespace, 'fragments': sorted(fids)})[:32]


def search_scene(scene, graph, profile, output, budget, frame_status):
    limits = profile['budgets']; archive = {}; singleton = []; visited = {}; traces = 0
    stats = {'time': scene.time, 'seed_records': 0, 'selected_seeds': 0, 'unselected_seeds': 0,
             'unexpanded_frontier_count': 0, 'depth_limit_frontier_count': 0, 'neighbor_cap_frontier_count': 0,
             'beam_cap_frontier_count': 0,
             'archive_excluded': 0, 'max_reached_fragments': 1 if scene.fragments else 0,
             'configured_reachable_fragments': min(limits['max_fragments'], 1 + limits['max_depth']),
             'stop_reasons': [], 'original_graph': graph.status['original_graph'],
             'graph_exploration_state': graph.status['exploration_state'],
             'singleton_count': len(scene.fragments)}

    def trace(event):
        nonlocal traces
        event = dict(event, time=scene.time, event_index=traces)
        output.event('search_trace.jsonl', event); traces += 1

    def prepare(candidate, path, seed, parent=None):
        candidate.update(candidate_id=stable_id(scene, profile, candidate['fragment_ids']),
                         namespace=scene.namespace, frame_status=frame_status,
                         seed_fragment_id=seed, addition_order=path, parent_candidate_id=parent,
                         source_point_ids=f'hypothesis_clouds/{scene.time}/' + stable_id(scene, profile, candidate['fragment_ids']) + '.npy',
                         point_namespace=dict(scene.namespace, format='C_order_flat_pixel_index'),
                         is_singleton=len(candidate['fragment_ids']) == 1)
        return candidate

    # Singletons have a separate uncapped inventory, including every 1–2 point fragment.
    for fid in sorted(scene.fragments):
        c = prepare(audit_candidate(scene, graph, [fid], profile, budget), [fid], fid)
        c['exploration_state'] = 'SINGLETON_PRESERVED'
        singleton.append(c); visited[(fid,)] = c
        output.npy(c['source_point_ids'], scene.fragments[fid].ids)
        output.event('singletons.jsonl', c)
        output.event('hypotheses.jsonl', c)
    if profile['variant'] == 'B0':
        stats.update(combined_count=0, candidate_ids=[c['candidate_id'] for c in singleton], exploration_state='B0_SINGLETON_BASELINE')
        return singleton, stats
    seed_jobs = []
    for cell, region in sorted(graph.regions.items()):
        if not region['core']:
            continue
        chosen, excluded = pick_seeds(scene, region['core'], limits['seeds_per_region'], profile['geometry']['normalization_scale_m'])
        stats['seed_records'] += len(chosen) + len(excluded)
        stats['selected_seeds'] += len(chosen); stats['unselected_seeds'] += len(excluded)
        output.event('seeds.jsonl', {'time': scene.time, 'cell': list(cell), 'selected': chosen, 'not_selected': excluded,
                                   'selection_rule': 'point-count strata 1-2/3-49/50-499/500+, round robin, farthest xyz+normalized image, ID tie-break',
                                   'not_selected_reason': 'SEED_REGION_CAP', 'small_only_region': all(len(scene.fragments[f].ids) < 50 for f in region['core'])})
        seed_jobs.extend((cell, seed, region['halo']) for seed in chosen)
    stopped = False
    for job_index, (cell, seed, local_fids) in enumerate(seed_jobs):
        beam = [visited[(seed,)]]
        try:
            for depth in range(1, limits['max_depth'] + 1):
                expansions = {}
                for parent in beam:
                    fids = tuple(parent['fragment_ids'])
                    available = (set().union(*(graph.adjacency[f] for f in fids)) & local_fids) - set(fids)
                    def neighbor_priority(fid):
                        links = [graph.pairs[tuple(sorted((f, fid)))] for f in fids if tuple(sorted((f, fid))) in graph.pairs]
                        return (min(p['geometry']['minimum_distance_m'] for p in links), fid)
                    neighbors = sorted(available, key=neighbor_priority)
                    rejected_by_cap = neighbors[limits['expansions_per_state']:]
                    stats['neighbor_cap_frontier_count'] += len(rejected_by_cap)
                    stats['unexpanded_frontier_count'] += len(rejected_by_cap)
                    if rejected_by_cap:
                        trace({'event': 'NEIGHBOR_CAP', 'parent': parent['candidate_id'], 'not_expanded_fragment_ids': rejected_by_cap,
                               'selection_rule': 'minimum measured gap then fragment ID; exploration only'})
                    for added in neighbors[:limits['expansions_per_state']]:
                        new_ids = tuple(sorted((*fids, added)))
                        links = [graph.pairs[tuple(sorted((f, added)))] for f in fids if tuple(sorted((f, added))) in graph.pairs]
                        gap = min(p['geometry']['minimum_distance_m'] for p in links)
                        if gap > profile['geometry']['max_added_gap_m']:
                            trace({'event': 'SEARCH_GATE_EXCLUDED', 'reason': 'MAX_ADDED_GAP', 'parent': parent['candidate_id'],
                                   'added_fragment': added, 'minimum_gap_m': gap, 'semantic_identity': 'UNKNOWN'})
                            continue
                        if new_ids in visited:
                            candidate = visited[new_ids]
                        else:
                            budget.take('expanded_states')
                            candidate = prepare(audit_candidate(scene, graph, new_ids, profile, budget),
                                                parent['addition_order'] + [added], seed, parent['candidate_id'])
                            candidate['maximum_addition_gap_m'] = max(parent.get('maximum_addition_gap_m', 0), gap)
                            candidate['exploration_state'] = 'EXPLORED_HOLD_HYPOTHESIS'
                            if candidate['validated_contradictions']:
                                trace({'event': 'VALIDATED_CONTRADICTION', 'candidate': candidate, 'scope': 'same_object_for_endpoints'})
                                continue
                            if any(r in candidate['risk_flags'] for r in ('DIAMETER_EXPLORATION_LIMIT', 'GROWTH_EXPLORATION_LIMIT')):
                                trace({'event': 'SEARCH_GATE_EXCLUDED', 'reason': 'WHOLE_CANDIDATE_GEOMETRY_LIMIT', 'candidate': candidate,
                                       'semantic_identity': 'UNKNOWN'})
                                continue
                            visited[new_ids] = candidate
                            archive[candidate['candidate_id']] = candidate
                            stats['max_reached_fragments'] = max(stats['max_reached_fragments'], len(new_ids))
                            trace({'event': 'STOP_HYPOTHESIS_ARCHIVED', 'depth': depth, 'cell': list(cell), 'candidate': candidate,
                                   'addition_edge_evidence': [p['fragment_ids'] for p in links]})
                        expansions[candidate['candidate_id']] = candidate
                next_beam = diverse(list(expansions.values()), limits['beam_per_seed'])
                kept = {c['candidate_id'] for c in next_beam}
                removed = [c['candidate_id'] for c in sorted(expansions.values(), key=lambda c: c['rank_tuple']) if c['candidate_id'] not in kept]
                stats['unexpanded_frontier_count'] += len(removed)
                stats['beam_cap_frontier_count'] += len(removed)
                trace({'event': 'BEAM_SELECTION', 'seed': seed, 'depth': depth, 'kept': sorted(kept), 'not_expanded': removed,
                       'reason': 'BEAM_CAP' if removed else 'ALL_AVAILABLE', 'singleton_competes_with_extensions': False})
                beam = next_beam
                if not beam:
                    break
                if depth == limits['max_depth']:
                    frontier = sum(len((set().union(*(graph.adjacency[f] for f in c['fragment_ids'])) & local_fids) - set(c['fragment_ids'])) for c in beam)
                    stats['depth_limit_frontier_count'] += frontier; stats['unexpanded_frontier_count'] += frontier
                    if frontier:
                        trace({'event': 'DEPTH_LIMIT', 'seed': seed, 'frontier_extensions_not_expanded': frontier})
        except BudgetStop as exc:
            stats['stop_reasons'].append(exc.reason)
            stats['unexpanded_frontier_count'] += len(beam)
            stats['unprocessed_seed_jobs'] = len(seed_jobs) - job_index - 1
            stats['frontier_count_interpretation'] = 'known pending states plus recorded excluded extensions; unenumerated successors UNKNOWN'
            stopped = True; break
    combined = diverse(list(archive.values()), limits['combined_per_time'])
    selected_ids = {c['candidate_id'] for c in combined}
    stats['archive_excluded'] = len(archive) - len(combined)
    # A budget exhaustion can still persist the bounded final inventory using remaining byte allowance.
    # Time/RSS expiry cannot be bypassed: caller retains already-written singleton/trace and marks partial.
    for c in combined:
        ids = np.unique(np.concatenate([scene.fragments[f].ids for f in c['fragment_ids']]))
        output.npy(c['source_point_ids'], ids)
        c['combined_rank'] = len([x for x in combined if x['rank_tuple'] < c['rank_tuple']]) + 1
        if stopped or stats['unselected_seeds'] or stats['unexpanded_frontier_count'] or stats['archive_excluded'] or graph.status['exploration_state'] == 'BUDGET_TRUNCATED':
            c['exploration_state'] = 'BUDGET_TRUNCATED'
        output.event('hypotheses.jsonl', c)
    for cid in sorted(set(archive) - selected_ids):
        output.event('archive_exclusions.jsonl', {'time': scene.time, 'candidate_id': cid, 'reason': 'FINAL_COMBINED_CAP',
                                                 'rank_tuple': archive[cid]['rank_tuple'], 'semantic_identity': 'UNKNOWN'})
    for name, reason in [('unselected_seeds', 'SEED_REGION_CAP'), ('neighbor_cap_frontier_count', 'NEIGHBOR_CAP'),
                         ('beam_cap_frontier_count', 'BEAM_CAP'), ('depth_limit_frontier_count', 'MAX_DEPTH'), ('archive_excluded', 'FINAL_COMBINED_CAP')]:
        if stats[name]: stats['stop_reasons'].append(reason)
    if graph.status['exploration_state'] == 'BUDGET_TRUNCATED': stats['stop_reasons'].append('GRAPH_PAIR_BUDGET')
    stats['stop_reasons'] = sorted(set(stats['stop_reasons']))
    stats['frontier_count_unit'] = 'logged extension/state occurrences; shared sets across seeds may repeat'
    stats.update(combined_count=len(combined), archived_stop_hypotheses=len(archive),
                 exploration_state='BUDGET_TRUNCATED' if stopped or stats['unselected_seeds'] or stats['unexpanded_frontier_count'] or stats['archive_excluded'] or graph.status['exploration_state'] == 'BUDGET_TRUNCATED' else 'EXHAUSTED_CONFIGURED_SEARCH',
                 trace_events=traces)
    return singleton + combined, stats
