"""YLM-X001 deterministic multi-hypothesis candidate formation, Phase 1–4."""
__version__ = '0.5.1'
