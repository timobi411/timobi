"""Read-only adapter for the inspected v0.5 / bridge-v02 saved v0.4 contract."""
from dataclasses import dataclass
from pathlib import Path
import zipfile
import numpy as np
from .io import read, sha, digest


def feature(value=None, denominator=None, unit=None, method=None, available=True):
    return {'available': 'AVAILABLE' if available else 'UNAVAILABLE', 'value': value if available else None,
            'denominator': denominator, 'unit': unit, 'method': method}


def shape(points):
    if not len(points):
        return {'state': 'EMPTY', 'obb': None}
    centered = points - points.mean(0)
    rank = int(np.linalg.matrix_rank(centered, tol=max(1e-10, float(np.linalg.norm(centered)) * 1e-8)))
    if len(points) < 4 or rank < 3:
        return {'state': ('POINT', 'LINEAR', 'PLANAR')[min(rank, 2)], 'obb': None, 'rank': rank,
                'reason': 'underdetermined_3d_obb; AABB and exploration remain available'}
    values, axes = np.linalg.eigh(centered.T @ centered / max(len(points) - 1, 1))
    axes = axes[:, ::-1]
    if np.linalg.det(axes) < 0:
        axes[:, -1] *= -1
    local = points @ axes
    low, high = local.min(0), local.max(0)
    return {'state': 'FULL_3D', 'rank': rank, 'eigenvalues_m2': values[::-1].tolist(),
            'obb': {'method': 'deterministic_PCA; repeated_eigenvalues_may_have_unstable_axes',
                    'center': (axes @ ((low + high) / 2)).tolist(), 'rotation': axes.tolist(), 'extent': (high - low).tolist()}}


@dataclass
class Fragment:
    fid: int
    ids: np.ndarray
    boundary_ids: np.ndarray
    low: np.ndarray
    high: np.ndarray
    centroid: np.ndarray
    record: dict


@dataclass
class Scene:
    time: str
    namespace: dict
    xyz: np.ndarray
    valid: np.ndarray
    labels: np.ndarray
    fragments: dict
    optional: dict
    relation_path: str | None
    fingerprint: str

    def points(self, fids, budget=None):
        ids = np.concatenate([self.fragments[f].ids for f in sorted(fids)]) if fids else np.array([], dtype=np.int64)
        ids = np.unique(ids)
        if budget:
            budget.take('point_copies', len(ids))
        return ids, self.xyz.reshape(-1, 3)[ids]


def check_npz_size(path, budget):
    with zipfile.ZipFile(path) as archive:
        size = sum(i.file_size for i in archive.infolist())
    if size > budget.limits['max_input_bytes']:
        raise ValueError('input expanded size exceeds max_input_bytes')
    budget.check()


def boundaries(labels):
    boundary = np.zeros(labels.shape, bool)
    for axis in (0, 1):
        a, b = [slice(None)] * 2, [slice(None)] * 2
        a[axis] = slice(1, None); b[axis] = slice(None, -1)
        different = labels[tuple(a)] != labels[tuple(b)]
        boundary[tuple(a)] |= different; boundary[tuple(b)] |= different
    if labels.size:
        boundary[[0, -1], :] = True; boundary[:, [0, -1]] = True
    return boundary & (labels >= 0)


def snapshot_inputs(config, output, budget):
    import copy
    snapshot = copy.deepcopy(config)
    records = []; total_input_bytes = 0
    for time, spec in sorted(snapshot['times'].items()):
        for key in ('pixels', 'clusters', 'canonical_mask', 'feature_arrays', 'relations', 'source_code'):
            if not spec.get(key):
                continue
            paths = spec[key] if key == 'source_code' else [spec[key]['path'] if isinstance(spec[key], dict) else spec[key]]
            for index, src in enumerate(paths):
                suffix = Path(src).suffix
                rel = f'inputs/{time}/{key}_{index:04d}{suffix}'
                total_input_bytes += Path(src).stat().st_size
                if total_input_bytes > budget.limits['max_input_bytes']:
                    raise ValueError('total input snapshot bytes exceed max_input_bytes')
                hashed = output.copy(src, rel)
                records.append({'time': time, 'role': key, 'index': index, 'original_path': str(Path(src).resolve()),
                                'snapshot': rel, 'sha256': hashed, 'bytes': Path(src).stat().st_size})
                if key == 'source_code':
                    spec[key][index] = rel
                elif isinstance(spec[key], dict):
                    spec[key]['path'] = rel
                else:
                    spec[key] = rel
    output.json('source_hashes.json', records)
    output.json('input_contract.json', snapshot)
    return snapshot, records


def build_scene(config, time, root, records, output, budget):
    spec = config['times'][time]
    check_npz_size(root / spec['pixels'], budget)
    with np.load(root / spec['pixels'], allow_pickle=False) as data:
        xyz, valid, labels = (data[k].copy() for k in ('xyz', 'valid', 'labels'))
    if xyz.ndim != 3 or xyz.shape[2] != 3 or valid.shape != xyz.shape[:2] or labels.shape != valid.shape:
        raise ValueError('organized xyz/valid/labels shape mismatch')
    if valid.dtype.kind != 'b' or labels.dtype.kind not in 'iu' or xyz.dtype.kind not in 'fiu':
        raise ValueError('invalid organized dtypes')
    if np.any((labels >= 0) & ~valid) or not np.isfinite(xyz[valid]).all():
        raise ValueError('invalid/nonfinite measured point')
    if spec.get('canonical_mask'):
        entry = spec['canonical_mask']; check_npz_size(root / entry['path'], budget)
        with np.load(root / entry['path'], allow_pickle=False) as z:
            mask = z[entry['key']]
        if mask.shape != valid.shape or mask.dtype.kind != 'b':
            raise ValueError('canonical mask shape/dtype invalid')
        if np.any(mask & (labels >= 0)):
            raise ValueError('labeled fragment contains canonical structure-removal pixels')
    metadata = read(root / spec['clusters'])['clusters']
    if any(type(c['id']) is not int or c['id'] < 0 for c in metadata):
        raise ValueError('nonnegative integer fragment IDs required')
    by_id = {c['id']: c for c in metadata}
    if len(by_id) != len(metadata):
        raise ValueError('duplicate fragment ID')
    ids, counts = np.unique(labels[labels >= 0], return_counts=True)
    if set(ids.tolist()) != set(by_id):
        raise ValueError('metadata and labels ID sets differ')
    for fid, count in zip(ids, counts):
        c = by_id[int(fid)]
        if c['point_count'] != int(count) or c.get('MODEL_INFERRED', 0) != 0:
            raise ValueError('point count mismatch or inferred points present')
    optional = {}
    roles = {'source_kind', 'sample_id', 'measurement_time', 'confidence', 'range_m', 'mad_m', 'missing_classification'}
    if spec.get('feature_arrays'):
        entry = spec['feature_arrays']
        if set(entry['keys']) - roles:
            raise ValueError('unknown optional feature role')
        check_npz_size(root / entry['path'], budget)
        with np.load(root / entry['path'], allow_pickle=False) as z:
            for role, key in sorted(entry['keys'].items()):
                array = z[key].copy()
                if array.shape != valid.shape or array.dtype.kind == 'O':
                    raise ValueError('optional features must be non-object HxW arrays')
                optional[role] = array
    namespace = {k: config[k] for k in ('run_id', 'case', 'window', 'boundary')}
    namespace['time'] = time
    source_fingerprint = digest({'context': namespace, 'schema': config['schema'], 'units': config['units'],
                                 'sources': sorted((r['role'], r['index'], r['sha256']) for r in records if r['time'] == time),
                                 'optional_mapping': spec.get('feature_arrays', {}).get('keys'),
                                 'canonical_mask_key': spec.get('canonical_mask', {}).get('key')})
    boundary = boundaries(labels).ravel(); flat = xyz.reshape(-1, 3); width = labels.shape[1]
    fragments = {}
    all_labeled = np.flatnonzero(labels.ravel() >= 0)
    # Group once; avoid scanning the whole image separately for every tiny fragment.
    order = np.argsort(labels.ravel()[all_labeled], kind='stable')
    grouped = all_labeled[order]; start = 0
    for fid, count in zip(ids.tolist(), counts.tolist()):
        budget.check()
        pixels = np.sort(grouped[start:start + count]); start += count
        budget.take('point_copies', count)
        pts = flat[pixels]; low, high = pts.min(0), pts.max(0)
        boundary_ids = pixels[boundary[pixels]]
        r, c = np.divmod(pixels, width)
        features = {
            'point_count': feature(count, count, 'representative_pixel', 'valid labeled measured representatives'),
            'centroid': feature(pts.mean(0).tolist(), count, 'm', 'arithmetic mean'),
            'aabb': feature([low.tolist(), high.tolist()], count, 'm', 'min/max over all fragment points'),
            'pca': feature(shape(pts), count, 'm', 'centered PCA; no noise'),
            'pixel_bbox': feature([int(r.min()), int(c.min()), int(r.max()), int(c.max())], count, 'pixel', 'row/column bounds'),
            'outer_boundary_count': feature(len(boundary_ids), count, 'pixel', '4-neighbor label transition or image border'),
            'current_temporal': feature(available=False, denominator=count, unit='representative_pixel', method='explicit source_kind mapping required'),
            'unique_measurements': feature(available=False, denominator=count, unit='source_measurement', method='unique (measurement_time,sample_id); not inferred from history length'),
            'measurement_provenance': feature(available=False, denominator=count, method='snapshot feature_arrays with role-to-key mapping'),
            'saved_edge_geometry': feature(available=False, method='pair_evidence adapter; absent is UNAVAILABLE'),
            'saved_relations_reference': feature({'snapshot': spec['relations'], 'endpoint_fragment_id': fid} if spec.get('relations') else None,
                                                method='exact saved relation records; geometry/reasons retained in original_payload',
                                                available=bool(spec.get('relations'))),
            'local_models': feature(available=False, method='upstream local-model schema not received'),
        }
        if 'source_kind' in optional:
            kind = optional['source_kind'].ravel()[pixels].astype(str)
            counts_kind = {str(k): int(n) for k, n in zip(*np.unique(kind, return_counts=True))}
            features['current_temporal'] = feature(counts_kind, count, 'representative_pixel', 'explicit source_kind values; not independent support counts')
        if 'sample_id' in optional and 'measurement_time' in optional:
            values = {(str(optional['sample_id'].ravel()[p]), str(optional['measurement_time'].ravel()[p])) for p in pixels}
            features['unique_measurements'] = feature(len(values), count, 'source_measurement', 'unique (time,sample), repeated history deduplicated')
            features['measurement_provenance'] = feature({'snapshot': spec['feature_arrays']['path'], 'keys': spec['feature_arrays']['keys'],
                                                         'pixel_ids_reference': f'hypothesis_clouds/{time}/fragment_{fid}.npy'}, count, method='source arrays retained verbatim')
        for name, unit in [('confidence', 'upstream_value'), ('range_m', 'm'), ('mad_m', 'm')]:
            values = optional.get(name)
            if values is None:
                features[name] = feature(available=False, denominator=count, unit=unit, method='explicit source array')
            else:
                a = np.asarray(values.ravel()[pixels], dtype=float)
                if not np.isfinite(a).all():
                    raise ValueError('nonfinite optional measured feature: ' + name)
                features[name] = feature({'min': float(a.min()), 'mean': float(a.mean()), 'max': float(a.max())}, count, unit, 'all representatives; no calibration implied')
        if 'missing_classification' in optional:
            features['missing_classification'] = feature({'snapshot': spec['feature_arrays']['path'], 'key': spec['feature_arrays']['keys']['missing_classification']},
                                                        int(valid.size), 'pixel', 'preserved upstream classification; no invented gap interpretation')
        else:
            features['missing_classification'] = feature(available=False, denominator=int(valid.size), unit='pixel')
        record = {'fragment_key': dict(namespace, fragment_id=fid), 'fragment_id': fid,
                  'source_point_ids': f'hypothesis_clouds/{time}/fragment_{fid}.npy',
                  'boundary_point_ids': f'features/{time}/boundary_{fid}.npy', 'features': features,
                  'identity_status': 'UNKNOWN', 'canonical_mask_available': bool(spec.get('canonical_mask'))}
        output.npy(record['source_point_ids'], pixels)
        output.npy(record['boundary_point_ids'], boundary_ids)
        output.event('fragment_features.jsonl', record)
        fragments[fid] = Fragment(fid, pixels, boundary_ids, low, high, pts.mean(0), record)
    for array in (xyz, valid, labels, *optional.values()):
        array.flags.writeable = False
    return Scene(time, namespace, xyz, valid, labels, fragments, optional,
                 str(root / spec['relations']) if spec.get('relations') else None, source_fingerprint)
