import argparse
import json
import os
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description='YLM v0.5.1 Phase 1-4 multi-hypothesis formation')
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('prepare-config'); p.add_argument('--out', required=True); p.add_argument('--existing')
    p = sub.add_parser('generate'); p.add_argument('--input', required=True); p.add_argument('--profile', required=True); p.add_argument('--out', required=True)
    p = sub.add_parser('replay'); p.add_argument('--run', required=True); p.add_argument('--out', required=True)
    p = sub.add_parser('verify'); p.add_argument('--run', required=True)
    p = sub.add_parser('view'); p.add_argument('--run', required=True)
    p = sub.add_parser('evaluate'); p.add_argument('--run', required=True); p.add_argument('--evaluation', required=True); p.add_argument('--out', required=True)
    args = parser.parse_args()
    for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
        os.environ[key] = '1'
    try:
        if args.command == 'prepare-config':
            from .config import template, inspect_profile
            from .io import read, Output
            dest = Path(args.out)
            if dest.exists():
                raise FileExistsError(dest)
            profile = read(args.existing) if args.existing else template()
            Output(dest.parent).json(dest.name, profile)
            print(json.dumps(inspect_profile(profile), ensure_ascii=False, indent=2)); return 0
        if args.command in ('generate', 'replay'):
            profile_path = args.profile if args.command == 'generate' else str(Path(args.run) / 'resolved_config.json')
            # Validate and apply an optional virtual-address ceiling before numerical imports.
            profile = json.loads(Path(profile_path).read_text())
            limit = profile.get('budgets', {}).get('virtual_address_limit_mib')
            if limit is not None:
                if not isinstance(limit, (int, float)) or limit <= 0:
                    raise ValueError('virtual_address_limit_mib must be positive or null')
                import resource
                _, hard = resource.getrlimit(resource.RLIMIT_AS)
                target = int(limit * 1024 ** 2)
                if hard != resource.RLIM_INFINITY: target = min(target, hard)
                resource.setrlimit(resource.RLIMIT_AS, (target, hard))
            from .pipeline import generate
            result = generate(args.input if args.command == 'generate' else None, profile_path, args.out,
                              replay=args.run if args.command == 'replay' else None)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0 if result['processing_complete'] and result['integrity_passed'] else 2
        if args.command in ('verify', 'view'):
            from .pipeline import verify
            result = verify(args.run)
            if args.command == 'view':
                result['viewer_file'] = str((Path(args.run) / 'index.html').resolve())
                result['instruction'] = 'Open index.html in a local browser; all viewer links are relative.'
            print(json.dumps(result, ensure_ascii=False, indent=2)); return 0
        if args.command == 'evaluate':
            from .evaluate import evaluate
            result = evaluate(args.run, args.evaluation, args.out)
            print(json.dumps({'evaluation': str(Path(args.out) / 'evaluation.json'),
                              'generation_outputs_unchanged': result['generation_outputs_unchanged'],
                              'identity_evaluation': result['identity_evaluation']}, ensure_ascii=False, indent=2)); return 0
    except Exception as exc:
        print(json.dumps({'status': 'FAILED', 'type': type(exc).__name__, 'message': str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
