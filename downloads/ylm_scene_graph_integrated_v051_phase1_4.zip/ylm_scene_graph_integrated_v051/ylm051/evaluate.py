"""Post-hoc-only evaluation. This module is never imported by candidate generation."""
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
from .io import read, rows, sha, Output, safe_ref
from .pipeline import verify


def rigid(t):
    t = np.asarray(t, float)
    if t.shape != (4, 4) or not np.isfinite(t).all() or not np.allclose(t[3], [0, 0, 0, 1]):
        raise ValueError('evaluation coordinate transform must be finite rigid 4x4')
    r = t[:3, :3]
    if not np.allclose(r.T @ r, np.eye(3), atol=1e-7) or not np.isclose(np.linalg.det(r), 1):
        raise ValueError('evaluation transform is not proper rigid')
    return t


def evaluate(run, evaluation_path, destination):
    run = Path(run).resolve(); evaluation_path = Path(evaluation_path).resolve()
    destination = Path(destination).resolve()
    if destination.exists() or destination.is_relative_to(run):
        raise ValueError('evaluation needs a separate new directory outside the generation run')
    verify(run)
    before = sha(run / 'artifact_hashes.json')
    config = read(evaluation_path)
    if config.get('schema') != 'ylm051.evaluation.v1' or set(config) - {'schema', 'dataset_role', 'selection_disclosure', 'times', 'gt_metrics'}:
        raise ValueError('invalid evaluation input schema')
    if not config.get('selection_disclosure'):
        raise ValueError('record whether development targets were selected using proxy/GT')
    destination.mkdir(parents=True); out = Output(destination)
    input_config = read(run / 'input_contract.json'); candidates = list(rows(run / 'hypotheses.jsonl'))
    report = {'generation_manifest_sha256': sha(run / 'run_manifest.json'), 'dataset_role': config['dataset_role'],
              'selection_disclosure': config['selection_disclosure'], 'times': {}, 'sources': [],
              'identity_evaluation': 'UNKNOWN', 'matching_accuracy': 'NOT_EVALUATED_PHASE5_6_NOT_RUN',
              'update_accuracy': 'NOT_EVALUATED_NO_GRAPH_UPDATES',
              'generation_resources': read(run / 'run_manifest.json')['resources']}
    if 'SYNTHETIC' in input_config['dataset_kind']:
        report['dataset_interpretation'] = 'synthetic behavior testing; not real-data accuracy'
    elif input_config['case'] in ('exp01', 'exp02'):
        report['dataset_interpretation'] = 'development data'
    elif input_config['case'] == 'exp08':
        report['dataset_interpretation'] = 'additional data previously referenced in development; not strict unseen test'
    else:
        report['dataset_interpretation'] = 'independence of capture/GT must be established separately'
    def resolve(v):
        p = Path(v).expanduser()
        return p.resolve() if p.is_absolute() else (evaluation_path.parent / p).resolve()
    overlays = {}
    for time, spec in sorted(config['times'].items()):
        if time not in input_config['times']:
            raise ValueError('evaluation time absent from generation')
        with np.load(safe_ref(run, input_config['times'][time]['pixels']), allow_pickle=False) as z:
            xyz, valid, labels = z['xyz'], z['valid'], z['labels']
        cs = [c for c in candidates if c['namespace']['time'] == time]
        cs.sort(key=lambda c: c['rank_tuple'])
        gt = proxy = None; result = {'candidate_count': len(cs), 'proxy': {'status': 'UNAVAILABLE'}, 'gt': {'status': 'UNAVAILABLE'}}
        if spec.get('proxy'):
            p = spec['proxy']; path = resolve(p['points']); report['sources'].append({'role': 'proxy_only', 'path': str(path), 'sha256': sha(path)})
            if p.get('units') != 'm' or not p.get('coordinate_evidence'):
                raise ValueError('proxy units and coordinate evidence are required')
            if path.suffix.lower() == '.pcd':
                import open3d as o3d
                old = np.asarray(o3d.io.read_point_cloud(str(path)).points)
            else:
                old = np.load(path, allow_pickle=False)
            if old.ndim != 2 or old.shape[1] != 3 or not np.isfinite(old).all():
                raise ValueError('proxy points must be finite Nx3')
            t = rigid(p['old_to_observation']); old = old @ t[:3, :3].T + t[:3, 3]
            radius = float(p['radius_m'])
            if not np.isfinite(radius) or radius <= 0:
                raise ValueError('positive evaluation radius required')
            observed = np.flatnonzero(valid.ravel())
            if len(observed) and len(old):
                distances, indices = cKDTree(xyz.reshape(-1, 3)[observed]).query(old)
                unique = np.unique(observed[indices[distances <= radius]])
                close_count = int((distances <= radius).sum())
            else:
                unique = np.array([], int); close_count = 0
            proxy = unique[labels.ravel()[unique] >= 0]
            result['proxy'] = {'status': 'POST_HOC_ONLY', 'old_points': len(old), 'within_radius_old_points': close_count,
                               'unique_observed_pixels': len(unique), 'unique_surviving_fragment_pixels': len(proxy),
                               'radius_m': radius, 'not_a_ground_truth_object': True,
                               'coordinate_evidence': p['coordinate_evidence']}
            overlays[time] = old
            out.npy(f'{time}_proxy_pixel_ids.npy', proxy)
        if spec.get('gt_labels'):
            path = resolve(spec['gt_labels']); report['sources'].append({'role': 'GT_only', 'path': str(path), 'sha256': sha(path)})
            gt = np.load(path, allow_pickle=False)
            if gt.shape != labels.shape or gt.dtype.kind not in 'iu' or np.any(gt < -1):
                raise ValueError('GT must be integer HxW: -1 unannotated, 0 background, >0 object')
            metric = config.get('gt_metrics', {})
            for key in ('coverage_threshold', 'purity_threshold', 'false_merge_min_fraction', 'recall_k'):
                if key not in metric:
                    raise ValueError('explicit GT metric thresholds and K required')
            for key in ('coverage_threshold', 'purity_threshold', 'false_merge_min_fraction'):
                if not 0 < metric[key] <= 1:
                    raise ValueError('GT metric fraction outside (0,1]')
            if type(metric['recall_k']) is not int or metric['recall_k'] < 1:
                raise ValueError('positive recall_k required')
            object_ids, totals = np.unique(gt[valid & (gt > 0)], return_counts=True)
            object_counts = dict(zip(object_ids.tolist(), totals.tolist()))
            result['gt'] = {'status': 'ANNOTATED_SYNTHETIC' if config['dataset_role'] == 'synthetic' else 'ANNOTATED_USER_DATA',
                            'object_totals': object_counts, 'denominator': 'all valid annotated object pixels, including pixels excluded from fragments',
                            'unannotated_valid_points': int(np.count_nonzero(valid & (gt < 0))),
                            'annotation': '-1 unannotated; 0 background; positive object ID', 'thresholds': metric,
                            'ranking_pool': 'all saved singletons and combined hypotheses by recorded rank_tuple'}
        candidate_results = []; recalled = set(); false_merge = 0; annotated_candidates = 0
        for rank, c in enumerate(cs, 1):
            ids = np.load(safe_ref(run, c['source_point_ids']), allow_pickle=False)
            record = {'candidate_id': c['candidate_id'], 'rank': rank, 'point_count': len(ids)}
            if proxy is not None:
                recovered = int(len(np.intersect1d(ids, proxy, assume_unique=True)))
                record['proxy'] = {'recovered_pixels': recovered, 'denominator_pixels': len(proxy),
                                   'recovery_ratio': recovered / len(proxy) if len(proxy) else None,
                                   'outside_proxy_points': len(ids) - recovered,
                                   'outside_proxy_is_not_false_merge': True}
            if gt is not None:
                values = gt.ravel()[ids]; annotated = int(np.count_nonzero(values >= 0))
                gt_counts = {oid: int(np.count_nonzero(values == oid)) for oid in object_counts}
                coverage = {str(oid): n / object_counts[oid] for oid, n in gt_counts.items()}
                purity = max(gt_counts.values(), default=0) / annotated if annotated else None
                components = [oid for oid, n in gt_counts.items() if annotated and n / annotated >= metric['false_merge_min_fraction']]
                merged = len(components) > 1
                if annotated:
                    annotated_candidates += 1; false_merge += int(merged)
                if rank <= metric['recall_k']:
                    for oid, n in gt_counts.items():
                        if annotated and n / object_counts[oid] >= metric['coverage_threshold'] and n / annotated >= metric['purity_threshold']:
                            recalled.add(oid)
                record['gt'] = {'object_coverage': coverage, 'candidate_purity': purity, 'annotated_points': annotated,
                                'unannotated_points': len(values) - annotated, 'false_merge': merged if annotated else None,
                                'objects_over_false_merge_fraction': components}
            candidate_results.append(record); out.event('candidate_evaluation.jsonl', dict(record, time=time))
        if gt is not None:
            result['gt']['recall_at_k'] = {'numerator_objects': len(recalled), 'denominator_objects': len(object_counts),
                                          'ratio': len(recalled) / len(object_counts) if object_counts else None}
            result['gt']['false_merge_rate'] = {'numerator_candidates': false_merge, 'denominator_annotated_candidates': annotated_candidates,
                                               'ratio': false_merge / annotated_candidates if annotated_candidates else None}
        result['candidates'] = candidate_results
        report['times'][time] = result
    if sha(run / 'artifact_hashes.json') != before:
        raise RuntimeError('generation output changed during evaluation')
    verify(run)
    report['generation_outputs_unchanged'] = True
    out.json('evaluation.json', report)
    import plotly.graph_objects as go
    fig = go.Figure()
    for time, old in overlays.items():
        shown = old[::max(1, int(np.ceil(len(old) / 12000)))]
        fig.add_trace(go.Scatter3d(x=shown[:, 0], y=shown[:, 1], z=shown[:, 2], mode='markers', name=time + ' POST-HOC PROXY ONLY', marker={'size': 2}))
    fig.update_layout(title='Post-hoc proxy layer only; not used by candidate generator', scene_aspectmode='data')
    fig.write_html(out.path('proxy_layer.html'), include_plotlyjs=True)
    out.text('index.html', '<!doctype html><meta charset="utf-8"><h1>事後評価（生成から独立）</h1><p>旧PCD外点はFalse Mergeではありません。GTがある場合だけ精度指標を計算。</p><a href="evaluation.json">評価結果</a> · <a href="candidate_evaluation.jsonl">候補別</a> · <a href="proxy_layer.html">代理点群の独立レイヤー</a>')
    return report
