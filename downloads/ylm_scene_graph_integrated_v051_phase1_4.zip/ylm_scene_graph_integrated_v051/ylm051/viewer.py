"""Offline viewer: relative JS, embedded display-only samples, no file:// fetch."""
import json
import math
from pathlib import Path
import numpy as np
from .io import read, rows


def build_viewer(run, output, max_points):
    from plotly.offline import get_plotlyjs
    config = read(run / 'input_contract.json')
    scenes = {}
    for time, spec in sorted(config['times'].items()):
        with np.load(run / spec['pixels'], allow_pickle=False) as z:
            xyz, labels, valid = z['xyz'], z['labels'], z['valid']
        ids = np.flatnonzero(valid.ravel() & (labels.ravel() >= 0))
        stride = max(1, math.ceil(len(ids) / max_points)); shown = ids[::stride]
        scenes[time] = {'xyz': xyz.reshape(-1, 3)[shown].tolist(), 'fragment_ids': labels.ravel()[shown].tolist(),
                        'pixel_ids': shown.tolist(), 'rows': (shown // labels.shape[1]).tolist(),
                        'columns': (shown % labels.shape[1]).tolist(), 'numeric_point_count': len(ids),
                        'display_count': len(shown), 'display_stride': stride}
    hypotheses = list(rows(run / 'hypotheses.jsonl'))
    evidence = list(rows(run / 'pair_evidence.jsonl'))
    graph_status = list(rows(run / 'graph_status.jsonl'))
    payload = json.dumps({'scenes': scenes, 'hypotheses': hypotheses, 'evidence': evidence, 'graphs': graph_status},
                         ensure_ascii=False, separators=(',', ':'), allow_nan=False).replace('<', '\\u003c')
    output.text('viewer/plotly.min.js', get_plotlyjs())
    template = '''<!doctype html><html lang="ja"><meta charset="utf-8"><title>YLM v0.5.1 hypotheses</title>
<style>body{font-family:system-ui;margin:20px;color:#192c41;background:#f4f7fa}header{background:#173753;color:white;padding:18px;border-radius:8px}main{display:grid;grid-template-columns:300px 1fr;gap:18px;margin-top:18px}section{background:white;padding:14px;border-radius:8px}label{display:block;margin:8px 0}select,input,button{padding:8px;max-width:100%;box-sizing:border-box}#list{width:100%;height:330px}pre{white-space:pre-wrap;font-size:12px;max-height:440px;overflow:auto}#plot{height:560px}.notice{padding:12px;background:#fff4cd}a{color:#086ea0}details{margin:12px 0}@media(max-width:850px){main{display:block}}</style>
<header><h1>YLM v0.5.1 — 複数仮説候補</h1><p>Phase 1–4 / identity UNKNOWN / update HELD</p></header>
<p class="notice">表示だけ間引き。数値・候補正本は全画素ID集合。旧PCD/GTは生成に使用していません。ICP初期値別重畳・ScenarioはNOT_RUN。</p>
<nav><a href="run_manifest.json">状態・資源</a> · <a href="search_summary.json">探索打切り</a> · <a href="search_trace.jsonl">追加順・探索ログ</a> · <a href="hypotheses.jsonl">候補一覧</a> · <a href="pair_evidence.jsonl">証拠</a> · <a href="evaluation.json">評価状態</a></nav>
<main><section><label>時刻 <select id="time"></select></label><label>候補ID / 断片ID検索<input id="query" placeholder="H-… または断片ID"></label><label>候補 <select id="list" size="16"></select></label>
<label>表示 <select id="view"><option value="3d">3D</option><option value="organized">organized画素</option><option value="xy">XY投影</option><option value="xz">XZ投影</option><option value="yz">YZ投影</option></select></label>
<label><input id="colors" type="checkbox" checked>元断片を色分け（候補外は灰色）</label><p id="counts"></p></section>
<section><div id="plot"></div><h2 id="title"></h2><p id="states"></p><details open><summary>seed・追加順・全体監査</summary><pre id="details"></pre></details><details><summary>各辺の根拠と棄却範囲</summary><pre id="evidence"></pre></details><details><summary>候補間重複</summary><pre id="overlap"></pre></details><details><summary>元グラフ欠落 / 探索打切り</summary><pre id="graph"></pre></details></section></main>
<script src="viewer/plotly.min.js"></script><script>const DATA=__PAYLOAD__;
const E=id=>document.getElementById(id); let selected=[];
for(const key of Object.keys(DATA.scenes)){const o=document.createElement('option');o.value=key;o.textContent=key;E('time').appendChild(o)}
function candidates(){const q=E('query').value.trim();const numeric=/^\\d+$/.test(q);selected=DATA.hypotheses.filter(c=>c.namespace.time===E('time').value&&(!q||(numeric?c.fragment_ids.some(f=>String(f)===q):c.candidate_id.includes(q))));const list=E('list');list.textContent='';selected.forEach((c,i)=>{const o=document.createElement('option');o.value=i;o.textContent=(c.is_singleton?'single ':'multi ')+c.fragment_ids.join(',')+' | '+c.candidate_id.slice(-9);list.appendChild(o)});if(selected.length)list.value='0';render()}
function render(){const scene=DATA.scenes[E('time').value];if(!scene)return;const c=selected[Number(E('list').value)];const ids=new Set(c?c.fragment_ids:[]);const selectedPoints=[],background=[];scene.fragment_ids.forEach((f,i)=>(ids.has(f)?selectedPoints:background).push(i));
const mode=E('view').value;const colors=E('colors').checked;const traces=[];for(const [name,indexes] of [['元観測（候補外）',background],['候補の実測代表点',selectedPoints]]){const fg=name.startsWith('候補');const marker={size:mode==='3d'?3:5,color:indexes.map(i=>fg?(colors?'hsl('+((scene.fragment_ids[i]*137.508)%360)+',75%,45%)':'#ff9900'):'#c1cad4')};const t={mode:'markers',name,marker,text:indexes.map(i=>'C'+scene.fragment_ids[i]+' pixel '+scene.pixel_ids[i])};
if(mode==='3d'){Object.assign(t,{type:'scatter3d',x:indexes.map(i=>scene.xyz[i][0]),y:indexes.map(i=>scene.xyz[i][1]),z:indexes.map(i=>scene.xyz[i][2])})}else{const axes=mode==='xy'?[0,1]:mode==='xz'?[0,2]:[1,2];Object.assign(t,{type:'scattergl',x:indexes.map(i=>mode==='organized'?scene.columns[i]:scene.xyz[i][axes[0]]),y:indexes.map(i=>mode==='organized'?scene.rows[i]:scene.xyz[i][axes[1]])})}traces.push(t)}
Plotly.react('plot',traces,{margin:{l:35,r:10,t:20,b:35},scene:{aspectmode:'data'},yaxis:{autorange:mode==='organized'?'reversed':true,scaleanchor:'x'},uirevision:E('time').value+mode});
E('counts').textContent='表示 '+scene.display_count+' / 数値対象 '+scene.numeric_point_count+'点。候補 '+selected.length+'件';E('title').textContent=c?c.candidate_id:'候補なし';E('states').textContent=c?[c.candidate_state,c.exploration_state,c.geometry_state,c.frame_status,c.identity_status,c.update_status].join(' / '):'';
E('details').textContent=JSON.stringify(c||{},null,2);E('evidence').textContent=JSON.stringify(DATA.evidence.filter(p=>p.time===E('time').value&&p.fragment_ids.every(f=>ids.has(f))),null,2);E('overlap').textContent=JSON.stringify(c?DATA.hypotheses.filter(o=>o.candidate_id!==c.candidate_id&&o.namespace.time===c.namespace.time&&o.fragment_ids.some(f=>ids.has(f))).map(o=>({candidate_id:o.candidate_id,shared_fragments:o.fragment_ids.filter(f=>ids.has(f))})):[],null,2);E('graph').textContent=JSON.stringify(DATA.graphs.filter(g=>g.time===E('time').value),null,2)}
E('query').addEventListener('input',candidates);E('time').addEventListener('change',candidates);for(const id of ['view','colors','list'])E(id).addEventListener('change',render);candidates();</script></html>'''
    output.text('index.html', template.replace('__PAYLOAD__', payload))
