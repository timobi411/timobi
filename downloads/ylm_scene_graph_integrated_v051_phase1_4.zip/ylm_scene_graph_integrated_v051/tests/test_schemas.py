import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from examples.make_fixture import make
from ylm051.io import read, rows
from ylm051.pipeline import generate


class SchemaTests(unittest.TestCase):
    def test_distributed_contracts_accept_generated_example_and_reject_gt_in_generator(self):
        schemas = {p.name.split('.')[0]: read(p) for p in (ROOT / 'schemas').glob('*.schema.json')}
        self.assertEqual(len(schemas), 6)
        for s in schemas.values(): Draft202012Validator.check_schema(s)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); fixture = make(root / 'fixture')
            for name, path in [('input', fixture / 'input.json'), ('profile', fixture / 'profiles/B3.json'),
                               ('evaluation', fixture / 'evaluation.json')]:
                Draft202012Validator(schemas[name]).validate(read(path))
            for e in rows(fixture / 't0/relations.jsonl'):
                Draft202012Validator(schemas['evidence']).validate(e)
            result = generate(fixture / 'input.json', fixture / 'profiles/B3.json', root / 'run')
            self.assertTrue(result['processing_complete'])
            for key, path in [('hypothesis', 'hypotheses.jsonl'), ('fragment_features', 'fragment_features.jsonl')]:
                validator = Draft202012Validator(schemas[key])
                for value in rows(root / 'run' / path): validator.validate(value)
            forbidden = read(fixture / 'input.json'); forbidden['gt_labels'] = 'gt.npy'
            self.assertFalse(Draft202012Validator(schemas['input']).is_valid(forbidden))


if __name__ == '__main__': unittest.main()
