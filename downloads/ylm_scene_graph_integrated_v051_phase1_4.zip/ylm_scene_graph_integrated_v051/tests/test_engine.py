import copy
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ylm051.io import Output, Budget, read, rows, sha, BudgetStop
from ylm051.config import template, validate_profile, load_input, inspect_profile
from ylm051.features import snapshot_inputs, build_scene
from ylm051.graph import normalize, independent_families, build_graph
from ylm051.search import diverse, search_scene
from ylm051.pipeline import generate, verify
from ylm051.evaluate import evaluate

spec = importlib.util.spec_from_file_location('fixtures', ROOT / 'examples/make_fixture.py')
fixture = importlib.util.module_from_spec(spec); spec.loader.exec_module(fixture)


def simple(root, fragments, relations=None, optional=False):
    root.mkdir(); out = Output(root)
    width = max([len(p) for p in fragments.values()] + [1]) + 1
    xyz = np.zeros((max(1, len(fragments)), width, 3), np.float32)
    valid = np.zeros(xyz.shape[:2], bool); labels = np.full(valid.shape, -1, np.int32)
    clusters = []
    for r, (fid, pts) in enumerate(sorted(fragments.items())):
        xyz[r, :len(pts)] = pts; valid[r, :len(pts)] = True; labels[r, :len(pts)] = fid
        clusters.append({'id': fid, 'point_count': len(pts), 'MODEL_INFERRED': 0})
    np.savez(root / 'pixels.npz', xyz=xyz, valid=valid, labels=labels)
    out.json('clusters.json', {'clusters': clusters})
    config = {'schema': 'ylm051.input.v1', 'run_id': 'synthetic', 'case': 'test', 'window': 'fixed11',
              'boundary': 'boundary_false', 'units': 'm', 'dataset_kind': 'SYNTHETIC',
              'development_selection': 'synthetic behavior test', 'frame_status': 'FRAME_UNVERIFIED',
              'times': {'t0': {'pixels': 'pixels.npz', 'clusters': 'clusters.json'}}}
    if relations is not None:
        out.text('relations.jsonl', '')
        for row in relations: out.event('relations.jsonl', row)
        config['times']['t0']['relations'] = 'relations.jsonl'
    out.json('input.json', config)
    p = fixture.profile(); p['budgets'].update(max_expanded_states=200, max_pair_checks=5000, seeds_per_region=2)
    out.json('profile.json', p)
    return root


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.root = Path(self.tmp.name)

    def tearDown(self): self.tmp.cleanup()

    def prepare(self, fragments, profile=None, relations=None):
        data = simple(self.root / 'input', fragments, relations)
        p = profile or read(data / 'profile.json')
        validate_profile(p)
        out = Output(self.root / 'run', Budget(p['budgets'])); out.root.mkdir()
        config, records = snapshot_inputs(load_input(data / 'input.json'), out, out.budget)
        scene = build_scene(config, 't0', out.root, records, out, out.budget)
        return scene, p, out

    def test_required_uncalibrated_parameters_not_silently_filled(self):
        p = template(); self.assertFalse(inspect_profile(p)['ready_to_generate'])
        with self.assertRaisesRegex(ValueError, 'required settings'): validate_profile(p)
        p = fixture.profile(); p['geometry']['normalization_scale_m'] = 0
        with self.assertRaises(ValueError): validate_profile(p)
        p = fixture.profile(); p['budgets']['max_depth'] = 16
        with self.assertRaisesRegex(ValueError, 'max_depth'): validate_profile(p)

    def test_tiny_only_region_seed_and_singleton_plus_extension(self):
        scene, p, out = self.prepare({1: [[0, 0, 0]], 2: [[.08, 0, 0], [.08, .01, 0]]})
        graph = build_graph(scene, p, out, out.budget)
        candidates, stats = search_scene(scene, graph, p, out, out.budget, 'FRAME_UNVERIFIED')
        self.assertEqual(sum(c['is_singleton'] for c in candidates), 2)
        self.assertTrue(any(c['fragment_ids'] == [1, 2] for c in candidates))
        self.assertTrue(all(c['shape']['obb'] is None for c in candidates))
        self.assertTrue(any(r['small_only_region'] for r in rows(out.root / 'seeds.jsonl')))
        self.assertTrue(all(c['identity_status'] == 'UNKNOWN' and c['update_status'] == 'HELD' for c in candidates))

    def test_missing_history_and_readonly_arrays(self):
        scene, p, out = self.prepare({1: [[0, 0, 0]]})
        self.assertFalse(scene.xyz.flags.writeable)
        self.assertEqual(scene.fragments[1].record['features']['unique_measurements']['available'], 'UNAVAILABLE')
        with self.assertRaises(ValueError): scene.xyz[0, 0, 0] = 1

    def test_halo_supplements_core_graph_without_duplicate_candidates(self):
        p = fixture.profile(); p['geometry'].update(grid_origin_m=[0, 0, 0], cell_size_m=1., halo_m=.1, pixel_gap=0)
        p['variant'] = 'B1'
        scene, p, out = self.prepare({1: [[.99, .5, .5]], 2: [[1.01, .5, .5]]}, p)
        base = build_graph(scene, p, out, out.budget)
        self.assertNotIn(2, base.adjacency[1])
        p['variant'] = 'B3'; supplemental = build_graph(scene, p, out, out.budget)
        self.assertIn(2, supplemental.adjacency[1])
        c, _ = search_scene(scene, supplemental, p, out, out.budget, 'FRAME_UNVERIFIED')
        self.assertEqual(sum(x['fragment_ids'] == [1, 2] for x in c), 1)
        self.assertTrue(any(r['route'] == 'SUPPLEMENTAL_HALO_BOUNDARY' for r in supplemental.pairs[(1, 2)]['routes']))

    def test_original_graph_unavailable_is_not_exhausted(self):
        scene, p, out = self.prepare({1: [[0, 0, 0]], 2: [[.1, 0, 0]]})
        p['budgets']['max_pair_checks'] = 1; out.budget.limits['max_pair_checks'] = 1
        graph = build_graph(scene, p, out, out.budget)
        self.assertEqual(graph.status['original_graph'], 'UNAVAILABLE')
        self.assertNotEqual(graph.status['exploration_state'], 'NO_RELATION')

    def test_independence_same_distance_or_reused_sample_not_double_counted(self):
        scene, p, out = self.prepare({1: [[0, 0, 0]], 2: [[.1, 0, 0]]})
        p['calibration'] = {'status': 'EXPLICIT_RULE', 'independence_rule': 'family_and_disjoint_measurement_v1', 'validated_rule_ids': ['r']}
        base = {'schema': 'ylm051.evidence.v1', 'evidence_id': 'a', 'fragment_ids': [1, 2], 'kind': 'DIRECT_HELD',
                'target': 'OBJECT_PART_ASSOCIATION', 'state': 'SUPPORTED', 'validated_rule_id': 'r', 'family': 'DISTANCE',
                'source_samples': ['current-shared'], 'source_pixels': [0]}
        a = normalize(base, scene, p); b = normalize(dict(base, evidence_id='b', kind='SPATIAL_NEAR'), scene, p)
        self.assertEqual(independent_families([a, b], p)['count'], 1)
        b['family'] = 'HISTORY_INCLUDES_CURRENT'
        self.assertEqual(independent_families([a, b], p)['count'], 1)
        p['calibration']['independence_rule'] = None
        self.assertEqual(normalize(base, scene, p)['state'], 'HOLD')
        self.assertIsNone(independent_families([a, b], p)['count'])

    def test_surface_rejection_does_not_reject_object_part(self):
        e = {'schema': 'ylm051.evidence.v1', 'evidence_id': 'step', 'fragment_ids': [1, 2], 'kind': 'DIRECT_HELD',
             'target': 'SURFACE_CONTINUATION', 'state': 'REJECTED', 'validated_rule_id': 'surface-rule', 'rejection_scope': 'surface_only'}
        p = fixture.profile(); p['calibration']['validated_rule_ids'] = ['surface-rule']
        scene, p, out = self.prepare({1: [[0, 0, 0]], 2: [[.1, 0, .08]]}, p, [e])
        g = build_graph(scene, p, out, out.budget); c, _ = search_scene(scene, g, p, out, out.budget, 'FRAME_UNVERIFIED')
        combined = next(c for c in c if len(c['fragment_ids']) == 2)
        self.assertFalse(combined['validated_contradictions'])
        self.assertIn('SURFACE_REJECTED_OBJECT_PART_UNDECIDED', combined['risk_flags'])

    def test_far_giant_relation_is_search_excluded_without_semantic_rejection(self):
        e = {'schema': 'ylm051.evidence.v1', 'evidence_id': 'giant', 'fragment_ids': [1, 2], 'kind': 'CHAIN_REVIEW',
             'target': 'OBJECT_PART_ASSOCIATION', 'state': 'HOLD'}
        scene, p, out = self.prepare({1: [[0, 0, 0]], 2: [[.6283, 0, 0], [4, 0, 0]]}, relations=[e])
        g = build_graph(scene, p, out, out.budget); c, _ = search_scene(scene, g, p, out, out.budget, 'FRAME_UNVERIFIED')
        self.assertFalse(any(len(x['fragment_ids']) > 1 for x in c))
        events = list(rows(out.root / 'search_trace.jsonl'))
        self.assertTrue(any(e['event'] == 'SEARCH_GATE_EXCLUDED' and e.get('semantic_identity') == 'UNKNOWN' for e in events))

    def test_point_bridge_and_third_fragment_risks(self):
        scene, p, out = self.prepare({1: [[0, 0, 0]], 2: [[.14, 0, 0]], 3: [[.07, 0, 0]]})
        g = build_graph(scene, p, out, out.budget); cs, _ = search_scene(scene, g, p, out, out.budget, 'FRAME_UNVERIFIED')
        c = next(c for c in cs if c['fragment_ids'] == [1, 2])
        self.assertIn('LOW_SUPPORT_BRIDGE', c['risk_flags'])
        self.assertIn(3, c['third_fragment_ids'])
        self.assertEqual(c['identity_status'], 'UNKNOWN')

    def test_archive_diversity_balances_classes_then_ranks_remainder(self):
        values = [{'fragment_ids': list(range(n)), 'rank_tuple': (n, i), 'candidate_id': str((n, i))}
                  for n in (1, 2, 5, 17) for i in range(5)]
        result = diverse(values, 9)
        self.assertEqual([len([x for x in result if len(x['fragment_ids']) == n]) for n in (1, 2, 5, 17)], [3, 2, 2, 2])

    def test_depth_16_32_64_reachability(self):
        data = simple(self.root / 'input', {i: [[i * .01, .5, .5]] for i in range(65)})
        for maximum in (16, 32, 64):
            p = fixture.profile(); p['geometry'].update(grid_origin_m=[-1, -1, -1], cell_size_m=5., halo_m=0., pixel_gap=0,
                                                        spatial_radius_m=.0101, max_added_gap_m=.0101, max_diameter_m=5., max_growth_ratio=1000.)
            p['budgets'].update(seeds_per_region=1, max_pair_checks=5000, max_point_copies=500000, max_expanded_states=200,
                                max_saved_bytes=64*1024**2, max_fragments=maximum, max_depth=maximum-1)
            out = Output(self.root / f'run{maximum}', Budget(p['budgets'])); out.root.mkdir()
            config, records = snapshot_inputs(load_input(data / 'input.json'), out, out.budget)
            scene = build_scene(config, 't0', out.root, records, out, out.budget)
            graph = build_graph(scene, p, out, out.budget)
            cs, stats = search_scene(scene, graph, p, out, out.budget, 'FRAME_UNVERIFIED')
            self.assertEqual(stats['max_reached_fragments'], maximum)
            self.assertIn('MAX_DEPTH', stats['stop_reasons'])


class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(); cls.root = Path(cls.temp.name)
        cls.input = fixture.make(cls.root / 'fixture')
        cls.run_dir = cls.root / 'run'
        cls.result = generate(cls.input / 'input.json', cls.input / 'profiles/B3.json', cls.run_dir)

    @classmethod
    def tearDownClass(cls): cls.temp.cleanup()

    def test_end_to_end_originals_immutable_and_phase5_not_run(self):
        self.assertTrue(self.result['processing_complete'], self.result)
        self.assertTrue(verify(self.run_dir)['integrity_passed'])
        self.assertEqual(read(self.run_dir / 'registration/status.json')['status'], 'NOT_RUN')
        self.assertEqual(read(self.run_dir / 'scene_graph_proposals.json')['existing_graph_write_count'], 0)
        self.assertEqual(read(self.run_dir / 'matching_scenarios.json')['status'], 'NOT_RUN')

    def test_actual_missingness_preserved_without_interpolation(self):
        records = list(rows(self.run_dir / 'fragment_features.jsonl'))
        self.assertTrue(all(r['features']['missing_classification']['available'] == 'AVAILABLE' for r in records))
        self.assertTrue(all(r['features']['unique_measurements']['value'] <= 3 for r in records))
        for c in rows(self.run_dir / 'hypotheses.jsonl'):
            self.assertEqual(c['point_count'], len(np.load(self.run_dir / c['source_point_ids'])))

    def test_time_namespaces_do_not_alias_flat_pixels(self):
        cs = list(rows(self.run_dir / 'singletons.jsonl'))
        a = next(c for c in cs if c['namespace']['time'] == 't0' and c['fragment_ids'] == [10])
        b = next(c for c in cs if c['namespace']['time'] == 't1' and c['fragment_ids'] == [10])
        self.assertNotEqual(a['candidate_id'], b['candidate_id'])
        self.assertNotEqual(a['point_namespace'], b['point_namespace'])

    def test_evaluation_gt_proxy_do_not_change_generation(self):
        before = sha(self.run_dir / 'hypotheses.jsonl')
        report = evaluate(self.run_dir, self.input / 'evaluation.json', self.root / 'evaluation')
        self.assertTrue(report['generation_outputs_unchanged'])
        self.assertEqual(before, sha(self.run_dir / 'hypotheses.jsonl'))
        self.assertEqual(report['times']['t0']['gt']['status'], 'ANNOTATED_SYNTHETIC')
        self.assertGreater(report['times']['t0']['gt']['false_merge_rate']['numerator_candidates'], 0)
        self.assertTrue(report['times']['t0']['proxy']['not_a_ground_truth_object'])
        self.assertTrue(all(x['proxy']['outside_proxy_is_not_false_merge'] for x in report['times']['t0']['candidates']))

    def test_replay_relocation_without_original_paths_and_order_invariance(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); moved = root / 'moved'; shutil.copytree(self.run_dir, moved)
            config = read(moved / 'input_contract.json')
            config['times'] = dict(reversed(list(config['times'].items())))
            # Changing map enumeration order is tested through a new generation input using identical source bytes.
            for spec in config['times'].values():
                for k in ('pixels', 'clusters', 'relations'):
                    if spec.get(k): spec[k] = str(moved / spec[k])
                for k in ('canonical_mask', 'feature_arrays'):
                    if spec.get(k): spec[k]['path'] = str(moved / spec[k]['path'])
            Output(root).json('reordered.json', config)
            replay = generate(root / 'reordered.json', moved / 'resolved_config.json', root / 'again')
            self.assertTrue(replay['processing_complete'], replay)
            a = [(c['candidate_id'], c['fragment_ids'], c['rank_tuple']) for c in rows(self.run_dir / 'hypotheses.jsonl')]
            b = [(c['candidate_id'], c['fragment_ids'], c['rank_tuple']) for c in rows(root / 'again/hypotheses.jsonl')]
            self.assertEqual(a, b)
            result = generate(None, moved / 'resolved_config.json', root / 'replayed', replay=moved)
            self.assertTrue(result['processing_complete'], result)
            self.assertEqual(a, [(c['candidate_id'], c['fragment_ids'], c['rank_tuple']) for c in rows(root / 'replayed/hypotheses.jsonl')])

    def test_generator_rejects_gt_input_contract(self):
        config = read(self.input / 'input.json'); config['old_pcd'] = 'do-not-read.pcd'
        path = self.root / 'forbidden.json'; Output(self.root).json(path.name, config)
        with self.assertRaisesRegex(ValueError, 'rejects'): load_input(path)

    def test_generation_ignores_changed_posthoc_files(self):
        changed = self.root / 'changed_posthoc'; shutil.copytree(self.input, changed)
        for time in ('t0', 't1'):
            np.save(changed / time / 'proxy.npy', np.array([[1e6, 1e6, 1e6]]))
            gt = np.load(changed / time / 'gt.npy'); gt[:] = 777
            np.save(changed / time / 'gt.npy', gt)
        Output(changed).json('evaluation.json', {'not_a_generation_input': True})
        result = generate(changed / 'input.json', changed / 'profiles/B3.json', self.root / 'independent_run')
        self.assertTrue(result['processing_complete'])
        fields = lambda path: [(c['candidate_id'], c['fragment_ids'], c['rank_tuple']) for c in rows(path)]
        self.assertEqual(fields(self.run_dir / 'hypotheses.jsonl'), fields(self.root / 'independent_run/hypotheses.jsonl'))

    def test_region_budget_has_visible_partial_graph_and_singletons(self):
        profile = read(self.input / 'profiles/B3.json'); profile['budgets']['max_regions'] = 1
        Output(self.root).json('small_region_budget.json', profile)
        result = generate(self.input / 'input.json', self.root / 'small_region_budget.json', self.root / 'limited_regions')
        self.assertTrue(result['processing_complete'])
        self.assertEqual(result['exploration_state'], 'BUDGET_TRUNCATED')
        statuses = list(rows(self.root / 'limited_regions/graph_status.jsonl'))
        self.assertEqual(len(statuses), 2)
        self.assertTrue(all(g['exploration_state'] == 'BUDGET_TRUNCATED' for g in statuses))
        self.assertEqual(len(list(rows(self.root / 'limited_regions/singletons.jsonl'))), 24)

    def test_global_budget_scope_and_separate_singleton_limit(self):
        summary = read(self.run_dir / 'search_summary.json')
        self.assertLessEqual(summary['resources']['counts']['expanded_states'], 600)
        self.assertIn('MAX_EXPANDED_STATES', summary['resources']['stop_reasons'])
        for time in ('t0', 't1'):
            self.assertEqual(summary['times'][time]['singleton_count'], 12)
            self.assertLessEqual(summary['times'][time]['combined_count'], 256)
        self.assertEqual(len(list(rows(self.run_dir / 'singletons.jsonl'))), 24)

    def test_viewer_relative_links_and_javascript_syntax(self):
        text = (self.run_dir / 'index.html').read_text()
        for rel in re.findall(r'(?:src|href)="([^"]+)"', text):
            self.assertFalse(rel.startswith(('/', 'http', 'file:')))
            self.assertTrue((self.run_dir / rel).is_file(), rel)
        script = re.findall(r'<script>(.*?)</script>', text, re.S)[0]
        path = self.root / 'viewer.js'; path.write_text(script)
        result = subprocess.run(['node', '--check', str(path)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('organized', script); self.assertIn('overlap', script)


class FailureTests(unittest.TestCase):
    def test_invalid_points_duplicate_ids_and_structure_resurrection(self):
        for mode in ('nan', 'duplicate', 'mask'):
            with tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); data = simple(root / 'input', {1: [[0, 0, 0]]})
                if mode == 'nan':
                    with np.load(data / 'pixels.npz') as z: a = {k: z[k] for k in z.files}
                    a['xyz'][0, 0, 0] = np.nan; np.savez(data / 'pixels.npz', **a)
                elif mode == 'duplicate':
                    Output(data).json('clusters.json', {'clusters': [{'id': 1, 'point_count': 1}, {'id': 1, 'point_count': 1}]})
                else:
                    np.savez(data / 'mask.npz', canonical=np.ones((1, 2), bool))
                    c = read(data / 'input.json'); c['times']['t0']['canonical_mask'] = {'path': 'mask.npz', 'key': 'canonical'}; Output(data).json('input.json', c)
                result = generate(data / 'input.json', data / 'profile.json', root / 'out')
                self.assertFalse(result['processing_complete'])
                self.assertEqual(result['stages']['t0:phase1'], 'FAILED')

    def test_empty_input_is_valid_but_not_accuracy_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); data = simple(root / 'input', {})
            result = generate(data / 'input.json', data / 'profile.json', root / 'out')
            self.assertTrue(result['processing_complete'], result)
            self.assertEqual(list(rows(root / 'out/hypotheses.jsonl')), [])
            self.assertEqual(result['precision_evaluation'], 'NOT_EVALUATED')

    def test_storage_and_wall_budget_partial_failures(self):
        for mode in ('storage', 'wall'):
            with tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); data = simple(root / 'input', {1: [[0, 0, 0]], 2: [[.1, 0, 0]]})
                p = read(data / 'profile.json')
                if mode == 'storage': p['budgets']['max_saved_bytes'] = 65536
                else: p['budgets']['wall_seconds'] = 1e-9
                Output(data).json('profile.json', p)
                result = generate(data / 'input.json', data / 'profile.json', root / 'out')
                self.assertFalse(result['processing_complete'])
                self.assertIn('error', result)
                self.assertTrue((root / 'out/run_manifest.json').exists())
                self.assertLessEqual(sum(p.stat().st_size for p in (root / 'out').rglob('*') if p.is_file()), p['budgets']['max_saved_bytes'])

    def test_tampered_reference_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); data = simple(root / 'input', {1: [[0, 0, 0]]})
            result = generate(data / 'input.json', data / 'profile.json', root / 'out')
            self.assertTrue(result['processing_complete'], result)
            c = next(rows(root / 'out/hypotheses.jsonl'))
            np.save(root / 'out' / c['source_point_ids'], np.array([99]))
            with self.assertRaises(ValueError): verify(root / 'out')


if __name__ == '__main__': unittest.main()
