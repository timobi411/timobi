"""Optional real-browser check (requires Playwright and installed Chromium)."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
from threading import Thread
from playwright.sync_api import sync_playwright


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--run', required=True); parser.add_argument('--out', required=True)
    parser.add_argument('--chromium', default='/usr/bin/chromium')
    parser.add_argument('--transport', choices=['file', 'http'], default='file')
    args = parser.parse_args(); run = Path(args.run).resolve(); out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=False)
    errors = []
    server = None
    url = (run / 'index.html').as_uri()
    if args.transport == 'http':
        server = ThreadingHTTPServer(('127.0.0.1', 0), partial(SimpleHTTPRequestHandler, directory=str(run)))
        Thread(target=server.serve_forever, daemon=True).start()
        url = 'http://127.0.0.1:%d/index.html' % server.server_port
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=args.chromium, headless=True,
                                    args=['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1100})
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.goto(url, wait_until='load')
        page.wait_for_function("document.querySelector('#list').options.length > 0 && document.querySelector('#plot').data")
        initial = page.locator('#list option').count()
        page.locator('#query').fill('10')
        page.wait_for_function("selected.length > 0 && selected.every(c=>c.fragment_ids.includes(10))")
        page.select_option('#list', '1')
        page.select_option('#view', 'organized')
        page.wait_for_function("document.querySelector('#plot').data[0].type === 'scattergl'")
        page.select_option('#view', 'xz')
        page.select_option('#view', '3d')
        page.locator('#colors').uncheck()
        page.wait_for_function("document.querySelector('#plot').data[0].type === 'scatter3d'")
        page.screenshot(path=str(out / 'viewer.png'), full_page=True)
        page.locator('#query').fill('')
        page.select_option('#time', 't1')
        page.wait_for_function("selected.length > 0 && selected.every(c=>c.namespace.time==='t1')")
        assert not errors, errors
        (out / 'result.json').write_text(json.dumps({'status': 'PASS', 'initial_candidate_options': initial,
            'transport': args.transport,
            'checked': ['relative local assets', 'fragment ID search', 'combined candidate selection', 'organized', 'XZ projection',
                        '3D', 'source/candidate color switch', 'T0/T1 switch', 'no JavaScript exceptions'],
            'javascript_errors': errors}, indent=2))
        browser.close()
    if server:
        server.shutdown(); server.server_close()


if __name__ == '__main__': main()
