# YLM-X001 v0.5.1 — Phase 1～4 複数仮説候補形成

添付仕様書 `v0.5.1-design-2` の今回納品範囲（Phase 1～4）を、新しい `ylm051` エンジンとして実装しました。小断片を残したまま、元断片の組合せを複数の候補として探索・監査します。元のクラスタリング、構造除去、旧ICP solverは変更していません。

**この版の出力は候補形成の診断結果です。identity は UNKNOWN、update は HELD、既存シーングラフへの書込は0です。Phase 5の追加ICP初期化とPhase 6のScenario割当は NOT_RUN です。** 正式v0.4保存結果が未受領のため、今回の検証・同梱サンプルは合成データです。

## まず結果を表示する

ZIPをPCに保存して、フォルダ全体を展開してください。

- `validation/sample_B3/index.html`：生成済み候補Viewer。Pythonのインストールなしで表示できます。
- `validation/sample_evaluation/index.html`：生成処理から独立した合成GT・代理領域の事後評価。
- `validation/browser/viewer.png`：動作確認時の画面。
- `validation/REPORT_ja.md`：実行結果、資源実測、検証範囲。

Viewerでは数字を入力すると断片IDに完全一致、`H-...` を入力すると候補IDに部分一致します。時刻、候補、3D／organized／XY・XZ・YZ表示、元断片の色分けを切り替えられます。seedからの追加順、各辺の根拠、候補間重複、打切り状態も確認できます。JSは相対パスで同梱し、CDNやデータ取得用fetchは使いません。

このクラウドのChromiumは `file://` を管理ポリシーで拒否したため、実ブラウザ操作試験はローカルHTTP経由で行いました。相対リンクとJS構文は別途検証済みです。PC側でも直接表示が制限される場合は、展開フォルダで `python -m http.server 8000 --bind 127.0.0.1` を起動し、そのPCのブラウザから `http://127.0.0.1:8000/validation/sample_B3/` を開いてください。

## 実行環境

CLIはLinux／WSL2向けです（LinuxのRSS計測と `resource` を使用）。Python 3.12で検証しました。Windowsの通常ブラウザでの保存済みHTML閲覧と、Linuxでの候補生成は別の操作です。ROSはPhase 1～4では不要です。

展開先 `ylm_scene_graph_integrated_v051` をカレントディレクトリにします。

```bash
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-dev.txt
python -m unittest discover -s tests -v
```

テスト中のJS構文確認にNode.jsも使います。生成だけなら `requirements.txt` で足ります。旧PCDを事後評価へ読む場合だけ `python -m pip install open3d==0.19.0` を追加してください。NumPy形式の代理点群ならOpen3Dは不要です。

## 合成例を生成・検査・表示する

出力フォルダは毎回新しい名前を指定します。既存結果を上書きしません。入力データのフォルダ内へ結果を出すことも拒否します。

```bash
python examples/make_fixture.py --out outputs/fixture
python -m ylm051 generate --input outputs/fixture/input.json --profile outputs/fixture/profiles/B3.json --out outputs/run_B3
python -m ylm051 verify --run outputs/run_B3
python -m ylm051 view --run outputs/run_B3
python -m ylm051 evaluate --run outputs/run_B3 --evaluation outputs/fixture/evaluation.json --out outputs/evaluation_B3
python -m ylm051 replay --run outputs/run_B3 --out outputs/replay_B3
```

`view` は検査後にHTMLの場所を表示します。生成と事後評価は別CLI・別入力・別出力です。生成CLIは旧PCD、GT、予定移動量を入力項目として受け取りません。評価を追加しても生成済み候補を変更しません。GT・代理ファイルの内容を変えて再生成しても、候補ID・断片集合・順位が一致することを試験しています。

`generate` の終了コード0は「指定予算の下で出力を作成し、原本ハッシュ整合を確認」の意味です。全探索や精度改善の意味ではありません。`run_manifest.json` と `search_summary.json` の `exploration_state` を必ず確認してください。時間・RSS・容量などで保存を完遂できない場合は終了コード2、部分結果と失敗理由を残します。

## 実データの設定

最初に未校正の設定ひな型を作ります。

```bash
python -m ylm051 prepare-config --out outputs/real_profile.json
```

画面に現行値・仮定・未設定項目が出ます。`geometry` のnull値と必須global予算を利用者が明示し、`parameter_sources` に値の根拠を記録してください。未設定のまま `generate` すると停止します。合成fixtureの距離やcellサイズは、実シーン向けの校正値ではありません。

入力は、受領v0.5/bridgeが読み込む `pixel_correspondence` の `xyz/valid/labels` とクラスタメタデータの契約に合わせています。ファイル名を推測して一括読込みする処理はありません。実在するパスをJSONで指定します。

```json
{
  "schema": "ylm051.input.v1",
  "run_id": "integrated_v04_mem8g_j502ewmi",
  "case": "exp02",
  "window": "fixed11",
  "boundary": "boundary_false",
  "units": "m",
  "dataset_kind": "REAL_DEVELOPMENT",
  "development_selection": "exp02 was previously selected using post-hoc proxy diagnostics",
  "frame_status": "FRAME_UNVERIFIED",
  "times": {
    "t0": {"pixels": "actual_t0/pixel_correspondence.npz", "clusters": "actual_t0/clusters.json"},
    "t1": {"pixels": "actual_t1/pixel_correspondence.npz", "clusters": "actual_t1/clusters.json"}
  }
}
```

ここでのパスは説明用です。正式結果 `organized_runs/integrated_v04_mem8g_j502ewmi/results/` は今回の受領物に含まれていません。元の実ファイルを用意してパスを置き換える必要があります。任意の上流スキーマを自動推測して読み込むものではありません。詳細は [入力契約](docs/INPUT_CONTRACT_ja.md) を参照してください。

canonical構造除去マスクがある場合は `canonical_mask` を指定します。指定すると、構造除去画素が断片へ混入していないことも検査します。未指定なら既存labelsをそのまま使い、マスクの検証はUNAVAILABLEです。コードを入力 `source_code` に指定すれば、そのコピーとハッシュも保存します。

## 探索と監査

- 全singletonは1～2点を含めて別一覧に保存します。結合候補256/時刻の枠には数えません。
- 全実測点が属する固定gridとhaloを用います。巨大断片のpatchは探索用で、候補には元断片全体を追加します。
- 各領域で点数階級と空間・画素分布からseedを分散選択し、1段に1断片を追加します。既定枠はseed32/領域、展開先12/状態、beam8/seed、結合256/時刻です。合成サンプルではseed8/領域に明示変更しています。
- 各段の停止仮説をarchiveへ残し、追加仮説から次段beamを選びます。singletonがbeamを占有して探索が進まない構造にはしません。
- 順位は矛盾・リスク・既知関係の支持率・独立証拠・形状増大とbridge依存・断片数・IDの辞書式です。点数や代理回収を加点しません。断片数階級1/2～4/5～16/17以上の利用可能枠を均等割当し、余りを順位順で充填します。
- AABB、PCA/OBB可否、直径の上界、成長比、最大追加gap、元グラフ連結、支持率、bridge、第三断片、観測信頼度を全体で監査します。直径にはAABB対角線の**上界**を使うことを明記しています。点・線・平面のOBB不成立を候補削除に使いません。
- 未校正の近接や保存関係はHOLDです。表面連続の棄却から部品関係の棄却を導きません。独立性認定ルール未設定ならSUPPORTEDへ昇格しません。

`max_expanded_states` 等のglobal予算はT0/T1・全領域・全seedで共有します。時刻順はt0→t1なので、t0が予算を使うとt1は少なくなる場合があります。seed/beam/隣接数/深さ/archiveの枠外はログへ残し、未探索を別物体判定へ変換しません。frontier数はログ上の状態・拡張の発生件数で、別seed間の同一集合は重複し得ます。未列挙分はUNKNOWNです。

保存容量は診断予約領域も含む上限です。通常payloadの上限から `min(1 MiB, 総容量/2)` を診断用に予約します。カウンタは上書き前の書込みも含めた保守的累積値です。実ファイル合計はCLI結果の `actual_saved_bytes` で報告します。RSSはLinux `ru_maxrss`、仮想アドレス上限は別項目です。CLIは数値ライブラリを1threadに固定します。任意のPythonプロセスからAPIを直接呼ぶ場合、そのプロセスの既存thread設定やピークRSSは引き継ぎます。

## 比較軸

```bash
python examples/run_comparison.py --fixture outputs/fixture --axis evidence --out outputs/evidence_comparison
python examples/run_comparison.py --fixture outputs/fixture --axis beam --out outputs/beam_comparison
python examples/make_fixture.py --out outputs/chain65 --chain-length 65
python examples/run_comparison.py --fixture outputs/chain65 --axis fragment_budget --out outputs/depth_comparison
```

| 軸 | 条件 |
|---|---|
| evidence | B0: singleton。B1: core領域・画像近傍。B2: 同じ探索に既存関係を追加。B3: 同条件にhalo補完経路を追加 |
| beam | 同じB3証拠・入力で幅1と幅8 |
| fragment_budget | 同じ入力で(最大断片数,深さ)=(16,15),(32,31),(64,63) |
| lightweight | `lightweight_depth16.json` は深さ16、最大17断片。上の32断片設定と混同しない |

B1～B3は同じ順位・beam・予算です。補完graphは元graphと別ファイルです。これらは候補形成の比較であり、未実装のL0/L1 ICP、構造条件A/C、Scenarioを混ぜていません。

## 保存・再現

主な出力は仕様書の名称を維持しています。

| ファイル | 内容 |
|---|---|
| `run_manifest.json` / `resolved_config.json` | 段階状態、独立した判定状態、固定設定、資源、入力不足 |
| `input_contract.json` / `source_hashes.json` / `inputs/` | 原本コピーの相対参照、原本とコピーのSHA-256 |
| `environment.json` | Python・依存ライブラリのversion/path、実行ソースhash |
| `fragment_features.jsonl` / `hypothesis_clouds/` | 断片特徴、各時刻のC順flat画素ID。点群座標の全状態複製はしない |
| `pair_evidence.jsonl` / `supplemental_graph.jsonl` | 正規化した証拠・探索経路・元payload |
| `singletons.jsonl` / `hypotheses.jsonl` | 全singletonと上限内の結合仮説 |
| `search_trace.jsonl` / `search_summary.json` | 追加順・停止仮説・除外理由・各予算の打切り |
| `registration/status.json` / `matching_scenarios.json` | NOT_RUN |
| `scene_graph_proposals.json` | HELD、提案なし、既存graph書込0 |
| `artifact_hashes.json` | 出力ファイルのSHA-256（自身を除く） |

保存フォルダ全体を移動しても相対参照から `verify` と `replay` が動作します。元ファイルが残っていればそのhashも比較します。元ファイルが削除されていても保存コピーから再生できます。変更・破損を検出した場合は停止します。

candidate_idは入力内容・名前空間・profile・ソート断片集合のSHA-256から生成します。同一入力・設定・ソフトウェアでのIDと順位、ファイル列挙順に対する不変性を試験しました。時間／RSSの打切り位置は実行機の負荷に依存するため、打切りで残る候補の全件一致まで保証しません。

## 事後評価の読み方

旧PCD/NumPy代理点群は明示的な単位・剛体変換・座標根拠・評価半径で元観測へ最近傍対応させます。元PCD点数と重複排除後の観測画素数は別の母数です。候補の代理回収率は「回収した代理画素数 / 構造除去後に残る代理画素数」です。代理領域外点数をFalse Mergeとは呼びません。

GTは各時刻HxW整数配列で、-1=未注釈、0=背景、正数=物体IDです。Object Coverageは「候補が含むその物体の点数 / 全valid観測内の注釈済み物体点数」で、分母には断片から除外された画素も含めます。Candidate Purityは「最大物体点数 / 候補内の注釈済み点数（背景含む）」です。未注釈点は別記し、分母から除きます。

Recall@Kは保存したsingletonと結合仮説をrank_tupleで並べ、明示したcoverage/purity閾値を満たす上位K内の物体数を全注釈物体数で割ります。False Mergeは明示した割合以上の点を持つ異なるGT物体が2つ以上含まれる候補の割合で、分母は注釈点を含む保存候補数です。Matching/Update Accuracyは未実施です。合成GTによる数値は実データの精度評価ではありません。

## 実装範囲と保全物

[実装状況表](docs/IMPLEMENTATION_STATUS_ja.md)、[入力契約](docs/INPUT_CONTRACT_ja.md)、[検証結果](validation/REPORT_ja.md)を参照してください。受領原本ZIPは `vendor/ylm_scene_graph_integrated_v05_diagnostic.zip` にバイト同一で保存しています。旧版を使う場合は別フォルダへ展開し、そのREADMEに従ってください。新エンジンは旧solverを改変・自動実行しません。

仕様書原文、受領物ハッシュ、6種類のJSON Schema、合成fixture生成器、26件の試験、実行ログ、比較結果、結果サンプルを同梱しています。正式v0.4ソース・保存結果、元の保存辺／履歴／局所モデルの実スキーマ、現行の実験診断成果物は未受領です。実exp02の候補性能、床ID 8の再構成、実データ8 GiB以内の動作は今回再検証できていません。
