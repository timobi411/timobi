"""Regenerate the distributed JSON Schema contracts (standard library only)."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def obj(properties, required=None, extra=False):
    return {'type': 'object', 'properties': properties,
            'required': list(properties) if required is None else required, 'additionalProperties': extra}


def arr(items, **kwargs):
    return dict(type='array', items=items, **kwargs)


def const(value): return {'const': value}
def enum(*values): return {'enum': list(values)}
def nullable(value): return {'anyOf': [value, {'type': 'null'}]}


STRING = {'type': 'string', 'minLength': 1}
NUMBER = {'type': 'number'}
POSITIVE = {'type': 'number', 'exclusiveMinimum': 0}
NONNEGATIVE = {'type': 'number', 'minimum': 0}
COUNT = {'type': 'integer', 'minimum': 1}
ID = {'type': 'integer', 'minimum': 0}
XYZ = arr(NUMBER, minItems=3, maxItems=3)
ANY_OBJECT = {'type': 'object'}

geometry = obj({
    'grid_origin_m': XYZ, 'cell_size_m': POSITIVE, 'halo_m': NONNEGATIVE,
    'spatial_radius_m': NONNEGATIVE, 'pixel_gap': ID, 'normalization_scale_m': POSITIVE,
    'max_added_gap_m': NONNEGATIVE, 'max_diameter_m': POSITIVE, 'max_growth_ratio': POSITIVE,
    'bridge_min_support': COUNT})
budgets = obj({key: COUNT for key in ('max_expanded_states', 'max_pair_checks', 'max_point_copies',
    'max_regions', 'max_region_memberships', 'max_input_bytes', 'seeds_per_region',
    'expansions_per_state', 'beam_per_seed', 'combined_per_time', 'max_fragments', 'max_depth')})
budgets['properties'].update(max_saved_bytes={'type': 'integer', 'minimum': 65536}, wall_seconds=POSITIVE,
                             rss_limit_mib=POSITIVE, virtual_address_limit_mib=nullable(POSITIVE))
budgets['required'] = list(budgets['properties'])
profile = obj({'schema': const('ylm051.profile.v1'), 'name': STRING, 'variant': enum('B0', 'B1', 'B2', 'B3'),
    'geometry': geometry, 'budgets': budgets,
    'calibration': obj({'status': STRING, 'independence_rule': enum(None, 'family_and_disjoint_measurement_v1'),
                        'validated_rule_ids': arr(STRING, uniqueItems=True)}),
    'viewer_max_points_per_time': {'type': 'integer', 'minimum': 1, 'maximum': 100000},
    'parameter_sources': obj({k: STRING for k in geometry['properties']}),
    'budget_scope': obj({'global': STRING, 'combined_per_time': STRING, 'beam_per_seed': STRING, 'seeds_per_region': STRING})})
profile['description'] = 'Runnable profile. prepare-config deliberately writes null placeholders that fail this schema until set. max_depth == max_fragments - 1 is checked by runtime.'

feature_roles = ('source_kind', 'sample_id', 'measurement_time', 'confidence', 'range_m', 'mad_m', 'missing_classification')
time_input = obj({'pixels': STRING, 'clusters': STRING,
    'canonical_mask': obj({'path': STRING, 'key': STRING}),
    'feature_arrays': obj({'path': STRING, 'keys': obj({key: STRING for key in feature_roles}, required=[])}),
    'relations': STRING, 'source_code': arr(STRING)}, required=['pixels', 'clusters'])
times = obj({'t0': time_input, 't1': time_input}, required=[]); times['minProperties'] = 1
generation = obj({'schema': const('ylm051.input.v1'), 'run_id': STRING, 'case': STRING,
    'window': enum('fixed11', 'all'), 'boundary': STRING, 'units': const('m'), 'dataset_kind': STRING,
    'development_selection': STRING, 'frame_status': STRING, 'times': times})
generation['description'] = 'Explicit paths only; GT, old PCD and evaluation hints are forbidden. Paths are relative to this JSON or absolute.'

evidence = obj({'schema': const('ylm051.evidence.v1'), 'evidence_id': STRING,
    'fragment_ids': arr(ID, minItems=2, maxItems=2, uniqueItems=True),
    'kind': enum('DIRECT_HELD', 'IMAGE_GAP', 'SPATIAL_NEAR', 'CHAIN_REVIEW'),
    'target': enum('SURFACE_CONTINUATION', 'OBJECT_PART_ASSOCIATION'), 'state': enum('SUPPORTED', 'HOLD', 'REJECTED'),
    'validated_rule_id': nullable(STRING), 'rejection_scope': nullable(STRING), 'conditions': ANY_OBJECT,
    'family': nullable(STRING), 'source_samples': arr(STRING), 'source_pixels': arr(ID),
    'source_candidate_id': nullable(STRING), 'exploration_state': STRING,
    'upstream_search_complete': {'anyOf': [{'type': 'boolean'}, const('UNAVAILABLE')]},
    'saved_geometry': obj({'distance_m': nullable(NONNEGATIVE), 'beta': nullable(NUMBER), 'reason': nullable(STRING)}, required=[])},
    required=['schema', 'evidence_id', 'fragment_ids', 'kind', 'target', 'state'], extra=True)
evidence['description'] = 'One JSONL record. Additional upstream attributes are preserved as original_payload, not silently interpreted. Calibrated rules and explicit independence provenance are required for SUPPORTED.'

namespace = obj({'run_id': STRING, 'case': STRING, 'window': enum('fixed11', 'all'), 'boundary': STRING,
                 'time': enum('t0', 't1')})
hypothesis = obj({'candidate_id': {'type': 'string', 'pattern': '^H-[0-9a-f]{32}$'}, 'namespace': namespace,
    'fragment_ids': arr(ID, minItems=1, uniqueItems=True), 'point_count': COUNT, 'source_point_ids': STRING,
    'is_singleton': {'type': 'boolean'}, 'rank_tuple': {'type': 'array', 'minItems': 10, 'maxItems': 10},
    'seed_fragment_id': ID, 'addition_order': arr(ID, minItems=1, uniqueItems=True),
    'candidate_state': const('DIAGNOSTIC_HYPOTHESIS'), 'exploration_state': STRING, 'geometry_state': STRING,
    'frame_status': STRING, 'identity_status': const('UNKNOWN'), 'update_status': const('HELD'),
    'risk_flags': arr(STRING), 'validated_contradictions': arr(STRING), 'aabb_m': arr(XYZ, minItems=2, maxItems=2),
    'diameter_upper_bound_m': NONNEGATIVE, 'growth_ratio': NONNEGATIVE,
    'known_relation_support': ANY_OBJECT, 'independent_evidence': ANY_OBJECT}, extra=True)
hypothesis['description'] = 'One output JSONL record. Full arrays/PCA/audit details are retained as additional fields; runtime verify checks measured whole-fragment membership, sorted IDs, hash and state.'

proxy = obj({'points': STRING, 'units': const('m'), 'old_to_observation': arr(arr(NUMBER, minItems=4, maxItems=4), minItems=4, maxItems=4),
             'coordinate_evidence': STRING, 'radius_m': POSITIVE})
eval_time = obj({'proxy': proxy, 'gt_labels': STRING}, required=[])
eval_time['minProperties'] = 1
eval_times = obj({'t0': eval_time, 't1': eval_time}, required=[]); eval_times['minProperties'] = 1
fraction = {'type': 'number', 'exclusiveMinimum': 0, 'maximum': 1}
evaluation = obj({'schema': const('ylm051.evaluation.v1'), 'dataset_role': STRING,
    'selection_disclosure': STRING, 'times': eval_times,
    'gt_metrics': obj({'coverage_threshold': fraction, 'purity_threshold': fraction,
                       'false_merge_min_fraction': fraction, 'recall_k': COUNT})},
    required=['schema', 'dataset_role', 'selection_disclosure', 'times'])
evaluation['description'] = 'Post-hoc evaluation only. gt_metrics required at runtime if GT labels supplied. Proper rigid transform checked at runtime.'

feature = obj({'available': enum('AVAILABLE', 'UNAVAILABLE'), 'value': {}, 'denominator': {},
               'unit': nullable(STRING), 'method': nullable(STRING)})
fragment_key = dict(namespace)
fragment_key['properties'] = dict(namespace['properties'], fragment_id=ID)
fragment_key['required'] = list(fragment_key['properties'])
fragments = obj({'fragment_key': fragment_key, 'fragment_id': ID, 'source_point_ids': STRING,
    'boundary_point_ids': STRING, 'features': {'type': 'object', 'additionalProperties': feature},
    'identity_status': const('UNKNOWN'), 'canonical_mask_available': {'type': 'boolean'}})


def main():
    for name, schema in {'profile': profile, 'input': generation, 'evidence': evidence,
                         'hypothesis': hypothesis, 'evaluation': evaluation, 'fragment_features': fragments}.items():
        schema = dict(schema, **{'$schema': 'https://json-schema.org/draft/2020-12/schema',
                                '$id': 'urn:ylm051:' + name + ':v1'})
        (HERE / (name + '.schema.json')).write_text(json.dumps(schema, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__': main()
