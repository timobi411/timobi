"""T0 world coordinates, T1 measurements in a common T1 frame. Lengths in metres."""
import argparse
import importlib.util
import json
from pathlib import Path
from time import monotonic

import numpy as np
import open3d as od
import plotly.graph_objects as go
from scipy.optimize import linear_sum_assignment
from scipy.spatial import cKDTree
import adaptive_clustering_V2 as v2


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))


def cloud(points):
    return od.geometry.PointCloud(od.utility.Vector3dVector(points))


def load(path):
    points = np.asarray(od.io.read_point_cloud(str(path)).points).copy()
    if not len(points) or not np.isfinite(points).all():
        raise ValueError(f'Invalid cloud: {path}')
    return points


def transform(points, matrix):
    return points @ matrix[:3, :3].T + matrix[:3, 3]


def rigid(matrix):
    m = np.asarray(matrix, float)
    if (m.shape != (4, 4) or not np.isfinite(m).all()
            or not np.allclose(m[3], [0,0,0,1]) or not np.allclose(m[:3,:3].T @ m[:3,:3], np.eye(3), atol=1e-6)
            or not np.isclose(np.linalg.det(m[:3,:3]), 1)):
        raise ValueError('Expected a rigid transform')
    return m


def normals(points, k):
    if len(points) < k:
        return np.zeros_like(points), np.zeros(len(points), bool)
    _, idx = cKDTree(points).query(points, k=k)
    delta = points[idx] - points[idx].mean(axis=1, keepdims=True)
    val, vec = np.linalg.eigh(delta.transpose(0,2,1) @ delta)
    return vec[:,:,0], (val[:,1] > 1e-9) & (val[:,0] < 0.20 * val[:,1])


def alignment(points, anchors, models, seed, cfg):
    matrix = seed.copy()
    if not anchors:
        return matrix, False, []
    pairs = [(points[np.asarray(ids,int)], models[key]) for key,ids in anchors.items()]
    if any(len(src)<3 or len(dst)<3 for src,dst in pairs):
        return matrix, False, []
    for _ in range(30):
        rows, residuals = [], []
        stats = []
        for src, dst in pairs:
            x = transform(src, matrix)
            dist, idx = cKDTree(dst).query(x)
            n, stable = normals(dst, cfg['neighbors'])
            keep = stable[idx] & (dist < cfg['alignment_search_m'])
            normal = n[idx[keep]]
            errors = ((x[keep]-dst[idx[keep]]) * normal).sum(axis=1)
            rows.extend(np.column_stack((np.cross(x[keep], normal),normal)))
            residuals.extend(errors)
            stats.append(dict(overlap=float(keep.mean()), rms=float(np.sqrt(np.mean(dist[keep]**2))) if keep.any() else None,
                              offset=np.mean(x[keep]-dst[idx[keep]],axis=0).tolist() if keep.any() else None))
        if len(rows)<6:
            return matrix,False,stats
        step,_,rank,singular=np.linalg.lstsq(rows,-np.asarray(residuals),rcond=cfg['alignment_rcond'])
        if rank<6:
            return matrix,False,stats
        if np.linalg.norm(step)<1e-6:
            break
        from scipy.spatial.transform import Rotation
        inc=np.eye(4)
        inc[:3,:3]=Rotation.from_rotvec(step[:3]).as_matrix()
        inc[:3,3]=step[3:]
        matrix=inc @ matrix
    else:
        return matrix,False,stats
    ok=all(a['overlap']>=cfg['alignment_overlap'] and a['rms']<=cfg['alignment_error_m'] and np.linalg.norm(a['offset'])<=cfg['alignment_bias_m'] for a in stats)
    return matrix,ok,stats


def visibility(model, views, cfg):
    # Keep nearest model voxel for each measured direction in each view.
    flags=np.zeros((len(model),4),bool)
    for origin,directions,ranges,fov in views:
        vectors=model-origin
        depth=np.linalg.norm(vectors,axis=1)
        unit=vectors/np.maximum(depth[:,None],1e-12)
        inside=np.ones(len(model),bool)
        if fov is not None:
            inside = (unit @ fov[0]) >= fov[1]
        flags[~inside,3]=True
        angle, ray=cKDTree(directions).query(unit)
        idx=np.flatnonzero(inside & (angle<=2*np.sin(np.deg2rad(cfg['ray_angle_deg'])/2)) & (depth>0))
        ordered=idx[np.argsort(depth[idx],kind='stable')]
        _,first=np.unique(ray[ordered],return_index=True)
        front=ordered[first]
        delta=ranges[ray[front]]-depth[front]
        valid=np.isfinite(delta) & (ranges[ray[front]]>0)
        tol=cfg['surface_m']
        for col,mask in enumerate([abs(delta)<=tol,delta>tol,delta < -tol]):
            flags[front[valid & mask],col]=True
    return flags


def sample(points, size):
    _,idx=np.unique(np.floor(points/size).astype(np.int64),axis=0,return_index=True)
    return points[np.sort(idx)]


def score(model, candidate, views, cfg, visibility_on):
    p=sample(model,cfg['voxel_m'])
    flags=visibility(p,views,cfg)
    evaluable=flags[:,0] | flags[:,1] if visibility_on else np.ones(len(p),bool)
    dist=cKDTree(candidate).query(p)[0]
    good=evaluable & (dist<=cfg['surface_m'])
    if visibility_on:
        good &= flags[:,0] & ~flags[:,1]
    q=sample(candidate,cfg['voxel_m'])
    purity=float((cKDTree(p).query(q)[0]<=cfg['surface_m']).mean())
    coverage=float(good.sum()/max(1,evaluable.sum()))
    spread=np.linalg.svd(p[good]-p[good].mean(0),compute_uv=False)/np.sqrt(good.sum()) if good.sum()>=3 else np.zeros(3)
    area=float(good.sum()*cfg['voxel_m']**2)
    rms=float(np.sqrt(np.mean(dist[good]**2))) if good.any() else None
    ok=area>=cfg['min_area_m2'] and coverage>=cfg['min_fraction'] and purity>=cfg['min_purity'] and spread[-1]>=cfg['min_depth_m']
    return dict(valid=bool(ok),utility=coverage*purity,matched_area=area,evaluable_area=float(evaluable.sum()*cfg['voxel_m']**2),fraction=coverage,
                rms=rms,purity=purity,spread=spread.tolist(),ray_counts=flags.sum(0).tolist(),unknown=int((~flags.any(1)).sum()))


def assignment(scores,margin):
    n,m=scores.shape
    extended=np.column_stack((scores,np.zeros((n,n))))
    rows,cols=linear_sum_assignment(-extended)
    best=extended[rows,cols].sum()
    selected={}
    for row,col in zip(rows,cols):
        if col>=m or scores[row,col]<=0:
            continue
        other=extended.copy()
        other[row,col]=-1
        a,b=linear_sum_assignment(-other)
        gap=float(best-other[a,b].sum())
        if gap>=margin:
            selected[row]=(col,gap)
    return selected


def main(job_path,out):
    start=monotonic()
    base=Path(job_path).resolve().parent
    job=read(job_path)
    cfg=read(base/job['config'])
    graph=read(base/job['graph'])
    nodes=graph['nodes']
    keys=[n.get('object_id',n.get('id')) for n in nodes]
    if None in keys or len(set(keys))!=len(keys): raise ValueError('Unique node IDs required')
    settings=job['objects']
    models={key:load(base/job.get('paths',{}).get(key,n['source_ply'])) for key,n in zip(keys,nodes)}
    import re
    if any(not isinstance(k,str) or not re.fullmatch(r'[A-Za-z0-9_-]+',k) for k in keys):
        raise ValueError('Node IDs must be safe filename components')
    active=list(settings)
    if any(k not in models or v['mobility'] not in ('fixed','movable','undecided') or not v['reason'] for k,v in settings.items()):
        raise ValueError('Invalid object experiment settings')
    out=Path(out)
    out.mkdir(parents=True,exist_ok=False)
    write(out/'experiment.json',job)
    write(out/'thresholds.json',cfg)
    if 'unknown_manifest' in job:
        manifest_path=base/job['unknown_manifest']
        source=read(manifest_path)['unclustered_ply']
        path=manifest_path.parent/source
        if not path.is_file(): raise FileNotFoundError(path)
        write(out/'t0_unknown_reference.json',dict(manifest=str(manifest_path),unclustered_ply=str(path)))
    visibility_on=job.get('mode','improved')!='no_visibility'
    raw=load(base/job['t1_ply'])
    structure=np.zeros(len(raw),bool)
    if 'exp001_condition_dir' in job:
        import hashlib
        condition=base/job['exp001_condition_dir']
        record=read(condition/'run.json')
        if hashlib.sha256(raw.astype('<f8').tobytes()).hexdigest()!=record['input_sha256']:
            raise ValueError('Selected condition differs from T1 representative')
        structure[np.load(condition/'indices.npz')['removed']]=True
        np.save(out/'background.indices.npy',np.flatnonzero(structure))
    anchors=job['anchor_indices']
    if set(anchors)!={k for k,v in settings.items() if v['use_for_scene_alignment']} or any(settings[k]['mobility']!='fixed' for k in anchors):
        raise ValueError('Supply point indices for exactly the selected fixed anchors')
    for ids in anchors.values():
        if any(i<0 or i>=len(raw) for i in ids): raise ValueError('Invalid anchor index')
    matrix,ok,stats=alignment(raw,anchors,models,rigid(job['initial_T_T0_from_T1']),cfg)
    points=transform(raw,matrix)
    views=[]
    for view in job['views']:
        a=np.load(base/view['rays_npz'])
        directions=a['directions'] @ matrix[:3,:3].T
        if not np.allclose(np.linalg.norm(directions,axis=1),1) or len(directions)!=len(a['ranges']): raise ValueError('Invalid rays')
        axis=view.get('fov_axis')
        fov=(np.asarray(axis)@matrix[:3,:3].T,np.cos(np.deg2rad(view['half_angle_deg']))) if axis is not None else None
        if len(directions)==0 or np.asarray(a['ranges']).shape!=(len(directions),): raise ValueError('Expected one range per ray')
        views.append((transform(np.asarray(view['origin']),matrix),directions,a['ranges'],fov))
    if not views: raise ValueError('At least one sensor view is required')
    write(out/'alignment.json',dict(matrix=matrix.tolist(),verified=ok,anchors=stats,frame=job['frame_id']))
    assigned=np.zeros(len(points),bool)
    taken=np.zeros(len(points),bool)
    layers=[('T1',points),('T0',np.vstack(list(models.values())))]
    decisions={}
    diagnostics=[]
    candidates=[]
    icp_calls=0
    def save(name,indices):
        np.save(out/(name+'.indices.npy'),indices)
        if len(indices):
            od.io.write_point_cloud(str(out/(name+'.ply')),cloud(points[indices]))
    if ok:
        normal,stable=normals(points,cfg['neighbors'])
        fixed=[k for k in active if settings[k]['mobility']=='fixed']
        costs=np.full((len(points),len(fixed)+2),np.inf)
        uncertain=np.zeros(len(points),bool)
        for j,k in enumerate(fixed):
            model=models[k]
            ns,reliable=normals(model,cfg['neighbors'])
            visible=visibility(model,views,cfg)[:,0] if visibility_on else np.ones(len(model),bool)
            dist,idx=cKDTree(model).query(points)
            uncertain |= (dist<=cfg['surface_m']) & (~stable | ~reliable[idx])
            good=stable & reliable[idx] & visible[idx] & (dist<=cfg['surface_m']) & (abs((normal*ns[idx]).sum(1))>=np.cos(np.deg2rad(cfg['normal_deg'])))
            costs[good,j]=dist[good]
        order=np.argsort(costs,axis=1)
        for j,k in enumerate(fixed):
            mask=~structure & (order[:,0]==j)&np.isfinite(costs[:,j])&(costs[np.arange(len(points)),order[:,1]]>costs[:,j]+cfg['surface_margin_m'])
            ids=np.flatnonzero(mask)
            save('fixed_'+k,ids)
            assigned[ids]=True
            layers.append((k,points[ids]))
            evidence=score(models[k],points[ids],views,cfg,visibility_on) if len(ids) else None
            decisions[k]={'status':'static' if evidence and evidence['valid'] else 'review_fixed','evidence':evidence}
        free=np.flatnonzero(~structure & ~assigned & ~uncertain & ~np.isfinite(costs).any(axis=1))
        if len(free):
            local=cloud(points[free]-views[0][0])
            clusters=v2.adaptive_core_expand_clustering(local,v2.MIN_CLUSTER_POINTS)
            candidates=[free[np.asarray(idx,int)] for idx in v2.adaptive_recluster(local,clusters)]
        movable=[k for k in active if k not in fixed]
        weights=np.zeros((len(movable),len(candidates)))
        poses={}
        visibility_on=job.get('mode','improved')!='no_visibility'
        unresolved=set()
        for i,k in enumerate(movable):
            model=models[k]
            flags=visibility(sample(model,cfg['voxel_m']),views,cfg)
            vacant=flags[:,1].sum()*cfg['voxel_m']**2>=cfg['min_area_m2'] and flags[:,1].sum()/max(1,(flags[:,0]|flags[:,1]).sum())>=cfg['min_fraction']
            decisions[k]=dict(status='held',origin_vacant=bool(vacant),ray_counts=flags.sum(0).tolist())
            for j,idx in enumerate(candidates):
                target=points[idx]
                shift=np.linalg.norm(model.mean(0)-target.mean(0))
                if shift>cfg['search_m']:
                    diagnostics.append(dict(id=k,candidate=j,reason='outside_search'))
                    continue
                pose=np.eye(4)
                evidence=score(model,target,views,cfg,visibility_on)
                reason='original_pose'
                size_ratio=np.linalg.norm(np.ptp(target,axis=0))/max(1e-9,np.linalg.norm(np.ptp(model,axis=0)))
                plausible=cfg['min_size_ratio']<=size_ratio<=cfg['max_size_ratio']
                if not evidence['valid'] and plausible and len(target)>=v2.MIN_CLUSTER_POINTS:
                    backend=job.get('adaptive_icp_v11') or job.get('experimental_icp')
                    if backend:
                        spec=importlib.util.spec_from_file_location('lab_icp',base/backend)
                        mod=importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(mod)
                        icp_calls+=1
                        trial=mod.evaluate_pair(cloud(model),cloud(target))
                        reason='adaptive_v11_candidate' if job.get('adaptive_icp_v11') else 'experimental_local_icp'
                        if trial and trial['valid']:
                            pose=rigid(trial['transformation'])
                            evidence=score(transform(model,pose),target,views,cfg,visibility_on)
                    else:
                        reason='missing_adaptive_icp_v11'
                        unresolved.add((i,j))
                diagnostics.append(dict(id=k,candidate=j,reason=reason,evidence=evidence,pose=pose.tolist()))
                if evidence['valid']:
                    trusted=[models[a].mean(0) for a in fixed if decisions[a]['status']=='static']
                    positioned=transform(model,pose).mean(0)
                    discrepancies=[abs(np.linalg.norm(target.mean(0)-ref)-np.linalg.norm(positioned-ref)) for ref in trusted]
                    relational=np.exp(-np.mean(discrepancies)/cfg['relation_scale_m']) if trusted else 1.
                    weights[i,j]=evidence['utility']*(0.9+0.1*relational)
                    poses[i,j]=pose
        for i,(j,gap) in assignment(weights,cfg['assignment_margin']).items():
            k=movable[i]
            if any(a==i or b==j for a,b in unresolved):
                decisions[k]['reason']='unverified_competing_pair'
                continue
            pose=poses[i,j]
            move=float(np.linalg.norm(transform(models[k].mean(0),pose)-models[k].mean(0)))
            angle=float(np.degrees(np.arccos(np.clip((np.trace(pose[:3,:3])-1)/2,-1,1))))
            decisions[k].update(status='moved' if move>cfg['movement_m'] or angle>cfg['movement_deg'] else 'static',pose=pose.tolist(),movement_m=move,rotation_deg=angle,gap=gap,candidate=int(j))
            taken[candidates[j]]=True
            save('observed_'+k,candidates[j])
            layers.append(('T0 transformed '+k,transform(models[k],pose)))
            od.io.write_point_cloud(str(out/('reference_'+k+'.ply')),cloud(transform(models[k],pose)))
        for j,ids in enumerate(candidates):
            save('candidate_'+str(j),ids)
            layers.append((f'candidate {j}',points[ids]))
    for k in keys: decisions.setdefault(k,dict(status='held',reason='alignment_review' if not ok else 'no_experiment_setting'))
    remaining=np.flatnonzero(~structure & ~assigned & ~taken)
    save('unknown',remaining)
    layers.append(('unknown',points[remaining]))
    write(out/'unknown_manifest.json',dict(unclustered_ply='unknown.ply' if len(remaining) else None,points=len(remaining),candidates=[j for j,ids in enumerate(candidates) if not taken[ids].any()]))
    for k,d in decisions.items():
        if d['status']=='held' and 'reason' not in d:
            d['reason']='ambiguous_assignment' if any(x['id']==k and x.get('evidence',{}).get('valid') for x in diagnostics) else 'insufficient_identity_evidence'
    for item in diagnostics:
        d=decisions[item['id']]
        item['selected']=d.get('candidate')==item['candidate'] and d['status'] in ('static','moved')
    for n,k in zip(nodes,keys): n['t1_registration']=dict(decisions[k], last_confirmed_frame=job['frame_id'] if decisions[k]['status'] in ('static','moved') else n.get('last_confirmed_frame','T0'))
    from relations import update
    changes=update(graph,keys,models,decisions,cfg,job['frame_id'])
    write(out/'relation_diff.json',changes)
    write(out/'updated_scene_graph.json',graph)
    write(out/'diff.json',decisions)
    write(out/'candidates.json',diagnostics)
    fig=go.Figure()
    for name,p in layers:
        if len(p): fig.add_scatter3d(x=p[:,0],y=p[:,1],z=p[:,2],mode='markers',name=name,marker=dict(size=2))
    fig.update_layout(scene_aspectmode='data')
    fig.write_html(out/'overlay.html')
    write(out/'run.json',dict(icp_calls=icp_calls,elapsed_s=monotonic()-start,verified_alignment=ok))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('job')
    parser.add_argument('new_output')
    args=parser.parse_args()
    main(args.job,args.new_output)
