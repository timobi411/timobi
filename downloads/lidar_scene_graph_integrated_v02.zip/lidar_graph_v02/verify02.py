"""Deterministic integrated acceptance case with a translated multipart chair."""
import argparse
from pathlib import Path
import numpy as np
import open3d as od
from registration import cloud,write,read
from integrate02 import run,select
from geometry02 import View
from graph02 import update

def fixture(folder):
    folder.mkdir(parents=True)
    rng=np.random.default_rng(312)
    def shape(center,scale,n=250):
        return rng.uniform(-1,1,(n,3))*scale+center
    seat=shape([0,0,2],[.23,.15,.05])
    back=shape([0,.16,2.18],[.22,.04,.17])
    pole=shape([-.08,-.04,1.82],[.035,.04,.15])
    parts=dict(seat=seat,back=back,base=pole)
    models=dict(chair1=np.vstack(list(parts.values())),deskA=shape([-.55,0,2],[.15,.22,.2]),deskB=shape([1.5,.05,2],[.15,.22,.2]),shelf=shape([3.,0.,2],[.21,.23,.31]))
    shift=np.array([1.,.02,.04])
    xyz=np.vstack([models['deskA'],models['deskB'],seat+shift,back+shift,pole+shift])
    f=np.r_[np.full(500,-1),np.repeat([0,1,2],250)]
    def save(k,p):
        od.io.write_point_cloud(str(folder/(k+'.ply')),cloud(p))
    nodes=[]
    for k,p in models.items():
        save(k,p)
        nodes.append(dict(object_id=k,mobility='movable' if k=='chair1' else 'fixed',source_ply=k+'.ply',T_world_from_object=np.eye(4).tolist()))
    for k,p in parts.items(): save(k,p)
    nodes[0].update(parts=[dict(part_id=k,ply=k+'.ply') for k in parts],part_edges=[['seat','back'],['seat','base']])
    write(folder/'map.json',dict(map_version='synthetic_1',frame='world',nodes=nodes,edges=[dict(source='chair1',target='deskA',type='near')]))
    save('t1',xyz)
    np.save(folder/'f.npy',f)
    rays=np.vstack([xyz,models['shelf']*.5])
    ranges=np.linalg.norm(rays,axis=1)
    np.savez(folder/'rays.npz',directions=rays/ranges[:,None],ranges=ranges)
    job=dict(graph='map.json',t1_ply='t1.ply',observation_id='synthetic_t1',views=[dict(npz='rays.npz')],fragment_ids='f.npy',validated_seed_reason='known synthetic frame; separate deskB validation',checks={'deskB':list(range(250,500))},settings=dict(yaw_seeds_deg=[0],search_s=60,min_depth_m=.012))
    write(folder/'job.json',job)
    return models

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('new_dir',type=Path)
    a=ap.parse_args()
    models=fixture(a.new_dir)
    out=a.new_dir/'result'
    run(a.new_dir/'job.json',out)
    d=read(out/'decisions.json')
    print({k:(v['status'],v.get('fragments')) for k,v in d.items()})
    assert d['chair1']['status']=='moved' and len(d['chair1']['fragments'])==3
    assert d['shelf']['status']=='held'
    delta=read(out/'graph_delta.json')
    near=lambda edges:{frozenset((e['source'],e['target'])) for e in edges if e['type']=='near'}
    assert frozenset(('chair1','deskA')) in near(delta['removed_edges'])
    assert frozenset(('chair1','deskB')) in near(delta['added_edges'])
    labels=np.load(out/'point_labels.npz')
    assert (labels['object_id'][500:]=='chair1').mean()>.98
    assert len(set(labels['part_id'][500:])-set(['']))==3
    after=read(out/'graph_after.json')
    _,again=update(after,models,d,'synthetic_t1',read(Path(__file__).with_name('settings02.json')))
    assert not any(again.values())
    job=read(a.new_dir/'job.json')
    job['views']=[]
    write(a.new_dir/'ply_only.json',job)
    run(a.new_dir/'ply_only.json',a.new_dir/'ply_only')
    assert all(x['status']!='disappeared' for x in read(a.new_dir/'ply_only/decisions.json').values())
    rows=[dict(object_id=k,fragments=[3],score=.9) for k in ['A','B']]
    assert select(rows,{'margin':.05,'solve_s':2})==({},True)
