import argparse
import subprocess
import sys
from pathlib import Path
from time import monotonic
import numpy as np
import registration as r


def baseline(job, base, out, alignment):
    out.mkdir()
    start = monotonic()
    graph = r.read(base/job['graph'])
    nodes = {n.get('object_id',n.get('id')): n for n in graph['nodes']}
    keys = list(job['objects'])
    matrix = np.array(alignment['matrix'])
    xyz = r.transform(r.load(base/job['t1_ply']), matrix)
    origin = r.transform(np.array(job['views'][0]['origin']),matrix)
    local = r.cloud(xyz-origin)
    groups = r.v2.adaptive_recluster(local,r.v2.adaptive_core_expand_clustering(local,r.v2.MIN_CLUSTER_POINTS))
    def meta(i,p,path):
        return dict(merged_id=i,points=len(p),pcd=str(path),center=p.mean(0).tolist(),extent=np.ptp(p,axis=0).tolist())
    sources = []
    for i,k in enumerate(keys):
        path = base/job.get('paths',{}).get(k,nodes[k]['source_ply'])
        sources.append(meta(i,r.load(path),path))
    targets = []
    for i,ids in enumerate(groups):
        path = out/f'target_{i}.ply'
        r.od.io.write_point_cloud(str(path),r.cloud(xyz[ids]))
        np.save(out/f'target_{i}.indices.npy',ids)
        targets.append(meta(i,xyz[ids],path))
    r.write(out/'t0_merged_clusters.json',sources)
    r.write(out/'t1_merged_clusters.json',targets)
    for name,source in job.get('b0_files',{}).items():
        if Path(name).name!=name: raise ValueError(name)
        (out/name).symlink_to((base/source).resolve(strict=True))
    for script in ['baseline_icp_B0.py','baseline_assignment_B0.py']:
        if script=='baseline_assignment_B0.py':
            missing=[p for p in ('t0_temporal_median.pcd','t1_temporal_median.pcd','t0*_occlusion_data.npz','t1*_occlusion_data.npz') if not list(out.glob(p))]
            if missing:
                r.write(out/'run.json',dict(status='blocked_original_B0_inputs',missing=missing,elapsed_s=monotonic()-start))
                return
        with (out/(script+'.log')).open('w') as stream:
            subprocess.run([sys.executable,str(Path(__file__).with_name(script).resolve())],cwd=out,stdout=stream,stderr=subprocess.STDOUT,check=True)
    pairs = r.read(out/'partial_icp_results_fixed_repro.json')
    if isinstance(pairs,dict): pairs=pairs['results']
    assignment = r.read(out/'hungarian_assignment_fixed_repro.json')
    decisions = {k:dict(status='held') for k in keys}
    for item in assignment['matched']:
        decisions[keys[item['t0_id']]]=dict(status=item['state'].lower(),candidate=item['t1_id'])
    r.write(out/'diff.json',decisions)
    r.write(out/'run.json',dict(elapsed_s=monotonic()-start,icp_calls=sum(x.get('start_yaw_deg') is not None for x in pairs)))


def metrics(folder,truth):
    result=r.read(folder/'run.json')
    if not (folder/'diff.json').exists(): return result
    dec=r.read(folder/'diff.json')
    result.update(held=sum(x['status'] not in ('moved','static') for x in dec.values()),correct_id=None,wrong_id=None,false_moved=None)
    if not truth: return result
    result.update(correct_id=0,wrong_id=0,false_moved=0,split_errors={},translation_errors_m=[],rotation_errors_deg=[])
    for k,t in truth['objects'].items():
        d=dec[k]
        if d['status'] not in ('moved','static'): continue
        idx=d.get('candidate')
        name=(('target_' if folder.name=='B0' else 'candidate_')+str(idx)) if idx is not None else 'fixed_'+k
        path=folder/(name+'.indices.npy')
        ids=set(np.load(path).tolist()) if path.exists() else set()
        expected=set(t['t1_indices'])
        correct=len(ids&expected)/max(1,len(ids|expected))>=truth['iou_threshold']
        result['correct_id' if correct else 'wrong_id']+=1
        result['false_moved']+=int(d['status']=='moved' and not t['moved'])
        if correct and 'pose' in t and 'pose' in d:
            error=np.linalg.inv(r.rigid(t['pose'])) @ r.rigid(d['pose'])
            result['translation_errors_m'].append(float(np.linalg.norm(error[:3,3])))
            result['rotation_errors_deg'].append(float(np.degrees(np.arccos(np.clip((np.trace(error[:3,:3])-1)/2,-1,1)))))
    for k,ids in truth.get('fixed_indices',{}).items():
        p=folder/('fixed_'+k+'.indices.npy')
        if p.exists():
            actual=set(np.load(p).tolist())
            result['split_errors'][k]=dict(extra=len(actual-set(ids)),missed=len(set(ids)-actual))
    return result


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('job',type=Path)
    ap.add_argument('output',type=Path)
    ap.add_argument('--truth',type=Path)
    args=ap.parse_args()
    out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=False)
    base=args.job.resolve().parent
    job=r.read(args.job)
    for mode in ['improved','no_visibility']:
        variant=dict(job,mode=mode)
        for key in ['graph','config','t1_ply','adaptive_icp_v11','experimental_icp','unknown_manifest','exp001_condition_dir']:
            if key in variant: variant[key]=str(base/variant[key])
        graph=r.read(variant['graph'])
        variant['paths']={k:str(base/job.get('paths',{}).get(k,n['source_ply'])) for n in graph['nodes'] for k in [n.get('object_id',n.get('id'))]}
        variant['views']=[dict(v,rays_npz=str(base/v['rays_npz'])) for v in job['views']]
        path=out/(mode+'.json')
        r.write(path,variant)
        r.main(path,out/mode)
    baseline(job,base,out/'B0',r.read(out/'improved/alignment.json'))
    truth=r.read(args.truth) if args.truth else None
    r.write(out/'comparison.json',{s:metrics(out/s,truth) for s in ['improved','no_visibility','B0']})
