# exp001 床・壁・天井除去の比較

前回版の登録入口は registration.py です。今回追加した exp001.py はXYZの比較を独立して実行します。結果を確認してから、採用した条件を registration.py に渡せます。

## 合成データで起動を確認

```bash
python -m pip install numpy scipy open3d plotly rosbags pillow pyyaml
python exp001_fixture.py demo
python exp001_check.py demo demo_result
```

demo_result/comparison.html のボタンで視点を保って表示を切り替えます。metrics.csv の median_m と p90_m は評価用の背景点に対する絶対残差、background_remaining は背景残存率、furniture_removed は家具部位の誤除去率です。cluster_counts の -1 は残った未クラスタ点、shared_with は同じクラスタに入った他の評価ラベルです。評価点がない指標は空欄になります。

## exp001 の静止区間を選ぶ

```bash
rec=real_experiment/exp001/rosbag_extract.QPvAdy/20261113T091929Z_environment48_03_04b64c
python exp001_bag.py "$rec" real_experiment/exp001/preview_new --stride 120
```

時刻付きの距離画像で家具移動後の区間を絞ります。静止は連続フレームでも確認してください。開始番号は対象topic内の0始まりです。例の START を選んだ番号に置き換えます。

```bash
python exp001_bag.py "$rec" real_experiment/exp001/window_new --start START --count 11
python exp001.py real_experiment/exp001/window_new/window.npz pilot_fixed.json real_experiment/exp001/compare_new
```

recording.json と organized PointCloud2 の幅・高さ・行パディング・エンディアン・XYZの型を読んで代表点群を作ります。フレーム時刻はheader stampのns、previewのファイル名はbag時刻のnsです。ピクセルごとの有効観測数を pixels.npz に記録します。PLYと indices.npz は同じセンサー座標の代表点順です。

## 予備確認で設定する項目

demo/config.json を別名でコピーして編集します。recording_id を実収録ID、up をセンサー座標で確認した上向き単位ベクトルに設定します。比較用座標は up を +Z に回した座標で、回転行列を input.json に保存します。各面の fit、eval、support はこの座標での [下限XYZ, 上限XYZ]、単位はmです。fit は面推定、eval は独立評価、support は目視で背景を確認した範囲に限定します。支持セルは support 内の距離整合点から作ります。eval 内の点を含むボクセルはA〜Dの平面係数推定から除きます。Aは残りの点に既存V2の設定で平面を推定し、その有限マスクを共通入力に適用します。

surfaces に床・各壁・天井を個別に登録し、小上がりも見えていれば別面にします。kind は floor、wall、ceiling、platform。height_m は支持点の中央高さの許容区間です。labels は画像の行×幅＋列のリストです。背景ラベル名は面名とそろえ、家具は chair_leg、table_top、bookshelf など別名にします。実験前に同じ設定ファイルを固定します。

CとDは同じRANSAC結果を共有します。Dのcutoffは初期支持点のMADから決めて固定します。remove_m は独立です。条件別のrun.jsonには係数と理由、fallback_countがあります。合成データの validation/exp001 は実収録の成績には使えません。C対Dは部位ごとの誤除去と背景残存、保留・フォールバックを見て採否を決めます。

## 後段で使う

experiment.json の t1_ply に compare_new/representative.ply を指定し、exp001_condition_dir に採用した条件のフォルダ（例 compare_new/D）を指定します。SHA256が違う点群を渡すと停止します。固定基準の位置合わせには背景を含む全点と元の視線を使い、個体の割当・unknown出力からは採用した背景を除きます。anchor_indices は representative.ply の0始まり番号です。採用条件を決めるまで従来のジョブを使用できます。

## RGBの動作確認

deployment(2).zip の環境で camera_lidar_calibration.offline_color の実際のCLIオプションを確認してください。exp001_rgb.py run PROFILE.json NEW_OUTPUT は同じ取付を確認した記録、校正YAMLのSHA256、合成した T_optical_from_ylm と実行引数を保存します。profileには same_mount_confirmed、calibration_yaml、rosbag、yaml_keys_mid360_from_color_optical と yaml_keys_mid360_from_ylm（YAML内の各4×4行列へのキー列）、offline_color_arguments（実CLIの引数配列）を設定します。引数配列の {bag}、{calibration}、{output}、{start}、{frames}、{offset_ms}、{max_range_m} を実行時に展開します。初期値は開始0、12フレーム、−130 ms、3 mです。bag内のRGB・depth・CameraInfo・内部TFは既存モジュールの入力に設定してください。実際のYAML構造・CLIとの接続はdeployment受領後の確認事項です。

投影結果から ylm_ns,rgb_ns,depth_ns,eligible_points,colored_points の12行のCSVを用意し、exp001_rgb.py audit INPUT.csv NEW.csv で補正後の時刻差と着色率を確認します。実画像の輪郭ずれは重ね合わせ画像で確認します。本番は選んだT1区間を使います。次段の局所法線・円柱推定は平面除去条件の採用後の比較項目です。
