"""Exercise disappearance, first observation, and confirmed appearance separately."""
from pathlib import Path
import sys
import numpy as np
import open3d as od
from geometry02 import correction,View
from registration import read,write,load,cloud
from verify02 import fixture
from integrate02 import run

folder=Path(sys.argv[1])
fixture(folder)
job=read(folder/'job.json')
model=load(folder/'shelf.ply')
points=load(folder/'t1.ply')
new=model+[1.,.4,0.]
points=np.vstack((points,new))
od.io.write_point_cloud(str(folder/'t1.ply'),cloud(points))
np.save(folder/'f.npy',np.r_[np.load(folder/'f.npy'),np.full(len(new),8)])
def rays(name,pts):
    r=np.linalg.norm(pts,axis=1)
    np.savez(folder/name,directions=pts/r[:,None],ranges=r)
rays('new.npz',np.vstack((points,model*1.4)))
rays('old.npz',new*1.4)
job.update(views=[{'npz':'new.npz'}],old_views=[{'npz':'old.npz'}],confirmed_new_fragments=[8])
write(folder/'job.json',job)
run(folder/'job.json',folder/'run')
d=read(folder/'run/decisions.json')
assert d['shelf']['status']=='disappeared',d['shelf']
assert sum(x['status']=='appeared' for x in d.values())==1
job['old_views']=[]
write(folder/'no_old.json',job)
run(folder/'no_old.json',folder/'no_old')
assert not any(x['status']=='appeared' for x in read(folder/'no_old/decisions.json').values())
cfg=read(Path(__file__).with_name('settings02.json'))
# Two independent corner-shaped fixed objects plus an unused validation target.
u,v=np.meshgrid(np.linspace(-.24,.24,13),np.linspace(-.24,.24,13))
plane=np.column_stack((u.ravel(),v.ravel(),np.zeros(u.size)))
corner=np.vstack((plane+[0,0,2],plane[:,[0,2,1]]+[0,-.3,2],plane[:,[2,1,0]]+[-.3,0,2]))
models={k:corner+[i,0,0] for i,k in enumerate('abc')}
p=np.vstack(list(models.values()))
r=np.linalg.norm(p,axis=1)
def build(m):
    return [View(m[:3,3],(p/r[:,None])@m[:3,:3].T,r)]
seed=np.eye(4)
seed[:3,3]=[.004,-.003,.002]
n=len(corner)
m,ok,diag=correction(p,models,{'a':np.arange(n),'b':np.arange(n,2*n)},{'c':np.arange(2*n,3*n)},seed,build,cfg)
assert ok and np.linalg.norm(m[:3,3])<.003,(m,diag)
print('Independent anchor correction, disappearance and appearance checks passed.')
