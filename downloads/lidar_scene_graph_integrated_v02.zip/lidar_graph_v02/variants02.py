"""Run controlled comparisons using the same frozen job and original point indices."""
import argparse
from pathlib import Path
from integrate02 import run
from registration import read,write


def variants(source,out):
    job=read(source)
    base=source.resolve().parent
    out.mkdir(parents=True,exist_ok=False)
    for key in ('graph','t1_ply','icp_adapter','fragment_ids','exp001_condition_dir','floating_indices','point_provenance'):
        if key in job: job[key]=str((base/job[key]).resolve())
    # Model and part paths are relative to the original job.
    graph=read(job['graph'])
    for n in graph['nodes']:
        n['source_ply']=str((base/job.get('paths',{}).get(n['object_id'],n['source_ply'])).resolve())
        for p in n.get('parts',[]): p['ply']=str((base/p['ply']).resolve())
    write(out/'input_graph.json',graph)
    job['graph']=str((out/'input_graph.json').resolve())
    job.pop('paths',None)
    for v in job.get('views',[])+job.get('old_views',[]): v['npz']=str((base/v['npz']).resolve())
    modes={'full':{},'single':{'common_pose':False},'no_parts':{'part_edges':False},'no_rays':{'use_rays':False},
           'common_only':{'part_edges':False,'use_rays':False},'no_relations':{'room_relations':False},'no_fixed_first':{'fixed_first':False}}
    for mode,changes in modes.items():
        j=dict(job,settings={**job.get('settings',{}),**changes})
        config=out/(mode+'.json')
        write(config,j)
        run(config,out/mode)
    for name,value in job.get('frozen_fragment_inputs',{}).items():
        if name not in ('fixed_merge','occlusion_assisted'): raise ValueError(name)
        config=out/(name+'.json')
        write(config,dict(job,fragment_ids=str((base/value).resolve()),settings={**job.get('settings',{}),'common_pose':False}))
        run(config,out/name)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('job',type=Path)
    ap.add_argument('new_output',type=Path)
    a=ap.parse_args()
    variants(a.job,a.new_output)
