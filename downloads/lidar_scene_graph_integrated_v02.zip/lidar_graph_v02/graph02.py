from copy import deepcopy
import numpy as np
from scipy.spatial import cKDTree
from registration import transform


def update(graph,models,decisions,obs,c):
    after=deepcopy(graph)
    nodes={n['object_id']:n for n in after['nodes']}
    if len(nodes)!=len(after['nodes']): raise ValueError('Duplicate object IDs')
    changed=set()
    changes=[]
    for k,d in decisions.items():
        if d['status']=='held': continue
        old=deepcopy(nodes.get(k))
        node=nodes.setdefault(k,{'object_id':k,'mobility':'unknown','T_world_from_object':np.eye(4).tolist()})
        history=node.setdefault('history',[])
        if any(h['decision_id']==d['decision_id'] for h in history): continue
        history.append(dict(decision_id=d['decision_id'],status=d['status'],observation_id=obs))
        node['active']=d['status']!='disappeared'
        if 'pose' in d:
            node['T_world_from_object']=(np.array(d['pose'])@np.array(node.get('T_world_from_object',np.eye(4)))).tolist()
        if d['status'] in ('moved','appeared','disappeared'): changed.add(k)
        changes.append(dict(id=k,before=old,after=deepcopy(node)))
    after['nodes']=list(nodes.values())
    edges=after.get('edges',[])
    seen=set()
    kept=[]
    removed=[]
    for e in edges:
        a,b,t=e['source'],e['target'],e['type']
        sig=(tuple(sorted((a,b))) if t=='near' else (a,b),t)
        if a==b or a not in nodes or b not in nodes or sig in seen: raise ValueError('Invalid edge '+str(sig))
        seen.add(sig)
        if changed.intersection((a,b)) and (t in ('near','on') or not (nodes[a].get('active',True) and nodes[b].get('active',True))): removed.append(e)
        else: kept.append(e)
    added=[]
    keys=sorted(k for k in models if nodes[k].get('active',True))
    def relations(a,b):
        x,y=models[a],models[b]
        result=[]
        threshold=c['wall_near_m'] if 'T0_W001' in (a,b) else c['near_m']
        if cKDTree(x).query(y)[0].min()<=threshold:
            result.append(dict(source=a,target=b,type='near'))
        for top,base,p,q in [(a,b,x,y),(b,a,y,x)]:
            xy=np.maximum(0,np.minimum(p.max(0)[:2],q.max(0)[:2])-np.maximum(p.min(0)[:2],q.min(0)[:2]))
            if xy.prod()/max(1e-9,np.ptp(p,axis=0)[:2].prod())>=c['on_overlap'] and abs(p[:,2].min()-q[:,2].max())<=c['on_gap_m'] and p[:,2].mean()>q[:,2].mean():
                result.append(dict(source=top,target=base,type='on'))
        return result
    for i,a in enumerate(keys):
        for b in keys[i+1:]:
            if changed.intersection((a,b)): added.extend(relations(a,b))
    def signature(e):
        a,b=e['source'],e['target']
        return (e['type'],*sorted((a,b))) if e['type']=='near' else (e['type'],a,b)
    prior={signature(e):e for e in removed}
    fresh={signature(e):e for e in added}
    after['edges']=kept+[prior.get(k,e) for k,e in fresh.items()]
    return after,dict(nodes=changes,removed_edges=[e for k,e in prior.items() if k not in fresh],added_edges=[e for k,e in fresh.items() if k not in prior])
