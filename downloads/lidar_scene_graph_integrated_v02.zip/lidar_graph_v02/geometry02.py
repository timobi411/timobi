"""Rigid geometric matching and per-view foreground range evidence."""
import numpy as np
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
from registration import transform, normals, rigid


class View:
    def __init__(self, origin, directions, ranges, shape=None, jump=.12):
        self.origin=np.asarray(origin,float)
        d=np.asarray(directions,float).reshape(-1,3)
        r=np.asarray(ranges,float).reshape(-1)
        if len(d)!=len(r): raise ValueError('Ray count mismatch')
        valid=np.isfinite(r)&(r>0)
        edge=np.zeros(len(r),bool)
        if shape is not None:
            image=r.reshape(shape)
            v=valid.reshape(shape)
            e=edge.reshape(shape)
            for ax in (0,1):
                a,b=(slice(1,None),slice(None,-1))
                first=(a,slice(None)) if ax==0 else (slice(None),a)
                second=(b,slice(None)) if ax==0 else (slice(None),b)
                boundary=(v[first]!=v[second]) | (abs(image[first]-image[second])>jump)
                e[first]|=boundary
                e[second]|=boundary
        norm=np.linalg.norm(d,axis=1)
        good=np.isfinite(norm)&(norm>0)
        self.d=d[good]/norm[good,None]
        self.r=r[good]
        self.edge=edge[good]
        self.tree=cKDTree(self.d)
        self.pixel=np.flatnonzero(good)
        self.shape=shape

    def project(self, points,c):
        # Values -1 hidden, 0 unknown, 1 surface, 2 occluded, 3 traversed.
        state=np.zeros(len(points),np.int8)
        boundary=np.zeros(len(points),bool)
        self.diagnostic={'isolated_model_rays':None,'contiguous_occluder_rays':None}
        if not len(self.d): return state,boundary
        v=points-self.origin
        length=np.linalg.norm(v,axis=1)
        delta,j=self.tree.query(v/np.maximum(length[:,None],1e-12))
        axial=np.sum(v*self.d[j],axis=1)
        lateral=np.linalg.norm(v-axial[:,None]*self.d[j],axis=1)
        ids=np.flatnonzero((axial>0)&(delta<=2*np.sin(np.radians(c['ray_angle_deg'])/2))&(lateral<=c['ray_width_m']))
        order=ids[np.argsort(axial[ids],kind='stable')]
        _,first=np.unique(j[order],return_index=True)
        state[ids]=-1
        front=order[first]
        state[front]=0
        ids=front[np.isfinite(self.r[j[front]])&(self.r[j[front]]>0)]
        boundary[ids]=self.edge[j[ids]]
        error=self.r[j[ids]]-axial[ids]
        tau=c['depth_noise_m']+c['align_error_m']+c['range_factor']*axial[ids]
        state[ids]=np.where(abs(error)<=tau,1,np.where(error<0,2,3))
        if self.shape is not None:
            from scipy.ndimage import convolve
            footprint=np.zeros(self.shape,np.int8)
            footprint.flat[self.pixel[j[front]]]=1
            adjacent=convolve(footprint,np.ones((3,3),np.int8),mode='constant')
            thin=adjacent.flat[self.pixel[j[ids]]]<=2
            boundary[ids[thin]]=True
            occluders=np.zeros(self.shape,np.int8)
            occluders.flat[self.pixel[j[ids[state[ids]==2]]]]=1
            neighbors=convolve(occluders,np.ones((3,3),np.int8),mode='constant')
            self.diagnostic=dict(isolated_model_rays=int(thin.sum()),contiguous_occluder_rays=int(((neighbors>1)&(occluders>0)).sum()))
        return state,boundary


def evidence(points,views,c):
    states=[]
    for v in views:
        s,b=v.project(points,c)
        states.append((s,b))
    support=np.zeros(len(points),bool)
    passed=support.copy()
    occ=support.copy()
    boundary=support.copy()
    for s,b in states:
        support|=(s==1)&~b
        passed|=(s==3)&~b
        occ|=(s==2)&~b
        boundary|=b
    counts=dict(match=int(support.sum()),passed=int(passed.sum()),occluded=int(occ.sum()),boundary=int(boundary.sum()),
                unknown=int((~(support|passed|occ)).sum()),per_view=[dict(hidden=int((s<0).sum()),unknown=int((s==0).sum()),edge=int(b.sum())) for s,b in states],organized_diagnostics=[v.diagnostic.copy() for v in views])
    return support,passed,counts


def correction(points,models,anchors,checks,seed,make_views,c):
    def residual(m):
        return {k:np.percentile(cKDTree(models[k]).query(transform(points[idx],m))[0],[50,90]).tolist() for k,idx in checks.items()}
    before=residual(seed)
    m=seed.copy()
    reason='insufficient_support'
    after=before
    for _ in range(c['align_steps']):
        rows=[]
        rhs=[]
        for k,idx in anchors.items():
            model=models[k]
            vis=evidence(model,make_views(m),c)[0]
            if vis.sum()<c['min_points']: continue
            dst=model[vis]
            n,stable=normals(dst,c['neighbors'])
            x=transform(points[idx],m)
            dist,j=cKDTree(dst).query(x)
            keep=(dist<c['align_search_m'])&stable[j]
            if keep.sum()<c['min_points']: continue
            x=x[keep]
            j=j[keep]
            error=np.sum(n[j]*(x-dst[j]),axis=1)
            w=np.sqrt(1/len(j)/np.maximum(1,abs(error)/c['surface_m']))
            rows.append(np.column_stack((np.cross(x,n[j]),n[j]))*w[:,None])
            rhs.append(-error*w)
        if len(rows)<c['min_anchors']: break
        twist,_,rank,_=np.linalg.lstsq(np.vstack(rows),np.concatenate(rhs),rcond=c['rank_tol'])
        if rank<6:
            reason='unconstrained'
            break
        inc=np.eye(4)
        inc[:3,:3]=Rotation.from_rotvec(twist[:3]).as_matrix()
        inc[:3,3]=twist[3:]
        m=inc@m
        if np.linalg.norm(twist)<1e-5:
            after=residual(m)
            if checks and all(v[1]<=c['validation_p90_m'] and v[1]<=before[k][1]+c['validation_slack_m'] for k,v in after.items()):
                return m,True,dict(reason='independent_validation',before=before,after=after)
            reason='validation_failed'
            break
    else:
        reason='nonconvergence'
        after=residual(m)
    return seed,False,dict(reason=reason,before=before,after=after)


def fit(src,dst):
    a,b=src.mean(0),dst.mean(0)
    u,_,vt=np.linalg.svd((src-a).T@(dst-b))
    r=vt.T@u.T
    if np.linalg.det(r)<0:
        vt[-1]*=-1
        r=vt.T@u.T
    m=np.eye(4)
    m[:3,:3]=r
    m[:3,3]=b-r@a
    return m


def refine(model,target,pose,c):
    tree=cKDTree(model)
    for _ in range(c['icp_steps']):
        dist,idx=tree.query(transform(target,np.linalg.inv(pose)))
        keep=dist<c['icp_gate_m']
        if keep.sum()<c['min_points']: break
        src=model[idx[keep]]
        if np.linalg.matrix_rank(src-src.mean(0))<2: break
        new=fit(src,target[keep])
        diff=np.max(abs(new-pose))
        pose=new
        if diff<1e-6: break
    return pose
