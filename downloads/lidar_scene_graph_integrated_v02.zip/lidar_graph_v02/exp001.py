"""Compare four structure-removal conditions on one organized T1 window."""
import argparse
import csv
import hashlib
import json
import warnings
from pathlib import Path
from time import perf_counter
from unittest.mock import patch

import numpy as np
import open3d as od
import plotly.graph_objects as go
from scipy.spatial.transform import Rotation
import adaptive_clustering_V2 as v2


def save_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False))


def cloud(points):
    return od.geometry.PointCloud(od.utility.Vector3dVector(points))


def ply(path, points):
    if len(points):
        if not od.io.write_point_cloud(str(path), cloud(points)):
            raise IOError(path)
    else:
        path.write_text('ply\nformat ascii 1.0\nelement vertex 0\nproperty float x\nproperty float y\nproperty float z\nend_header\n')


def representative(window, cfg):
    xyz = window['xyz'].astype(float)
    frames, ids, times = (window[k] for k in ('frame_id','message_id','timestamp_ns'))
    if (xyz.ndim != 4 or xyz.shape[-1] != 3 or len(xyz) != cfg['frames']
            or any(len(x)!=len(xyz) for x in (frames,ids,times)) or len(set(frames))!=1
            or not np.all(np.diff(ids)==1) or np.any(np.diff(times)<=0)):
        raise ValueError('Expected one consecutive organized window in one frame')
    valid = np.isfinite(xyz).all(-1)
    ranges = np.linalg.norm(xyz,axis=-1)
    valid &= (ranges>=.05) & (ranges<=v2.MAX_RANGE)
    if not 1<=cfg['min_observations']<=len(xyz): raise ValueError('Invalid minimum observations')
    xyz[~valid]=np.nan
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',RuntimeWarning)
        median=np.nanmedian(xyz,axis=0)
    counts=valid.sum(0)
    pixels=np.flatnonzero(counts>=cfg['min_observations'])
    return median.reshape(-1,3)[pixels],pixels,counts


def inside(points,box):
    low,high=np.array(box)
    if not np.all(low<high): raise ValueError('Invalid region bounds')
    return ((points>=low)&(points<high)).all(1)


def fit(p,w):
    if np.count_nonzero(w)>2:
        center=np.average(p,axis=0,weights=w)
        _,s,v=np.linalg.svd((p-center)*np.sqrt(w[:,None]),full_matrices=False)
        if s[1]>max(s[0]*1e-6,1e-10):
            return np.r_[v[-1],-v[-1]@center]
    raise ValueError('linear_or_insufficient_support')


def cells(p,model,width):
    n=model[:3]
    u=np.cross(n,np.eye(3)[np.argmin(abs(n))])
    u/=np.linalg.norm(u)
    return np.floor(p@np.stack([u,np.cross(n,u)]).T/width).astype(np.int64)


def support(p,m,s,c):
    dist=abs(p@m[:3]+m[3])
    mask=dist<=c['inlier_m']
    q=p[mask]
    if len(q)<c['min_support']: raise ValueError('low_support')
    horizontal=s['kind']!='wall'
    dot=abs(m[2])
    if (horizontal and dot<np.cos(np.radians(c['angle_deg']))) or (not horizontal and dot>np.sin(np.radians(c['angle_deg']))):
        raise ValueError('normal_constraint')
    if not s['height_m'][0]<=np.median(q[:,2])<=s['height_m'][1]: raise ValueError('height_constraint')
    spread=np.linalg.svd(q-q.mean(0),compute_uv=False)/np.sqrt(len(q))
    if spread[1]<c['min_spread_m']: raise ValueError('linear_support')
    occupied=np.unique(cells(q,m,c['cell_m']),axis=0)
    if len(occupied)*c['cell_m']**2<c['min_area_m2']: raise ValueError('area_constraint')
    return mask,occupied


def ransac(p,s,c,rng):
    if len(p)<3: raise ValueError('insufficient_candidates')
    best=None
    rank=(0,-np.inf)
    for _ in range(c['trials']):
        a,b,d=p[rng.choice(len(p),3,replace=False)]
        n=np.cross(b-a,d-a)
        length=np.linalg.norm(n)
        if length<1e-9: continue
        n/=length
        m=np.r_[n,-n@a]
        try: mask,_=support(p,m,s,c)
        except ValueError: continue
        score=(int(mask.sum()),-np.median(abs(p[mask]@n+m[3])))
        if score>rank: best,rank=m,score
    if best is None: raise ValueError('no_valid_ransac')
    return best


def tukey(p,m,s,c,log):
    mask,_=support(p,m,s,c)
    r=p[mask]@m[:3]+m[3]
    cutoff=float(np.clip(4.685*1.4826*np.median(abs(r-np.median(r))),*c['cutoff_bounds_m']))
    log['cutoff_m']=cutoff
    for i in range(c['iterations']):
        log['iterations']=i+1
        r=(p@m[:3]+m[3])/cutoff
        w=np.maximum(0,1-r*r)**2
        if np.count_nonzero(w)<c['min_support']: raise ValueError('low_weighted_support')
        updated=fit(p,w)
        if updated[:3]@m[:3]<0: updated=-updated
        support(p,updated,s,c)
        if np.degrees(np.arccos(np.clip(updated[:3]@m[:3],-1,1)))<=c['converge_deg'] and abs(updated[3]-m[3])<=c['converge_m']:
            return updated
        m=updated
    raise ValueError('nonconvergence')


def compare(window_path,config_path,out):
    cfg=json.loads(config_path.read_text())
    out.mkdir(parents=True,exist_ok=False)
    window=np.load(window_path,allow_pickle=False)
    if 'recording_id' in window and str(window['recording_id'])!=cfg['recording_id']:
        raise ValueError('Recording ID differs from frozen config')
    if len(set(s['name'] for s in cfg['surfaces']))!=len(cfg['surfaces']) or not cfg['surfaces']:
        raise ValueError('Specify uniquely named structure regions')
    raw,pixels,counts=representative(window,cfg)
    if not len(raw): raise ValueError('No representative points')
    up=np.asarray(cfg['up'],float)
    if not np.isclose(np.linalg.norm(up),1): raise ValueError('up must be a unit vector')
    rot=Rotation.align_vectors([[0,0,1]],[up])[0]
    p=rot.apply(raw)
    save_json(out/'config.json',cfg)
    digest=hashlib.sha256(raw.astype('<f8').tobytes()).hexdigest()
    save_json(out/'input.json',dict(sha256=digest,points=len(raw),rotation_to_analysis=rot.as_matrix().tolist(),
        shape=list(counts.shape),**{k:window[k].tolist() for k in ('frame_id','message_id','timestamp_ns')},recording_id=cfg['recording_id']))
    np.savez_compressed(out/'pixels.npz',representative_pixels=pixels,valid_counts=counts)
    ply(out/'representative.ply',raw)
    # Common Open3D voxels with the complete original membership of each voxel.
    voxel,_,trace=cloud(p).voxel_down_sample_and_trace(v2.VOXEL_SIZE,p.min(0)-v2.VOXEL_SIZE/2,p.max(0)+v2.VOXEL_SIZE/2)
    q=np.asarray(voxel.points)
    parent=np.empty(len(p),int)
    for i,rows in enumerate(trace): parent[np.asarray(rows)]=i
    reserved=np.zeros(len(q),bool)
    for surface in cfg['surfaces']:
        reserved[parent[inside(p,surface['eval'])]]=True
    rng=np.random.default_rng(cfg['seed'])
    seeds={}
    labels=cfg.get('labels',{})
    def annotation(name):
        rows=np.asarray(labels.get(name,[]),int)
        if np.any((rows<0)|(rows>=counts.size)): raise ValueError('Annotation pixel outside image')
        return np.isin(pixels,rows)
    metrics=[]
    fig=go.Figure()
    for method in 'ABCD':
        start=perf_counter()
        dest=out/method
        dest.mkdir()
        removed=np.zeros(len(q),bool)
        actual=np.zeros(len(p),bool)
        logs=[]
        baseline_models=[]
        native=[]
        if method=='A':
            original=v2.finite_plane_band_mask
            def capture(points,plane,*args):
                baseline_models.append(np.asarray(plane['model']))
                native.append(dict(model=np.asarray(plane['model']).tolist(), support=int(plane['point_count']),band_m=args[0],footprint_margin_m=args[1]))
                removed[:] |= original(q,plane,*args)
                actual[:] |= original(p,plane,*args)
                return original(points,plane,*args)
            od.utility.random.seed(cfg['seed'])
            with patch.object(v2,'finite_plane_band_mask',capture):
                v2.remove_room_structures(cloud(q[~reserved]))
        for region in cfg['surfaces']:
            name=region['name']
            train=inside(q,region['fit']) & ~reserved
            evalbox=region['eval']
            if np.all(np.minimum(region['fit'][1],evalbox[1])>np.maximum(region['fit'][0],evalbox[0])):
                raise ValueError('Fit and evaluation boxes overlap: '+name)
            pp=q[train]
            test=inside(p,evalbox)&annotation(name)
            log=dict(surface=name,iterations=0,fallback=False,fit_voxels=int(train.sum()))
            m=None
            try:
                if method=='A':
                    # Associate the already fitted native planes using the designated training ROI.
                    eligible=[m for m in baseline_models if abs(m[2])<(0.5 if region['kind']=='wall' else 2)]
                    if region['kind']!='wall': eligible=[m for m in eligible if abs(m[2])>.5]
                    if not eligible or not len(pp): raise ValueError('no_native_plane')
                    m=min(eligible,key=lambda x:np.median(abs(pp@x[:3]+x[3])))
                elif method=='B': m=fit(pp,np.ones(len(pp)))
                elif method=='C':
                    m=ransac(pp,region,cfg,rng)
                    seeds[name]=m.copy()
                else:
                    if name not in seeds: raise ValueError('C_held')
                    m=seeds[name]
                    try: m=tukey(pp,m,region,cfg,log)
                    except ValueError as error: log.update(fallback=True,reason=str(error))
                if method!='A':
                    mask,occupied=support(pp,m,region,cfg)
                    # Extend support only from independently specified structure support ROI.
                    candidates=inside(q,region['support']) & (abs(q@m[:3]+m[3])<=cfg['inlier_m'])
                    occupied=np.unique(cells(q[candidates],m,cfg['cell_m']),axis=0)
                    occupied_set=set(map(tuple,occupied))
                    footprint=np.array([tuple(x) in occupied_set for x in cells(q,m,cfg['cell_m'])])
                    removed |= footprint & (abs(q@m[:3]+m[3])<=cfg['remove_m'])
                    raw_footprint=np.array([tuple(x) in occupied_set for x in cells(p,m,cfg['cell_m'])])
                    actual |= raw_footprint & (abs(p@m[:3]+m[3])<=cfg['remove_m'])
                    log.update(support=int(mask.sum()),cells=len(occupied))
                log['model']=m.tolist()
            except ValueError as error:
                m=None
                log['held']=str(error)
            residual=abs(p[test]@m[:3]+m[3]) if m is not None else []
            metrics.append(dict(method=method,group=name,n=int(test.sum()),median_m=float(np.median(residual)) if len(residual) else None,p90_m=float(np.percentile(residual,90)) if len(residual) else None,fallback=int(log['fallback']),held=log.get('held')))
            logs.append(log)
        # Cluster voxels of surviving measurements; no removed point can contribute.
        surviving=np.flatnonzero(~actual)
        if len(surviving):
            rest,_,groups_raw=cloud(p[surviving]).voxel_down_sample_and_trace(v2.VOXEL_SIZE,p.min(0)-v2.VOXEL_SIZE/2,p.max(0)+v2.VOXEL_SIZE/2)
            local_points=np.asarray(rest.points)
        else:
            local_points=np.empty((0,3))
            groups_raw=[]
        free=np.arange(len(local_points))
        cid=np.full(len(free),-1)
        if len(free):
            local=cloud(local_points)
            groups=v2.adaptive_recluster(local,v2.adaptive_core_expand_clustering(local,v2.MIN_CLUSTER_POINTS))
            for i,idx in enumerate(groups):
                cid[free[np.asarray(idx,int)]]=i
        point_ids=np.full(len(p),-1)
        for j,rows in enumerate(groups_raw): point_ids[surviving[np.asarray(rows)]]=cid[j]
        np.savez_compressed(dest/'indices.npz',removed=np.flatnonzero(actual),remaining=np.flatnonzero(~actual),cluster_id=point_ids)
        for i in np.unique(point_ids[point_ids>=0]): ply(dest/f'cluster_{i}.ply',raw[point_ids==i])
        ply(dest/'removed.ply',raw[actual])
        ply(dest/'remaining.ply',raw[~actual])
        for label in labels:
            subset=annotation(label)
            surface=next((s for s in cfg['surfaces'] if s['name']==label),None)
            if surface: subset &= inside(p,surface['eval'])
            ids,n=np.unique(point_ids[subset & ~actual],return_counts=True)
            clusters=ids[ids>=0]
            sharing={str(i):[other for other in labels if other!=label and np.any(annotation(other)&(point_ids==i))] for i in clusters}
            metrics.append(dict(method=method,group=label,n=int(subset.sum()),background_remaining=float((~actual[subset]).mean()) if surface and subset.any() else None,
                furniture_removed=float(actual[subset].mean()) if not surface and subset.any() else None,cluster_count=len(clusters),shared_with=json.dumps(sharing,ensure_ascii=False),cluster_counts=json.dumps(dict(zip(ids.astype(str),n.tolist())))))
        save_json(dest/'run.json',dict(input_sha256=digest,points=len(raw),seconds=perf_counter()-start,planes=logs,native=native,fallback_count=sum(int(z['fallback']) for z in logs)))
        for title,mask,color in [('残存',~actual,point_ids),('除去',actual,None)]:
            xyz=raw[mask]
            fig.add_scatter3d(x=xyz[:,0],y=xyz[:,1],z=xyz[:,2],mode='markers',name=method+' '+title,
                 visible=method=='A',marker=dict(size=2,color=color[mask] if color is not None else 'red'))
    fig.update_layout(scene_aspectmode='data',uirevision='same-camera',updatemenus=[dict(buttons=[dict(label=m,method='restyle',args=[dict(visible=[j//2==i for j in range(8)])]) for i,m in enumerate('ABCD')])])
    fig.write_html(out/'comparison.html')
    with (out/'metrics.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=sorted(set().union(*(row.keys() for row in metrics))))
        w.writeheader()
        w.writerows(metrics)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    for name in ('window','config','new_output'): ap.add_argument(name,type=Path)
    args=ap.parse_args()
    compare(args.window,args.config,args.new_output)
