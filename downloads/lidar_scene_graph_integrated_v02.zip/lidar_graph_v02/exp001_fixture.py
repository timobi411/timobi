"""Example only. Regions and thresholds require an exp001 pilot observation."""
import json
import sys
from pathlib import Path
import numpy as np

out=Path(sys.argv[1])
out.mkdir()
y,x=np.mgrid[0:60,0:84]*.025
rng=np.random.default_rng(101)
z=rng.normal(0,.004,x.shape)
table=(x>.7)&(x<1.3)&(y>.3)&(y<.95)
z[table]+=.35
xyz=np.stack([x+.1,y,z],axis=-1)
window=np.repeat(xyz[None],11,axis=0)
window[:8,0,0]=np.nan
np.savez_compressed(out/'window.npz',xyz=window,frame_id=['synthetic']*11,message_id=np.arange(11),timestamp_ns=np.arange(11)+1000)
surface=dict(name='floor',kind='floor',fit=[[0,-.1,-.05],[1.7,1.6,.42]],eval=[[1.75,-.1,-.1],[2.3,1.6,.1]],support=[[0,-.1,-.03],[2.3,1.6,.03]],height_m=[-.08,.08])
cfg=dict(recording_id='synthetic',up=[0,0,1],frames=11,min_observations=6,seed=42,trials=100,inlier_m=.02,remove_m=.018,angle_deg=20,min_spread_m=.05,min_support=20,min_area_m2=.05,cell_m=.1,cutoff_bounds_m=[.012,.04],iterations=40,converge_deg=.002,converge_m=.00005,surfaces=[surface],labels=dict(floor=np.flatnonzero((xyz[:,:,0]>=1.75)&~table).tolist(),table=np.flatnonzero(table).tolist()))
(out/'config.json').write_text(json.dumps(cfg,indent=2))
