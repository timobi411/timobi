"""Read organized ROS 2 PointCloud2 without changing row order or padding."""
import argparse
import json
from pathlib import Path

import numpy as np
from rosbags.highlevel import AnyReader
from rosbags.typesys import Stores, get_typestore


def decode(msg):
    if msg.height<=1: raise ValueError('Unorganized PointCloud2')
    xyz=[]
    for axis in 'xyz':
        field=next(f for f in msg.fields if f.name==axis)
        dtype=('>' if msg.is_bigendian else '<')+{7:'f4',8:'f8'}[field.datatype]
        xyz.append(np.ndarray((msg.height,msg.width),dtype=dtype,buffer=msg.data,offset=field.offset,strides=(msg.row_step,msg.point_step)))
    return np.stack(xyz,axis=-1)


def extract(args):
    metadata=json.loads((args.recording/'recording.json').read_text())
    root=args.recording/'rosbag'
    args.output.mkdir(parents=True,exist_ok=False)
    data=[]
    times=[]
    ids=[]
    frames=[]
    seen=0
    with AnyReader([root], default_typestore=get_typestore(Stores.ROS2_HUMBLE)) as reader:
        con=[c for c in reader.connections if c.topic=='/lumotive_ros/pointcloud']
        if not con: raise ValueError('Missing YLM topic')
        for i,(conn,stamp,payload) in enumerate(reader.messages(connections=con)):
            seen+=1
            if args.start is None and i%args.stride: continue
            if args.start is not None and i<args.start: continue
            msg=reader.deserialize(payload,conn.msgtype)
            xyz=decode(msg)
            if args.start is None:
                from PIL import Image
                depth=np.linalg.norm(xyz,axis=-1)
                Image.fromarray(np.uint8(np.clip(np.nan_to_num(depth)/7,0,1)*255)).save(args.output/f'{i:06d}_{stamp}.png')
                continue
            times.append(msg.header.stamp.sec*10**9+msg.header.stamp.nanosec)
            data.append(xyz)
            frames.append(msg.header.frame_id)
            ids.append(i)
            if len(data)==args.count: break
    if args.start is not None:
        if len(data)!=args.count or len(set(frames))!=1 or len({x.shape for x in data})!=1:
            raise ValueError('Incomplete or mixed-frame window')
        np.savez_compressed(args.output/'window.npz',recording_id=args.recording.name,xyz=data,frame_id=frames,timestamp_ns=times,message_id=ids)
    (args.output/'source.json').write_text(json.dumps(dict(recording=args.recording.name,metadata=metadata,messages_read=seen,start=args.start),ensure_ascii=False,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('recording',type=Path)
    ap.add_argument('output',type=Path)
    ap.add_argument('--start',type=int)
    ap.add_argument('--count',type=int,default=11)
    ap.add_argument('--stride',type=int,default=120)
    extract(ap.parse_args())
