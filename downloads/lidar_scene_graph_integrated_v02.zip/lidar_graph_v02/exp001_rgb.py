"""Run the lab's offline_color CLI and audit its exported projection records.

The deployment supplies its CLI options. Keep them in a reviewed JSON profile.
"""
import argparse
import csv
import hashlib
import json
import subprocess
import sys
from pathlib import Path
import numpy as np
import yaml


def rigid(value):
    a=np.asarray(value,float)
    if a.shape!=(4,4) or not np.allclose(a[3],[0,0,0,1]) or not np.allclose(a[:3,:3].T@a[:3,:3],np.eye(3),atol=1e-5) or not np.isclose(np.linalg.det(a[:3,:3]),1):
        raise ValueError('Invalid calibration matrix')
    return a


def run(profile,out):
    cfg=json.loads(profile.read_text())
    if not cfg.get('same_mount_confirmed'): raise ValueError('Mount confirmation required')
    calibration=Path(cfg['calibration_yaml']).resolve(strict=True)
    if calibration.name!='live_color_wide48_rgb60.yaml': raise ValueError('Unexpected calibration file')
    bag=Path(cfg['rosbag']).resolve(strict=True)
    out.mkdir(parents=True,exist_ok=False)
    fields=dict(bag=str(bag),calibration=str(calibration),output=str(out.resolve()),start=str(cfg.get('start',0)),frames='12',offset_ms='-130',max_range_m='3')
    template=cfg['offline_color_arguments']
    for key in fields:
        if not any('{'+key+'}' in t for t in template): raise ValueError('Missing CLI placeholder '+key)
    args=[sys.executable,'-m','camera_lidar_calibration.offline_color',*[a.format_map(fields) for a in template]]
    calib=yaml.safe_load(calibration.read_text())
    def matrix(keys):
        value=calib
        for key in keys: value=value[key]
        return rigid(np.asarray(value).reshape(4,4))
    optical=np.linalg.inv(matrix(cfg['yaml_keys_mid360_from_color_optical']))@matrix(cfg['yaml_keys_mid360_from_ylm'])
    (out/'projection_job.json').write_text(json.dumps(dict(command=args,T_optical_from_ylm=optical.tolist(),yaml_sha256=hashlib.sha256(calibration.read_bytes()).hexdigest(),profile=cfg),indent=2))
    with (out/'offline_color.log').open('w') as log:
        subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)


def audit(path,out):
    # Export one row per YLM frame from the installed deployment's results.
    rows=list(csv.DictReader(path.open()))
    if len(rows)!=12: raise ValueError('Expected twelve projection records')
    for r in rows:
        n=int(r['eligible_points'])
        valid=int(r['colored_points'])
        if not 0<=valid<=n: raise ValueError('Invalid projection counts')
        r['valid_fraction']=valid/n if n else None
        r['corrected_delta_ms']=(int(r['ylm_ns'])-130000000-int(r['rgb_ns']))/1e6
        r['depth_delta_ms']=(int(r['ylm_ns'])-130000000-int(r['depth_ns']))/1e6
    with out.open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys())
        w.writeheader()
        w.writerows(rows)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('mode',choices=['run','audit'])
    ap.add_argument('input',type=Path)
    ap.add_argument('output',type=Path)
    a=ap.parse_args()
    (run if a.mode=='run' else audit)(a.input,a.output)
