"""Adapt a previous release job and preserve its initial alignment direction."""
import argparse
from pathlib import Path
from registration import read,write


def convert(source,out,version,obs):
    base=source.resolve().parent
    old=read(source)
    graph=read(base/old['graph'])
    nodes=[]
    for n in graph['nodes']:
        k=n.get('object_id',n.get('id'))
        v=old['objects'].get(k,{})
        node=dict(n,object_id=k,mobility=v.get('mobility','unknown'),source_ply=str((base/old.get('paths',{}).get(k,n['source_ply'])).resolve()))
        nodes.append(node)
    edges=[]
    for e in graph.get('edges',graph.get('relations',[])):
        edges.append(dict(e,source=e.get('source',e.get('from')),target=e.get('target',e.get('to')),type=e.get('type',e.get('relation',e.get('predicate')))))
    out.mkdir(parents=True,exist_ok=False)
    write(out/'map.json',dict(graph,schema_version='0.2',frame=graph.get('frame','T0'),map_version=version,nodes=nodes,edges=edges))
    views=[]
    for v in old['views']:
        import numpy as np
        m=np.eye(4)
        m[:3,3]=v['origin']
        views.append(dict(npz=str((base/v['rays_npz']).resolve()),T_reference_from_view=m.tolist()))
    new=dict(graph='map.json',views=views,t1_ply=str((base/old['t1_ply']).resolve()),observation_id=obs,anchors=old['anchor_indices'],checks={},
             T_world_from_t1_sensor=old['initial_T_T0_from_T1'])
    for src,dst in [('adaptive_icp_v11','icp_adapter'),('exp001_condition_dir','exp001_condition_dir')]:
        if src in old: new[dst]=str((base/old[src]).resolve())
    write(out/'job.json',new)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('previous_job',type=Path)
    p.add_argument('new_output',type=Path)
    p.add_argument('map_version')
    p.add_argument('observation_id')
    a=p.parse_args()
    convert(a.previous_job,a.new_output,a.map_version,a.observation_id)
