"""Offline T0/T1 registration with exclusive shared-pose fragment hypotheses."""
import argparse
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
from time import monotonic

import numpy as np
import plotly.graph_objects as go
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
import adaptive_clustering_V2 as v2
from geometry02 import View, correction, evidence, refine
from graph02 import update
from registration import cloud, load, read, rigid, sample, transform, write


def select(rows,c):
    if not rows: return {},True
    groups=defaultdict(list)
    for i,h in enumerate(rows):
        groups[('id',h['object_id'])].append(i)
        for f in h['fragments']: groups[('fragment',f)].append(i)
    rr,cc=zip(*[(r,i) for r,ids in enumerate(groups.values()) for i in ids])
    A=coo_matrix((np.ones(len(rr)),(rr,cc)),shape=(len(groups),len(rows))).tocsc()
    utility=np.array([h['score'] for h in rows])
    def solve(ub):
        return milp(-utility,integrality=np.ones(len(rows)),bounds=Bounds(0,ub),constraints=LinearConstraint(A,0,1),options={'time_limit':c['solve_s']})
    ub=np.ones(len(rows))
    best=solve(ub)
    if not best.success: return {},False
    selected={}
    for i in np.flatnonzero(best.x>.5):
        upper=ub.copy()
        upper[i]=0
        alt=solve(upper)
        if not alt.success: return {},False
        gap=float(alt.fun-best.fun)
        rows[i]['assignment_gap']=gap
        if gap>=c['margin']: selected[rows[i]['object_id']]=rows[i]
    return selected,True


def evaluate(model,target,pose,views,c):
    moved=transform(model,pose)
    d,j=cKDTree(moved).query(target)
    good=d<=c['surface_m']
    match,passed,counts=evidence(moved,views,c)
    observed=match|passed
    nearest=cKDTree(target).query(moved)[0]<=c['surface_m']
    supported=nearest & match & ~passed if views else nearest
    denom=observed.sum() if views else min(len(moved),len(target))
    fraction=min(1,float(supported.sum()/max(1,denom)))
    purity=float(good.mean())
    contradiction=float(passed.sum()/max(1,observed.sum()))
    spread=np.linalg.svd(moved[supported]-moved[supported].mean(0),compute_uv=False)/np.sqrt(supported.sum()) if supported.sum()>=3 else np.zeros(3)
    ok=(supported.sum()>=c['min_points'] and fraction>=c['min_fraction'] and purity>=c['min_purity'] and contradiction<=c['max_pass'] and spread[-1]>=c['min_depth_m'])
    return dict(valid=bool(ok),fraction=fraction,purity=purity,score=fraction*purity*(1-contradiction),rays=counts,
                matched_voxels=int(supported.sum()),matched_points=int(good.sum()),residual_median=float(np.median(d)),pass_ratio=contradiction),good


def run(jobfile,out):
    start=monotonic()
    base=jobfile.resolve().parent
    job=read(jobfile)
    files={jobfile.resolve()}
    def path(v):
        p=(base/v).resolve(strict=True)
        files.add(p)
        return p
    c=read(Path(__file__).with_name('settings02.json'))
    c.update(job.get('settings',{}))
    graph=read(path(job['graph']))
    obs=job['observation_id']
    version=graph['map_version']
    nodes={n['object_id']:n for n in graph['nodes']}
    models={}
    parts={}
    for k,n in nodes.items():
        if n.get('active',True):
            models[k]=sample(load(path(job.get('paths',{}).get(k,n['source_ply']))),c['voxel_m'])
            if n.get('model_frame','world')=='object':
                models[k]=transform(models[k],rigid(n['T_world_from_object']))
            parts[k]={a['part_id']:transform(sample(load(path(a['ply'])),c['voxel_m']),rigid(n.get('T_world_from_object',np.eye(4)))@rigid(a.get('T_object_from_part',np.eye(4)))) for a in n.get('parts',[])}
    points=load(path(job['t1_ply']))
    seed=rigid(job.get('T_world_from_t1_sensor',np.eye(4)))
    if 'T_exp001_from_T0' in job:
        if 'T_world_from_t1_sensor' in job: raise ValueError('Specify only one transform direction')
        seed=np.linalg.inv(rigid(job['T_exp001_from_T0']))
    def views_for(records):
        inputs=[]
        for v in records:
            a=np.load(path(v['npz']))
            shape=a['ranges'].shape
            directions=a['directions'].reshape(-1,3)
            ranges=a['ranges'].astype(float).copy()
            if 'valid' in a: ranges[~a['valid'].astype(bool)]=np.nan
            inputs.append((rigid(v.get('T_reference_from_view',np.eye(4))),directions,ranges,shape if len(shape)==2 else None))
        def build(m):
            return [View((m@t)[:3,3],d@(m@t)[:3,:3].T,r,h,c['boundary_m']) for t,d,r,h in inputs]
        return build
    build=views_for(job.get('views',[]))
    old_views=views_for(job.get('old_views',[]))(np.eye(4))
    anchors=job.get('anchors',{})
    checks=job.get('checks',{})
    if set(anchors)&set(checks) or set(i for v in anchors.values() for i in v)&set(i for v in checks.values() for i in v):
        raise ValueError('Validation must use independent anchors and points')
    for k,ids in {**anchors,**checks}.items():
        if nodes[k]['mobility']!='fixed' or not ids or min(ids)<0 or max(ids)>=len(points): raise ValueError('Invalid anchor')
    if anchors and job.get('correct_alignment',True):
        matrix,verified,alignment=correction(points,models,anchors,checks,seed,build,c)
    else:
        matrix=seed
        residual={k:np.percentile(cKDTree(models[k]).query(transform(points[ids],matrix))[0],[50,90]).tolist() for k,ids in checks.items()}
        verified=bool(job.get('validated_seed_reason')) and bool(residual) and all(v[1]<=c['validation_p90_m'] for v in residual.values())
        alignment=dict(reason=job.get('validated_seed_reason','unverified_seed'),validation=residual)
    world=transform(points,matrix)
    views=build(matrix)
    out.mkdir(parents=True,exist_ok=False)
    write(out/'alignment.json',dict(**alignment,verified=verified,T_world_from_t1_sensor=matrix.tolist()))
    decisions={}
    parent=np.full(len(points),'',dtype=object)
    part=parent.copy()
    fragment=np.full(len(points),-1)
    # Preserve input-to-ray provenance independently from downsampling/classification.
    source_view=np.full(len(points),-1)
    source_pixel=np.full(len(points),-1)
    if 'point_provenance' in job:
        refs=np.load(path(job['point_provenance']))
        source_view,source_pixel=refs['view'],refs['pixel']
        if any(a.shape!=(len(points),) or a.dtype.kind not in 'iu' for a in (source_view,source_pixel)):
            raise ValueError('Invalid point provenance')
        for v in np.unique(source_view):
            if v<0: continue
            if v>=len(job.get('views',[])): raise ValueError('Unknown source view')
            nr=np.load(path(job['views'][v]['npz']))['ranges'].size
            ix=source_pixel[source_view==v]
            if np.any((ix<0)|(ix>=nr)): raise ValueError('Invalid source pixel')
    fixed=[k for k in models if nodes[k]['mobility']=='fixed']
    costs=np.full((len(points),len(fixed)+2),np.inf)
    for j,k in enumerate(fixed):
        vis=evidence(models[k],views,c)[0] if views else np.ones(len(models[k]),bool)
        if vis.any():
            dist=cKDTree(models[k][vis]).query(world)[0]
            costs[:,j]=np.where(dist<=c['surface_m'],dist,np.inf)
    if c['fixed_first'] and verified:
        order=np.argsort(costs,axis=1)
        for j,k in enumerate(fixed):
            category=nodes[k].get('class')
            if category and sum(nodes[r].get('class')==category for r in fixed)>1: continue
            ids=np.flatnonzero((order[:,0]==j)&np.isfinite(costs[:,j])&(costs[np.arange(len(points)),order[:,1]]>costs[:,j]+c['fixed_margin_m']))
            if len(ids)>=c['min_points']:
                info,_=evaluate(models[k],world[ids],np.eye(4),views,c)
                if info['valid']:
                    decisions[k]=dict(status='static',reason='fixed_visible_surface',evidence=info,pose=np.eye(4).tolist())
                    parent[ids]=k
    free=parent==''
    if 'exp001_condition_dir' in job:
        d=base/job['exp001_condition_dir']
        record=read(path(d/'run.json'))
        if sha256(points.astype('<f8').tobytes()).hexdigest()!=record['input_sha256']: raise ValueError('Different representative')
        free[np.load(path(d/'indices.npz'))['removed']]=False
    if c['remove_structures'] and free.sum()>=c['min_points']:
        # Fixed observations have already been reserved. Refit on the residual.
        idx=np.flatnonzero(free)
        remaining,*_=v2.remove_room_structures(cloud(world[idx]))
        kept=set(map(tuple,np.asarray(remaining.points)))
        free[idx]=[tuple(p) in kept for p in world[idx]]
    if 'floating_indices' in job: free[np.load(path(job['floating_indices']))]=False
    if 'fragment_ids' in job:
        f=np.load(path(job['fragment_ids']))
        if f.shape!=(len(points),) or f.dtype.kind not in 'iu': raise ValueError('Expected one integer fragment ID per input point')
        fragment[free]=f[free]
    elif free.any():
        idx=np.flatnonzero(free)
        local=cloud(points[idx])
        groups=v2.adaptive_recluster(local,v2.adaptive_core_expand_clustering(local,v2.MIN_CLUSTER_POINTS))
        for j,g in enumerate(groups): fragment[idx[g]]=j
    groups={int(j):np.flatnonzero(fragment==j) for j in np.unique(fragment) if j>=0}
    rows=[]
    valid=[]
    truncated=False
    calls=0
    begin=monotonic()
    scoring_views=views if c['use_rays'] else []
    for k,model in models.items():
        if k in decisions: continue
        options=[]
        for j,idx in groups.items():
            target=world[idx]
            ratio=np.linalg.norm(np.ptp(target,axis=0))/max(1e-8,np.linalg.norm(np.ptp(model,axis=0)))
            if ratio>c['max_size_ratio']: continue
            options.append((abs(1-ratio),j))
        options.sort()
        truncated|=len(options)>c['top_k']
        hypotheses=[np.eye(4)]
        for _,j in options[:c['top_k']]:
            if monotonic()-begin>c['search_s']:
                truncated=True
                break
            t=world[groups[j]]
            if nodes[k]['mobility']=='fixed':
                # Fixed-ID competition uses distinct observations at the prior pose.
                continue
            if job.get('icp_adapter'):
                import importlib.util
                spec=importlib.util.spec_from_file_location('experiment_icp',path(job['icp_adapter']))
                mod=importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                trial=mod.evaluate_pair(cloud(model),cloud(t))
                calls+=1
                if trial and trial['valid']: hypotheses.append(rigid(trial['transformation']))
            for source in [model,*parts[k].values()]:
                if monotonic()-begin>c['search_s']: truncated=True; break
                for angle in c['yaw_seeds_deg']:
                    if monotonic()-begin>c['search_s']: truncated=True; break
                    pose=np.eye(4)
                    pose[:3,:3]=Rotation.from_euler('z',angle,degrees=True).as_matrix()
                    pose[:3,3]=t.mean(0)-pose[:3,:3]@source.mean(0)
                    hypotheses.append(refine(source,t,pose,c))
                    calls+=1
        distinct=[]
        for pose in hypotheses:
            if monotonic()-begin>c['search_s']:
                truncated=True
                break
            if any(np.linalg.norm(pose-v)<1e-4 for v in distinct): continue
            distinct.append(pose)
            tree=cKDTree(transform(model,pose))
            fits=[j for _,j in options if (tree.query(world[groups[j]])[0]<=c['surface_m']).mean()>=c['min_purity']]
            sets=[[j] for j in fits]
            if len(fits)>1 and c['common_pose']:
                from itertools import combinations
                sets.append(fits)
                if len(fits)>2:
                    for size in range(2,min(len(fits),4)):
                        for subset in combinations(fits,size):
                            if len(sets)>=c['max_sets']: truncated=True; break
                            sets.append(list(subset))
                        if len(sets)>=c['max_sets']: break
            for fs in sets:
                if monotonic()-begin>c['search_s']: truncated=True; break
                idx=np.concatenate([groups[j] for j in fs])
                m=refine(model,world[idx],pose,c) if len(fs)>1 and nodes[k]['mobility']!='fixed' else pose
                info,mask=evaluate(model,world[idx],m,scoring_views,c)
                passed={j:float(mask[fragment[idx]==j].mean()) for j in fs}
                if min(passed.values())<c['min_purity']: info['valid']=False
                row=dict(object_id=k,observation_id=obs,fragments=fs,pose=m.tolist(),fragment_support=passed,**info)
                if parts[k]:
                    ds=np.column_stack([cKDTree(transform(p,m)).query(world[idx])[0] for p in parts[k].values()])
                    ids=np.argmin(ds,axis=1)
                    supported=[a for a in range(ds.shape[1]) if ((ids==a)&(ds[:,a]<=c['surface_m'])).sum()>=c['min_points']]
                    row['supported_parts']=[list(parts[k])[a] for a in supported]
                    edge_scores=[]
                    for a,b in nodes[k].get('part_edges',[]):
                        if a not in row['supported_parts'] or b not in row['supported_parts']: continue
                        offsets=[]
                        for key in (a,b):
                            surface=transform(parts[k][key],m)
                            dist,nearest=cKDTree(surface).query(world[idx])
                            use=(ids==list(parts[k]).index(key))&(dist<=c['surface_m'])
                            offsets.append(np.median(world[idx][use]-surface[nearest[use]],axis=0))
                        edge_scores.append(float(np.exp(-np.linalg.norm(offsets[0]-offsets[1])/c['surface_m'])))
                    row['edge_scores']=edge_scores
                    if c['part_edges'] and edge_scores: row['score']*=.8+.2*np.mean(edge_scores)
                if c['room_relations'] and nodes[k]['mobility']=='fixed':
                    refs=[r for r in fixed if r in decisions and r!=k]
                    if refs:
                        expected=transform(model,m).mean(0)
                        center=world[idx].mean(0)
                        errors=[abs(np.linalg.norm(center-world[parent==r].mean(0))-np.linalg.norm(expected-models[r].mean(0))) for r in refs]
                        vectors=[(center-world[parent==r].mean(0),expected-models[r].mean(0)) for r in refs]
                        angles=[float(np.degrees(np.arccos(np.clip(a@b/max(1e-12,np.linalg.norm(a)*np.linalg.norm(b)),-1,1)))) for a,b in vectors]
                        row['relation_direction_deg']=float(np.median(angles))
                        row['relation_frame']=graph.get('frame','world')
                        row['score']*=.95+.05*np.exp(-row['relation_direction_deg']/20)
                        row['relation_error_m']=float(np.median(errors))
                        row['score']*=.8+.2*np.exp(-row['relation_error_m']/c['surface_m'])
                rows.append(row)
                if row['valid']: valid.append(row)
    # Combine numerically equivalent poses, retaining alternatives with distinct orientation.
    pool=[]
    for h in sorted(valid,key=lambda x:-x['score']):
        m=np.array(h['pose'])
        def equivalent(v):
            if v['object_id']!=h['object_id'] or v['fragments']!=h['fragments']: return False
            q=np.array(v['pose'])
            center=models[h['object_id']].mean(0)
            return np.linalg.norm(transform(center,m)-transform(center,q))<c['movement_m'] and Rotation.from_matrix(m[:3,:3]@q[:3,:3].T).magnitude()<np.radians(c['movement_deg'])
        if not any(equivalent(v) for v in pool): pool.append(h)
    selected,optimal=select(pool,c)
    if not verified or truncated or not optimal: selected={}
    part_records=[]
    positioned=dict(models)
    for k,model in models.items():
        _,_,old=evidence(model,views,c)
        if k in selected:
            h=selected[k]
            m=np.array(h['pose'])
            positioned[k]=transform(model,m)
            move=np.linalg.norm(positioned[k].mean(0)-model.mean(0))
            angle=Rotation.from_matrix(m[:3,:3]).magnitude()*180/np.pi
            decisions[k]=dict(status='moved' if move>c['movement_m'] or angle>c['movement_deg'] else 'static',reason='exclusive_common_pose',pose=h['pose'],score=h['score'],fragments=h['fragments'],old_rays=old)
            ids=np.concatenate([groups[j] for j in h['fragments']])
            ids=ids[cKDTree(positioned[k]).query(world[ids])[0]<=c['surface_m']]
            if np.any(parent[ids]!=''): raise RuntimeError('Double assignment')
            parent[ids]=k
        elif k not in decisions:
            plausible=any(r['object_id']==k and r['matched_voxels']>=c['min_points'] for r in rows)
            empty=c['use_rays'] and verified and optimal and not truncated and not plausible and old['passed']>=c['min_points'] and old['passed']/len(model)>=c['absence_fraction'] and old['match']==0
            decisions[k]=dict(status='disappeared' if empty else 'held',reason='old_surface_traversed' if empty else 'alignment_search_or_observation_insufficient',old_rays=old)
        ids=np.flatnonzero(parent==k)
        if len(ids) and parts[k]:
            names=list(parts[k])
            m=np.array(decisions[k]['pose'])
            costs=np.column_stack([cKDTree(transform(p,m)).query(world[ids])[0] for p in parts[k].values()]+[np.full(len(ids),np.inf)])
            order=np.argsort(costs,axis=1)
            for j,name in enumerate(names):
                annotated=next(a for a in nodes[k]['parts'] if a['part_id']==name)
                use=(order[:,0]==j)&(costs[:,j]<=c['surface_m'])&(costs[np.arange(len(ids)),order[:,1]]>costs[:,j]+c['fixed_margin_m'])
                if annotated.get('symmetry_group'): use[:]=False
                part[ids[use]]=name
                part_records.append(dict(object_id=k,part_id=name,observation_id=obs,indices=ids[use].tolist(),fragments=np.unique(fragment[ids[use]]).tolist()))
    for j,ids in groups.items():
        if len(ids)<c['min_points'] or np.any(parent[ids]!=''): continue
        _,_,old=evidence(sample(world[ids],c['voxel_m']),old_views,c)
        if not (c['use_rays'] and verified and optimal and not truncated and job.get('confirmed_new_fragments',[]).count(j) and old['passed']>=c['min_points'] and old['match']==0 and old['passed']/max(1,len(sample(world[ids],c['voxel_m'])))>=c['absence_fraction']): continue
        if any(j in h['fragments'] for h in valid): continue
        key='new_'+sha256(f'{version}/{obs}/{j}'.encode()).hexdigest()[:16]
        parent[ids]=key
        positioned[key]=world[ids]
        decisions[key]=dict(status='appeared',reason='old_rays_and_reviewed_instance',old_rays=old,fragments=[j],pose=np.eye(4).tolist())
    for k,d in decisions.items():
        if k in models:
            d.setdefault('old_rays',evidence(models[k],views,c)[2])
        d.setdefault('fragments',[])
        d.setdefault('score',d.get('evidence',{}).get('score'))
        d.update(object_id=k,observation_id=obs,decision_id=sha256(f'{version}/{obs}/{k}'.encode()).hexdigest(),observed_points=int((parent==k).sum()))
    after,delta=update(graph,positioned,decisions,obs,c)
    for n in after['nodes']:
        k=n['object_id']
        if k in nodes and 'source_ply' in n:
            n['source_ply']=str(path(job.get('paths',{}).get(k,n['source_ply'])))
            for annotation in n.get('parts',[]):
                annotation['ply']=str(path(annotation['ply']))
        if decisions.get(k,{}).get('status')=='moved' and n.get('model_frame','world')=='world':
            # A world-frame PLY must move along with its node for subsequent observations.
            import open3d as od
            dest=out/('model_'+sha256(k.encode()).hexdigest()[:16]+'.ply')
            full=od.io.read_point_cloud(n['source_ply'])
            full.transform(np.asarray(decisions[k]['pose']))
            od.io.write_point_cloud(str(dest),full)
            n['source_ply']=str(dest.resolve())
    for n in after['nodes']:
        k=n['object_id']
        if decisions.get(k,{}).get('status')=='appeared':
            import open3d as od
            dest=out/(k+'.ply')
            od.io.write_point_cloud(str(dest),cloud(positioned[k]))
            n['source_ply']=dest.name
    for change in delta['nodes']:
        change['after']=next(n for n in after['nodes'] if n['object_id']==change['id'])
    unassigned=[]
    for j,idx in groups.items():
        remaining=idx[parent[idx]=='']
        if len(remaining):
            unassigned.append(dict(observation_id=obs,fragment_id=j,indices=remaining.tolist(),status='first_observed_candidate' if len(remaining)==len(idx) else 'partial_fragment_residual',reason='no_confirmed_correspondence'))
    write(out/'unassigned_observations.json',unassigned)
    write(out/'graph_before.json',graph)
    write(out/'graph_after.json',after)
    write(out/'graph_delta.json',delta)
    write(out/'decisions.json',decisions)
    write(out/'room_graph.json',dict(frame=graph.get('frame','world'),edges=after['edges']))
    write(out/'part_graphs.json',{k:dict(parts=n.get('parts',[]),edges=n.get('part_edges',[]),part_of=[dict(source=p['part_id'],target=k,type='part_of') for p in n.get('parts',[])]) for k,n in nodes.items()})
    write(out/'fixed_audit.json',{k:dict(status=decisions[k]['status'],points=decisions[k]['observed_points'],old_rays=decisions[k]['old_rays'],review_priority=k.endswith(('O010','O011'))) for k in fixed})
    for name,records in [('candidates',rows),('fragment_part_assignments',part_records)]:
        with (out/(name+'.jsonl')).open('w') as f:
            for r in records: f.write(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n')
    np.savez_compressed(out/'point_labels.npz',original_index=np.arange(len(points)),source_view=source_view,source_pixel=source_pixel,object_id=parent.astype(str),part_id=part.astype(str),fragment_id=fragment)
    fig=go.Figure()
    for k in np.unique(parent.astype(str)):
        use=parent==k
        xyz=world[use]
        fig.add_scatter3d(x=xyz[:,0],y=xyz[:,1],z=xyz[:,2],name=k or 'unassigned',mode='markers',marker=dict(size=2),text=[f'fragment={f} part={p}' for f,p in zip(fragment[use],part[use])])
    for k,p in positioned.items():
        matched,passed,_=evidence(p,views,c)
        codes=np.zeros(len(p),int)
        for v in views:
            state,_=v.project(p,c)
            codes[state==2]=2
        codes[matched]=1
        codes[passed]=3
        fig.add_scatter3d(x=p[:,0],y=p[:,1],z=p[:,2],name='model '+k,visible='legendonly',mode='markers',marker=dict(size=2,color=codes,cmin=0,cmax=3),text=np.array(['unknown','match','occluded','passed'])[codes])
    fig.update_layout(scene_aspectmode='data')
    fig.write_html(out/'review.html')
    # Independently enumerate all active pairs for the local delta audit.
    from itertools import combinations
    changed={k for k,d in decisions.items() if d['status'] in ('moved','appeared','disappeared')}
    active={n['object_id'] for n in after['nodes'] if n.get('active',True)}
    expected=set()
    for a,b in combinations(sorted(active & positioned.keys()),2):
        x,y=positioned[a],positioned[b]
        if cKDTree(x).query(y)[0].min()<=(c['wall_near_m'] if 'T0_W001' in (a,b) else c['near_m']):
            expected.add(('near',a,b))
        for top,base_id,p,q in [(a,b,x,y),(b,a,y,x)]:
            overlap=np.maximum(0,np.minimum(p.max(0),q.max(0))-np.maximum(p.min(0),q.min(0)))[:2].prod()
            if overlap/max(1e-9,np.ptp(p,axis=0)[:2].prod())>=c['on_overlap'] and abs(p[:,2].min()-q[:,2].max())<=c['on_gap_m'] and p[:,2].mean()>q[:,2].mean(): expected.add(('on',top,base_id))
    actual={(e['type'],*(sorted((e['source'],e['target'])) if e['type']=='near' else (e['source'],e['target']))) for e in after['edges'] if e['type'] in ('on','near')}
    differences=actual.symmetric_difference(expected)
    write(out/'relation_audit.json',dict(all_differences=sorted(differences),affected_differences=sorted(e for e in differences if changed.intersection(e[1:]))))
    write(out/'metrics.json',dict(seconds=monotonic()-start,icp_calls=calls,candidates=len(rows),truncated=truncated,optimal=optimal,states={s:sum(d['status']==s for d in decisions.values()) for s in ('static','moved','appeared','disappeared','held')}))
    write(out/'manifest.json',dict(observation_id=obs,map_version=version,settings=c,inputs={str(p):sha256(p.read_bytes()).hexdigest() for p in sorted(files)},code={p.name:sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*.py')},clustering_origin='reference T1 origin',fragment_source=job.get('fragment_ids','Adaptive V2')))

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('job',type=Path)
    ap.add_argument('new_output',type=Path)
    args=ap.parse_args()
    run(args.job,args.new_output)
