# 異種LiDAR 部屋・部品グラフ統合実験版 v0.2

同梱の comparison02/full/review.html は合成例の実行結果です。各凡例で観測点とモデルを切り替え、ポインタでクラスタ番号と部品IDを確認できます。実装の根拠とする設計は lidar_scene_graph_integration_spec_v0.2.md にあります。

## 動かし方

Python環境に numpy、scipy（milp対応）、open3d、plotly をインストールし、展開したディレクトリで実行します。

```bash
python integrate02.py examples02/job.json run_new
python variants02.py examples02/job.json comparison_new
python evaluate02.py examples02/truth.json scores_new.json run_new
python verify02.py fixture_new
python test_states02.py states_new
```

研究PCの前回版jobは次のように変換できます。

```bash
python import_job02.py old/experiment.json input_new T0_min301 exp001_t1
python integrate02.py input_new/job.json exp001_new
```

変換後、実際の部品注釈と独立検証用の checks を追加します。job の相対パスは job ファイルの位置を基準にします。各runは新規フォルダを必要とします。

## 入力契約

- graph の map_version は採用地図の識別子、frame は地図の座標系です。nodes の object_id は永続IDです。mobility は fixed、movable または unknown を使います。class に同じ分類を指定した固定家具は先行確定から外し、候補間の差を調べます。edges は source、target、type を持ちます。
- source_ply は既定でT0地図座標です。model_frame が object のとき T_world_from_object で地図へ置きます。parts は part_id、part_type、ply、任意の T_object_from_part、symmetry_group。部品PLYは部品局所座標、変換省略時は物体座標です。part_edges は部品IDの組です。椅子の座面・背・台座、机の天板・脚・フレーム、棚の側板・棚板を同じ形式で指定します。対称グループの点は親までを確定します。
- t1_ply は共通T1基準座標の実測点です。T_world_from_t1_sensor と T_exp001_from_T0 のどちらか一方を与えます。後者は一度だけ逆転します。exp001には研究PCの z_and_tilt を指定します。views の npz は directions（H×W×3単位方向）、ranges（H×W、m）、任意の valid です。T_reference_from_view は各視点からT1基準への4×4剛体変換。old_views は同じ形式でT0地図座標に置きます。平坦な配列でも使用できますが、画素近傍の診断にはH×Wが必要です。
- point_provenance NPZ の view、pixel はT1の各行に対応する視点番号・行優先の画素番号です。復元できない場合はラベルに −1 を保存します。PLYのみなら views を空にします。表面への幾何照合を行い、レイによる消失確定は保留します。
- anchors と checks は別々の固定IDと元点番号を使います。補正は可視面の法線残差を物体単位で均し、ランクと独立区画のP50・P90を検証します。既存変換のみを評価する場合は correct_alignment=false、validated_seed_reason と独立した checks を指定します。全体変換が未検証の場合も形状候補は出力します。
- 前回の平面比較を採用する場合は exp001_condition_dir を指定します。固定物の割当後に同じ入力ハッシュの背景マスクを使います。settings.remove_structures=true では残存点に旧V2の構造除去を再適用します。浮遊点の旧jobマスクは floating_indices（元行番号のNPY）で渡します。fragment_ids を渡すと保存済みの分割を再利用し、省略時は残存点をV2へ渡します。多視点V2の距離原点は共通T1基準原点です。
- icp_adapter は研究室の既存 evaluate_pair を指定できます。既定の補助仮説は重心・複数yawから開始したSE(3)近接点フィットです。候補はROI全域から作り、個々の断片と結合後の支持率を双方記録します。設定の top_k、max_sets、search_s、solve_s で探索範囲を管理します。既知の探索打切り・未解決の競合は可動物の採用を保留します。外部ICP呼出しの途中では中断しません。
- 旧視点で通過を確認した未割当断片は confirmed_new_fragments に人が物体として確認した番号を渡したとき、新IDを発行します。その他の初観測候補と過結合の残り点は unassigned_observations.json に残ります。

## 判定と比較

閾値は settings02.json にあり、job.settings で実験ごとに上書きできます。Ray幅、境界幅、必要な可視支持、判定差などは未校正の初期値です。organized視点では深度境界と細く孤立したモデルレイを別集計します。全視点の実測レイに対するモデルの前面を照合し、同じ物体姿勢で部品間の表面位置誤差も評価します。確認画面のモデル色には一致・遮蔽・通過・不明を表示します。

variants02.py は同じ観測で全機能・単独断片・部品エッジなし・レイなし・共通姿勢のみ・部屋関係なし・固定先行なしを比較します。frozen_fragment_inputs に fixed_merge、occlusion_assisted の元点対応NPYを登録すると、それらの既存結合を入力した比較も実行します。旧アルゴリズム自体の再現用には前回版の compare.py と実行済みjobを使います。合成の旧B0再実行結果は validation/v02/baseline_synthetic.json にあります。

evaluate02.py の正解は照合処理とは別入力です。examples02/truth.json を参照してください。手測定の並進は基準点 center_world と一緒に指定し、回転が未計測なら rotation_measured=false とします。任意の equivalent_world_rotation_xyzw は評価に許す対称回転です。局所差分と全再計算の比較は relation_audit.json に保存します。on は地図の+Zを上にした水平投影と鉛直距離による近似です。新規または移動した世界座標モデルは新run側へ保存します。

## 検証範囲

examples02 は固定分割と手動部品を持つ合成点群です。全機能では椅子の3断片750点を親IDに回収し、机A近傍から机B近傍へ更新しました。棚は遮蔽で保留。部品ID正答は座面249/250、背248/250、台座243/250でした。部品エッジを外した場合もこの合成例では親ID・姿勢は同じでした。これだけでは部品関係の改善量は判定できません。生成したデータは実際のexp001や実験椅子とは区別してください。

実収録の固定7物体、O010/O011の低支持、C0/C1の過結合、椅子709点、他視点の机・棚は未評価です。fixed_audit.json と元点番号で個別監査できます。受入には研究PCの該当job、正しい向きの全体変換、organized YLM、固定物・部品の注釈、点やグラフ差分の正解が必要です。

参考資料は考え方から独立実装しました。Khronosの横距離・レイ投影、OASIS-Map §III-C の割合と信頼度、DovSGの局所更新を参照しました。SG-PGM等の学習済みモデルを実行した結果は含みません。DovSGとScan2CADの添付ZIPは32 MiB転送上限で直接読めず、DovSGは公開リポジトリの該当2ファイル、Scan2CADは添付論文を参照しました。取得資料のハッシュは validation/v02/references.json にあります。
