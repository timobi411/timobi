"""Score completed runs only against independently supplied annotations."""
import argparse
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from registration import read,write,rigid


def score(folder,truth):
    dec=read(folder/'decisions.json')
    data=np.load(folder/'point_labels.npz')
    result=dict(run=read(folder/'metrics.json'),objects={},relation_audit=read(folder/'relation_audit.json'))
    for k,t in truth.get('objects',{}).items():
        d=dec.get(k,{})
        pred=set(np.flatnonzero(data['object_id']==k))
        actual=set(t['indices'])
        inter=len(pred&actual)
        row=dict(correct_points=inter,extra_points=len(pred-actual),missed_points=len(actual-pred),
                 precision=inter/len(pred) if pred else None,recall=inter/len(actual) if actual else None,
                 status=d.get('status'),correct_state=d.get('status')==t.get('status') if 'status' in t else None)
        if 'pose' in t and 'pose' in d:
            gt=rigid(t['pose'])
            est=rigid(d['pose'])
            center=np.array(t.get('center_world',[0,0,0]))
            row['translation_error_m']=float(np.linalg.norm((gt[:3,:3]-est[:3,:3])@center+gt[:3,3]-est[:3,3]))
            if t.get('rotation_measured',True):
                sym=[np.eye(3),*[Rotation.from_quat(q).as_matrix() for q in t.get('equivalent_world_rotation_xyzw',[])]]
                row['rotation_error_deg']=float(min(np.degrees(Rotation.from_matrix(est[:3,:3].T@gt[:3,:3]@s).magnitude()) for s in sym))
        row['parts']={p:dict(correct=int(np.sum((data['object_id'][ix]==k)&(data['part_id'][ix]==p))),total=len(ix)) for p,ix in t.get('parts',{}).items() if ix}
        result['objects'][k]=row
    if 'edges' in truth:
        sig=lambda e:(e['type'],*(sorted((e['source'],e['target'])) if e['type']=='near' else (e['source'],e['target'])))
        actual={sig(e) for e in truth['edges']}
        pred={sig(e) for e in read(folder/'graph_after.json')['edges']}
        result['edges']=dict(correct=len(pred&actual),extra=sorted(pred-actual),missed=sorted(actual-pred))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('truth',type=Path)
    p.add_argument('new_output',type=Path)
    p.add_argument('runs',type=Path,nargs='+')
    a=p.parse_args()
    if a.new_output.exists(): raise FileExistsError(a.new_output)
    write(a.new_output,{str(d):score(d,read(a.truth)) for d in a.runs})
