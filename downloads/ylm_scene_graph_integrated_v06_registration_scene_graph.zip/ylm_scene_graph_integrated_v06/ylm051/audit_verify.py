"""Independent saved-input reconstruction; no proxy inputs, no generation mutation."""
from collections import Counter
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
from .io import read,rows,digest
from .boundary_audit import contact_arrays,summarize,expansion_details,DISTANCE_ATOL

def equal(a,b,path='root'):
    if isinstance(a,dict):
        if set(a)!=set(b):raise ValueError('audit fields mismatch '+path)
        for k in a:equal(a[k],b[k],path+'.'+k)
    elif isinstance(a,(list,tuple)):
        if len(a)!=len(b):raise ValueError('audit length mismatch '+path)
        for i,(x,y) in enumerate(zip(a,b)):equal(x,y,path+str(i))
    elif isinstance(a,float):
        if b is None or not np.isfinite(b) or not np.isclose(a,b,rtol=0,atol=DISTANCE_ATOL):raise ValueError('audit numeric mismatch '+path)
    elif a!=b:raise ValueError('audit value mismatch '+path)

def audit_verify(run,check_integrity=True):
    run=Path(run);manifest=read(run/'run_manifest.json')
    if check_integrity:
        from .pipeline import verify
        verify(run)
    if not (run/'audit_status.json').exists():
        return {'integrity':True,'audit_complete':False,'status':'UNAVAILABLE_LEGACY_PARENT_AND_CONTACT_AUDIT',
                'processing_complete':manifest['processing_complete'],'accuracy':'NOT_EVALUATED'}
    status=read(run/'audit_status.json')
    if not status['audit_complete']:
        return {'integrity':True,'audit_complete':False,'status':'PARTIAL','audit_status':status,
                'processing_complete':manifest['processing_complete'],'search_exhaustive':manifest['search_exhaustive'],'accuracy':'NOT_EVALUATED'}
    config=read(run/'input_contract.json');profile=read(run/'resolved_config.json')
    summary_rows=list(rows(run/'contact_geometry_summary.jsonl'));gate_rows=list(rows(run/'pair_gate_audit.jsonl'))
    summaries={(r['time'],tuple(r['fragment_ids'])):r for r in summary_rows}
    gates={(r['time'],tuple(r['fragment_ids'])):r for r in gate_rows}
    if len(summaries)!=len(summary_rows) or len(gates)!=len(gate_rows):raise ValueError('duplicate audit pair record')
    pairs={};scenes={};total=0
    for r in rows(run/'pair_evidence.jsonl'):pairs.setdefault(r['time'],{})[tuple(r['fragment_ids'])]=r
    if set(gates)!={(t,k) for t,ps in pairs.items() for k in ps}:raise ValueError('gate audit pair coverage mismatch')
    inventories={t:set() for t in config['times']}
    for r in rows(run/'pair_pipeline.jsonl'):inventories[r['time']].add(tuple(r['fragment_ids']))
    for t,spec in config['times'].items():
        with np.load(run/spec['pixels']) as z:xyz,valid,labels=z['xyz'],z['valid'],z['labels']
        arr=contact_arrays(xyz,valid,labels);scenes[t]=(xyz,labels)
        with np.load(run/f'contact_geometry_{t}.npz') as z:
            if set(z.files)!=set(arr):raise ValueError('contact columns mismatch')
            for k,v in arr.items():
                if v.shape!=z[k].shape or not (np.allclose(v,z[k],rtol=0,atol=DISTANCE_ATOL) if np.issubdtype(v.dtype,np.floating) else np.array_equal(v,z[k])):raise ValueError('contact mismatch '+k)
        # Compare all legacy scan endpoints independently of its normalization.
        with np.load(run/f'image_contacts_{t}.npz') as z:old=z['contacts']
        oldkeys=sorted((int(a),int(b),*sorted((int(p),int(q))),int(d)) for a,b,p,q,d in old)
        newkeys=sorted((int(a),int(b),*sorted((int(p),int(q))),int(d)) for (a,b),(p,q),d in zip(arr['fragment_ids'],arr['pixel_ids'],arr['direction']))
        if oldkeys!=newkeys:raise ValueError('legacy contact missing or duplicated')
        offsets={};i=0
        while i<len(newkeys):
            key=tuple(map(int,arr['fragment_ids'][i]));j=i+1
            while j<len(newkeys) and tuple(arr['fragment_ids'][j])==key:j+=1
            offsets[key]=(i,j);i=j
        if {k for tt,k in summaries if tt==t}!=inventories[t]|set(offsets):raise ValueError('pair summary coverage mismatch')
        w=labels.shape[1];flat=xyz.reshape(-1,3).astype(np.float64);lab=labels.ravel()
        points={int(f):flat[lab==f] for f in np.unique(lab[lab>=0])};trees={f:cKDTree(v) for f,v in points.items()}
        for key in inventories[t]|set(offsets):
            row=summaries[t,key];start,end=offsets.get(key,(0,0));equal(row['offset'],[start,end]);equal({k:row[k] for k in summarize(arr,start,end)},summarize(arr,start,end))
            if key in pairs.get(t,{}):
                pair=pairs[t][key];geo=pair['geometry'];near=row['nearest_3d'];p,q=near['pixel_ids']
                if [int(lab[p]),int(lab[q])]!=list(key):raise ValueError('nearest endpoint membership')
                distance=float(trees[key[1]].query(points[key[0]])[0].min())
                equal(near['distance_m'],distance);equal(geo['minimum_distance_m'],distance)
                equal(float(np.linalg.norm(flat[q]-flat[p])),distance)
                equal(near['signed_delta_range_m'],float(np.linalg.norm(flat[q])-np.linalg.norm(flat[p])))
                equal(near['row_col_delta'],[q//w-p//w,q%w-p%w]);equal(near['is_direct_4_contact'],abs(q//w-p//w)+abs(q%w-p%w)==1)
                gate=gates[t,key];g=profile['geometry']
                sp=geo['minimum_distance_m']<=g['spatial_radius_m'];im=geo['pixel_boundary_gap'] is not None and geo['pixel_boundary_gap']<=g['pixel_gap']
                orig=any(e['origin']=='original_saved_relation' for e in pair['evidence'])
                equal(gate['spatial_gate'],{'value_m':geo['minimum_distance_m'],'limit_m':g['spatial_radius_m'],'operator':'<=','passed':sp})
                equal(gate['image_gate'],{'value_pixels':geo['pixel_boundary_gap'],'limit_pixels':g['pixel_gap'],'operator':'<=','passed':im})
                equal(gate['original_relation_present'],orig);equal(gate['final_or'],bool(sp or im or orig))
                equal(gate['typed_references']['GEOMETRY_DISTANCE']['pixel_ids'],[p,q])
                pixelrefs=gate['typed_references']['IMAGE_DISTANCE']['pixel_ids']
                if pixelrefs:
                    a,b=pixelrefs
                    if [int(lab[a]),int(lab[b])]!=list(key):raise ValueError('image endpoint membership')
                    equal(float(np.hypot(a//w-b//w,a%w-b%w)),geo['pixel_boundary_gap'])
            elif row['nearest_3d'] is not None:raise ValueError('unevaluated nearest must be null')
        total+=len(newkeys)
    regions={(r['time'],tuple(r['cell'])):set(r['halo_fragment_ids']) for r in rows(run/'regions.jsonl')}
    generated=list(rows(run/'generated_archive.jsonl'));byid={c['candidate_id']:c for c in generated}
    byid.update({c['candidate_id']:c for c in rows(run/'singletons.jsonl')})
    count=0;gen=Counter();reused=Counter();seen={};seenids=set();first={}
    events=rows(run/'expansion_events.jsonl') if (run/'expansion_events.jsonl').exists() else []
    for event in events:
        t=event['time'];parent=event['parent_fragment_ids'];added=event['added_fragment'];ids=sorted(parent+[added])
        if event['sequence']!=count or event['event_id'] in seenids:raise ValueError('event sequence mismatch')
        expected_event='E-'+digest([event['namespace'],count,event['seed_region'],event['seed'],event['parent_candidate_id'],added])[:32]
        equal(event['event_id'],expected_event)
        seenids.add(event['event_id']);count+=1
        if added in parent or ids!=event['result_fragment_ids']:raise ValueError('event fragment union mismatch')
        # Parent comes from all generated states, not final archive; its set is also explicitly required in every event.
        if byid[event['parent_candidate_id']]['fragment_ids']!=parent:raise ValueError('parent set mismatch')
        detail=expansion_details(parent,added,pairs.get(t,{}),regions[t,tuple(event['seed_region'])],profile['geometry']['max_added_gap_m'])
        equal({k:event[k] for k in detail},detail)
        labels=scenes[t][1];equal(event['added_point_count'],int((labels==added).sum()));equal(event['result_point_count'],int(np.isin(labels,ids).sum()))
        if event['result']=='GENERATED_HYPOTHESIS':
            cid=event['result_candidate_id'];equal(byid[cid]['fragment_ids'],ids)
            if event['candidate_reused']!=(cid in seen.setdefault(t,set())):raise ValueError('reused event classification')
            if not detail['decision']['passed']:raise ValueError('generated through failed distance gate')
            if cid not in first:first[cid]=event
            seen[t].add(cid);gen[t]+=1;reused[t]+=int(event['candidate_reused'])
    if count!=status['counters_seen'].get('expansion_events_started',0):raise ValueError('missing expansion events')
    equal(dict(gen),status['generated_event_count']);equal(dict(reused),status['reused_candidate_event_count'])
    equal({t:len(v) for t,v in seen.items()},status['unique_generated_candidate_count'])
    for c in generated:
        e=first[c['candidate_id']];parent=byid[e['parent_candidate_id']]
        equal(c['addition_order'],parent['addition_order']+[e['added_fragment']])
    actual_origins=list(rows(run/'candidate_event_origins.jsonl')) if (run/'candidate_event_origins.jsonl').exists() else []
    if len(actual_origins)!=len(generated):raise ValueError('representative origin coverage')
    for row in actual_origins:
        equal(row['representative_event_id'],first[row['candidate_id']]['event_id']);equal(row['representative_addition_order'],byid[row['candidate_id']]['addition_order'])
    from .archive import select_archive
    actual_selection=list(rows(run/'selection_events.jsonl')) if (run/'selection_events.jsonl').exists() else []
    saved=list(rows(run/'hypotheses.jsonl'))
    for t in config['times']:
        emitted=[];cs=[c for c in generated if c['namespace']['time']==t]
        selected,_=select_archive(cs,profile,audit_sink=lambda r:emitted.append(dict(r,time=t)))
        equal(emitted,[r for r in actual_selection if r['time']==t])
        equal([c['candidate_id'] for c in selected],[c['candidate_id'] for c in saved if c['namespace']['time']==t and not c['is_singleton']])
    return {'integrity':True,'processing_complete':manifest['processing_complete'],'search_exhaustive':manifest['search_exhaustive'],
            'audit_complete':True,'contact_count_verified':total,'expansion_events_verified':count,'unavailable_parent_events':0,
            'selection_events_verified':len(actual_selection),'generated_event_count':dict(gen),'unique_generated_candidate_count':{t:len(v) for t,v in seen.items()},
            'reused_candidate_event_count':dict(reused),'archived_unique_candidate_count':status['archived_unique_candidate_count'],
            'accuracy':'NOT_EVALUATED','identity':'UNKNOWN','distance_reproduction_tolerance_m':DISTANCE_ATOL}
