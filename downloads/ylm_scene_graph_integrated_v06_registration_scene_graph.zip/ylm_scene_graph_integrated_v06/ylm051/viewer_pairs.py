"""Relative, offline pair-stage audit UI alongside the original candidate viewer."""
import json
import math
import numpy as np
from .io import read,rows

def build_pair_viewer(run,output,max_points):
    config=read(run/'input_contract.json');scenes={};records=list(rows(run/'pair_pipeline.jsonl'))
    candidates=list(rows(run/'hypotheses.jsonl'));generated=list(rows(run/'generated_archive.jsonl'))
    for t,spec in config['times'].items():
        with np.load(run/spec['pixels']) as z:
            xyz,labels,valid=z['xyz'],z['labels'],z['valid']
        ids=np.flatnonzero(valid.ravel()&(labels.ravel()>=0));shown=ids[::max(1,math.ceil(len(ids)/max_points))]
        with np.load(run/f'image_contacts_{t}.npz') as z: contacts=z['contacts']
        selected=contacts[::max(1,math.ceil(len(contacts)/max_points))]
        scenes[t]={'xyz':xyz.reshape(-1,3)[shown].tolist(),'ids':labels.ravel()[shown].tolist(),
                   'row':(shown//labels.shape[1]).tolist(),'col':(shown%labels.shape[1]).tolist(),
                   'total_points':len(ids),'display_points':len(shown),'contacts_total':len(contacts),
                   'contacts':[{'pair':v[:2].tolist(),'pixel_ids':v[2:4].tolist(),'xyz':xyz.reshape(-1,3)[v[2:4]].tolist(),
                                'row':(v[2:4]//labels.shape[1]).tolist(),'col':(v[2:4]%labels.shape[1]).tolist(),'direction':int(v[4])} for v in selected]}
    # Geometry attached to the same pair view; all stages retain separate fields.
    geometries={(r['time'],tuple(r['fragment_ids'])):r for r in rows(run/'pair_evidence.jsonl')}
    for r in records:r['evaluation_details']=geometries.get((r['time'],tuple(r['fragment_ids'])))
    data={'scenes':scenes,'pairs':records,'saved':candidates,'generated':generated,'profile':read(run/'resolved_config.json')}
    payload=json.dumps(data,ensure_ascii=False,separators=(',',':'),allow_nan=False).replace('<','\\u003c')
    html='''<!doctype html><html lang="ja"><meta charset="utf-8"><title>YLM v0.5.1.1 pair audit</title>
<style>body{font:15px system-ui;margin:20px;background:#f3f6fa;color:#19334c}header{background:#183b56;color:white;padding:20px}main{display:grid;grid-template-columns:320px 1fr;gap:20px}section{background:white;padding:16px}label{display:block;margin:9px 0}input,select{max-width:100%;padding:6px}#pairs{width:100%;height:260px}#plot{height:600px}pre{white-space:pre-wrap;max-height:600px;overflow:auto}a{color:#0879aa}</style>
<header><h1>v0.5.1.1 ペア探索・保存監査</h1><p>列挙・評価・拡張・保存を個別表示 / identity UNKNOWN / update HELD / ICP NOT_RUN</p></header>
<p><a href="index.html">候補Viewer</a> · <a href="pair_pipeline_summary.json">段階別指標</a> · <a href="candidate_diversity.json">保存多様性</a> · <a href="archive_selection.jsonl">保存／除外理由</a></p>
<main><section><label>時刻<select id="time"></select></label>
<label>ペアID（例 206,245・完全一致）<input id="pairQuery"></label>
<label>元断片ID（完全一致）<input id="fragmentQuery"></label>
<label>方向<select id="direction"><option value="">全経路</option><option>H_ONLY</option><option>V_ONLY</option><option>BOTH</option></select></label>
<label>共有Core<select id="shared"><option value="">すべて</option><option value="true">あり</option><option value="false">なし</option></select></label>
<label>幾何評価<select id="evaluation"><option value="">すべて</option><option>EVALUATED</option><option>NOT_EVALUATED</option><option>INVALID_INPUT</option></select></label>
<label>探索ゲート<select id="gate"><option value="">すべて</option><option>ELIGIBLE</option><option>HOLD</option><option>EXCLUDED_BY_PROFILE</option></select></label>
<select id="pairs" size="12"></select>
<label>表示<select id="view"><option value="3d">3D</option><option value="organized">organized画素</option></select></label>
<label><input id="points" type="checkbox" checked>元断片（色分け）</label><label><input id="contacts" type="checkbox" checked>画像接触edge</label><label><input id="grid" type="checkbox">選択ペアのCore境界・共有領域</label>
<label>候補ID（部分一致）<input id="candidateQuery" placeholder="H-..."></label><label>候補集合<select id="candidatePool"><option value="saved">保存候補</option><option value="generated">生成候補（保存前）</option></select></label><select id="candidates"></select>
<label><input id="candidateLayer" type="checkbox">候補点レイヤー</label><p id="counts"></p></section>
<section><div id="plot"></div><h2>ペアの全段階状態</h2><p id="states"></p><pre id="details"></pre></section></main>
<script src="viewer/plotly.min.js"></script><script>const DATA=__DATA__;const E=id=>document.getElementById(id);let shownPairs=[],shownCandidates=[];
Object.keys(DATA.scenes).forEach(t=>E('time').add(new Option(t,t)));
function filter(){const t=E('time').value,q=E('pairQuery').value.trim(),f=E('fragmentQuery').value.trim();let requested=q?q.split(/[,\\s]+/).map(Number).sort((a,b)=>a-b):[];
shownPairs=DATA.pairs.filter(p=>p.time===t&&(!q||(requested.length===2&&p.fragment_ids.every((v,i)=>v===requested[i])))&&(!f||p.fragment_ids.some(v=>String(v)===f))&&(!E('direction').value||p.direction_class===E('direction').value)&&(!E('shared').value||String(p.shared_core)===E('shared').value)&&(!E('evaluation').value||p.geometry_evaluation===E('evaluation').value)&&(!E('gate').value||p.exploration_gate===E('gate').value));
E('pairs').textContent='';shownPairs.forEach((p,i)=>E('pairs').add(new Option(p.fragment_ids.join(',')+' '+p.geometry_evaluation,i)));if(shownPairs.length)E('pairs').value='0';candidates();}
function candidates(){const q=E('candidateQuery').value.trim();shownCandidates=DATA[E('candidatePool').value].filter(c=>c.namespace.time===E('time').value&&(!q||c.candidate_id.includes(q)));E('candidates').textContent='';shownCandidates.forEach((c,i)=>E('candidates').add(new Option(c.candidate_id+' ['+c.fragment_ids.join(',')+']',i)));if(shownCandidates.length)E('candidates').value='0';render();}
function render(){const s=DATA.scenes[E('time').value],p=shownPairs[Number(E('pairs').value)],org=E('view').value==='organized',traces=[];const selected=new Set(p?p.fragment_ids:[]);
function points(name,indexes,color,size){let r={name,mode:'markers',marker:{color,size},text:indexes.map(i=>'C'+s.ids[i])};if(org)Object.assign(r,{type:'scattergl',x:indexes.map(i=>s.col[i]),y:indexes.map(i=>s.row[i])});else Object.assign(r,{type:'scatter3d',x:indexes.map(i=>s.xyz[i][0]),y:indexes.map(i=>s.xyz[i][1]),z:indexes.map(i=>s.xyz[i][2])});traces.push(r);}
if(E('points').checked)points('元断片',s.ids.map((_,i)=>i),s.ids.map(f=>selected.has(f)?'hsl('+f*137.508%360+',75%,45%)':'#bdc8d3'),3);
if(E('candidateLayer').checked&&shownCandidates.length){const c=shownCandidates[Number(E('candidates').value)],ids=new Set(c.fragment_ids);points(E('candidatePool').value+' 候補',s.ids.map((_,i)=>i).filter(i=>ids.has(s.ids[i])),'#ff9a00',5);}
const keys=new Set(shownPairs.map(p=>p.fragment_ids.join(',')));let edges=s.contacts.filter(c=>keys.has(c.pair.join(','))&&(!p||c.pair.join(',')===p.fragment_ids.join(',')));
if(E('contacts').checked&&edges.length){const x=[],y=[],z=[];edges.forEach(c=>{for(let i=0;i<2;i++){x.push(org?c.col[i]:c.xyz[i][0]);y.push(org?c.row[i]:c.xyz[i][1]);z.push(c.xyz[i][2]);}x.push(null);y.push(null);z.push(null);});traces.push({type:org?'scattergl':'scatter3d',mode:'lines',name:'画像4近傍接触',x,y,z,line:{color:'#d54444',width:4}});}
if(E('grid').checked&&p&&!org){const g=DATA.profile.geometry,shared=new Set(p.shared_core_cells.map(c=>c.join(','))),cells=new Map();Object.values(p.core_cells).flat().forEach(c=>cells.set(c.join(','),c));for(const [key,c] of cells){const low=c.map((v,i)=>g.grid_origin_m[i]+v*g.cell_size_m),v=Array.from({length:8},(_,n)=>low.map((x,i)=>x+((n>>i)&1)*g.cell_size_m)),x=[],y=[],z=[];for(let a=0;a<8;a++)for(let d=0;d<3;d++){const b=a^(1<<d);if(a<b){x.push(v[a][0],v[b][0],null);y.push(v[a][1],v[b][1],null);z.push(v[a][2],v[b][2],null)}}traces.push({type:'scatter3d',mode:'lines',name:(shared.has(key)?'共有Core ':'Core ')+key,x,y,z,line:{color:shared.has(key)?'#18a08c':'#8d7abc',width:2}});}}
Plotly.react('plot',traces,{scene:{aspectmode:'data'},yaxis:{autorange:org?'reversed':true,scaleanchor:'x'},uirevision:E('time').value+org});E('details').textContent=JSON.stringify(p||{},null,2);E('states').textContent=p?[p.discovery,p.geometry_evaluation,p.exploration_gate,p.hypothesis_usage,p.archive].join(' → '):'一致なし';E('counts').textContent='点 '+s.display_points+'/'+s.total_points+'、接触表示用 '+s.contacts.length+'/'+s.contacts_total+'、絞込ペア '+shownPairs.length+'。表示のみ間引き。';}
['time','direction','shared','evaluation','gate'].forEach(k=>E(k).onchange=filter);['pairQuery','fragmentQuery'].forEach(k=>E(k).oninput=filter);E('candidateQuery').oninput=candidates;E('candidatePool').onchange=candidates;['pairs','view','points','contacts','grid','candidates','candidateLayer'].forEach(k=>E(k).onchange=render);filter();</script></html>'''
    output.text('pair_viewer.html',html.replace('__DATA__',payload))
    # Link without introducing absolute paths or an external server requirement.
    path=run/'index.html'
    output.text('index.html',path.read_text().replace('<nav>','<nav><a href="pair_viewer.html">v0.5.1.1 ペア・Grid監査</a> · ',1).replace('YLM v0.5.1 —','YLM v0.5.1.1 —'))
