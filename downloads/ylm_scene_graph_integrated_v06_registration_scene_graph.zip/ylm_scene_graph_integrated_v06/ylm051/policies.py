"""Explicit, uncalibrated search/storage controls; never identity thresholds."""

def defaults():
    return {'version': 'ylm0511.search.v1', 'scheduler': 'image_first_fair_v1',
            'expansion_scope': 'graph_frontier', 'archive_policy': 'diverse_v1',
            'budget_scope': 'per_time_reserved', 'image_tile_pixels': 32,
            'max_image_pixels_scanned': 10000000, 'max_unique_pairs_enumerated': 200000,
            'max_spatial_pairs_enumerated': 20000, 'max_spatial_proposals': 200000,
            'max_gap_pairs_enumerated': 20000, 'max_gap_proposals': 200000,
            'similarity_threshold': 0.85, 'similarity_group_limit': 2,
            'relax_similarity_to_fill': False,
            'parameter_source': 'explicit uncalibrated diagnostic storage/scheduling assumptions; not GT-tuned'}

def policy(profile):
    return profile.get('candidate_search', defaults())

def validate(p):
    s = policy(p)
    if set(s) != set(defaults()): raise ValueError('candidate_search fields must match schema')
    if s['version'] != 'ylm0511.search.v1' or s['scheduler'] != 'image_first_fair_v1': raise ValueError('unsupported search policy')
    if s['expansion_scope'] not in ('seed_region', 'graph_frontier'): raise ValueError('invalid expansion_scope')
    if s['archive_policy'] not in ('legacy_size_rank', 'diverse_v1'): raise ValueError('invalid archive_policy')
    if s['budget_scope'] not in ('per_time_reserved', 'global_shared'): raise ValueError('invalid budget_scope')
    for key in ('image_tile_pixels','max_image_pixels_scanned','max_unique_pairs_enumerated','max_spatial_pairs_enumerated','max_spatial_proposals','max_gap_pairs_enumerated','max_gap_proposals','similarity_group_limit'):
        if type(s[key]) is not int or s[key] < 1: raise ValueError('positive integer required: '+key)
    if not 0 < s['similarity_threshold'] <= 1: raise ValueError('invalid Jaccard threshold')
    if type(s['relax_similarity_to_fill']) is not bool: raise ValueError('explicit similarity relaxation boolean required')
    if not s['parameter_source']: raise ValueError('policy parameter sources required')
    return p
