"""Exact right/down image scan, independent from expensive pair checks."""
from collections import defaultdict, deque
import numpy as np
from .io import BudgetStop

def scan_image(scene, settings, budget, output):
    labels, valid = scene.labels, scene.valid
    height, width = labels.shape
    contacts = []; pairs = {}; processed = 0; reason = None
    try:
        for row in range(height):
            budget.check()
            if (row+1)*width > settings['max_image_pixels_scanned']: raise BudgetStop('IMAGE_PIXELS_SCAN_LIMIT')
            row_contacts = []
            for col in range(width):
                if not valid[row,col] or labels[row,col] < 0: continue
                for rr,cc,direction in ((row,col+1,0),(row+1,col,1)):
                    if rr>=height or cc>=width or not valid[rr,cc] or labels[rr,cc]<0 or labels[row,col]==labels[rr,cc]: continue
                    a,b=sorted((int(labels[row,col]),int(labels[rr,cc])))
                    row_contacts.append((a,b,row*width+col,rr*width+cc,direction))
            new={c[:2] for c in row_contacts if c[:2] not in pairs}
            if len(pairs)+len(new)>settings['max_unique_pairs_enumerated']: raise BudgetStop('UNIQUE_IMAGE_PAIRS_LIMIT')
            for a,b,p,q,d in row_contacts:
                entry=pairs.setdefault((a,b),{'horizontal_contact_count':0,'vertical_contact_count':0,'contact_indices':[], 'representative_pixel':p})
                entry['horizontal_contact_count' if d==0 else 'vertical_contact_count']+=1
                entry['contact_indices'].append(len(contacts));contacts.append((a,b,p,q,d))
            processed=row+1
    except BudgetStop as exc:
        reason=exc.reason
    complete=processed==height
    status={'time':scene.time,'image_enumeration_complete':complete,'processed_source_rows':[0,processed],
            'unknown_source_rows':[processed,height],'image_pixels_scanned':processed*width,'total_image_pixels':height*width,
            'image_contacts':len(contacts),'unique_image_pairs_enumerated':len(pairs),'stop_reason':reason,
            'contact_rule':'right/down once, valid nonnegative different labels, no wrap',
            'enumeration_rate':1.0 if complete and pairs else None,
            'rate_status':'MEASURED' if complete and pairs else 'NOT_APPLICABLE' if complete else 'UNKNOWN_DENOMINATOR'}
    output.json(f'image_scan/{scene.time}.json',status,essential=True)
    array=np.asarray(contacts,dtype=np.int64).reshape(-1,5)
    output.npz(f'image_contacts_{scene.time}.npz', contacts=array)
    for pair,entry in sorted(pairs.items()):
        h,v=entry['horizontal_contact_count'],entry['vertical_contact_count']
        entry['direction_class']='BOTH' if h and v else 'H_ONLY' if h else 'V_ONLY'
        r,c=divmod(entry['representative_pixel'],max(1,width));n=settings['image_tile_pixels']
        entry['tile']=[r//n,c//n]
        entry['contact_reference']=f'image_contacts_{scene.time}.npz'
        entry['contact_sampling']='NONE; all contact pixel endpoints stored'
    return pairs,status

def round_robin(queues):
    q=[deque(v) for _,v in sorted(queues.items()) if v]
    while q:
        next_round=[]
        for values in q:
            yield values.popleft()
            if values: next_round.append(values)
        q=next_round

def image_order(inventory):
    strata=defaultdict(lambda:defaultdict(list))
    for pair,row in sorted(inventory.items()):
        strata[(row['direction_class'], bool(row['shared_core']))][tuple(row['tile'])].append(pair)
    return list(round_robin({key:list(round_robin(tiles)) for key,tiles in strata.items()}))
