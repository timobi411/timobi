"""Separated pair discovery, fair evaluation and independent pipeline states."""
from collections import defaultdict
import itertools
import numpy as np
from .graph import Graph, build_regions, normalize, pair_geometry, independent_families, TARGETS
from .contacts import scan_image, image_order, round_robin
from .policies import policy
from .io import rows, digest, BudgetStop


def build_graph(scene, profile, output, budget):
    s=policy(profile)
    image,scan=scan_image(scene,s,budget,output)
    if not scan['image_enumeration_complete']:
        # A partial image scan is never allowed to appear as a successful generation.
        raise BudgetStop(scan['stop_reason'] or 'INCOMPLETE_IMAGE_ENUMERATION')
    regions=build_regions(scene,profile,output,budget)
    cores=defaultdict(set)
    for cell,r in regions.items():
        for f in r['core']: cores[f].add(cell)
    inventory={}; queues=defaultdict(set); original={}; enumeration={}
    def add(pair,route):
        pair=tuple(sorted(map(int,pair)))
        if pair not in inventory:
            if len(inventory)>=s['max_unique_pairs_enumerated']: return False
            shared=sorted(cores[pair[0]]&cores[pair[1]])
            inventory[pair]={'time':scene.time,'fragment_ids':list(pair),'discovery':'ENUMERATED',
                'geometry_evaluation':'NOT_EVALUATED','exploration_gate':'HOLD',
                'hypothesis_usage':'NOT_CONSIDERED','archive':'NOT_APPLICABLE',
                'routes':[],'shared_core':bool(shared),'shared_core_cells':[list(c) for c in shared],
                'core_cells':{str(f):[list(c) for c in sorted(cores[f])] for f in pair},
                'expansion_attempts':0,'used_for_expansion':0,'generated_co_membership':0,'saved_co_membership':0,
                'semantic_identity':'UNKNOWN','stop_reasons':[]}
        if route not in inventory[pair]['routes']: inventory[pair]['routes'].append(route)
        queues[route].add(pair)
        return True
    for pair,row in sorted(image.items()):
        add(pair,'IMAGE_CONTACT_4');inventory[pair].update(row)
        row['shared_core']=inventory[pair]['shared_core']
        output.event('image_pair_inventory.jsonl',inventory[pair])
    if profile['variant'] in ('B2','B3') and scene.relation_path:
        seen=set()
        for record in rows(scene.relation_path):
            e=normalize(record,scene,profile); pair=tuple(e['fragment_ids'])
            if e['evidence_id'] in seen: raise ValueError('duplicate evidence ID')
            seen.add(e['evidence_id'])
            if not add(pair,'ORIGINAL_RELATION'):
                enumeration['original']='UNIQUE_PAIR_LIMIT';break
            original.setdefault(pair,[]).append(e)
    if profile['variant']=='B2' and not scene.relation_path:
        raise ValueError('B2 NOT_EVALUATED: explicit upstream relation adapter/input required')
    # Enumeration has independent memory/work bounds; pair geometry consumes none here.
    if profile['variant']!='B0':
        for route,membership in [('BASE_CORE_AABB','core'),('SUPPLEMENTAL_HALO_BOUNDARY','halo')]:
            if membership=='halo' and profile['variant']!='B3': continue
            proposals=0; unique=set(); halted=False
            for cell,r in sorted(regions.items()):
                if not r['core']: continue
                for pair in itertools.combinations(sorted(r[membership]),2):
                    budget.check()
                    if proposals>=s['max_spatial_proposals']:
                        halted=True;break
                    proposals+=1
                    if pair not in unique and len(unique)>=s['max_spatial_pairs_enumerated']:
                        halted=True;break
                    unique.add(pair)
                    if not add(pair,route): halted=True;break
                if halted: break
            enumeration[route]={'proposals':proposals,'unique_pairs':len(unique),'complete':not halted,
                                'stop_reason':'SPATIAL_ENUMERATION_LIMIT' if halted else None}
        gap=int(profile['geometry']['pixel_gap']); labels=scene.labels; proposals=0; unique=set();halted=False
        for dr in range(gap+1):
            if halted: break
            for dc in range(-gap,gap+1):
                if (dr==0 and dc<=0) or dr*dr+dc*dc<=1 or dr*dr+dc*dc>gap*gap: continue
                if dr>=labels.shape[0] or abs(dc)>=labels.shape[1]: continue
                budget.check()
                ar,br=slice(dr,None),slice(None,-dr if dr else None)
                ac,bc=(slice(dc,None),slice(None,-dc if dc else None)) if dc>=0 else (slice(None,dc),slice(-dc,None))
                a,b=labels[ar,ac],labels[br,bc];mask=(a>=0)&(b>=0)&(a!=b)
                for pair in np.unique(np.sort(np.column_stack([a[mask],b[mask]]),axis=1),axis=0):
                    pair=tuple(map(int,pair))
                    if proposals>=s['max_gap_proposals'] or (pair not in unique and len(unique)>=s['max_gap_pairs_enumerated']): halted=True;break
                    proposals+=1;unique.add(pair)
                    if not add(pair,'BASE_IMAGE_GAP_GT1'):halted=True;break
                if halted:break
        enumeration['BASE_IMAGE_GAP_GT1']={'proposals':proposals,'unique_pairs':len(unique),'complete':not halted}
    sequence=image_order(image)
    seen=set(sequence)
    for pair in round_robin({k:sorted(v) for k,v in queues.items() if k!='IMAGE_CONTACT_4'}):
        if pair not in seen:sequence.append(pair);seen.add(pair)
    pairs={};adjacency={f:set() for f in scene.fragments};stop=None
    if profile['variant']=='B0': sequence=[]
    for order,pair in enumerate(sequence):
        entry=inventory[pair]
        try:
            budget.take('pair_checks')
            geo=pair_geometry(scene,*pair,profile,budget)
            ev=list(original.get(pair,[]))
            near=geo['minimum_distance_m']<=profile['geometry']['spatial_radius_m']
            image_gate=geo['pixel_boundary_gap'] is not None and geo['pixel_boundary_gap']<=profile['geometry']['pixel_gap']
            for kind,condition,family in [('SPATIAL_NEAR',near,'GEOMETRY_DISTANCE'),('IMAGE_GAP',image_gate,'IMAGE_DISTANCE')]:
                for target in sorted(TARGETS):
                    ev.append({'evidence_id':digest([scene.time,pair,kind,target])[:20],'fragment_ids':list(pair),
                        'kind':kind,'target':target,'state':'HOLD','family':family,'calibration':'UNCALIBRATED',
                        'source_samples':[],'source_pixels':[geo['closest_source_pixel'],geo['closest_target_pixel']],
                        'time':scene.time,'conditions':{'exploration_threshold_met':bool(condition)},
                        'origin':'image_contact_4' if pair in image else 'supplemental_search' if 'SUPPLEMENTAL_HALO_BOUNDARY' in entry['routes'] else 'baseline_geometry',
                        'rejection_scope':None,'upstream_search_complete':'UNAVAILABLE'})
            eligible=near or image_gate or bool(original.get(pair))
            entry.update(geometry_evaluation='EVALUATED',exploration_gate='ELIGIBLE' if eligible else 'EXCLUDED_BY_PROFILE',evaluation_order=order)
            record={'time':scene.time,'fragment_ids':list(pair),'geometry':geo,'evidence':ev,
                    'routes':[{'route':r,'cell':[]} for r in sorted(entry['routes'])],
                    'exploration_state':'ELIGIBLE_FOR_HYPOTHESIS' if eligible else 'SEARCH_GATE_EXCLUDED',
                    'semantic_identity':'UNKNOWN','independent_support':independent_families(ev,profile)}
            pairs[pair]=record
            if eligible:
                adjacency[pair[0]].add(pair[1]);adjacency[pair[1]].add(pair[0])
            output.event('pair_evidence.jsonl',record)
            if 'SUPPLEMENTAL_HALO_BOUNDARY' in entry['routes']:output.event('supplemental_graph.jsonl',record)
        except BudgetStop as exc:
            stop=exc.reason;break
        except (ValueError,FloatingPointError) as exc:
            entry.update(geometry_evaluation='INVALID_INPUT',exploration_gate='HOLD',error=str(exc),evaluation_order=order)
        output.event('pair_evaluation.jsonl',entry)
    for pair in sequence:
        if inventory[pair]['geometry_evaluation']=='NOT_EVALUATED':inventory[pair]['stop_reasons'].append(stop or 'NOT_EVALUATED')
    truncated=bool(stop) or any(isinstance(v,dict) and not v.get('complete',True) for v in enumeration.values()) or bool(enumeration.get('original'))
    status={'time':scene.time,'original_graph':'AVAILABLE' if scene.relation_path else 'UNAVAILABLE','original_edges':len(original),
            'normalized_pairs':len(pairs),'unique_pairs_enumerated':len(inventory),'enumerated_unprocessed_pairs':sum(v['geometry_evaluation']=='NOT_EVALUATED' for v in inventory.values()),
            'unseen_pair_count':'UNKNOWN' if truncated else 0,'exploration_state':'BUDGET_TRUNCATED' if truncated else 'ENUMERATED_WITHIN_CONFIGURED_ROUTES',
            'stop_reason':stop,'variant':profile['variant'],'image_scan':scan,'enumeration':enumeration,
            'absence_interpretation':'not evidence of no relation','scheduler':s['scheduler']}
    output.event('graph_status.jsonl',status)
    graph=Graph(pairs,adjacency,regions,status)
    graph.inventory=inventory;graph.image_inventory=image;graph.cores=cores
    graph.expansion_scope=s['expansion_scope']
    return graph


def finish_diagnostics(graph,candidates,output,time_key):
    inv=getattr(graph,'inventory',{})
    for c in candidates:
        if len(c['fragment_ids'])<2:continue
        for pair in itertools.combinations(c['fragment_ids'],2):
            if pair in inv:inv[pair]['saved_co_membership']+=1
    for pair,e in sorted(inv.items()):
        e['hypothesis_usage']='GENERATED' if e['used_for_expansion'] else 'EXPANSION_CONSIDERED' if e['expansion_attempts'] else 'NOT_CONSIDERED'
        archive_states=e.get('candidate_archive_states',{})
        e['archive']='KEPT' if e['saved_co_membership'] else 'PRUNED_RANK' if archive_states.get('PRUNED_RANK') else 'PRUNED_DIVERSITY' if archive_states.get('PRUNED_DIVERSITY') else 'NOT_APPLICABLE'
        if not e['expansion_attempts'] and e['exploration_gate']=='ELIGIBLE':
            possible_local=any(set(pair)<=r['halo'] for r in graph.regions.values())
            e['stop_reasons'].append('GRID_SCOPE_NO_COMMON_REGION' if not possible_local and getattr(graph,'expansion_scope',None)=='seed_region' else 'NOT_REACHED_WITHIN_CONFIGURED_SEARCH')
        e['actual_usage_definition']='deterministic minimum-gap eligible frontier witness; all co-memberships counted separately'
        # The candidate-level archive ledger gives diversity/rank pruning, independent from co-membership.
        output.event('pair_pipeline.jsonl',e)
    image=getattr(graph,'image_inventory',{})
    groups={'ALL':list(image)}
    for d in ('H_ONLY','V_ONLY','BOTH'):
        for shared in (False,True): groups[f'{d}/shared_core={shared}']=[p for p,r in image.items() if r['direction_class']==d and bool(r['shared_core'])==shared]
    metrics={}
    for name,keys in groups.items():
        n=len(keys);counts={'enumerated':n,'evaluated':sum(inv[k]['geometry_evaluation']=='EVALUATED' for k in keys),
            'invalid_input':sum(inv[k]['geometry_evaluation']=='INVALID_INPUT' for k in keys),
            'gate_passed':sum(inv[k]['exploration_gate']=='ELIGIBLE' for k in keys),
            'expansion_considered':sum(inv[k]['expansion_attempts']>0 for k in keys),
            'used_for_expansion':sum(inv[k]['used_for_expansion']>0 for k in keys),
            'generated_co_membership':sum(inv[k]['generated_co_membership']>0 for k in keys),
            'saved_co_membership':sum(inv[k]['saved_co_membership']>0 for k in keys)}
        metrics[name]={'denominator_image_unique_pairs':n,'counts':counts,'rates_over_image_pairs':{k:v/n if n else None for k,v in counts.items()},
                       'not_evaluated_pairs':[list(k) for k in keys if inv[k]['geometry_evaluation']=='NOT_EVALUATED'],
                       'status':'MEASURED' if n else 'NOT_APPLICABLE'}
    return {'time':time_key,'image_scan':graph.status.get('image_scan'), 'metrics':metrics,
            'unique_pairs_enumerated':len(inv),'geometry_pairs_evaluated':len(graph.pairs),
            'interpretation':'search reachability, not object accuracy; co-membership differs from causal expansion use'}
