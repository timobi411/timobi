"""Passive float64 boundary and expansion diagnostics. Never used for search decisions."""
from collections import Counter
import numpy as np
from scipy.spatial import cKDTree
from .io import BudgetStop, digest

TIE_ATOL = 1e-12  # numerical tie reporting only, not a search threshold
DISTANCE_ATOL = 1e-6

def contact_arrays(xyz, valid, labels, check=None):
    xyz=np.asarray(xyz,dtype=np.float64); h,w=labels.shape
    good=valid & np.isfinite(xyz).all(axis=2) & (labels>=0)
    contacts=[]
    for r in range(h):
        if check:check()
        for c in range(w):
            if not good[r,c]: continue
            for rr,cc,d in ((r,c+1,0),(r+1,c,1)):
                if rr>=h or cc>=w or not good[rr,cc] or labels[r,c]==labels[rr,cc]:continue
                a,b=int(labels[r,c]),int(labels[rr,cc]);p,q=r*w+c,rr*w+cc
                if a>b:a,b,p,q=b,a,q,p
                contacts.append((a,b,p,q,d))
    rows=np.array(sorted(contacts),dtype=np.int64).reshape(-1,5)
    p=rows[:,2:4];pts=xyz.reshape(-1,3)[p];ranges=np.linalg.norm(pts,axis=2)
    delta=pts[:,1]-pts[:,0];dr=ranges[:,1]-ranges[:,0]
    return {'fragment_ids':rows[:,:2],'pixel_ids':p,'row_col':np.stack(np.divmod(p,max(1,w)),axis=-1),
            'xyz':pts,'direction':rows[:,4],'delta_xyz':delta,'distance_m':np.linalg.norm(delta,axis=1),
            'range_m':ranges,'signed_delta_range_m':dr,'abs_delta_range_m':np.abs(dr)}

def quantiles(v,qs=(0,.05,.5,.95,1)):
    return np.quantile(v,qs).tolist() if len(v) else None

def summarize(arr,start,end):
    d=arr['direction'][start:end];p=arr['pixel_ids'][start:end];dr=arr['signed_delta_range_m'][start:end]
    return {'contact_count':end-start,'horizontal_count':int((d==0).sum()),'vertical_count':int((d==1).sum()),
        'distinct_endpoints':int(len(np.unique(p))),'distinct_endpoints_by_fragment':[int(len(np.unique(p[:,i]))) for i in (0,1)],
        'distance_min_p05_p50_p95_max_m':quantiles(arr['distance_m'][start:end]),
        'abs_range_min_p05_p50_p95_max_m':quantiles(arr['abs_delta_range_m'][start:end]),
        'signed_range_min_p50_max_m':quantiles(dr,(0,.5,1)),
        'signed_range_counts':{'positive':int((dr>0).sum()),'negative':int((dr<0).sum()),'zero':int((dr==0).sum())}}

def minima(links):
    if not links:return {'minimum_m':None,'equal_minimum_pairs':[],'representative_pair':None}
    v=min(p['geometry']['minimum_distance_m'] for p in links)
    keys=sorted(p['fragment_ids'] for p in links if abs(p['geometry']['minimum_distance_m']-v)<=TIE_ATOL)
    return {'minimum_m':v,'equal_minimum_pairs':keys,'representative_pair':keys[0]}

def expansion_details(parent_ids,added,pairs,local_fids,limit):
    links=[pairs[tuple(sorted((f,added)))] for f in parent_ids if tuple(sorted((f,added))) in pairs]
    eligible=[p for p in links if p['exploration_state']=='ELIGIBLE_FOR_HYPOTHESIS']
    allowed=[p for p in eligible if added in local_fids or any(r['route'] in ('IMAGE_CONTACT_4','ORIGINAL_RELATION') for r in p['routes'])]
    witness=min(allowed,key=lambda p:(p['geometry']['minimum_distance_m'],p['fragment_ids'])) if allowed else None
    a,e=minima(links),minima(eligible)
    return {'all_links':sorted(p['fragment_ids'] for p in links),'eligible_links':sorted(p['fragment_ids'] for p in eligible),
            'all_links_minimum':a,'eligible_links_minimum':e,
            'decision':{'set':'legacy_all_links','distance_m':a['minimum_m'],'operator':'<=','limit_m':limit,
                        'passed':a['minimum_m'] is not None and a['minimum_m']<=limit},
            'shadow_eligible_passed':e['minimum_m'] is not None and e['minimum_m']<=limit,
            'shadow_only':True,'tie_absolute_tolerance_m':TIE_ATOL,
            'witness_pair':witness['fragment_ids'] if witness else None,
            'witness_rule':'minimum measured gap among eligible allowed frontier links, then pair key',
            'witness_is_distance_minimizer':bool(witness and witness['fragment_ids'] in a['equal_minimum_pairs']),
            'routes':sorted({r['route'] for p in links for r in p['routes']}),'crosses_seed_region':added not in local_fids}

class AuditRecorder:
    def __init__(self,output):
        self.output=output;self.seen=Counter();self.written=Counter();self.stops=[];self.contacts={};self.pending=None
        self.generated=Counter();self.reused=Counter();self.unique={};self.representatives={}

    def write(self,name,value,kind='event'):
        self.seen[name]+=1
        if self.stops:return False
        try:
            if kind=='npz':self.output.npz(name,**value)
            else:self.output.event(name,value)
            self.written[name]+=1;return True
        except (BudgetStop,MemoryError) as exc:
            self.stops.append(getattr(exc,'reason',type(exc).__name__));return False

    def start(self,scene,graph,parent,added,cell,seed,depth,local_fids,profile,reused):
        i=self.seen.get('expansion_events_started',0);self.seen['expansion_events_started']+=1
        ids=sorted(parent['fragment_ids']+[added])
        from .search import stable_id
        event={'schema':'ylm0512.expansion.v1','event_id':'E-'+digest([scene.namespace,i,cell,seed,parent['candidate_id'],added])[:32],
               'sequence':i,'time':scene.time,'namespace':scene.namespace,'seed':seed,'seed_region':list(cell),'depth':depth,
               'parent_candidate_id':parent['candidate_id'],'parent_fragment_ids':parent['fragment_ids'],
               'added_fragment':added,'result_fragment_ids':ids,'result_candidate_id':stable_id(scene,profile,ids),
               'candidate_reused':reused,'added_point_count':len(scene.fragments[added].ids),
               'result_point_count':sum(len(scene.fragments[f].ids) for f in ids),
               **expansion_details(parent['fragment_ids'],added,graph.pairs,local_fids,profile['geometry']['max_added_gap_m'])}
        self.pending=event;return event

    def finish(self,event,result,candidate=None,stop_reason=None):
        event.update(result=result,stop_reason=stop_reason,risk_flags=candidate['risk_flags'] if candidate else [],
                     risk_status='AUDITED' if candidate else 'NOT_REACHED')
        if result=='GENERATED_HYPOTHESIS':
            t=event['time'];self.generated[t]+=1;self.reused[t]+=int(event['candidate_reused'])
            self.unique.setdefault(t,set()).add(event['result_candidate_id'])
            if not event['candidate_reused']:self.representatives[event['result_candidate_id']]=event['event_id']
        self.write('expansion_events.jsonl',event);self.pending=None

    def status(self,complete_search=False):
        for value in self.contacts.values():
            value['pairs_unwritten']=value['total_pairs']-value['pairs_written'] if 'total_pairs' in value else None
        return {'schema':'ylm0512.audit.v1','audit_complete':bool(complete_search and not self.stops and self.pending is None and all(v['complete'] for v in self.contacts.values())),
                'stop_reasons':self.stops,'counters_seen':dict(self.seen),'counters_written':dict(self.written),
                'unwritten_records':{k:n-self.written[k] for k,n in self.seen.items() if k!='expansion_events_started'},
                'contacts':self.contacts,'generated_event_count':dict(self.generated),
                'unique_generated_candidate_count':{t:len(v) for t,v in self.unique.items()},'reused_candidate_event_count':dict(self.reused),
                'unreached_work':'NONE' if complete_search else 'UNKNOWN_REMAINING_SEARCH_OR_AUDIT',
                'counter_scope':'audit records do not consume pair/expanded/point-copy budgets; wall/RSS/storage remain global',
                'accuracy':'NOT_EVALUATED','identity':'UNKNOWN'}

    def boundaries(self,scene,graph,profile):
        t=scene.time;self.contacts[t]={'complete':False,'pairs_written':0,'contacts_written':0,'unwritten_contacts':None}
        if self.stops:return
        if not (self.output.root/f'image_contacts_{t}.npz').exists():
            self.stops.append('IMAGE_ENUMERATION_UNAVAILABLE');return
        try:
            if self.output.budget:self.output.budget.check()
            arr=contact_arrays(scene.xyz,scene.valid,scene.labels,check=self.output.budget.check if self.output.budget else None)
            legacy=np.load(self.output.root/f'image_contacts_{t}.npz')['contacts']
            expected=sorted((int(a),int(b),*sorted((int(p),int(q))),int(d)) for a,b,p,q,d in legacy)
            actual=sorted((int(a),int(b),*sorted((int(p),int(q))),int(d)) for (a,b),(p,q),d in zip(arr['fragment_ids'],arr['pixel_ids'],arr['direction']))
            if expected!=actual:raise ValueError('full image contact endpoint mismatch')
            self.contacts[t]['unwritten_contacts']=len(actual)
            if not self.write(f'contact_geometry_{t}.npz',arr,'npz'):return
            self.contacts[t].update(contacts_written=len(actual),unwritten_contacts=0)
            offsets={};i=0
            while i<len(actual):
                key=tuple(map(int,arr['fragment_ids'][i]));j=i+1
                while j<len(actual) and tuple(arr['fragment_ids'][j])==key:j+=1
                offsets[key]=(i,j);i=j
            h,w=scene.labels.shape
            keys=sorted(set(getattr(graph,'inventory',{}))|set(offsets));self.contacts[t]['total_pairs']=len(keys)
            for key in keys:
                start,end=offsets.get(key,(0,0));pair=graph.pairs.get(key);nearest=None;gate=None
                if pair:
                    geo=pair['geometry'];p,q=geo['closest_source_pixel'],geo['closest_target_pixel']
                    pa,pb=scene.xyz.reshape(-1,3)[[p,q]].astype(np.float64)
                    delta=[q//w-p//w,q%w-p%w]
                    nearest={'pixel_ids':[p,q],'distance_m':float(np.linalg.norm(pb-pa)),
                             'legacy_distance_m':geo['minimum_distance_m'],'row_col_delta':delta,
                             'is_direct_4_contact':sum(abs(v) for v in delta)==1,
                             'signed_delta_range_m':float(np.linalg.norm(pb)-np.linalg.norm(pa))}
                    ba,bb=(scene.fragments[f].boundary_ids for f in key)
                    refs=None
                    if len(ba) and len(bb):
                        ca=np.column_stack(np.divmod(ba,w));cb=np.column_stack(np.divmod(bb,w))
                        ds,nn=cKDTree(cb).query(ca);idx=int(np.argmin(ds));refs=[int(ba[idx]),int(bb[nn[idx]])]
                    spatial=geo['minimum_distance_m']<=profile['geometry']['spatial_radius_m']
                    image=geo['pixel_boundary_gap'] is not None and geo['pixel_boundary_gap']<=profile['geometry']['pixel_gap']
                    original=any(e['origin']=='original_saved_relation' for e in pair['evidence'])
                    gate={'time':t,'fragment_ids':list(key),
                        'spatial_gate':{'value_m':geo['minimum_distance_m'],'limit_m':profile['geometry']['spatial_radius_m'],'operator':'<=','passed':spatial},
                        'image_gate':{'value_pixels':geo['pixel_boundary_gap'],'limit_pixels':profile['geometry']['pixel_gap'],'operator':'<=','passed':image},
                        'original_relation_present':original,'final_or':bool(spatial or image or original),
                        'calibrated_identity_support_present':any(e['state']=='SUPPORTED' and e['target']=='OBJECT_PART_ASSOCIATION' and e['calibration']=='VALIDATED_RULE_REFERENCED' for e in pair['evidence']),
                        'typed_references':{'GEOMETRY_DISTANCE':{'pixel_ids':[p,q],'measurement':'whole_fragment_3d_nearest'},
                                            'IMAGE_DISTANCE':{'pixel_ids':refs,'measurement':'boundary_pixel_distance','unavailable_reason':None if refs else 'NO_BOUNDARY_ENDPOINTS'}},
                        'evidence_ids':{family:[e['evidence_id'] for e in pair['evidence'] if e['family']==family] for family in ('GEOMETRY_DISTANCE','IMAGE_DISTANCE')},
                        'legacy_source_pixels_meaning':'legacy records use 3D-nearest endpoints for both families; typed_references here are authoritative; targets do not duplicate independent support'}
                    self.write('pair_gate_audit.jsonl',gate)
                row={'schema':'ylm0512.contact_summary.v1','time':t,'namespace':scene.namespace,'input_fingerprint':scene.fingerprint,
                     'fragment_ids':list(key),'array':f'contact_geometry_{t}.npz','offset':[start,end],
                     'status':'DIRECT_CONTACT' if end>start else 'NO_DIRECT_CONTACT','nearest_3d':nearest,
                     'nearest_status':'EVALUATED' if pair else 'NOT_EVALUATED','precision':'float64',
                     'sign_definition':'higher fragment ID endpoint minus lower fragment ID endpoint',
                     'range_origin':'coordinate origin; sensor origin unverified','quantile_method':'numpy linear',**summarize(arr,start,end)}
                if not self.write('contact_geometry_summary.jsonl',row):return
                self.contacts[t]['pairs_written']+=1
            self.contacts[t]['complete']=not self.stops
        except (BudgetStop,MemoryError) as exc:self.stops.append(getattr(exc,'reason',type(exc).__name__))
