"""Fixed-archive selection and strictly separate post-hoc proxy evaluation."""
from collections import Counter
from pathlib import Path
import itertools
import numpy as np
from .io import Output,Budget,BudgetStop,read,rows,sha,digest
from .archive import select_archive,diversity,owner

def observation_metrics(run,time,generated,selected,records=()):
    config=read(run/'input_contract.json');profile=read(run/'resolved_config.json')
    with np.load(run/config['times'][time]['pixels']) as z:labels,valid,xyz=z['labels'],z['valid'],z['xyz']
    allpixels=set(map(int,np.flatnonzero(valid.ravel()&(labels.ravel()>=0))))
    fragments={int(f):set(map(int,np.flatnonzero(labels.ravel()==f))) for f in np.unique(labels[labels>=0])}
    def union(cs):return set().union(*(fragments[f] for c in cs for f in c['fragment_ids'])) if cs else set()
    generated_pixels=union(generated);saved_pixels=union(selected)
    contact={tuple(r['fragment_ids']):r for r in rows(run/'contact_geometry_summary.jsonl') if r['time']==time and r['contact_count']} if (run/'contact_geometry_summary.jsonl').exists() else {}
    def describe(cs):
        point_counts=[sum(len(fragments[f]) for f in c['fragment_ids']) for c in cs]
        maxsteps=[];pairs=set()
        for c in cs:
            pp=set(itertools.combinations(c['fragment_ids'],2));pairs.update(pp)
            steps=[contact[p]['abs_range_min_p05_p50_p95_max_m'][-1] for p in pp if p in contact]
            if steps:maxsteps.append(max(steps))
        pix=union(cs);origin=np.asarray(profile['geometry']['grid_origin_m']);cell=profile['geometry']['cell_size_m']
        tiles=set(map(tuple,np.floor((xyz.reshape(-1,3)[sorted(pix)]-origin)/cell).astype(np.int64))) if pix else set()
        fragment_counts=Counter(f for c in cs for f in c['fragment_ids']);owner_counts=Counter(str(owner(c)) for c in cs)
        region_counts=Counter(str(owner(c)[0]) for c in cs)
        return {'candidate_count':len(cs),'fragment_union':sorted({f for c in cs for f in c['fragment_ids']}),
                'pixel_union_count':len(pix),'grid_tile_union_count':len(tiles),'grid_tile_definition':'all measured points; same profile grid',
                'fragment_count_distribution':dict(Counter(len(c['fragment_ids']) for c in cs)),
                'point_count_min_p05_p50_p95_max':np.quantile(point_counts,[0,.05,.5,.95,1]).tolist() if point_counts else None,
                'candidate_max_contact_abs_range_min_p05_p50_p95_max_m':np.quantile(maxsteps,[0,.05,.5,.95,1]).tolist() if maxsteps else None,
                'candidates_with_direct_contact':len(maxsteps),'internal_unique_contact_pairs':sum(p in contact for p in pairs),
                'owner_counts':dict(owner_counts),'region_counts':dict(region_counts),'fragment_appearance_counts':dict(sorted(fragment_counts.items())),
                'maximum_fragment_concentration':max(fragment_counts.values())/len(cs) if cs else None,
                'exact_duplicate_fragment_sets':len(cs)-len({tuple(c['fragment_ids']) for c in cs}),
                'diversity':diversity(cs,list(records)) if len(cs)<=profile['budgets']['combined_per_time'] else {'pairwise_jaccard':'not expanded for all generated states; selected set measured separately'}}
    return {'time':time,'all_observed_points':len(allpixels),'all_observed_fragments':len(fragments),
            'singletons':{'pixel_union':len(allpixels),'fragment_union':len(fragments),'included_in_combined_metrics':False},
            'generated_combined':describe(generated),'saved_combined':describe(selected),
            'generated_only_pixel_count':len(generated_pixels-saved_pixels),'not_generated_pixel_count':len(allpixels-generated_pixels),
            'union_definition':'union across hypotheses, not one object or accuracy','accuracy':'NOT_EVALUATED'}

def select_run(source,destination,policy='S0'):
    run=Path(source).resolve();dest=Path(destination).resolve()
    if dest.exists():raise FileExistsError('new selection output directory required')
    if policy not in ('S0','coverage_order_v1'):raise ValueError('unknown selection policy')
    from .pipeline import verify
    verify(run);profile=read(run/'resolved_config.json');b=Budget(profile['budgets']);out=Output(dest,b);dest.mkdir(parents=True)
    generated=list(rows(run/'generated_archive.jsonl'));before=sha(run/'generated_archive.jsonl');result={'policy':policy,'default_policy':'S0',
        'generated_archive_sha256':before,'profile_sha256':sha(run/'resolved_config.json'),'source_modules':__import__('ylm051.pipeline',fromlist=['runtime']).runtime()['source_modules'],
        'selection_only':True,'proxy_inputs':'NOT_ACCEPTED','times':{},'complete':False}
    out.text('selection_events.jsonl','');out.text('selected_candidates.jsonl','');out.text('selection_decisions.jsonl','')
    try:
        for t in sorted(read(run/'input_contract.json')['times']):
            cs=[c for c in generated if c['namespace']['time']==t]
            chosen,records=select_archive(cs,profile,selection_policy=policy,
                audit_sink=lambda row:out.event('selection_events.jsonl',dict(row,time=t)))
            for c in chosen:out.event('selected_candidates.jsonl',c)
            for r in records:out.event('selection_decisions.jsonl',dict(r,time=t))
            result['times'][t]=observation_metrics(run,t,cs,chosen,records)
            result['times'][t]['configured_cap']=profile['budgets']['combined_per_time']
            result['times'][t]['under_cap_reason']='SIMILARITY_OR_AVAILABLE_CANDIDATES' if len(chosen)<profile['budgets']['combined_per_time'] else None
            result['times'][t]['similarity_threshold']=profile['candidate_search']['similarity_threshold']
            result['times'][t]['similarity_group_limit']=profile['candidate_search']['similarity_group_limit']
        result['complete']=True
    except BudgetStop as exc:result['stop_reason']=exc.reason
    result['resources']=b.report();result['generation_unchanged']=sha(run/'generated_archive.jsonl')==before
    out.json('selection_manifest.json',result,essential=True);return result

def proxy_evaluate(source,selection,proxy_path,time,destination):
    run=Path(source).resolve();dest=Path(destination).resolve()
    if dest.exists():raise FileExistsError('new evaluation output required')
    from .pipeline import verify
    verify(run);profile=read(run/'resolved_config.json');config=read(run/'input_contract.json')
    before=sha(run/'artifact_hashes.json');archive_hash=sha(run/'generated_archive.jsonl')
    b=Budget(profile['budgets']);out=Output(dest,b);dest.mkdir(parents=True)
    proxy=np.load(proxy_path,allow_pickle=False)
    if proxy.ndim!=1 or not np.issubdtype(proxy.dtype,np.integer):raise ValueError('proxy must be a one-dimensional integer pixel-ID array')
    with np.load(run/config['times'][time]['pixels']) as z:labels,valid=z['labels'],z['valid']
    observed=set(map(int,np.flatnonzero(valid.ravel()&(labels.ravel()>=0))));target=set(map(int,proxy))
    if not target<=observed:raise ValueError('proxy IDs outside valid labeled observation')
    generated=[c for c in rows(run/'generated_archive.jsonl') if c['namespace']['time']==time]
    selected_file=Path(selection)/'selected_candidates.jsonl' if selection else run/'hypotheses.jsonl'
    if selection and read(Path(selection)/'selection_manifest.json')['generated_archive_sha256']!=archive_hash:raise ValueError('selection archive mismatch')
    selected=[c for c in rows(selected_file) if c['namespace']['time']==time and len(c['fragment_ids'])>1]
    frag={int(f):set(map(int,np.flatnonzero(labels.ravel()==f))) for f in np.unique(labels[labels>=0])}
    pixels={c['candidate_id']:set().union(*(frag[f] for f in c['fragment_ids'])) for c in generated}
    gen_union=set().union(*pixels.values()) if pixels else set();saved_union=set().union(*(pixels[c['candidate_id']] for c in selected)) if selected else set()
    scores=[{'candidate_id':c['candidate_id'],'fragment_ids':c['fragment_ids'],'inside':len(pixels[c['candidate_id']]&target),
             'outside':len(pixels[c['candidate_id']]-target),'inside_already_in_saved_union':len(pixels[c['candidate_id']]&target&saved_union),
             'inside_outside_saved_union':len((pixels[c['candidate_id']]&target)-saved_union)} for c in generated]
    ins=np.array([v['inside'] for v in scores]);outs=np.array([v['outside'] for v in scores]);pareto=[]
    result={'status':'COMPLETE','proxy_sha256':sha(proxy_path),'proxy_unique_pixels':len(target),'proxy_original_entries':len(proxy),
        'generated_archive_sha256':archive_hash,'selected_candidates_sha256':sha(selected_file),
        'partition':{'saved':len(target&saved_union),'generated_only':len((target&gen_union)-saved_union),'not_generated':len(target-gen_union)},
        'accuracy':'NOT_EVALUATED','proxy_is_independent_GT':False,'outside_meaning':'not in proxy; not established false merge'}
    try:
        for s in scores:
            dominated=np.any((ins>=s['inside'])&(outs<=s['outside'])&((ins>s['inside'])|(outs<s['outside'])))
            s['non_dominated']=not bool(dominated);out.event('candidate_proxy_comparison.jsonl',s)
            if not dominated:pareto.append(s['candidate_id'])
        result['non_dominated_candidate_ids']=pareto
        # All saved and Pareto candidate pairs, streamed under the original wall/storage ceiling.
        ids=sorted(set(pareto)|{c['candidate_id'] for c in selected});n=0
        for a,c in itertools.combinations(ids,2):
            pa,pc=pixels[a],pixels[c]
            out.event('candidate_pixel_overlap.jsonl',{'a':a,'b':c,'all_intersection':len(pa&pc),'proxy_intersection':len(pa&pc&target),'all_union':len(pa|pc)});n+=1
        result['overlap_pairs_written']=n
    except BudgetStop as exc:result.update(status='PARTIAL',stop_reason=exc.reason)
    result['resources']=b.report();result['generation_unchanged']=before==sha(run/'artifact_hashes.json') and archive_hash==sha(run/'generated_archive.jsonl')
    out.json('proxy_evaluation.json',result,essential=True);return result
