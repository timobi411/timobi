"""Evidence remains hypotheses; search exclusion never becomes semantic rejection."""
from dataclasses import dataclass
import itertools
import numpy as np
from scipy.spatial import cKDTree
from .io import rows, digest, BudgetStop

KINDS = {'DIRECT_HELD', 'IMAGE_GAP', 'SPATIAL_NEAR', 'CHAIN_REVIEW'}
TARGETS = {'SURFACE_CONTINUATION', 'OBJECT_PART_ASSOCIATION'}


def aabb_gap(a, b):
    return float(np.linalg.norm(np.maximum(0, np.maximum(a.low - b.high, b.low - a.high))))


def normalize(record, scene, profile):
    if record.get('schema') != 'ylm051.evidence.v1':
        raise ValueError('relations need an explicit ylm051.evidence.v1 adapter; raw upstream schema is not guessed')
    a, b = record['fragment_ids']
    if type(a) is not int or type(b) is not int or a == b or a not in scene.fragments or b not in scene.fragments:
        raise ValueError('invalid relation endpoints')
    kind, target = record['kind'], record['target']
    if kind not in KINDS or target not in TARGETS:
        raise ValueError('unknown relation kind or target')
    state = record['state']
    if state not in ('SUPPORTED', 'HOLD', 'REJECTED'):
        raise ValueError('invalid relation state')
    rule = record.get('validated_rule_id')
    calibrated = bool(rule and rule in profile['calibration']['validated_rule_ids'])
    independence = profile['calibration']['independence_rule']
    promoted = state == 'SUPPORTED' and calibrated and independence is not None and bool(record.get('source_samples') or record.get('source_pixels'))
    rejected = state == 'REJECTED' and calibrated and bool(record.get('rejection_scope'))
    normalized_state = 'SUPPORTED' if promoted else 'REJECTED' if rejected else 'HOLD'
    evidence = {'evidence_id': str(record['evidence_id']), 'fragment_ids': sorted([a, b]), 'kind': kind,
                'target': target, 'state': normalized_state, 'original_state': state,
                'calibration': 'VALIDATED_RULE_REFERENCED' if calibrated else 'UNCALIBRATED',
                'validated_rule_id': rule, 'rejection_scope': record.get('rejection_scope') if rejected else None,
                'conditions': record.get('conditions', {}), 'family': record.get('family'),
                'source_samples': sorted(set(map(str, record.get('source_samples', [])))),
                'source_pixels': sorted(set(int(p) for p in record.get('source_pixels', []))),
                'source_candidate_id': record.get('source_candidate_id'),
                'exploration_state': record.get('exploration_state', 'SAVED_UPSTREAM'),
                'upstream_search_complete': record.get('upstream_search_complete', 'UNAVAILABLE'),
                'origin': 'original_saved_relation', 'time': scene.time,
                'original_payload': record, 'interpretation': 'relation hypothesis, not object identity'}
    for p in evidence['source_pixels']:
        if p < 0 or p >= scene.labels.size:
            raise ValueError('relation source pixel out of range')
    return evidence


def independent_families(evidence, profile):
    eligible = [e for e in evidence if e['state'] == 'SUPPORTED' and e.get('family')]
    if profile['calibration']['independence_rule'] is None:
        return {'available': 'UNAVAILABLE', 'count': None, 'families': [], 'reason': 'no_independence_rule'}
    chosen, used_samples, used_pixels = [], set(), set()
    for e in sorted(eligible, key=lambda e: (e['family'], e['evidence_id'])):
        samples = set(e['source_samples']); pixels = {(e['time'], p) for p in e['source_pixels']}
        if not samples and not pixels:
            continue
        if e['family'] in chosen or samples & used_samples or pixels & used_pixels:
            continue
        # Different channels without common provenance cannot be certified independent.
        if chosen and (not samples or not used_samples) and (not pixels or not used_pixels):
            continue
        chosen.append(e['family']); used_samples |= samples; used_pixels |= pixels
    return {'available': 'AVAILABLE', 'count': len(chosen), 'families': chosen,
            'method': 'unique families with explicit disjoint measurement/sample/pixel tokens'}


def build_regions(scene, profile, output, budget):
    g = profile['geometry']; size = g['cell_size_m']; halo = g['halo_m']; origin = np.asarray(g['grid_origin_m'])
    regions = {}
    flat = scene.xyz.reshape(-1, 3)
    for fid, fragment in sorted(scene.fragments.items()):
        budget.check(); budget.take('point_copies', len(fragment.ids))
        pts = flat[fragment.ids]
        keys = np.floor((pts - origin) / size).astype(np.int64)
        unique, inverse = np.unique(keys, axis=0, return_inverse=True)
        for index, key_array in enumerate(unique):
            key = tuple(map(int, key_array)); patch = pts[inverse == index]
            low, high = patch.min(0), patch.max(0)
            first = np.floor((low - halo - origin) / size).astype(int)
            last = np.floor((high + halo - origin) / size).astype(int)
            # Membership is by local patch extents, never by a giant cluster's centroid.
            for cell in itertools.product(*(range(int(a), int(b) + 1) for a, b in zip(first, last))):
                budget.check()
                if cell not in regions:
                    budget.take('regions'); regions[cell] = {'core': set(), 'halo': set(), 'patches': {}}
                entry = regions[cell]
                if fid not in entry['halo']:
                    budget.take('region_memberships'); entry['halo'].add(fid)
                if cell == key:
                    entry['core'].add(fid)
                entry['patches'].setdefault(fid, []).append({'source_core_cell': list(key), 'aabb_m': [low.tolist(), high.tolist()],
                                                            'point_count': len(patch), 'parent_fragment_id': fid})
    for cell, data in sorted(regions.items()):
        output.event('regions.jsonl', {'time': scene.time, 'cell': list(cell), 'core_fragment_ids': sorted(data['core']),
                                      'halo_fragment_ids': sorted(data['halo']),
                                      'patches': {str(k): v for k, v in sorted(data['patches'].items())},
                                      'origin_m': origin.tolist(), 'cell_size_m': size, 'halo_m': halo,
                                      'patch_usage': 'search-only; hypotheses always include whole fragments'})
    return regions


def pair_geometry(scene, a, b, profile, budget):
    fa, fb = scene.fragments[a], scene.fragments[b]
    _, pa = scene.points([a], budget); _, pb = scene.points([b], budget)
    d, near = cKDTree(pb).query(pa)
    best = int(np.argmin(d)); min_distance = float(d[best])
    radius = profile['geometry']['spatial_radius_m']
    close = d <= radius
    pix_a, pix_b = fa.boundary_ids, fb.boundary_ids
    coords_a = np.column_stack(np.divmod(pix_a, scene.labels.shape[1]))
    coords_b = np.column_stack(np.divmod(pix_b, scene.labels.shape[1]))
    pixel_gap = float(cKDTree(coords_b).query(coords_a)[0].min()) if len(coords_a) and len(coords_b) else None
    midpoint = (pa[best] + pb[int(near[best])]) / 2
    if not hasattr(scene,'_bounds_cache'):
        fs=sorted(scene.fragments)
        scene._bounds_cache=(np.array(fs),np.array([scene.fragments[f].low for f in fs]),np.array([scene.fragments[f].high for f in fs]))
    fs,lows,highs=scene._bounds_cache
    mask=(fs!=a)&(fs!=b)&np.all(midpoint>=lows-radius,axis=1)&np.all(midpoint<=highs+radius,axis=1)
    third=fs[mask].tolist()
    return {'aabb_lower_bound_m': aabb_gap(fa, fb), 'minimum_distance_m': min_distance,
            'normalized_gap': min_distance / profile['geometry']['normalization_scale_m'],
            'normalization_scale_m': profile['geometry']['normalization_scale_m'],
            'pixel_boundary_gap': pixel_gap, 'source_support_points': int(close.sum()),
            'target_support_points': int(len(np.unique(near[close]))),
            'support_definition': 'unique representative pixels within exploration radius; not identity support',
            'support_radius_m': radius, 'source_point_denominator': len(pa), 'target_point_denominator': len(pb),
            'closest_source_pixel': int(fa.ids[best]), 'closest_target_pixel': int(fb.ids[int(near[best])]),
            'third_fragments_near_midpoint_aabb': third, 'third_fragment_meaning': 'risk cue, not different-object proof'}


@dataclass
class Graph:
    pairs: dict
    adjacency: dict
    regions: dict
    status: dict


def build_graph(scene, profile, output, budget):
    regions = build_regions(scene, profile, output, budget)
    proposals = {}; original = {}
    if scene.relation_path:
        seen = set()
        for record in rows(scene.relation_path):
            e = normalize(record, scene, profile)
            if e['evidence_id'] in seen:
                raise ValueError('duplicate evidence ID')
            seen.add(e['evidence_id'])
            original.setdefault(tuple(e['fragment_ids']), []).append(e)
    variant = profile['variant']
    def add(a, b, route, cell=None):
        if a != b:
            pair = tuple(sorted((int(a), int(b))))
            proposals.setdefault(pair, set()).add((route, tuple(cell) if cell is not None else ()))
    # Baseline B1: core-region AABB candidates plus image-neighborhood boundary pairs.
    if variant != 'B0':
        for cell, r in sorted(regions.items()):
            for a, b in itertools.combinations(sorted(r['core']), 2):
                budget.check(); add(a, b, 'BASE_CORE_AABB', cell)
                if len(proposals) > budget.limits['max_pair_checks']:
                    break
            if len(proposals) > budget.limits['max_pair_checks']:
                break
        gap = int(profile['geometry']['pixel_gap']); labels = scene.labels
        for dr in range(gap + 1):
            for dc in range(-gap, gap + 1):
                if (dr == 0 and dc <= 0) or dr * dr + dc * dc > gap * gap:
                    continue
                budget.check()
                ar, br = slice(dr, None), slice(None, -dr if dr else None)
                if dc >= 0:
                    ac, bc = slice(dc, None), slice(None, -dc if dc else None)
                else:
                    ac, bc = slice(None, dc), slice(-dc, None)
                left, right = labels[ar, ac], labels[br, bc]
                mask = (left >= 0) & (right >= 0) & (left != right)
                if mask.any():
                    for a, b in np.unique(np.sort(np.column_stack([left[mask], right[mask]]), axis=1), axis=0):
                        add(a, b, 'BASE_IMAGE_GAP')
                if len(proposals) > budget.limits['max_pair_checks']:
                    break
            if len(proposals) > budget.limits['max_pair_checks']:
                break
    if variant in ('B2', 'B3'):
        for a, b in sorted(original):
            add(a, b, 'ORIGINAL_RELATION')
    if variant == 'B3':
        for cell, r in sorted(regions.items()):
            if not r['core']:
                continue
            for a, b in itertools.combinations(sorted(r['halo']), 2):
                budget.check(); add(a, b, 'SUPPLEMENTAL_HALO_BOUNDARY', cell)
                if len(proposals) > budget.limits['max_pair_checks']:
                    break
            if len(proposals) > budget.limits['max_pair_checks']:
                break
    pairs, adjacency = {}, {f: set() for f in scene.fragments}
    remaining = len(proposals); truncated = False; stop_reason = None
    for pair, routes in sorted(proposals.items()):
        try:
            budget.take('pair_checks')
            a, b = pair
            ev = sorted(original.get(pair, []) if variant in ('B2', 'B3') else [], key=lambda e: e['evidence_id'])
            geo = pair_geometry(scene, a, b, profile, budget)
            near = geo['minimum_distance_m'] <= profile['geometry']['spatial_radius_m']
            image = geo['pixel_boundary_gap'] is not None and geo['pixel_boundary_gap'] <= profile['geometry']['pixel_gap']
            for kind, condition, family in [('SPATIAL_NEAR', near, 'GEOMETRY_DISTANCE'), ('IMAGE_GAP', image, 'IMAGE_DISTANCE')]:
                for target in sorted(TARGETS):
                    eid = digest([scene.time, pair, kind, target])[:20]
                    ev.append({'evidence_id': eid, 'fragment_ids': list(pair), 'kind': kind, 'target': target,
                               'state': 'HOLD', 'family': family, 'calibration': 'UNCALIBRATED',
                               'source_samples': [], 'source_pixels': [geo['closest_source_pixel'], geo['closest_target_pixel']],
                               'time': scene.time, 'conditions': {'exploration_threshold_met': bool(condition),
                                                                 'missingness_interpretation': 'UNAVAILABLE' if 'missing_classification' not in scene.optional else 'AVAILABLE_NOT_IDENTITY_EVIDENCE'},
                               'origin': 'supplemental_search' if any(r[0] == 'SUPPLEMENTAL_HALO_BOUNDARY' for r in routes) else 'baseline_geometry',
                               'rejection_scope': None, 'upstream_search_complete': 'UNAVAILABLE'})
            explore = near or image or bool(original.get(pair) and variant in ('B2', 'B3'))
            record = {'time': scene.time, 'fragment_ids': list(pair), 'geometry': geo, 'evidence': ev,
                      'routes': [{'route': r, 'cell': list(c)} for r, c in sorted(routes)],
                      'exploration_state': 'ELIGIBLE_FOR_HYPOTHESIS' if explore else 'SEARCH_GATE_EXCLUDED',
                      'semantic_identity': 'UNKNOWN', 'independent_support': independent_families(ev, profile)}
            pairs[pair] = record
            if explore:
                adjacency[a].add(b); adjacency[b].add(a)
            output.event('pair_evidence.jsonl', record)
            if any(r[0] == 'SUPPLEMENTAL_HALO_BOUNDARY' for r in routes):
                output.event('supplemental_graph.jsonl', record)
            remaining -= 1
        except BudgetStop as exc:
            truncated = True; stop_reason = exc.reason; break
    if len(proposals) > budget.limits['max_pair_checks']:
        truncated = True; stop_reason = stop_reason or 'PAIR_PROPOSAL_LIMIT'
    status = {'time': scene.time, 'original_graph': 'AVAILABLE' if scene.relation_path else 'UNAVAILABLE',
              'original_edges': len(original), 'normalized_pairs': len(pairs), 'enumerated_unprocessed_pairs': remaining,
              'unseen_pair_count': 'UNKNOWN' if truncated else 0,
              'exploration_state': 'BUDGET_TRUNCATED' if truncated else 'ENUMERATED_WITHIN_CONFIGURED_ROUTES',
              'stop_reason': stop_reason, 'variant': variant, 'absence_interpretation': 'not evidence of no relation'}
    output.event('graph_status.jsonl', status)
    return Graph(pairs, adjacency, regions, status)
