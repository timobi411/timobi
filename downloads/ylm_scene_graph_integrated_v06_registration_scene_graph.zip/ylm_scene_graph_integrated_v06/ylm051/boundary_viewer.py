"""Single-file offline boundary/event viewer, with matched candidate comparison axes."""
import json
import numpy as np
from plotly.offline import get_plotlyjs
from .io import read,rows

def build_boundary_viewer(run,output):
    config=read(run/'input_contract.json');scenes={}
    contacts=list(rows(run/'contact_geometry_summary.jsonl'));gates=list(rows(run/'pair_gate_audit.jsonl'))
    events=list(rows(run/'expansion_events.jsonl')) if (run/'expansion_events.jsonl').exists() else []
    candidates=[{'id':c['candidate_id'],'time':c['namespace']['time'],'fragments':c['fragment_ids'],'point_count':c['point_count']} for c in rows(run/'hypotheses.jsonl')]
    for t,spec in config['times'].items():
        with np.load(run/spec['pixels']) as z:xyz,valid,labels=z['xyz'],z['valid'],z['labels']
        ids=np.flatnonzero(valid.ravel()&(labels.ravel()>=0));flat=xyz.reshape(-1,3)
        with np.load(run/f'contact_geometry_{t}.npz') as z:
            edges=[{'pair':f.tolist(),'pixels':p.tolist(),'xyz':pts.tolist(),'distance':float(d),'range_delta':float(dr)}
                for f,p,pts,d,dr in zip(z['fragment_ids'],z['pixel_ids'],z['xyz'],z['distance_m'],z['signed_delta_range_m'])]
        scenes[t]={'pixels':ids.tolist(),'labels':labels.ravel()[ids].tolist(),'xyz':flat[ids].tolist(),'edges':edges,'shape':list(labels.shape)}
    payload=json.dumps({'scenes':scenes,'contacts':contacts,'gates':gates,'events':events,'candidates':candidates},ensure_ascii=False,separators=(',',':'),allow_nan=False).replace('<','\\u003c')
    template='''<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>v0.5.1.2 接触境界・追加根拠監査</title>
<style>body{font:15px/1.6 system-ui;background:#f1f5fa;color:#18364d;margin:24px}header{background:#183b56;color:white;padding:20px}section{background:white;padding:18px;margin-top:16px}label{display:inline-block;margin:8px}input,select,button{padding:6px;max-width:380px}#pairplot{height:500px}.compare{display:grid;grid-template-columns:1fr 1fr}.plot{height:500px}pre{max-height:430px;overflow:auto;white-space:pre-wrap}a{color:#076b9c}</style>
<header><h1>v0.5.1.2 接触境界と候補拡張の監査</h1><p>画像隣接・3D最近傍・実際の追加判定を個別に表示。identity UNKNOWN / registration NOT_RUN / update HELD</p></header>
<p><a href="index.html">候補Viewer</a> · <a href="pair_viewer.html">探索ペアViewer</a> · <a href="audit_status.json">監査完全性</a></p>
<section><label>時刻 <select id="time"></select></label><label>ペアID（完全一致）<input id="pair" value="206,245"></label><button id="show">表示</button>
<label>線の意味 <select id="measurement"><option value="contact">画像4近傍接触</option><option value="nearest">3D最近傍</option><option value="witness">拡張witnessの3D最近傍</option></select></label>
<label>追加イベント <select id="event"></select></label><p id="counts"></p><div id="pairplot"></div><pre id="details"></pre></section>
<section><h2>保存候補A/B比較</h2><p>同じ軸範囲・視点で比較します。C244は赤。選択候補の全実測点を表示し、表示間引きはしません。</p>
<label>A <select id="candidateA"></select></label><label>B <select id="candidateB"></select></label><button id="compare">比較</button><p id="comparisonCounts"></p>
<div class="compare"><div class="plot" id="plotA"></div><div class="plot" id="plotB"></div></div></section>
<script>__PLOTLY__</script><script>const D=__DATA__;const el=id=>document.getElementById(id);let currentEvents=[],camera={eye:{x:1.5,y:1.5,z:1.1}},syncing=false;
const key=p=>p.join(',');const scene=()=>D.scenes[el('time').value];
function pointTrace(ids,s){let ii=s.labels.map((f,i)=>ids.includes(f)?i:-1).filter(i=>i>=0);return {type:'scatter3d',mode:'markers',name:'元実測点',x:ii.map(i=>s.xyz[i][0]),y:ii.map(i=>s.xyz[i][1]),z:ii.map(i=>s.xyz[i][2]),text:ii.map(i=>'C'+s.labels[i]+' pixel '+s.pixels[i]),marker:{size:4,color:ii.map(i=>s.labels[i]===244?'#e5333d':'#397eb5')}};}
function line(a,b,pixels,d,dr,name){return {type:'scatter3d',mode:'lines+markers',name,x:[a[0],b[0]],y:[a[1],b[1]],z:[a[2],b[2]],line:{width:7},text:[0,1].map(()=>name+' pixels '+pixels+' / 距離 '+d.toFixed(6)+' m / 高ID−低ID range差 '+dr.toFixed(6)+' m'),hoverinfo:'text'};}
function nearestLine(pair,s,label){const r=D.contacts.find(r=>r.time===el('time').value&&key(r.fragment_ids)===key(pair));if(!r||!r.nearest_3d)return null;let n=r.nearest_3d,ii=n.pixel_ids.map(p=>s.pixels.indexOf(p));return line(s.xyz[ii[0]],s.xyz[ii[1]],n.pixel_ids,n.distance_m,n.signed_delta_range_m,label);}
function pairKey(){return el('pair').value.split(/[,\s]+/).filter(Boolean).map(Number).sort((a,b)=>a-b);}
function updateEvents(){const t=el('time').value,p=pairKey();currentEvents=D.events.filter(e=>e.time===t&&e.all_links.some(k=>key(k)===key(p)));el('event').innerHTML='';currentEvents.forEach((e,i)=>el('event').add(new Option(e.event_id.slice(0,14)+' '+e.result,i)));drawPair();}
function drawPair(){let s=scene(),p=pairKey(),e=currentEvents[Number(el('event').value)],lines=[],kind=el('measurement').value;
if(kind==='contact')lines=s.edges.filter(v=>key(v.pair)===key(p)).map(v=>line(v.xyz[0],v.xyz[1],v.pixels,v.distance,v.range_delta,'画像4近傍接触'));
else{let n=nearestLine(kind==='witness'&&e?e.witness_pair||p:p,s,kind==='witness'?'拡張witness（判定集合は別途表示）':'全断片3D最近傍');if(n)lines=[n];}
const ids=kind==='witness'&&e?[...new Set([...p,...(e.witness_pair||[])])]:p;const pt=pointTrace(ids,s);
Plotly.react('pairplot',[pt,...lines],{margin:{t:10},scene:{aspectmode:'data',camera},uirevision:'pair'});
el('counts').textContent='元全観測 '+s.pixels.length+'点 / ペア表示 '+pt.x.length+'点、全接触 '+s.edges.length+'本 / 表示線 '+lines.length+'本。rangeは座標原点からの距離（センサ原点未検証）。';
el('details').textContent=JSON.stringify({contact:D.contacts.find(r=>r.time===el('time').value&&key(r.fragment_ids)===key(p)),gate:D.gates.find(r=>r.time===el('time').value&&key(r.fragment_ids)===key(p)),expansion_event:e||null},null,2);}
function compare(){const cs=D.candidates.filter(c=>c.time===el('time').value),a=cs[+el('candidateA').value],b=cs[+el('candidateB').value];if(!a||!b)return;const s=scene(),ta=pointTrace(a.fragments,s),tb=pointTrace(b.fragments,s),traces=[ta,tb],ranges={};['x','y','z'].forEach(k=>{const v=[...ta[k],...tb[k]],lo=Math.min(...v),hi=Math.max(...v),pad=Math.max(.02,(hi-lo)*.1);ranges[k+'axis']={range:[lo-pad,hi+pad]};});
['plotA','plotB'].forEach((id,i)=>Plotly.react(id,[traces[i]],{margin:{t:20},title:(i?'B':'A')+' '+traces[i].x.length+'点',scene:{...ranges,aspectmode:'cube',camera},uirevision:'compare'}));
el('comparisonCounts').textContent='A '+ta.x.length+'/'+a.point_count+'点、B '+tb.x.length+'/'+b.point_count+'点。追加断片 B−A: '+b.fragments.filter(f=>!a.fragments.includes(f)).join(',');}
function refresh(){const t=el('time').value,cs=D.candidates.filter(c=>c.time===t);['candidateA','candidateB'].forEach(id=>{el(id).innerHTML='';cs.forEach((c,i)=>el(id).add(new Option(c.id+' ['+c.fragments+'] '+c.point_count+'点',i)));});const a=cs.findIndex(c=>key(c.fragments)==='206,245,246,247'),b=cs.findIndex(c=>key(c.fragments)==='206,244,245,246,247');if(a>=0)el('candidateA').value=a;if(b>=0)el('candidateB').value=b;updateEvents();compare();}
Object.keys(D.scenes).forEach(t=>el('time').add(new Option(t,t)));el('time').onchange=refresh;el('show').onclick=updateEvents;el('measurement').onchange=drawPair;el('event').onchange=drawPair;el('compare').onclick=compare;refresh();
['plotA','plotB'].forEach((id,i)=>el(id).on('plotly_relayout',e=>{if(syncing||!e['scene.camera'])return;camera=e['scene.camera'];syncing=true;Plotly.relayout(i?'plotA':'plotB',{'scene.camera':camera}).then(()=>syncing=false);}));
</script></html>'''
    output.text('boundary_audit.html',template.replace('__PLOTLY__',get_plotlyjs()).replace('__DATA__',payload))
