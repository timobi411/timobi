"""Explicit shape versions and adjudicated novel nodes; default accumulation is OFF."""
import copy
from pathlib import Path
import numpy as np
from .util import require,transformed,sha,digest
from .registration import geometry


def accumulate(node,model_points,current_points,point_keys,new_pose,pair,profile,destination):
    require(profile['shape_accumulation'],'Shape accumulation OFF')
    require(pair['identity_status']=='CONFIRMED' and pair['integration_validity']=='VALID_FOR_POSE' and
            pair['frame_status'] in ('VERIFIED_FIXED','VERIFIED_TRANSFORM') and not pair['reasons'],'Shape accumulation ineligible')
    require(len(point_keys)==len(current_points) and len(set(point_keys))==len(point_keys),'Duplicate observation provenance')
    require(pair['metrics']['rmse_m']<=profile['thresholds']['max_rmse_m'],'Alignment residual')
    existing=set(node['model'].get('accumulated_point_keys',[]));keep=[i for i,key in enumerate(point_keys) if key not in existing]
    require(keep,'No new shape evidence')
    local=transformed(np.asarray(current_points)[keep],np.linalg.inv(np.array(new_pose['matrix'])))
    merged=np.concatenate([model_points,local]);dest=Path(destination);dest.parent.mkdir(parents=True,exist_ok=True)
    np.save(dest,merged,allow_pickle=False)
    model=copy.deepcopy(node['model']);model.update(version=model['version']+1,
        asset={'path':'../model_updates/'+dest.name,'sha256':sha(dest)},
        accumulated_point_keys=sorted(existing|set(point_keys)),previous_asset=copy.deepcopy(node['model']['asset']),
        accumulation_evidence={'pair_id':pair['pair_id'],'added_points':len(keep),'current_measurements_only':True})
    return model


def novel_node(graph_id,candidate,cloud,frame,adjudication,destination):
    require(candidate['current_count']>=4 and geometry(cloud)['rank']==3,'New model needs current spatial support')
    require(adjudication.get('reviewer') and adjudication.get('timestamp') and adjudication.get('basis') and
            adjudication.get('novelty_confirmed') is True,'Independent novelty adjudication required')
    require('proxy' not in adjudication['basis'].lower(),'Proxy cannot adjudicate identity')
    center=cloud.mean(0);local=cloud-center;dest=Path(destination);dest.parent.mkdir(parents=True,exist_ok=True);np.save(dest,local,allow_pickle=False)
    oid='obj:'+digest([graph_id,candidate['key']])[:24];pose=np.eye(4);pose[:3,3]=center
    p={'frame_id':frame,'matrix':pose.tolist()}
    return {'object_id':oid,'lifecycle':'ACTIVE','states':{'identity':'CONFIRMED','motion':'UNKNOWN_MOTION','observation':'CURRENT_OBSERVED'},
        'model':{'version':1,'asset':{'path':'../model_updates/'+dest.name,'sha256':sha(dest)},'reference_point':[0,0,0],
                 'geometry_status':'VERIFIED','quality':geometry(cloud),'source_pixel_ids':candidate['source_point_ids']},
        'pose':p,'last_confirmed':{'pose':p,'time_ns':candidate['time_ns']},
        'observation_refs':[{'key':candidate['key'],'role':'ADJUDICATED_NOVELTY'}],
        'attributes':{'semantic_label':{'value':'unknown','source':'NO_SEMANTIC_OBSERVATION'}},'provenance':{'adjudication':adjudication}}
