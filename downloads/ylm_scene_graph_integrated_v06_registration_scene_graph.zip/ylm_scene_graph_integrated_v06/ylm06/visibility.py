import numpy as np
from scipy.spatial import cKDTree
from .util import transformed, transform, require


def assess(model_points,obs,frame_status,thresholds):
    meta=obs['meta']; result={'observation_id':meta['observation_id'],'status':'UNKNOWN','reason':'PROJECTION_UNVERIFIED',
        'projectable':0,'valid_comparisons':0,'missing':0,'unprojectable':len(model_points),
        'unique_rays':0,'unique_frames':0,'support_pixel_ids':[],
        'time_range_ns':[meta['window_start_ns'],meta['window_end_ns']]}
    if meta['freshness_status']=='HISTORY_ONLY': result.update(status='HISTORY_ONLY',reason='HISTORY_ONLY'); return result
    cal=meta['ray_calibration']
    if frame_status not in ('VERIFIED_FIXED','VERIFIED_TRANSFORM') or not cal or cal.get('status')!='VERIFIED_DIRECT_RAYS': return result
    require(cal.get('projection')=='PINHOLE_DIRECT' and cal.get('range_definition')=='EUCLIDEAN' and cal.get('evidence'), 'Unsupported/unverified ray contract')
    if meta['freshness_status']!='VERIFIED': result['reason']='FRESHNESS_UNVERIFIED'; return result
    if any(thresholds[k] is None for k in ['visibility_min_rays','visibility_support_fraction','visibility_range_tolerance_m']):
        result['reason']='VISIBILITY_THRESHOLDS_UNSET'; return result
    pts=transformed(model_points,np.linalg.inv(obs['T'])); h,w=obs['valid'].shape
    good=pts[:,2]>0; col=np.zeros(len(pts),int); row=col.copy()
    col[good]=np.rint(cal['fx']*pts[good,0]/pts[good,2]+cal['cx']).astype(int)
    row[good]=np.rint(cal['fy']*pts[good,1]/pts[good,2]+cal['cy']).astype(int)
    good&=(row>=0)&(row<h)&(col>=0)&(col<w)
    result['projectable']=int(good.sum()); result['unprojectable']=int((~good).sum())
    if not good.any(): result.update(status='OUT_OF_VIEW',reason='VERIFIED_PROJECTION_OUTSIDE_FOV'); return result
    # z-buffer nearest model surface for each actual direct sensor ray.
    rays={}
    for i in np.flatnonzero(good):
        pid=int(row[i]*w+col[i]); r=float(np.linalg.norm(pts[i])); rays[pid]=min(r,rays.get(pid,float('inf')))
    support={'occlusion':[],'absence':[],'occupied':[]}; frames=set()
    for pid,expected in sorted(rays.items()):
        if not obs['valid'].ravel()[pid]: result['missing']+=1; continue
        p=obs['xyz'].reshape(-1,3)[pid]; rr,cc=divmod(pid,w)
        # Verify that the input sample actually lies on the declared ray.
        if p[2]<=0 or abs(cal['fx']*p[0]/p[2]+cal['cx']-cc)>cal['pixel_tolerance'] or abs(cal['fy']*p[1]/p[2]+cal['cy']-rr)>cal['pixel_tolerance']:
            result['reason']='INPUT_RAY_MISMATCH'; return result
        prov=meta['provenance']; current=prov['current_rule']=='ALL_SYNTHETIC'
        if prov['current_rule']=='SOURCE_TYPE_VALUES': current=obs['arrays'][prov['source_type_key']].ravel()[pid] in prov['current_values']
        if not current: result['missing']+=1; continue
        delta=float(np.linalg.norm(p))-expected; tol=thresholds['visibility_range_tolerance_m']
        support['occlusion' if delta < -tol else 'absence' if delta > tol else 'occupied'].append(pid)
        if prov['frame_key']: frames.add(int(obs['arrays'][prov['frame_key']].ravel()[pid]))
    n=sum(map(len,support.values())); result.update(valid_comparisons=n,unique_rays=n,unique_frames=len(frames),support_pixel_ids=support)
    if n<thresholds['visibility_min_rays']: result['reason']='INSUFFICIENT_DIRECT_RAYS'; return result
    fraction=thresholds['visibility_support_fraction']
    if len(support['occlusion'])/n>=fraction: result['status']='OCCLUSION_SUPPORTED'
    elif len(support['absence'])/n>=fraction: result['status']='ABSENCE_SUPPORTED_AT_OLD_POSE'
    result['reason']='DIRECT_CURRENT_RAY_COMPARISON'; result['denominator']=n
    return result
