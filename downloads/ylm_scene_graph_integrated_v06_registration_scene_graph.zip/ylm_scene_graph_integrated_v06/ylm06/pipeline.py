import copy
import itertools
import os
import platform
import shutil
import sys
from pathlib import Path
import numpy as np
from . import __version__
from .util import read,write,write_lines,lines,sha,digest,inventory,require,transformed,Budget,BudgetStop
from .contracts import load
from .registration import register
from .assignment import solve
from .visibility import assess
from .graph import build_patch,clean_graph,check_graph


def sources():
    return inventory(Path(__file__).parent,{'.py','.json'})


def points(candidate,observations):
    obs=observations[candidate['observation_id']]
    return transformed(obs['xyz'].reshape(-1,3)[candidate['source_point_ids']],obs['T'])


def snapshot(config,config_path,inv,out):
    """Preserve relative relationships of source runs, not guessed cwd paths."""
    base=Path(config_path).resolve().parent
    common=Path(os.path.commonpath(list(inv)))
    if common.is_file(): common=common.parent
    mapping={}
    for source,meta in inv.items():
        src=Path(source); dest=out/'inputs/snapshot'/src.relative_to(common)
        from . import util
        if util.ACTIVE_BUDGET is not None:util.ACTIVE_BUDGET.preflight(src.stat().st_size)
        dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dest)
        mapping[source]=str(dest.relative_to(out))
    def walk(value):
        if isinstance(value,dict):
            return {k:walk(v) for k,v in value.items() if k!='allowed_roots'}
        if isinstance(value,list): return [walk(v) for v in value]
        if isinstance(value,str):
            possible=str((base/value).resolve())
            return mapping.get(possible,value)
        return value
    result=walk(config); result['allowed_roots']=[]
    write(out/'integration.json',result)
    return mapping


def enumerate_pairs(models,candidates,observations):
    # Round-robin model, then observation/tile/singleton strata. Similar candidates
    # consume one turn in their spatial stratum, not an entire model budget.
    iterators=[]; bykey={c['key']:c for c in candidates}
    for model in models:
        buckets={}
        for c in candidates:
            if c['observation_id']==model.get('source_observation'): continue
            obs=observations[c['observation_id']]; p=points(c,observations)
            center=p.mean(axis=0); tile=tuple(np.floor(center/0.75).astype(int).tolist())
            group=(c['observation_id'],tile,c['is_singleton']); buckets.setdefault(group,[]).append(c)
        for values in buckets.values(): values.sort(key=lambda c:(tuple(c['fragment_ids']),c['key']))
        def model_iter(m=model,groups=buckets):
            its=[iter(groups[k]) for k in sorted(groups)]; exhausted=set()
            while len(exhausted)<len(its):
                for i,it in enumerate(its):
                    if i in exhausted: continue
                    c=next(it,None)
                    if c is None: exhausted.add(i); continue
                    pid='pair:'+digest([m['object_id'],c['key']])[:24]
                    yield {'pair_id':pid,'object_id':m['object_id'],'candidate_key':c['key'],
                        'observation_id':c['observation_id'],'persistent_model':m['persistent'],
                        'enumeration_route':'model_round_robin_observation_tile_singleton_strata',
                        'simple_gates':{'center_distance_m':float(np.linalg.norm(m['points'].mean(axis=0)-points(c,observations).mean(axis=0))),
                                        'threshold':None,'usage':'DIAGNOSTIC_NO_EXCLUSION'},
                        'evaluation_status':'QUEUED','identity_status':'UNRESOLVED','motion_status':'UNKNOWN_MOTION'}
        iterators.append(iter(model_iter()))
    exhausted=set(); priority=0
    while len(exhausted)<len(iterators):
        for i,it in enumerate(iterators):
            if i in exhausted: continue
            row=next(it,None)
            if row is None: exhausted.add(i); continue
            row['priority']=priority; priority+=1; yield row


def _run(config_path,out,resume=False):
    out=Path(out).resolve(); c,observations,candidates,graph,inv=load(config_path)
    source=sources(); signature=digest({'config':c,'inputs':inv,'sources':source})
    if out.exists():
        require(resume,'Output exists; explicit --resume required')
        state=read(out/'resume.json'); require(state['signature']==signature,'Resume input/profile/source mismatch')
        if state['stage']=='COMPLETE': verify(out); return read(out/'run_manifest.json')
        # Immutable incomplete attempt remains available; only complete verified runs
        # are reusable. A restart uses a fresh child attempt with the same fingerprints.
        attempt=out/('attempt-'+str(len(list(out.glob('attempt-*')))+1))
        return run(config_path,attempt,False)
    out.mkdir(parents=True); budget=Budget(c['resources'],out)
    from . import util
    util.ACTIVE_BUDGET=budget
    write(out/'resume.json',{'signature':signature,'stage':'STARTED'})
    write(out/'resolved_config.json',c); write(out/'source_inventory.json',source)
    mapping=snapshot(c,config_path,inv,out)
    write(out/'input_inventory.json',{'originals':inv,'snapshots':mapping})
    write(out/'frames/transforms.json',c['frame_contract'])
    write_lines(out/'candidates/index.jsonl',candidates)
    models=[]; exclusions=[]
    if graph:
        for n in graph['nodes']:
            models.append({'object_id':n['object_id'],'persistent':True,'points':transformed(n['_points'],n['pose']['matrix']),
                'reference':transformed(np.array(n['model']['reference_point'])[None,:],n['pose']['matrix'])[0],
                'geometry_verified':n['model']['geometry_status']=='VERIFIED','model_version':n['model']['version']})
        from .graph import seal_graph
        input_display=clean_graph(graph)
        original_graph_path=(Path(config_path).resolve().parent/c['graph_input']['graph_path']).resolve()
        for node in input_display['nodes']:
            original_asset=str((original_graph_path.parent/node['model']['asset']['path']).resolve())
            node['model']['asset']['path']=mapping[original_asset]
        input_display['display_copy_of_graph_hash']=graph['hash']
        write(out/'input_graph.json',seal_graph(input_display))
    lookup={v['key']:v for v in candidates}
    for ds in c.get('diagnostic_sources',[]):
        require(not graph,'Diagnostic source models are a separate mode from persistent graph registration')
        require(set(ds)=={'observation_id','candidate_ids','selection_reason'},'Explicit diagnostic model keys required')
        for cid in ds['candidate_ids']:
            key=ds['observation_id']+'::'+cid; require(key in lookup,'Diagnostic model candidate missing')
            p=points(lookup[key],observations)
            models.append({'object_id':'diagnostic:'+key,'persistent':False,'points':p,'reference':p.mean(axis=0),
                           'geometry_verified':False,'source_observation':ds['observation_id'],'model_version':None})
        exclusions.append({'observation_id':ds['observation_id'],'selected':ds['candidate_ids'],'reason':ds['selection_reason'],
            'not_enumerated_as_models':[v['candidate_id'] for v in candidates if v['observation_id']==ds['observation_id'] and v['candidate_id'] not in ds['candidate_ids']]})
    write(out/'registration/model_enumeration.json',exclusions)
    pairs=[]; bymodel={m['object_id']:m for m in models}
    for p in enumerate_pairs(models,candidates,observations):
        if len(pairs)%64==0:budget.check()
        if len(pairs)>c['resources']['output_bytes']//4096:raise BudgetStop('pair_enumeration_storage_forecast')
        pairs.append(p)
    write_lines(out/'registration/pair_pipeline.jsonl',pairs)
    hypotheses=[]; records=[]; detailed=0; stopped=False
    try: budget.check()
    except BudgetStop: stopped=True
    for p in pairs:
        candidate=lookup[p['candidate_key']]
        if candidate['point_count']<3 or len(bymodel[p['object_id']]['points'])<3:
            p.update(evaluation_status='INVALID_INPUT',integration_validity='INVALID_INPUT',reasons=['INSUFFICIENT_INPUT_POINTS']);continue
        if stopped or detailed>=c['resources']['detailed_pairs']:
            p.update(evaluation_status='NOT_EVALUATED_BUDGET',integration_validity='NOT_EVALUATED',reasons=['DETAIL_BUDGET']); continue
        model=bymodel[p['object_id']]; candidate=lookup[p['candidate_key']]; obs=observations[candidate['observation_id']]
        try:
            budget.check()
            context={
                'pair_id':p['pair_id'],'reference_point':model['reference'].tolist(),'initialization_limit':c['resources']['initializations'],
                'frame_status':c['frame_contract']['status'],'dataset_role':c['dataset_role'],'sensor_id':obs['meta']['sensor_id'],
                'model_verified':model['geometry_verified'],'current_count':candidate['current_count'],'current_mask':candidate['current_mask']}
            if c['profiles']['solver']['mode']=='B0_COMPAT':
                from .legacy_pair import register_b0
                result,hs=register_b0(model['points'],points(candidate,observations),context,budget)
            else:
                result,hs=register(model['points'],points(candidate,observations),c['profiles'],context,budget)
            p.update(result); hypotheses.extend(hs); detailed+=1
            p.update(schema_version='ylm.registration.pair.v1',source_model={'object_id':p['object_id'],'model_version':model['model_version']},
                target_candidate={'observation_id':candidate['observation_id'],'candidate_id':candidate['candidate_id']},
                decision_profile_id=c['profiles']['decision']['profile_id'],profile_hash=digest(c['profiles']),source_hashes=source,
                input_fingerprints_digest=digest(inv),hypotheses=[h['hypothesis_id'] for h in hs])
            pts=points(candidate,observations); p['observed_center']=pts.mean(axis=0).tolist(); p['observed_extent']=np.ptp(pts,axis=0).tolist()
            if p.get('transformation') is not None:
                ref='frames/objects/'+p['pair_id'].replace(':','_')+'.json'
                write(out/ref,{'matrix':p['transformation'],'from_frame':c['frame_contract']['graph_frame'],
                    'to_frame':c['frame_contract']['graph_frame'],'time_ns':candidate['time_ns'],'kind':'OBJECT',
                    'calculation_route':c['profiles']['solver']['dof'],'meaning':'G1_from_G0_object'})
                p['transform_ref']=ref
            records.append({'candidate_key':candidate['key'],'pair_id':p['pair_id'],'current_points':candidate['current_count'],
                'total_points':candidate['point_count'],'observed_center':p['observed_center'],'observed_extent':p['observed_extent'],
                'state':p.get('observation_status','UNKNOWN'),'model_overwritten':False})
        except BudgetStop as exc:
            stopped=True; p.update(evaluation_status='NOT_EVALUATED_BUDGET',integration_validity='NOT_EVALUATED',reasons=[str(exc)])
    write_lines(out/'registration/pairs.jsonl',pairs); write_lines(out/'registration/hypotheses.jsonl',hypotheses)
    write_lines(out/'registration/pair_pipeline.jsonl',({k:p.get(k) for k in ('pair_id','object_id','candidate_key','observation_id','priority','enumeration_route','simple_gates','evaluation_status','integration_validity','reasons')} for p in pairs))
    assignment=solve(pairs,candidates,c['profiles']['decision'],c['resources']['assignment_states'])
    write(out/'assignment/assignment.json',assignment); write_lines(out/'assignment/solutions.jsonl',assignment['solutions'])
    visibility=[]
    for model in models:
        for obs in observations.values():
            if obs['meta']['observation_id']==model.get('source_observation'): continue
            v=assess(model['points'],obs,c['frame_contract']['status'],c['profiles']['decision']['thresholds']); v['object_id']=model['object_id']; visibility.append(v)
    write_lines(out/'visibility/evidence.jsonl',visibility); write_lines(out/'observations/records.jsonl',records)
    selected={p['candidate_key'] for p in pairs if p['pair_id'] in assignment['primary']}
    provisional=[{'provisional_observation_id':'prov:'+digest(v['key'])[:24],'candidate_key':v['key'],
        'reason':'NOVELTY_UNCONFIRMED; not a permanent object','duplicate_registration_risk':'UNRESOLVED',
        'current_points':v['current_count']} for v in candidates if v['key'] not in selected]
    write_lines(out/'provisional/observations.jsonl',provisional)
    refs={k:{'path':'../'+p,'sha256':sha(out/p)} for k,p in {'config':'integration.json','assignment':'assignment/assignment.json',
        'pairs':'registration/pairs.jsonl','hypotheses':'registration/hypotheses.jsonl','frames':'frames/transforms.json','visibility':'visibility/evidence.jsonl'}.items()}
    patch,preview=build_patch(graph,pairs,assignment,candidates,c,refs,source,inv,visibility)
    if graph is not None:
        from .models import accumulate,novel_node
        from .graph import operation,apply_operations,seal_graph,content_hash
        from .assignment import overlap
        from .util import safe_path
        bypair={p['pair_id']:p for p in pairs};nodes={n['object_id']:n for n in graph['nodes']}
        if c['profiles']['decision']['shape_accumulation']:
            for pid in assignment['primary']:
                p=bypair[pid];node=nodes[p['object_id']];candidate=lookup[p['candidate_key']]
                current=np.asarray(candidate['current_mask'],bool);pts=points(candidate,observations)[current]
                keys=[candidate['observation_id']+':pixel:'+str(i) for i,k in zip(candidate['source_point_ids'],current) if k]
                pose=next(n['pose'] for n in preview['nodes'] if n['object_id']==node['object_id'])
                newmodel=accumulate(node,node['_points'],pts,keys,pose,p,c['profiles']['decision'],out/'model_updates'/(digest(pid)+'.npy'))
                patch['operations'].append(operation('VERSION_MODEL',node['object_id'],node['model'],newmodel,[dict(refs['pairs'],record_id=pid)],'CURRENT_ALIGNED_SHAPE_VERSION'))
        adjudications=[];accepted_candidates=[lookup[bypair[k]['candidate_key']] for k in assignment['primary']]
        for ref in c.get('adjudications',[]):
            a=read(safe_path(Path(config_path).resolve().parent,ref['path'],c.get('allowed_roots',[])))
            key=a.get('candidate_key');require(key in lookup,'Unknown adjudicated candidate');candidate=lookup[key]
            related=[p for p in pairs if p['candidate_key']==key]
            if assignment['unevaluated'] or not related or any(p['evaluation_status']!='EVALUATED' or p['identity_status'] in ('CONFIRMED','AMBIGUOUS') for p in related):
                patch['held_operations'].append({'candidate_key':key,'reason':'NOVELTY_EVALUATION_INCOMPLETE_OR_COMPETING_IDENTITY'});continue
            if c['frame_contract']['status'] not in ('VERIFIED_FIXED','VERIFIED_TRANSFORM') or any(overlap(candidate,x) for x in accepted_candidates):
                patch['held_operations'].append({'candidate_key':key,'reason':'NOVELTY_FRAME_OR_CONFLICT'});continue
            pts=points(candidate,observations)[np.asarray(candidate['current_mask'],bool)]
            node=novel_node(graph['graph_id'],candidate,pts,c['frame_contract']['graph_frame'],a,out/'model_updates'/(digest(key)+'.npy'))
            patch['operations'].append(operation('ADD_NODE',node['object_id'],None,node,[],'EXPLICIT_INDEPENDENT_NOVELTY_ADJUDICATION'))
            accepted_candidates.append(candidate);adjudications.append(dict(a,object_id=node['object_id']))
        if adjudications:
            record={'records':adjudications,'novelty_confirmed':True,'reviewer':'; '.join(a['reviewer'] for a in adjudications),
                    'timestamp':[a['timestamp'] for a in adjudications],'evaluation_complete':True,'frame_verified':True,
                    'current_support':True,'shape_registerable':True,'ambiguous_competitors':False,'approved_object_ids':[a['object_id'] for a in adjudications]}
            write(out/'adjudication.json',record);patch['evidence_refs']['adjudication']={'path':'../adjudication.json','sha256':sha(out/'adjudication.json')}
        preview=apply_operations(clean_graph(graph),patch['operations']);patch['expected_postconditions']['content_hash_before_version_increment']=content_hash(preview);preview=seal_graph(preview)
        newly_registered={op['after']['provenance']['adjudication']['candidate_key'] for op in patch['operations'] if op['type']=='ADD_NODE'}
        provisional=[v for v in provisional if v['candidate_key'] not in newly_registered]
        write_lines(out/'provisional/observations.jsonl',provisional)
    if preview is not None:
        from .graph import seal_graph
        preview=copy.deepcopy(preview)
        changed_models={op['object_id'] for op in patch['operations'] if op['type'] in ('ADD_NODE','VERSION_MODEL')}
        for node in preview['nodes']:
            if node['object_id'] not in changed_models:
                original_asset=str((original_graph_path.parent/node['model']['asset']['path']).resolve())
                node['model']['asset']['path']='../'+mapping[original_asset]
        preview['proposal_semantic_postcondition_hash']=patch['expected_postconditions']['content_hash_before_version_increment']
        preview=seal_graph(preview)
    write(out/'scene_graph_proposal/patch.json',patch); write(out/'scene_graph_proposal/preview_graph.json',preview)
    summary={'enumerated':len(pairs),'detailed':detailed,'unevaluated':len(assignment['unevaluated']),
        'degenerate':sum(p.get('integration_validity')=='HELD_DEGENERATE' for p in pairs),
        'ambiguous':sum(p.get('identity_status')=='AMBIGUOUS' for p in pairs),'conflicts':len(assignment['conflicts']),
        'primary':len(assignment['primary']),'auxiliary':len(assignment['auxiliary']),'provisional':len(provisional),'new_persistent':sum(op['type']=='ADD_NODE' for op in patch['operations']),
        'updated_nodes':len({op['object_id'] for op in patch['operations'] if op['object_id']}),
        'retained_nodes':len(graph['nodes']) if graph else 0,'changed_edges':sum(op['type']=='MARK_EDGE_STALE' for op in patch['operations']),
        'evaluations_per_model':{m['object_id']:sum(p['object_id']==m['object_id'] and p['evaluation_status']=='EVALUATED' for p in pairs) for m in models}}
    write(out/'registration/summary.json',summary)
    status={'processing_complete':not stopped,'integrity_passed':True,'registration_evaluation':'GEOMETRIC_DIAGNOSTIC',
        'identity_accuracy':'NOT_EVALUATED','motion_accuracy':'NOT_EVALUATED','update_accuracy':'NOT_EVALUATED','graph_modified':False}
    write(out/'evaluation/status.json',status)
    manifest={'version':__version__,'run_id':c['run_id'],**status,'requested_pair_evaluation_complete':not assignment['unevaluated'],
        'partial':stopped or bool(assignment['unevaluated']) or any(not p.get('initialization_complete',True) for p in pairs) or assignment['budget_exhausted'],
        'graph_update':'PROPOSAL_ONLY','frame_status':c['frame_contract']['status'],'resources':budget.stats(),
        'environment':{'python':sys.version,'platform':platform.platform(),'numpy':np.__version__},'counts':summary}
    write(out/'run_manifest.json',manifest)
    from .viewer import render
    render(out,candidates,observations,models,pairs,assignment,patch,manifest)
    final_size=sum(p.stat().st_size for p in out.rglob('*') if p.is_file())
    if final_size>c['resources']['output_bytes']:
        manifest['partial']=True; manifest['processing_complete']=False; manifest['resources']['stop_reasons'].append('output_bytes')
    manifest['resources']=dict(budget.stats(),stop_reasons=manifest['resources']['stop_reasons']); write(out/'run_manifest.json',manifest)
    write(out/'resume.json',{'signature':signature,'stage':'COMPLETE'})
    hashes=inventory(out); hashes.pop('artifact_hashes.json',None); hashes.pop('verification.json',None)
    write(out/'artifact_hashes.json',hashes); verification=verify(out); write(out/'verification.json',verification)
    return manifest


def run(config_path,out,resume=False):
    from . import util
    previous=util.ACTIVE_BUDGET
    try:
        return _run(config_path,out,resume)
    except BudgetStop as exc:
        budget=util.ACTIVE_BUDGET;util.ACTIVE_BUDGET=None;out=Path(out).resolve()
        manifest={'version':__version__,'processing_complete':False,'partial':True,'integrity_passed':False,
            'reason':'RESOURCE_LIMIT:'+str(exc),'graph_modified':False,'identity_accuracy':'NOT_EVALUATED',
            'resources':budget.stats() if budget else {}}
        if out.exists():
            write(out/'run_manifest.json',manifest)
            write(out/'verification.json',{'integrity_passed':False,'reason':'PARTIAL_STAGES; no graph apply allowed'})
        return manifest
    finally:util.ACTIVE_BUDGET=previous


def verify(root):
    root=Path(root).resolve(); hashes=read(root/'artifact_hashes.json')
    for rel,h in hashes.items():
        p=(root/rel).resolve(); require(p.is_relative_to(root) and p.is_file() and sha(p)==h,'Artifact missing/changed: '+rel)
    # Re-open relocated input contracts; full fragment unions and upstream masks are rechecked.
    _,_,candidates,_,_=load(root/'integration.json')
    index=list(lines(root/'candidates/index.jsonl')); require(index==candidates,'Candidate snapshot mismatch')
    patch=read(root/'scene_graph_proposal/patch.json')
    if patch['base']:
        from .graph import validate_patch
        snapshot_config=read(root/'integration.json')
        validate_patch(root/'scene_graph_proposal/patch.json',root/snapshot_config['graph_input']['graph_path'])
        from .util import safe_path
        for name in ['input_graph.json','scene_graph_proposal/preview_graph.json']:
            gp=root/name;g=read(gp);check_graph(g)
            for node in g['nodes']:
                asset=node['model']['asset'];p=safe_path(gp.parent,asset['path'],[root]);require(sha(p)==asset['sha256'],'Display graph asset missing/changed')
    manifest=read(root/'run_manifest.json')
    return {'integrity_passed':True,'artifact_count':len(hashes),'candidate_count':len(candidates),
        'processing_complete':manifest['processing_complete'],'graph_modified':False,'identity_accuracy':'NOT_EVALUATED'}
