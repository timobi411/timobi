import hashlib
import json
import os
import resource
import time
from pathlib import Path
import numpy as np

ACTIVE_BUDGET=None


class Invalid(ValueError):
    pass


class BudgetStop(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


def read(path):
    def bad(value):
        raise Invalid('Non-finite JSON: ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'), parse_constant=bad)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    payload=canonical(value)+b'\n'
    if ACTIVE_BUDGET is not None:ACTIVE_BUDGET.preflight(len(payload))
    path.write_bytes(payload)


def lines(path):
    with open(path, encoding='utf-8') as f:
        for line in f:
            if line.strip():
                yield json.loads(line, parse_constant=lambda x: (_ for _ in ()).throw(Invalid(x)))


def write_lines(path, values):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'wb') as f:
        for v in values:
            payload=canonical(v)+b'\n'
            if ACTIVE_BUDGET is not None:
                # O(1) on each row; actual tree size is refreshed at stage boundaries.
                ACTIVE_BUDGET.account(len(payload))
            f.write(payload)


def safe_path(base, reference, allowed=()):
    base = Path(base).resolve(); p = (base / reference).resolve()
    require(any(p.is_relative_to(Path(root).resolve()) for root in (base, *allowed)), 'Reference outside explicit roots: ' + str(p))
    require(p.is_file(), 'Missing asset: ' + str(p))
    return p


def transform(matrix, tolerance=1e-6):
    t = np.asarray(matrix, dtype=float)
    require(t.shape == (4, 4) and np.isfinite(t).all(), 'Invalid 4x4 transform')
    require(np.allclose(t[3], [0, 0, 0, 1], atol=tolerance, rtol=0), 'Invalid homogeneous row')
    require(np.allclose(t[:3, :3].T @ t[:3, :3], np.eye(3), atol=tolerance, rtol=0), 'Nonorthogonal rotation')
    require(abs(np.linalg.det(t[:3, :3]) - 1) <= tolerance, 'Improper rotation')
    return t


def transformed(points, t):
    return np.asarray(points) @ np.asarray(t)[:3, :3].T + np.asarray(t)[:3, 3]


def rotation_error(a, b):
    return float(np.degrees(np.arccos(np.clip((np.trace(a[:3, :3] @ b[:3, :3].T) - 1) / 2, -1, 1))))


def inventory(root, suffixes=None):
    root = Path(root)
    return {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob('*')) if p.is_file()
            and '__pycache__' not in p.parts and (suffixes is None or p.suffix in suffixes)}


class Budget:
    def __init__(self, config, out):
        self.config, self.out, self.start = config, Path(out), time.monotonic()
        self.stops = []
        self.accounted=0

    def account(self,amount):
        self.accounted+=amount
        if self.accounted>self.config['output_bytes']-65536:
            self.stops.append('output_bytes');raise BudgetStop('output_bytes')

    def preflight(self,amount):
        # Conservative cumulative writes, including rewrites; avoids an O(files^2)
        # directory walk when copying thousands of immutable candidate ID assets.
        self.check();self.account(amount)

    def stats(self):
        return {'wall_seconds': time.monotonic() - self.start,
                'peak_rss_mib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024,
                'output_bytes': sum(p.stat().st_size for p in self.out.rglob('*') if p.is_file()),
                'stop_reasons': self.stops}

    def check(self):
        s = {'wall_seconds':time.monotonic()-self.start,
             'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
             'output_bytes':self.accounted}
        for measured, limit in [('wall_seconds', 'wall_seconds'), ('peak_rss_mib', 'rss_mib'), ('output_bytes', 'output_bytes')]:
            if s[measured] >= self.config[limit]:
                self.stops.append(limit)
                raise BudgetStop(limit)


def fsync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
