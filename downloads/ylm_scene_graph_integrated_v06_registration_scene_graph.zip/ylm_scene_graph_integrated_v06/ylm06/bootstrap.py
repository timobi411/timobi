import copy
import os
import tempfile
from pathlib import Path
import numpy as np
from .contracts import load
from .pipeline import points
from .assignment import overlap
from .registration import geometry
from .graph import seal_graph,check_graph
from .util import read,write,sha,digest,require,fsync_dir,safe_path


def bootstrap(config_path,out):
    path=Path(config_path).resolve(); cfg=read(path)
    require(set(cfg)=={'schema_version','graph_id','integration_config','approved_candidates','adjudication'},'Bootstrap fields')
    require(cfg['schema_version']=='ylm.bootstrap.v1','Bootstrap version')
    config_ref=safe_path(path.parent,cfg['integration_config'])
    c,observations,candidates,graph,inv=load(config_ref)
    require(graph is None and c['frame_contract']['status'] in ('VERIFIED_FIXED','VERIFIED_TRANSFORM'),'Bootstrap needs verified frame and explicit empty-graph mode')
    adjudication=cfg['adjudication']
    require(adjudication.get('reviewer') and adjudication.get('timestamp') and adjudication.get('basis') and adjudication.get('approved') is True,'Explicit bootstrap approval record required')
    require('proxy' not in adjudication['basis'].lower(),'Proxy is not an identity adjudication')
    approved=cfg['approved_candidates']; require(approved and len(approved)==len(set(approved)),'Explicit nonempty approved set')
    bykey={v['key']:v for v in candidates}; require(set(approved)<=set(bykey),'Unknown approved candidate')
    selected=[bykey[k] for k in approved]
    require(not any(overlap(a,b) for i,a in enumerate(selected) for b in selected[i+1:]),'Overlapping bootstrap observations')
    out=Path(out).resolve(); require(not out.exists(),'Bootstrap output exists'); out.parent.mkdir(parents=True,exist_ok=True)
    temp=Path(tempfile.mkdtemp(prefix='.ylm-bootstrap-',dir=out.parent)); nodes=[]
    try:
        for candidate in selected:
            require(candidate['current_count']>=4,'No verified current support')
            pts=points(candidate,observations); geom=geometry(pts)
            require(geom['rank']==3 and geom['unique_points']>=4,'Unregisterable model geometry')
            center=pts.mean(axis=0); local=pts-center; model_path=temp/'models'/('model_'+digest(candidate['key'])[:24]+'.npy')
            model_path.parent.mkdir(exist_ok=True); np.save(model_path,local,allow_pickle=False)
            pose=np.eye(4); pose[:3,3]=center
            oid='obj:'+digest([cfg['graph_id'],candidate['key']])[:24]
            nodes.append({'object_id':oid,'lifecycle':'ACTIVE','states':{'identity':'CONFIRMED','motion':'UNKNOWN_MOTION','observation':'CURRENT_OBSERVED'},
                'model':{'asset':{'path':str(model_path.relative_to(temp)),'sha256':sha(model_path)},'version':1,
                    'reference_point':[0,0,0],'geometry_status':'VERIFIED','quality':geom,'source_pixel_ids':candidate['source_point_ids'],
                    'observation_id':candidate['observation_id'],'shape_accumulation':'OFF'},
                'pose':{'frame_id':c['frame_contract']['graph_frame'],'matrix':pose.tolist()},
                'last_confirmed':{'pose':{'frame_id':c['frame_contract']['graph_frame'],'matrix':pose.tolist()},'time_ns':candidate['time_ns']},
                'observation_refs':[{'key':candidate['key'],'role':'BOOTSTRAP','candidate_id':candidate['candidate_id'],'observation_id':candidate['observation_id']}],
                'attributes':{'semantic_label':{'value':'unknown','source':'NO_SEMANTIC_OBSERVATION'}},
                'provenance':{'adjudication':adjudication,'candidate_key':candidate['key']}})
        g=seal_graph({'schema_version':'ylm.scene_graph.v1','graph_id':cfg['graph_id'],'version':1,'frame':c['frame_contract']['graph_frame'],
            'units':'m','timestamp':adjudication['timestamp'],'nodes':nodes,'edges':[],'history':[],
            'bootstrap_input_fingerprints':inv,'dataset_role':c['dataset_role']})
        check_graph(g); write(temp/'graph.json',g); write(temp/'bootstrap_record.json',cfg)
        for f in temp.rglob('*'):
            if f.is_file():
                with open(f,'rb') as stream: os.fsync(stream.fileno())
        fsync_dir(temp); os.rename(temp,out); fsync_dir(out.parent)
        return {'graph_path':str(out/'graph.json'),'nodes':len(nodes),'graph_id':cfg['graph_id'],'version':1}
    except BaseException:
        import shutil
        shutil.rmtree(temp); raise
