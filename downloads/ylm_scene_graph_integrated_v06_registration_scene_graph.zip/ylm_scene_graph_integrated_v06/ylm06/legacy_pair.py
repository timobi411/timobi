"""File contract for isolated B0, including an audit of all frozen initializers."""
import argparse
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import numpy as np
from .legacy import B0_SHA
from .util import sha,require,write,read,BudgetStop


def register_b0(a,b,context,budget=None):
    if context['initialization_limit']<7:raise BudgetStop('B0 requires all 7 frozen initializations')
    with tempfile.TemporaryDirectory(prefix='ylm-b0-') as td:
        root=Path(td);np.save(root/'source.npy',a);np.save(root/'target.npy',b)
        timeout=max(.01,budget.config['wall_seconds']-budget.stats()['wall_seconds']) if budget else 1800
        process=subprocess.Popen([sys.executable,'-m','ylm06.legacy_pair','--request',str(root)],
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
        start=time.monotonic()
        try:
            while True:
                try:stdout,stderr=process.communicate(timeout=.1);break
                except subprocess.TimeoutExpired:
                    if time.monotonic()-start>timeout:raise BudgetStop('B0 wall budget')
                    if budget:
                        budget.check()
                        try:
                            status=Path('/proc')/str(process.pid)/'status'
                            rss=next(float(line.split()[1])/1024 for line in status.read_text().splitlines() if line.startswith('VmRSS:'))
                            if rss>=budget.config['rss_mib']:raise BudgetStop('B0 RSS exceeded')
                        except (FileNotFoundError,StopIteration):pass
            require(process.returncode==0,'B0 subprocess failed: '+stderr[-1000:])
        except BaseException:
            process.kill();process.communicate();raise
        response=read(root/'result.json')
    legacy=response['legacy']; result={'evaluation_status':'EVALUATED','legacy_valid':None if legacy is None else legacy['valid'],
        'legacy_score':None if legacy is None else legacy['score'],'integration_validity':'NOT_EVALUATED',
        'identity_status':'UNRESOLVED','motion_status':'UNKNOWN_MOTION','observation_status':'UNKNOWN',
        'transformation':None if legacy is None else legacy['transformation'],'selected_hypothesis_id':None,
        'reasons':['FROZEN_B0_DIAGNOSTIC_ONLY'],'legacy_result':legacy,'initialization_complete':True,
        'frame_status':context['frame_status'],'input_maps':{'source_indices':list(range(len(a))),'target_indices':list(range(len(b)))}}
    hypotheses=response['hypotheses']
    for i,h in enumerate(hypotheses):h['hypothesis_id']=context['pair_id']+':B0:'+str(i)
    return result,hypotheses


def worker(root):
    import open3d as o3d
    from .registration import metrics
    source=Path(__file__).parent/'vendor/frozen/baseline_icp_B0.py';require(sha(source)==B0_SHA,'Frozen source changed')
    spec=importlib.util.spec_from_file_location('frozen_B0_pair',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    root=Path(root);clouds=[]
    for name in ('source','target'):
        cloud=o3d.geometry.PointCloud();cloud.points=o3d.utility.Vector3dVector(np.load(root/(name+'.npy'),allow_pickle=False));clouds.append(cloud)
    legacy=m.evaluate_pair(*clouds);a,b=[cloud.voxel_down_sample(m.VOXEL) for cloud in clouds];aa,bb=np.asarray(a.points),np.asarray(b.points);hypotheses=[]
    if len(aa) and len(bb):
        for yaw in m.YAW_CANDIDATES:
            start=time.monotonic();initial=m.rotation_about_center(aa.mean(0),yaw)
            coarse=m.registration_icp_4dof(a,b,m.COARSE_DISTANCE,initial,m.MAX_ITER)
            fine=m.registration_icp_4dof(a,b,m.FINE_DISTANCE,coarse.transformation,m.MAX_ITER)
            hypotheses.append({'initial_yaw_deg':yaw,'initial_transform':initial.tolist(),'transformation':fine.transformation.tolist(),
                'metrics':metrics(aa,bb,fine.transformation,{'fine_m':m.FINE_DISTANCE,'normal_k':12}),
                'legacy_fitness':fine.fitness,'legacy_rmse':fine.inlier_rmse,'elapsed_seconds':time.monotonic()-start,
                'convergence_reason':'LEGACY_FUNCTION_DOES_NOT_EXPOSE_TERMINATION','pose_adoption':'HELD_B0_COMPATIBILITY'})
    write(root/'result.json',{'legacy':legacy,'hypotheses':hypotheses,'source_sha256':B0_SHA})


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--request',required=True);a=p.parse_args();worker(a.request)
