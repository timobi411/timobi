"""Persistent graph copies, checked patches and atomic version publication."""
import copy
import fcntl
import os
import shutil
import tempfile
from pathlib import Path
import numpy as np
from .util import read,write,sha,digest,require,transform,transformed,fsync_dir,safe_path

ALLOWED={'ADD_NODE','UPDATE_POSE','APPEND_OBSERVATION','UPDATE_STATUS','VERSION_MODEL','MARK_EDGE_STALE'}


def content_hash(g):
    return digest({k:v for k,v in g.items() if k!='hash'})


def seal_graph(g):
    g=copy.deepcopy(g); g.pop('hash',None); g['hash']=content_hash(g); return g


def check_graph(g):
    from .schema import validate
    validate('scene_graph',g)
    require(g.get('schema_version')=='ylm.scene_graph.v1' and g.get('units')=='m','Graph schema/units')
    require(set(g)>={'graph_id','version','hash','frame','timestamp','nodes','edges','history'},'Graph fields')
    require(isinstance(g['version'],int) and g['version']>=1 and g['hash']==content_hash(g),'Graph hash/version')
    ids=set(); edges=set()
    for n in g['nodes']:
        require(set(n)>={'object_id','lifecycle','states','model','pose','last_confirmed','observation_refs','attributes','provenance'},'Node contract')
        require(n['object_id'] not in ids,'Duplicate object ID'); ids.add(n['object_id'])
        transform(n['pose']['matrix']); require(n['pose']['frame_id']==g['frame'],'Node frame mismatch')
        require(set(n['model'])>={'asset','version','reference_point','geometry_status'},'Model contract')
        require(n['states']['identity'] in ('CONFIRMED','AMBIGUOUS','UNRESOLVED','REJECTED_UNDER_PROFILE'),'Identity enum')
        require(n['states']['motion'] in ('STATIC','MOVED','UNKNOWN_MOTION'),'Motion enum')
        require(n['states']['observation'] in ('CURRENT_OBSERVED','PARTIAL','HISTORY_ONLY','OCCLUSION_SUPPORTED','OUT_OF_VIEW','UNKNOWN','ABSENCE_SUPPORTED_AT_OLD_POSE'),'Observation enum')
        refs=[r['key'] for r in n['observation_refs']]; require(len(refs)==len(set(refs)),'Duplicate observations')
    for e in g['edges']:
        require(set(e)>={'edge_id','source','target','relation_type','evidence','status','valid_time','provenance'},'Edge fields')
        require(e['edge_id'] not in edges and {e['source'],e['target']}<=ids,'Edge duplicate or dangling endpoint'); edges.add(e['edge_id'])
    return True


def clean_graph(g):
    result=copy.deepcopy(g)
    for n in result['nodes']: n.pop('_points',None)
    return result


def operation(kind,oid,before,after,evidence,reason):
    value={'type':kind,'object_id':oid,'preconditions':{'before_sha256':digest(before)},'before':before,'after':after,
           'evidence_refs':evidence,'decision_status':'CONFIRMED','reason_codes':[reason]}
    value['operation_id']='op:'+digest(value)[:24]; return value


def apply_operations(base,operations):
    g=copy.deepcopy(base); nodes={n['object_id']:n for n in g['nodes']}; edges={e['edge_id']:e for e in g['edges']}
    seen=set(); changed_pose=set()
    for op in operations:
        require(op['type'] in ALLOWED and op['operation_id'] not in seen,'Unsupported/duplicate operation'); seen.add(op['operation_id'])
        require(op['preconditions']['before_sha256']==digest(op['before']),'Operation before hash')
        kind=op['type']; oid=op['object_id']
        if kind=='ADD_NODE':
            require(oid not in nodes and op['before'] is None and op['after']['object_id']==oid,'Duplicate ADD_NODE')
            nodes[oid]=copy.deepcopy(op['after']); g['nodes'].append(nodes[oid]); continue
        if kind=='MARK_EDGE_STALE':
            edge=edges[op['after']['edge_id']]; require(edge==op['before'],'Edge precondition'); edge.clear(); edge.update(copy.deepcopy(op['after'])); continue
        require(oid in nodes,'Unknown operation object'); n=nodes[oid]
        field={'UPDATE_POSE':'pose','APPEND_OBSERVATION':'observation_refs','UPDATE_STATUS':'states','VERSION_MODEL':'model'}[kind]
        require(n[field]==op['before'],'Operation before value mismatch')
        if kind=='UPDATE_POSE':
            require(oid not in changed_pose,'Conflicting poses'); changed_pose.add(oid); transform(op['after']['matrix'])
            require(op['after']['frame_id']==g['frame'],'Pose frame mismatch')
            n['last_confirmed']={'pose':copy.deepcopy(op['after']),'time_ns':op.get('time_ns')}
        if kind=='APPEND_OBSERVATION':
            keys=[r['key'] for r in op['after']]
            require(len(keys)==len(set(keys)) and op['after'][:len(op['before'])]==op['before'],'Non-idempotent observation append')
        if kind=='VERSION_MODEL': require(op['after']['version']==op['before']['version']+1,'Model version must increment')
        n[field]=copy.deepcopy(op['after'])
    return g


def build_patch(graph,pairs,assignment,candidates,config,evidence_refs,source_hashes,inputs,visibility=()):
    base=clean_graph(graph) if graph is not None else None
    if base is None:
        return {'schema_version':'ylm.graph_patch.v1','transaction_id':'tx:'+digest([config['run_id'],inputs])[:24],
                'base':None,'input_fingerprints':inputs,'profile_hash':digest(config['profiles']),'source_hashes':source_hashes,
                'operations':[],'held_operations':[{'reason':'NO_PERSISTENT_GRAPH_DIAGNOSTIC_ONLY'}],
                'preconditions':{},'evidence_refs':evidence_refs,'expected_postconditions':None},None
    bypair={p['pair_id']:p for p in pairs}; bycandidate={c['key']:c for c in candidates}
    nodes={n['object_id']:n for n in base['nodes']}; operations=[]; moved=set(); held=[]
    for pid in assignment['primary']:
        p=bypair[pid]; n=nodes[p['object_id']]; c=bycandidate[p['candidate_key']]
        ev=[dict(evidence_refs['pairs'],record_id=pid)]
        if p['motion_status']=='MOVED':
            pose=copy.deepcopy(n['pose']); pose['matrix']=(np.array(p['transformation'])@np.array(n['pose']['matrix'])).tolist()
            op=operation('UPDATE_POSE',n['object_id'],n['pose'],pose,ev,'CONFIRMED_REGISTERED_MODEL_DISPLACEMENT'); op['time_ns']=c['time_ns']; operations.append(op); moved.add(n['object_id'])
        records=[{'key':c['key']+'::'+pid,'observation_id':c['observation_id'],'candidate_id':c['candidate_id'],
                  'evidence_pair_id':pid,'time_ns':c['time_ns'],'role':'PRIMARY','observed_center':p['observed_center'],
                  'observed_extent':p['observed_extent'],'transform':p['transformation'],'model_replaced':False}]
        for aux in assignment['auxiliary']:
            if aux['primary_pair_id']!=pid: continue
            a=bypair[aux['pair_id']]; ac=bycandidate[a['candidate_key']]
            records.append({'key':ac['key']+'::'+a['pair_id'],'observation_id':ac['observation_id'],'candidate_id':ac['candidate_id'],
                'evidence_pair_id':a['pair_id'],'time_ns':ac['time_ns'],'role':'AUXILIARY','model_replaced':False})
        existing={r['key'] for r in n['observation_refs']}; records=[r for r in records if r['key'] not in existing]
        if records: operations.append(operation('APPEND_OBSERVATION',n['object_id'],n['observation_refs'],n['observation_refs']+records,ev,'CURRENT_REGISTERED_OBSERVATION'))
        states=copy.deepcopy(n['states']); states.update(identity=p['identity_status'],motion=p['motion_status'],observation=p['observation_status'])
        if states!=n['states']: operations.append(operation('UPDATE_STATUS',n['object_id'],n['states'],states,ev,'CONFIRMED_STATE'))
    for n in base['nodes']:
        if not any(bypair[pid]['object_id']==n['object_id'] for pid in assignment['primary']):
            held.append({'object_id':n['object_id'],'reason':'NO_CONFIRMED_PRIMARY; MODEL_AND_LAST_POSE_PRESERVED',
                         'pair_ids':[p['pair_id'] for p in pairs if p['object_id']==n['object_id']]})
            d=config['profiles']['decision']
            visible=[v for v in visibility if v['object_id']==n['object_id'] and v['status']!='UNKNOWN']
            if (visible and len({v['status'] for v in visible})==1 and d['validation_status']!='UNCALIBRATED'
                and d['validation_record'] and all(x is not None for x in d['thresholds'].values())
                and config['frame_contract']['status'] in ('VERIFIED_FIXED','VERIFIED_TRANSFORM')):
                v=visible[0];states=copy.deepcopy(n['states']);states['observation']=v['status']
                if states!=n['states']:
                    operations.append(operation('UPDATE_STATUS',n['object_id'],n['states'],states,
                        [dict(evidence_refs['visibility'],object_id=n['object_id'],observation_id=v['observation_id'])],'VERIFIED_VISIBILITY_ONLY'))
    for edge in base['edges']:
        if edge.get('category')!='semantic' and {edge['source'],edge['target']}&moved:
            after=copy.deepcopy(edge); after['status']='STALE' if edge.get('category')=='spatial' else 'UNKNOWN'; after['stale_reason']='ENDPOINT_POSE_CHANGED'
            operations.append(operation('MARK_EDGE_STALE',None,edge,after,[], 'SPATIAL_RELATION_REQUIRES_REEVALUATION'))
    # Multiple observation times for one object are deliberately separate runs;
    # this rejects conflicting operations rather than silently using last writer.
    preview=apply_operations(base,operations)
    patch={'schema_version':'ylm.graph_patch.v1','transaction_id':'tx:'+digest([base['hash'],config,inputs,operations])[:24],
           'base':{'graph_id':base['graph_id'],'version':base['version'],'hash':base['hash']},
           'input_fingerprints':inputs,'profile_hash':digest(config['profiles']),'source_hashes':source_hashes,
           'operations':operations,'held_operations':held,'preconditions':{'no_delete_merge_split':True},
           'evidence_refs':evidence_refs,'expected_postconditions':{'content_hash_before_version_increment':content_hash(preview)}}
    return patch,seal_graph(preview)


def validate_patch(patch_path,graph_path):
    from .util import lines
    from .profiles import validate, applicable
    pp=Path(patch_path).resolve(); patch=read(pp); base=read(graph_path); check_graph(base)
    from .schema import validate as validate_schema
    validate_schema('graph_patch',patch)
    require(patch.get('schema_version')=='ylm.graph_patch.v1','Patch schema')
    require(patch['base']=={'graph_id':base['graph_id'],'version':base['version'],'hash':base['hash']},'STALE_BASE')
    require(patch['transaction_id'] not in [h.get('transaction_id') for h in base['history']],'TRANSACTION_ALREADY_APPLIED')
    # Every decision dependency is content-addressed. A CONFIRMED label alone is insufficient.
    refs={}
    for key,ref in patch['evidence_refs'].items():
        path=safe_path(pp.parent,ref['path'],[pp.parent.parent]); require(sha(path)==ref['sha256'],'Evidence fingerprint mismatch: '+key); refs[key]=path
    config=read(refs['config']); validate(config['profiles'],config['dataset_role'])
    from .contracts import load
    _,observations,candidates,_,_=load(refs['config'])
    candidate_map={c['key']:c for c in candidates}
    require(digest(config['profiles'])==patch['profile_hash'],'Profile fingerprint mismatch')
    assignment=read(refs['assignment']); pairs={p['pair_id']:p for p in lines(refs['pairs'])}
    hypotheses={h['hypothesis_id']:h for h in lines(refs['hypotheses'])}
    from .assignment import solve
    reproduced=solve(list(pairs.values()),candidates,config['profiles']['decision'],config['resources']['assignment_states'])
    require(reproduced['primary']==assignment['primary'] and reproduced['auxiliary']==assignment['auxiliary'] and
            reproduced['optimality_proven']==assignment['optimality_proven'],'Assignment decision mismatch')
    nodes={n['object_id']:n for n in base['nodes']}; posed=set()
    for op in patch['operations']:
        require(op['decision_status']=='CONFIRMED','Unconfirmed operation')
        if op['type']=='MARK_EDGE_STALE': continue
        if op['type']=='UPDATE_STATUS' and op['reason_codes']==['VERIFIED_VISIBILITY_ONLY']:
            from .visibility import assess
            node=nodes[op['object_id']];oid=op['evidence_refs'][0]['observation_id']
            obs=observations[oid];asset=safe_path(Path(graph_path).resolve().parent,node['model']['asset']['path'])
            pts=transformed(np.load(asset,allow_pickle=False),node['pose']['matrix'])
            v=assess(pts,obs,config['frame_contract']['status'],config['profiles']['decision']['thresholds'])
            require(v['status']!='UNKNOWN' and config['profiles']['decision']['validation_status']!='UNCALIBRATED','Visibility not applicable')
            expected=copy.deepcopy(op['before']);expected['observation']=v['status'];require(expected==op['after'],'Visibility status mismatch')
            continue
        if op['type']=='ADD_NODE':
            evidence=read(refs['adjudication']) if 'adjudication' in refs else None
            require(evidence and evidence.get('novelty_confirmed') and evidence.get('reviewer') and evidence.get('timestamp'),'New object requires independent adjudication')
            require(evidence.get('evaluation_complete') and evidence.get('frame_verified') and evidence.get('current_support') and evidence.get('shape_registerable') and not evidence.get('ambiguous_competitors'),'Novelty preconditions')
            require(op['object_id'] in evidence.get('approved_object_ids',[]),'Object not adjudicated')
            record=next(r for r in evidence['records'] if r['object_id']==op['object_id']);key=record['candidate_key']
            require(key in candidate_map and candidate_map[key]['current_count']>=4,'Novel candidate current support')
            related=[p for p in pairs.values() if p['candidate_key']==key]
            require(related and not assignment['unevaluated'] and all(p['evaluation_status']=='EVALUATED' and
                p['identity_status'] not in ('CONFIRMED','AMBIGUOUS') for p in related),'Novelty competitors incomplete/ambiguous')
            approved_records=[]
            for ref in config.get('adjudications',[]):
                source=safe_path(refs['config'].parent,ref['path']);require(sha(source)==ref['sha256'],'Adjudication input hash')
                approved_records.append(read(source))
            require(any(r.get('candidate_key')==key and r.get('novelty_confirmed') and r.get('reviewer') and r.get('timestamp') for r in approved_records),'Missing independent source adjudication')
            require(config['frame_contract']['status'] in ('VERIFIED_FIXED','VERIFIED_TRANSFORM'),'Novelty frame unverified')
            model_path=safe_path(pp.parent,op['after']['model']['asset']['path'],[pp.parent.parent])
            require(sha(model_path)==op['after']['model']['asset']['sha256'],'New model asset hash')
            from .registration import geometry
            require(geometry(np.load(model_path,allow_pickle=False))['rank']==3,'New model unregistrable')
            continue
        require(op['type']!='VERSION_MODEL' or config['profiles']['decision']['shape_accumulation'],'Shape accumulation disabled')
        require(assignment['optimality_proven'] and not assignment['unevaluated'],'Unresolved assignment')
        require(op['evidence_refs'],'Missing operation evidence')
        p=pairs[op['evidence_refs'][0]['record_id']]
        require(p['pair_id'] in assignment['primary'] and p['object_id']==op['object_id'],'No primary evidence')
        require(p['evaluation_status']=='EVALUATED' and p['integration_validity']=='VALID_FOR_POSE' and p['identity_status']=='CONFIRMED','Ineligible pair')
        require(p.get('legacy_valid') is not False and p['initialization_complete'] and p['selected_hypothesis_id'],'Invalid/partial result')
        h=hypotheses[p['selected_hypothesis_id']]
        require(h['numerically_valid'] and h['pose_constrained'] and h['profile_eligible'],'Selected pose not eligible')
        require(p['transformation']==h['transformation'] and p['metrics']==h['metrics'],'Selected hypothesis mismatch')
        candidate=candidate_map[p['candidate_key']]; obs=observations[candidate['observation_id']]
        require(candidate['current_count']>=config['profiles']['decision']['thresholds']['min_unique_points'],'Insufficient current measurements')
        from .pipeline import points
        reasons=applicable(config['profiles'],config['dataset_role'],obs['meta']['sensor_id'],float(np.linalg.norm(points(candidate,observations).mean(0))),
                           [p['metrics']['denominators']['source_points'],p['metrics']['denominators']['target_points']])
        require(not reasons,'Profile outside validation scope')
        require(not p['reasons'] and config['frame_contract']['status'] in ('VERIFIED_FIXED','VERIFIED_TRANSFORM'),'Frame/profile blocked')
        require(config['frame_contract'].get('independent_support') and config['frame_contract']['evidence'],'Frame evidence missing')
        require(nodes[op['object_id']]['model']['geometry_status']=='VERIFIED','Unverified model')
        transform(p['transformation']); m=p['metrics']; d=config['profiles']['decision']; t=d['thresholds']
        require(d['validation_status']!='UNCALIBRATED' and d['validation_record'] and all(v is not None for v in t.values()),'Uncalibrated decision')
        require(m['correspondences']>=t['min_correspondences'] and min(m['unique_source'],m['unique_target'])>=t['min_unique_points'] and
                m['rmse_m'] is not None and m['rmse_m']<=t['max_rmse_m'] and m['source_coverage']>=t['source_coverage'] and m['target_coverage']>=t['target_coverage'],'Metric conditions')
        if op['type']=='UPDATE_POSE':
            require(p['motion_status']=='MOVED','No confirmed movement')
            expected=np.array(p['transformation'])@np.array(op['before']['matrix'])
            require(np.allclose(expected,op['after']['matrix'],atol=1e-9,rtol=0),'Pose composition mismatch'); posed.add(op['object_id'])
        if op['type']=='UPDATE_STATUS':
            expected=copy.deepcopy(op['before']);expected.update(identity=p['identity_status'],motion=p['motion_status'],observation=p['observation_status'])
            require(op['after']==expected,'Invalid status update')
        if op['type']=='VERSION_MODEL':
            new_asset=safe_path(pp.parent,op['after']['asset']['path'],[pp.parent.parent]);require(sha(new_asset)==op['after']['asset']['sha256'],'Versioned asset hash')
            old_asset=safe_path(Path(graph_path).resolve().parent,op['before']['asset']['path'])
            old_points=np.load(old_asset,allow_pickle=False);new_points=np.load(new_asset,allow_pickle=False)
            require(np.array_equal(old_points,new_points[:len(old_points)]),'Shape version must preserve original model points')
            require(op['after']['previous_asset']==op['before']['asset'],'Missing prior shape asset')
    preview=apply_operations(base,patch['operations'])
    for e in preview['edges']:
        if e.get('category')=='spatial' and {e['source'],e['target']}&posed: require(e['status'] in ('STALE','UNKNOWN'),'Spatial edge not invalidated')
    require(content_hash(preview)==patch['expected_postconditions']['content_hash_before_version_increment'],'Patch postcondition')
    check_graph(seal_graph(preview)); return patch,base,preview


def apply_patch(patch_path,graph_path,out,store=None,fault=None):
    out=Path(out).resolve(); graph_path=Path(graph_path).resolve(); patch,base,preview=validate_patch(patch_path,graph_path)
    require(patch['operations'],'EMPTY_PATCH_NO_GRAPH_CHANGE')
    require(not out.exists(),'Output exists')
    out.parent.mkdir(parents=True,exist_ok=True)
    # Explicit store publishes a current pointer; otherwise ledger only, no pointer.
    registry=Path(store).resolve() if store else out.parent/'.ylm_transactions'/digest(base['graph_id'])[:24]
    registry.mkdir(parents=True,exist_ok=True)
    with open(registry/'lock','a+b') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        ledger=read(registry/'ledger.json') if (registry/'ledger.json').exists() else {'transactions':[],'current':None}
        # Recover a crash after immutable graph publication but before atomic ledger
        # replacement. A complete version carries its transaction journal and hash.
        pending_path=registry/'pending.json'
        if pending_path.exists():
            pending=read(pending_path); published=Path(pending['out'])/'graph.json'
            if published.exists():
                recovered=read(published);check_graph(recovered)
                require(recovered['history'][-1]['transaction_id']==pending['transaction_id'],'Recovery journal mismatch')
                if pending['transaction_id'] not in ledger['transactions']: ledger['transactions'].append(pending['transaction_id'])
                ledger['current']={'hash':recovered['hash'],'version':recovered['version'],'path':str(published)}
                write(registry/'ledger.next',ledger)
                with open(registry/'ledger.next','rb') as f:os.fsync(f.fileno())
                os.replace(registry/'ledger.next',registry/'ledger.json');fsync_dir(registry)
            pending_path.unlink();fsync_dir(registry)
        require(patch['transaction_id'] not in ledger['transactions'],'TRANSACTION_ALREADY_APPLIED')
        if ledger['current'] is not None: require(ledger['current']['hash']==base['hash'],'STALE_BASE')
        temp=Path(tempfile.mkdtemp(prefix='.ylm-transaction-',dir=out.parent))
        try:
            preview['version']=base['version']+1
            preview['history']=base['history']+[{'transaction_id':patch['transaction_id'],'base_hash':base['hash'],
                'patch_sha256':sha(patch_path),'correction_of':patch.get('correction_of'),'previous_version':base['version']}]
            for n in preview['nodes']:
                ref=n['model']['asset']
                is_new=any(op['object_id']==n['object_id'] and op['type'] in ('VERSION_MODEL','ADD_NODE') for op in patch['operations'])
                src=safe_path(Path(patch_path).resolve().parent,ref['path'],[Path(patch_path).resolve().parent.parent]) if is_new else safe_path(graph_path.parent,ref['path'])
                require(sha(src)==ref['sha256'],'Model asset changed')
                dest=temp/'models'/(ref['sha256']+src.suffix); dest.parent.mkdir(exist_ok=True); shutil.copyfile(src,dest)
                n['model']['asset']['path']=str(dest.relative_to(temp))
            preview=seal_graph(preview); check_graph(preview)
            write(temp/'graph.json',preview); write(temp/'transaction.json',patch)
            write(temp/'diff.json',patch['operations']); write(temp/'verification.json',{'integrity_passed':True,'graph_modified':True,'base_hash':base['hash'],'physical_accuracy':'NOT_EVALUATED'})
            if fault=='exception': raise RuntimeError('Injected exception before publication')
            if fault=='capacity': raise OSError(28,'Injected ENOSPC')
            if fault=='process_stop': os._exit(97)
            for path in temp.rglob('*'):
                if path.is_file():
                    with open(path,'rb') as f: os.fsync(f.fileno())
            fsync_dir(temp)
            write(pending_path,{'transaction_id':patch['transaction_id'],'out':str(out),'base_hash':base['hash']})
            with open(pending_path,'rb') as f:os.fsync(f.fileno())
            fsync_dir(registry);os.rename(temp,out);fsync_dir(out.parent)
            if fault=='after_publish_stop':os._exit(98)
            ledger['transactions'].append(patch['transaction_id']); ledger['current']={'hash':preview['hash'],'version':preview['version'],'path':str(out/'graph.json')}
            write(registry/'ledger.next',ledger)
            with open(registry/'ledger.next','rb') as f: os.fsync(f.fileno())
            os.replace(registry/'ledger.next',registry/'ledger.json'); fsync_dir(registry)
            pending_path.unlink();fsync_dir(registry)
            return {'graph_modified':True,'graph_version':preview['version'],'transaction_id':patch['transaction_id'],'graph_path':str(out/'graph.json')}
        except BaseException:
            # Never delete caller outputs or previous versions. Only our staging tree.
            if temp.exists(): shutil.rmtree(temp)
            raise


def import_legacy(raw,graph_id,frame,models):
    """Preserve the complete raw record; imported geometry is never verified by naming."""
    nodes=[]; mapping={}
    for i,old in enumerate(raw.get('nodes',[])):
        legacy=str(old.get('id',i)); oid='import:'+digest([graph_id,legacy])[:24]; mapping[legacy]=oid
        nodes.append({'object_id':oid,'legacy_source_id':legacy,'raw_legacy_node':copy.deepcopy(old),
            'lifecycle':'ACTIVE','states':{'identity':'UNRESOLVED','motion':'UNKNOWN_MOTION','observation':'UNKNOWN'},
            'model':dict(models[legacy],geometry_status='UNVERIFIED_IMPORTED_GEOMETRY'),
            'pose':{'frame_id':frame,'matrix':np.eye(4).tolist(),'pose_status':'UNVERIFIED_IMPORTED_GEOMETRY'},
            'last_confirmed':None,'observation_refs':[],'attributes':copy.deepcopy(old.get('attributes',{})),'provenance':{'legacy':legacy}})
    edges=[]
    for i,e in enumerate(raw.get('edges',[])):
        edge=copy.deepcopy(e); edge.update(edge_id=str(e.get('edge_id','import-edge:'+str(i))),source=mapping[str(e['source'])],target=mapping[str(e['target'])],
            relation_type=e.get('relation_type','UNKNOWN'),evidence=e.get('evidence',[]),status='UNKNOWN',valid_time=e.get('valid_time'),provenance={'raw_legacy_edge':e}); edges.append(edge)
    return seal_graph({'schema_version':'ylm.scene_graph.v1','graph_id':graph_id,'version':1,'frame':frame,'units':'m','timestamp':None,
        'nodes':nodes,'edges':edges,'history':[],'raw_legacy_graph':raw,'legacy_id_map':mapping})
