from pathlib import Path
import copy
import numpy as np
from .util import read, lines, sha, digest, safe_path, require, transform
from .profiles import validate

TOP = {'schema_version','run_id','dataset_role','units','observations','candidate_runs','graph_input','bootstrap',
       'frame_contract','profiles','resources','allowed_roots','diagnostic_sources','adjudications'}


def checked_asset(base, spec, allowed, inventory):
    require(isinstance(spec, dict) and set(spec) >= {'path','sha256'}, 'Asset needs path and sha256')
    path = safe_path(base, spec['path'], allowed); h = sha(path)
    require(h == spec['sha256'], 'Asset hash mismatch: ' + str(path))
    inventory[str(path)] = {'sha256': h, 'bytes': path.stat().st_size}
    return path


def load(config_path):
    path = Path(config_path).resolve(); c = read(path)
    from .schema import validate as validate_schema
    validate_schema('integration_input',c)
    require(set(c) <= TOP, 'Unknown integration input fields (evaluation data forbidden)')
    require(c.get('schema_version') == 'ylm.integration.input.v1' and c.get('units') == 'm', 'Input version/units')
    for k in ('run_id','dataset_role','observations','candidate_runs','frame_contract','profiles','resources'):
        require(k in c, 'Missing input ' + k)
    require(c['dataset_role'] in ('SYNTHETIC_ONLY','REAL_DEVELOPMENT','REAL_EVALUATION'), 'Unknown dataset role')
    require(bool(c.get('graph_input')) != bool(c.get('bootstrap')), 'Explicit graph_input or bootstrap required')
    if c.get('bootstrap'):
        require(c['bootstrap'] == {'mode': 'DIAGNOSTIC_ONLY_NO_GRAPH'}, 'Execute bootstrap separately to create a graph')
    validate(c['profiles'], c['dataset_role'])
    r = c['resources']
    require(set(r) == {'workers','numerical_threads','rss_mib','wall_seconds','detailed_pairs','initializations','output_bytes','assignment_states'}, 'Resource fields')
    require(r['workers'] == r['numerical_threads'] == 1, 'Initial release supports worker/thread1')
    require(all(isinstance(v,(float,int)) and not isinstance(v,bool) and v > 0 for v in r.values()), 'Positive resources required')
    require(r['output_bytes']>=131072,'Output budget must reserve >=128KiB for diagnostics')
    for k in ('detailed_pairs','initializations','assignment_states','output_bytes'):
        require(isinstance(r[k], int), 'Integer budget required')
    allowed = [(path.parent / p).resolve() for p in c.get('allowed_roots', [])]
    inv = {str(path): {'sha256':sha(path),'bytes':path.stat().st_size}}
    def asset(spec, base=path.parent): return checked_asset(base,spec,allowed,inv)
    for adjudication in c.get('adjudications',[]): asset(adjudication)
    observations, candidates = {}, []
    frame = c['frame_contract']; tol = c['profiles']['solver']['numerical_tolerance']
    require(set(frame) >= {'status','graph_frame','transforms','evidence'}, 'Frame contract fields')
    require(frame['status'] in ('VERIFIED_FIXED','VERIFIED_TRANSFORM','FRAME_UNVERIFIED'), 'Invalid frame status')
    if frame['status'].startswith('VERIFIED'):
        require(frame['evidence'] and frame.get('independent_support') is True, 'Independent frame evidence required')
        for ref in frame['evidence']: asset(ref)
    for obs in c['observations']:
        fields = {'observation_id','case','time','window','boundary','sensor_frame','sensor_id','reference_time_ns',
                  'window_start_ns','window_end_ns','received_frames','pixels','upstream_manifest',
                  'provenance','structure_mask','shape','namespace','freshness_status','ray_calibration'}
        require(set(obs) == fields, 'Observation fields must be explicit: ' + str(set(obs)^fields))
        oid = obs['observation_id']; require(oid not in observations, 'Duplicate observation ID')
        start,end,ref = [obs[k] for k in ('window_start_ns','window_end_ns','reference_time_ns')]
        require(all(v is None or isinstance(v,int) for v in (start,end,ref)), 'Integer ns timestamps')
        require(all(v is None for v in (start,end,ref)) or all(v is not None for v in (start,end,ref)) and start <= ref <= end, 'Inconsistent time window')
        require(obs['freshness_status'] in ('VERIFIED','UNAVAILABLE','HISTORY_ONLY'), 'Freshness status')
        if obs['freshness_status'] == 'VERIFIED': require(ref is not None and obs['received_frames'], 'Freshness needs recorded frame selection')
        p = asset(obs['pixels']); z = np.load(p, allow_pickle=False)
        require(set(z.files) >= {'xyz','labels','valid'}, 'pixels keys')
        xyz, labels, valid = z['xyz'], z['labels'], z['valid']
        require(xyz.shape == tuple(obs['shape']) + (3,) and labels.shape == valid.shape == tuple(obs['shape']), 'H/W mismatch')
        require(xyz.dtype.kind == 'f' and labels.dtype.kind in 'iu' and valid.dtype.kind == 'b', 'pixels dtypes')
        require(np.isfinite(xyz[valid]).all(), 'Nonfinite valid xyz')
        mask_path = asset(obs['structure_mask']); mask_key = obs['structure_mask'].get('key','canonical_structure_mask')
        with np.load(mask_path, allow_pickle=False) as mz: mask = mz[mask_key]
        require(mask.shape == labels.shape and mask.dtype.kind == 'b', 'Mask shape/dtype')
        asset(obs['upstream_manifest'])
        prov = obs['provenance']; require(set(prov) >= {'current_rule','source_type_key','time_key','frame_key','sample_key'}, 'Provenance mapping required')
        require(prov['current_rule'] in ('SOURCE_TYPE_VALUES','ALL_SYNTHETIC','UNAVAILABLE'), 'Current provenance rule')
        if prov['current_rule'] == 'ALL_SYNTHETIC': require(c['dataset_role'] == 'SYNTHETIC_ONLY','Synthetic provenance on real data')
        arrays = {k:z[k] for k in z.files}
        for key in ('source_type_key','time_key','frame_key','sample_key'):
            if prov[key] is not None: require(prov[key] in arrays and arrays[prov[key]].shape == labels.shape, 'Provenance array missing/shape')
        require(oid in frame['transforms'], 'Missing sensor transform (explicit identity diagnostic permitted)')
        t = transform(frame['transforms'][oid]['matrix'],tol)
        require(frame['transforms'][oid]['from_frame'] == obs['sensor_frame'] and frame['transforms'][oid]['to_frame'] == frame['graph_frame'], 'Sensor transform direction')
        observations[oid] = {'meta':obs,'xyz':xyz,'labels':labels,'valid':valid,'mask':mask,'arrays':arrays,'T':t}
    require(set(frame['transforms']) == set(observations), 'Unknown frame observation')
    seen = set()
    for run in c['candidate_runs']:
        require(set(run) == {'observation_id','manifest','input_contract','resolved_config','candidates','artifact_hashes','source_hashes','source_environment','selection_policy','selection_manifest'}, 'Candidate contract fields')
        oid = run['observation_id']; require(oid in observations, 'Unknown candidate observation')
        obs = observations[oid]; meta=obs['meta']; man=read(asset(run['manifest']))
        require(man.get('version') == '0.5.1.2' and man.get('integrity_passed') is True, 'Unsupported candidate run version/integrity')
        environment=read(asset(run['source_environment']))
        require(isinstance(environment.get('source_modules'),dict) and environment['source_modules'],'Candidate implementation hashes required')
        require(all(isinstance(h,str) and len(h)==64 and set(h)<=set('0123456789abcdef') for h in environment['source_modules'].values()),'Invalid candidate source hash')
        if c['dataset_role']!='SYNTHETIC_ONLY':require('ylm051/pipeline.py' in environment['source_modules'],'Unknown candidate implementation')
        upstream=read(asset(run['input_contract'])); asset(run['resolved_config']); asset(run['source_hashes'])
        for k in ('case','window','boundary'): require(upstream[k] == meta[k], 'Candidate metadata mismatch')
        require(meta['namespace'] == dict(case=upstream['case'],window=upstream['window'],boundary=upstream['boundary'],run_id=upstream['run_id'],time=meta['time']), 'Namespace mismatch')
        require(upstream.get('units') == 'm', 'Candidate units')
        cp=asset(run['candidates']); artifacts=read(asset(run['artifact_hashes'])); runbase=Path(asset(run['manifest'])).parent
        original_time=upstream['times'][meta['time']]
        require(sha(safe_path(runbase,original_time['pixels'],allowed))==meta['pixels']['sha256'],'Observation/candidate pixels fingerprint mismatch')
        require('canonical_mask' in original_time and sha(safe_path(runbase,original_time['canonical_mask']['path'],allowed))==meta['structure_mask']['sha256'],'Observation/candidate mask fingerprint mismatch')
        for record in read(asset(run['source_hashes'])):
            p=safe_path(runbase,record['snapshot'],allowed)
            require(sha(p)==record['sha256'], 'Upstream snapshot fingerprint mismatch')
            inv[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
        if run['selection_manifest'] is not None: asset(run['selection_manifest'])
        require(run['selection_policy'] in ('S0','coverage_order_v1'), 'Unsupported selection policy')
        rows=list(lines(cp)); fid_pixels={int(f):np.flatnonzero((obs['labels']==f)&obs['valid']&~obs['mask']) for f in np.unique(obs['labels'][obs['valid']&~obs['mask']]) if f>=0}
        for item in rows:
            if item['namespace']['time'] != meta['time']: continue
            require(item['namespace']==meta['namespace'],'Candidate namespace contamination')
            key=oid+'::'+item['candidate_id']; require(key not in seen,'Duplicate candidate key'); seen.add(key)
            ids_path=safe_path(runbase,item['source_point_ids'],allowed)
            require(item['source_point_ids'] in artifacts and sha(ids_path)==artifacts[item['source_point_ids']], 'Candidate point IDs fingerprint')
            inv[str(ids_path)]={'sha256':sha(ids_path),'bytes':ids_path.stat().st_size}
            ids=np.load(ids_path,allow_pickle=False)
            require(ids.ndim==1 and ids.dtype.kind in 'iu' and len(np.unique(ids))==len(ids), 'Invalid pixel IDs')
            require(len(ids)>0 and ids.min()>=0 and ids.max()<obs['labels'].size,'Pixel IDs outside image')
            fids=item['fragment_ids']; require(len(fids)==len(set(fids)) and set(fids)<=set(fid_pixels),'Fragment ID mismatch')
            expected=np.sort(np.concatenate([fid_pixels[f] for f in fids]))
            require(np.array_equal(np.sort(ids),expected) and len(ids)==item['point_count'], 'Candidate full fragment union mismatch')
            current=np.zeros(len(ids),dtype=bool)
            if meta['provenance']['current_rule']=='ALL_SYNTHETIC': current[:]=True
            elif meta['provenance']['current_rule']=='SOURCE_TYPE_VALUES':
                current=np.isin(obs['arrays'][prov_key(meta,'source_type_key')].ravel()[ids],meta['provenance']['current_values'])
            if meta['freshness_status']!='VERIFIED': current[:]=False
            elif meta['reference_time_ns'] is not None:
                timekey=meta['provenance']['time_key']; framekey=meta['provenance']['frame_key']
                if timekey is None or framekey is None: current[:]=False
                else:
                    timestamps=obs['arrays'][timekey].ravel()[ids]
                    current &= (timestamps>=meta['window_start_ns']) & (timestamps<=meta['window_end_ns'])
                    current &= np.isin(obs['arrays'][framekey].ravel()[ids],meta['received_frames'])
                    freshness=c['profiles']['decision']['thresholds']['freshness_ns']
                    if freshness is not None: current &= abs(meta['reference_time_ns']-timestamps)<=freshness
            candidates.append({'key':key,'candidate_id':item['candidate_id'],'observation_id':oid,
                'fragment_ids':fids,'source_point_ids':ids.tolist(),'shape':meta['shape'],'namespace':meta['namespace'],
                'point_count':len(ids),'is_singleton':item['is_singleton'],'selection_policy':run['selection_policy'],
                'search_exhaustive':man.get('exploration_state')=='EXHAUSTIVE','original_record':item,
                'current_count':int(current.sum()),'current_mask':current.tolist(), 'time_ns':meta['reference_time_ns']})
    graph=None
    if c.get('graph_input'):
        from .graph import check_graph
        gs=c['graph_input']; gp=asset({'path':gs['graph_path'],'sha256':gs['content_sha256']}); graph=read(gp)
        check_graph(graph); require(graph['graph_id']==gs['graph_id'] and graph['version']==gs['version'],'Graph identity/version')
        require(graph['frame']==frame['graph_frame'],'Graph frame mismatch')
        for node in graph['nodes']:
            mp=asset(node['model']['asset'],gp.parent)
            points=np.load(mp,allow_pickle=False); require(points.ndim==2 and points.shape[1]==3 and np.isfinite(points).all(),'Invalid model cloud')
            node['_points']=points
    return c, observations, candidates, graph, inv


def prov_key(meta,key):
    value=meta['provenance'][key]; require(value is not None,'Missing explicit provenance mapping'); return value
