import numpy as np
from scipy.optimize import linear_sum_assignment
from .util import rotation_error


def overlap(a,b):
    return a['observation_id']==b['observation_id'] and (bool(set(a['fragment_ids'])&set(b['fragment_ids'])) or bool(set(a['source_point_ids'])&set(b['source_point_ids'])))


def solve(pairs,candidates,decision,max_states,budget=None):
    bykey={c['key']:c for c in candidates}; byid={p['pair_id']:p for p in pairs}
    groups=sorted({(p['object_id'],p['observation_id']) for p in pairs})
    eligible=[p for p in pairs if p.get('identity_status')=='CONFIRMED' and p.get('integration_validity')=='VALID_FOR_POSE' and p.get('persistent_model')]
    options={g:[] for g in groups}; unmatched=decision['utility']['unmatched_cost']
    for p in eligible:
        if p['integration_rank']>0: options[p['object_id'],p['observation_id']].append(p)
    for g in options: options[g].sort(key=lambda p:(-p['integration_rank'],p['pair_id']))
    # Hungarian is a recorded baseline only; it cannot express fragment overlap.
    models=sorted({p['object_id'] for p in eligible}); keys=sorted({p['candidate_key'] for p in eligible})
    hungarian=[]
    if models and keys:
        cost=np.zeros((len(models),len(keys)+len(models))); cost[:,:len(keys)]=1e6
        for p in eligible: cost[models.index(p['object_id']),keys.index(p['candidate_key'])]=-p['integration_rank']
        rows,cols=linear_sum_assignment(cost)
        hungarian=[{'object_id':models[i],'candidate_key':keys[j]} for i,j in zip(rows,cols) if j<len(keys) and cost[i,j]<0]
    states=0; cut=False; best=[]
    # Top two complete configurations, including explicit unmatched alternatives.
    suffix=[0.]*(len(groups)+1)
    for i in range(len(groups)-1,-1,-1): suffix[i]=suffix[i+1]+max([p['integration_rank'] for p in options[groups[i]]]+[-unmatched])
    def visit(i,selected,score):
        nonlocal states,cut,best
        if states>=max_states: cut=True; return
        states+=1
        if budget is not None and states%128==0: budget.check()
        if len(best)==2 and score+suffix[i]<best[-1][0]-1e-12: return
        if i==len(groups):
            best.append((score,tuple(p['pair_id'] for p in selected))); best=sorted(set(best),key=lambda v:(-v[0],v[1]))[:2]; return
        for p in options[groups[i]]:
            if any(overlap(bykey[p['candidate_key']],bykey[q['candidate_key']]) for q in selected): continue
            visit(i+1,selected+[p],score+p['integration_rank'])
        visit(i+1,selected,score-unmatched)
    # Avoid recursion dependent on thousands of all-invalid real model groups.
    active=[g for g in groups if options[g]]; fixed_unmatched=len(groups)-len(active)
    groups=active; suffix=[0.]*(len(groups)+1)
    for i in range(len(groups)-1,-1,-1): suffix[i]=suffix[i+1]+max([p['integration_rank'] for p in options[groups[i]]]+[-unmatched])
    if len(groups)>200:
        cut=True; best=[(-fixed_unmatched*unmatched,())]
    else: visit(0,[],-fixed_unmatched*unmatched)
    primary=list(best[0][1]) if best else []; held=[]; conflicts=[]
    unresolved_budget=any(p['evaluation_status'] in ('NOT_EVALUATED_BUDGET','QUEUED','NOT_ENUMERATED') for p in pairs)
    margin=decision['thresholds']['conflict_margin']; difference=best[0][0]-best[1][0] if len(best)>1 else None
    ambiguous=set()
    if len(best)>1 and (margin is None or difference<=margin): ambiguous=set(best[0][1])^set(best[1][1])
    for pid in list(primary):
        reasons=[]
        if cut: reasons.append('ASSIGNMENT_OPTIMALITY_UNPROVEN')
        if unresolved_budget: reasons.append('UNEVALUATED_COMPETITORS')
        if pid in ambiguous: reasons.append('COMPETING_CONFIGURATIONS_WITHIN_MARGIN')
        if reasons: primary.remove(pid); held.append({'pair_id':pid,'reasons':reasons})
    for p in eligible:
        for q in eligible:
            if p['pair_id']<q['pair_id'] and overlap(bykey[p['candidate_key']],bykey[q['candidate_key']]):
                conflicts.append({'pair_ids':[p['pair_id'],q['pair_id']],'reason':'SHARED_OBSERVATION_PIXELS_OR_FRAGMENTS'})
    auxiliary=[]; occupied=[bykey[byid[pid]['candidate_key']] for pid in primary]
    model_support={pid:set(byid[pid].get('metrics',{}).get('model_support_indices',[])) for pid in primary}
    for p in sorted(pairs,key=lambda p:p['pair_id']):
        if p.get('integration_validity')!='VALID_FOR_PARTIAL_OBSERVATION' or p['pair_id'] in primary or cut or unresolved_budget: continue
        c=bykey[p['candidate_key']]
        if not c['current_count'] or any(overlap(c,q) for q in occupied): continue
        for pid in primary:
            q=byid[pid]
            if (p['object_id'],p['observation_id'])!=(q['object_id'],q['observation_id']): continue
            a,b=np.array(p['transformation']),np.array(q['transformation']); t=decision['thresholds']
            if t['cluster_translation_m'] is None or t['cluster_rotation_deg'] is None: continue
            if np.linalg.norm(a[:3,3]-b[:3,3])>t['cluster_translation_m'] or rotation_error(a,b)>t['cluster_rotation_deg']: continue
            support=set(p['metrics']['model_support_indices'])
            if support & model_support[pid]: continue
            auxiliary.append({'pair_id':p['pair_id'],'primary_pair_id':pid,'unique_new_model_support':len(support)})
            occupied.append(c); model_support[pid]|=support; break
    chosen=set(primary)|{a['pair_id'] for a in auxiliary}
    held_ids={h['pair_id'] for h in held}
    for p in pairs:
        if p['pair_id'] not in chosen and p['pair_id'] not in held_ids and p['evaluation_status']=='EVALUATED':
            held.append({'pair_id':p['pair_id'],'reasons':p.get('reasons') or ['NOT_SELECTED_OR_NONPERSISTENT_MODEL']})
    return {'schema_version':'ylm.assignment.v1','primary':primary,'auxiliary':auxiliary,'conflicts':conflicts,'held':held,
        'unevaluated':[p['pair_id'] for p in pairs if p['evaluation_status']!='EVALUATED'],
        'unmatched':[{'object_id':oid,'observation_id':obs,'reason':'NO_CONFIRMED_NONCONFLICTING_PRIMARY'}
            for oid,obs in sorted({(p['object_id'],p['observation_id']) for p in pairs})
            if not any((byid[k]['object_id'],byid[k]['observation_id'])==(oid,obs) for k in primary)],
        'optimality_proven':not cut,'states_visited':states,'budget_exhausted':cut,
        'best_second_margin':difference,'solutions':[{'utility':score,'pair_ids':list(ids)} for score,ids in best],
        'hungarian_comparison':hungarian,'objective':'sum(integration_rank) - unmatched_cost * unmatched_model_observation_groups',
        'utility_profile':decision['utility'],'provisional_policy':'No new persistent IDs without independent novelty/adjudication'}
