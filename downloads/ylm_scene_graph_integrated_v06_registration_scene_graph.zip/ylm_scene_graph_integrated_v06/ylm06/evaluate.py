from pathlib import Path
from .util import read,write,lines,sha,require
from .pipeline import verify


def evaluate(run,evaluation_config):
    run=Path(run).resolve(); verify(run); cfg=read(evaluation_config)
    require(set(cfg)=={'schema_version','evaluation_id','ground_truth','proxy','author','created_at','basis'},'Evaluation contract fields')
    require(cfg['schema_version']=='ylm.evaluation.v1' and cfg['author'] and cfg['created_at'] and cfg['basis'],'GT provenance required')
    pairs={p['pair_id']:p for p in lines(run/'registration/pairs.jsonl')}; correct=0; denominator=0; unclear=0; unevaluated=0; details=[]
    for record in cfg['ground_truth']:
        require(record['identity'] in ('same','different','unclear') and record.get('basis'),'GT identity/basis')
        if record['identity']=='unclear': unclear+=1; continue
        pair=pairs.get(record['pair_id'])
        if pair is None or pair['evaluation_status']!='EVALUATED' or pair['identity_status'] in ('AMBIGUOUS','UNRESOLVED'):
            unevaluated+=1; continue
        denominator+=1; equal=(pair['identity_status']=='CONFIRMED')==(record['identity']=='same'); correct+=equal
        details.append({'pair_id':record['pair_id'],'identity_correct':equal})
    result={'evaluation_config_sha256':sha(evaluation_config),'ground_truth_scope':'SEPARATE_POSTHOC_ONLY',
        'identity_accuracy':correct/denominator if denominator else None,'denominator':denominator,'correct':correct,
        'unclear_excluded':unclear,'unresolved_or_unevaluated':unevaluated,'details':details,
        'motion_accuracy':'NOT_EVALUATED','update_accuracy':'NOT_EVALUATED','proxy':cfg['proxy'],
        'proxy_is_independent_GT':False,'graph_modified':False}
    dest=run/'evaluations'/cfg['evaluation_id']; require(dest.parent.resolve()==(run/'evaluations').resolve(),'Evaluation ID must be a simple name')
    require(not dest.exists(),'Evaluation output exists'); dest.mkdir(parents=True)
    write(dest/'config.json',cfg); write(dest/'result.json',result); return result
