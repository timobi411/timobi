"""Explicit 4/6 DOF nearest-neighbour registration with audited hypotheses."""
import time
import copy
import numpy as np
from scipy.spatial import cKDTree
from .util import require, transform, transformed, rotation_error, digest
from .profiles import applicable


def normalize_legacy(record):
    r=copy.deepcopy(record)
    for target, aliases in {'source_coverage':['source_coverage','t0_coverage','source_overlap'],
                            'target_coverage':['target_coverage','t1_coverage','target_overlap']}.items():
        values=[r[k] for k in aliases if r.get(k) is not None]
        require(all(np.isfinite(v) and 0<=v<=1 for v in values),'Invalid coverage')
        require(not values or all(abs(v-values[0])<=1e-12 for v in values),'Contradictory coverage aliases')
        r[target]=values[0] if values else None
    r['legacy_valid']=r.get('valid'); r['evaluation_status']=r.get('evaluation_status','NOT_EVALUATED')
    r['identity_status']='UNRESOLVED'; r['motion_status']='UNKNOWN_MOTION'
    r['integration_validity']='NOT_EVALUATED'
    if r.get('transformation') is not None: transform(r['transformation'])
    # Never promotes a legacy score/valid into an integrated confirmation.
    return r


def preprocess(points,s):
    points=np.asarray(points,dtype=float)
    require(points.ndim==2 and points.shape[1]==3 and np.isfinite(points).all(),'Invalid registration points')
    ids=np.arange(len(points))
    if s['voxel_m']>0 and len(points):
        _,first=np.unique(np.floor(points/s['voxel_m']).astype(np.int64),axis=0,return_index=True)
        ids=np.sort(first)
    if len(ids)>s['max_points']: ids=ids[np.linspace(0,len(ids)-1,s['max_points'],dtype=int)]
    return points[ids],ids


def fit(a,b,dof):
    ac=a.mean(axis=0); bc=b.mean(axis=0)
    t=np.eye(4)
    if dof=='4DOF':
        x=a[:,:2]-ac[:2]; y=b[:,:2]-bc[:2]
        angle=np.arctan2(np.sum(x[:,0]*y[:,1]-x[:,1]*y[:,0]),np.sum(x*y))
        co,si=np.cos(angle),np.sin(angle); t[:2,:2]=[[co,-si],[si,co]]
    else:
        u,_,v=np.linalg.svd((a-ac).T@(b-bc)); r=v.T@u.T
        if np.linalg.det(r)<0: v[-1]*=-1; r=v.T@u.T
        t[:3,:3]=r
    t[:3,3]=bc-t[:3,:3]@ac
    return t


def icp(a,b,initial,s,budget=None):
    t=initial.copy(); steps=0; reason='ITERATION_LIMIT'
    # The smaller observation is matched to the larger model, avoiding fitting
    # missing model regions to the visible boundary. Transform remains source->target.
    reverse=len(b)<0.85*len(a)
    target_tree=cKDTree(b)
    for radius in (s['coarse_m'],s['fine_m']):
        for _ in range(s['iterations']):
            if budget is not None: budget.check()
            moved=transformed(a,t)
            if reverse:
                distances,source_idx=cKDTree(moved).query(b,workers=1)
                keep=distances<=radius; aa=moved[source_idx[keep]]; bb=b[keep]
            else:
                distances,idx=target_tree.query(moved,workers=1)
                keep=distances<=radius; aa=moved[keep]; bb=b[idx[keep]]
            if len(aa)<3: reason='INSUFFICIENT_CORRESPONDENCE'; break
            delta=fit(aa,bb,s['dof']); t=delta@t; steps+=1
            if np.linalg.norm(delta-np.eye(4))<s['convergence_m']: reason='TRANSFORM_TOLERANCE'; break
    return t,steps,reason


def geometry(points):
    if not len(points): return {'unique_points':0,'eigenvalues':[0.,0.,0.],'spread_m':0.,'rank':0}
    unique=np.unique(points,axis=0); cov=(unique-unique.mean(axis=0)).T@(unique-unique.mean(axis=0))/max(len(unique),1)
    eig=np.maximum(np.linalg.eigvalsh(cov),0)
    return {'unique_points':len(unique),'eigenvalues':eig.tolist(),'spread_m':float(np.linalg.norm(np.ptp(unique,axis=0))),
            'rank':int(np.sum(eig>max(eig[-1]*1e-8,1e-16)))}


def normals(points,k):
    if len(points)<max(k,4): return None
    _,idx=cKDTree(points).query(points,k=k,workers=1)
    local=points[idx]; local-=local.mean(axis=1,keepdims=True)
    _,v=np.linalg.eigh(np.einsum('nki,nkj->nij',local,local)/k)
    return v[:,:,0]


def metrics(a,b,t,s):
    moved=transformed(a,t); ds,idx=cKDTree(b).query(moved,workers=1); dt,_=cKDTree(moved).query(b,workers=1)
    support=ds<=s['fine_m']; count=int(support.sum())
    na,nb=normals(a,s['normal_k']),normals(b,s['normal_k'])
    normal=None
    if na is not None and nb is not None and count:
        normal=float(np.mean(np.abs(np.sum((na@t[:3,:3].T)[support]*nb[idx[support]],axis=1))))
    return {'correspondences':count,'unique_source':count,'unique_target':int(len(np.unique(idx[support]))),
        'source_coverage':count/len(a),'target_coverage':float(np.mean(dt<=s['fine_m'])),
        'fitness':count/len(a),'rmse_m':float(np.sqrt(np.mean(ds[support]**2))) if count else None,
        'denominators':{'source_points':len(a),'target_points':len(b),'coverage_distance_m':s['fine_m']},
        'normal_abs_dot_mean':normal,'normal_reason':None if normal is not None else 'INSUFFICIENT_NORMAL_SUPPORT',
        'model_support_indices':np.flatnonzero(support).tolist(), 'target_support_indices':np.unique(idx[support]).tolist(),
        'correspondence_geometry':geometry(a[support])}


def initializations(a,b,s):
    values=[('model_pose_no_motion',np.eye(4))]
    center=np.eye(4); center[:3,3]=b.mean(axis=0)-a.mean(axis=0); values.append(('center_translation',center))
    for yaw in s['yaw_degrees']:
        theta=np.deg2rad(yaw); t=np.eye(4); t[:2,:2]=[[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]]
        t[:3,3]=a.mean(axis=0)-t[:3,:3]@a.mean(axis=0)
        values.append(('yaw_about_model_center:'+str(yaw),t)); values.append(('yaw_center_aligned:'+str(yaw),center@t))
    for i,m in enumerate(s['extra_rotations']): values.append(('explicit_rotation:'+str(i),transform(m)))
    return values


def select_hypothesis(hypotheses,d):
    valid=[h for h in hypotheses if h['numerically_valid'] and h['pose_constrained'] and h.get('profile_eligible',True)]
    partial=[h for h in hypotheses if h['numerically_valid']]
    pool=valid or partial
    if not pool: return None,[],False
    pool=sorted(pool,key=lambda h:(-h['integration_rank'],h['hypothesis_id']))
    clusters=[]; t=d['thresholds']; configured=all(t[k] is not None for k in ['cluster_translation_m','cluster_rotation_deg','solution_margin'])
    for h in pool:
        a=np.array(h['transformation']); found=None
        if configured:
            for i,cluster in enumerate(clusters):
                b=np.array(cluster[0]['transformation'])
                if np.linalg.norm(a[:3,3]-b[:3,3])<=t['cluster_translation_m'] and rotation_error(a,b)<=t['cluster_rotation_deg']:
                    found=i; break
        if found is None: clusters.append([h])
        else: clusters[found].append(h)
    ambiguous=not configured or len(clusters)>1 and clusters[0][0]['integration_rank']-clusters[1][0]['integration_rank']<=t['solution_margin']
    return pool[0],[[h['hypothesis_id'] for h in group] for group in clusters],ambiguous


def register(a,b,profiles,context,budget=None):
    s,d=profiles['solver'],profiles['decision']; thresholds=d['thresholds']
    a,aid=preprocess(a,s); b,bid=preprocess(b,s); hypotheses=[]
    result={'evaluation_status':'EVALUATED','legacy_valid':None,'legacy_score':None,
        'integration_validity':'INVALID_INPUT','identity_status':'UNRESOLVED','motion_status':'UNKNOWN_MOTION',
        'observation_status':'UNKNOWN','transformation':None,'selected_hypothesis_id':None,'reasons':[],
        'input_maps':{'source_indices':aid.tolist(),'target_indices':bid.tolist()},'solution_clusters':[],
        'metric_definitions':{'coverage':'fraction within fine_m, denominators are preprocessed point counts',
                              'integration_rank':'coverage_weight*min(coverages)+residual_weight*(1-rmse/fine_m)-risk_cost'},
        'hypothesis_count_requested':0,'initialization_complete':True}
    if min(len(a),len(b))<3:
        result['reasons']=['INSUFFICIENT_INPUT_POINTS']; return result,hypotheses
    ga,gb=geometry(a),geometry(b)
    values=initializations(a,b,s); result['hypothesis_count_requested']=len(values)
    cap=context['initialization_limit']; result['initialization_complete']=len(values)<=cap
    # Held-out source samples are not fitted. Target is a shared reference surface;
    # this is geometric cross-validation, never independent object identity evidence.
    evaluation=np.arange(len(a))[::s['evaluation_stride']] if len(a)>=s['split_min_points'] else np.array([],dtype=int)
    fitids=np.setdiff1d(np.arange(len(a)),evaluation)
    result['fit_evaluation_split']={'status':'HELD_OUT_SOURCE_SHARED_TARGET' if len(evaluation) else 'UNAVAILABLE',
        'fit_source_indices':aid[fitids].tolist(),'evaluation_source_indices':aid[evaluation].tolist(),
        'target_shared':True,'independent_identity_evidence':False}
    for i,(route,initial) in enumerate(values[:cap]):
        start=time.monotonic(); t,steps,reason=icp(a[fitids],b,initial,s,budget)
        transform(t,s['numerical_tolerance']); m=metrics(a,b,t,s)
        constrained=all(g['rank']==3 for g in [ga,gb,m['correspondence_geometry']])
        if thresholds['eigen_ratio_min'] is not None:
            constrained &= all(g['eigenvalues'][0]>=thresholds['eigen_ratio_min']*max(g['eigenvalues'][-1],1e-20) for g in [ga,gb,m['correspondence_geometry']])
        valid=m['correspondences']>=3 and m['unique_target']>=3 and m['rmse_m'] is not None
        rank=0.
        if valid:
            u=d['utility']; rank=u['coverage_weight']*min(m['source_coverage'],m['target_coverage'])+u['residual_weight']*(1-m['rmse_m']/s['fine_m'])-u['risk_cost']
        h={'hypothesis_id':context['pair_id']+':h'+str(i),'initialization_route':route,'initial_transform':initial.tolist(),
           'transformation':t.tolist(),'convergence_reason':reason,'iterations':steps,'elapsed_seconds':time.monotonic()-start,
           'metrics':m,'numerically_valid':valid,'pose_constrained':bool(constrained),'integration_rank':float(rank),
           'geometry':{'source':ga,'target':gb},'dof':s['dof'],'evaluation_rmse_m':None}
        h['profile_eligible']=valid and all(thresholds[k] is None or value>=thresholds[k] for k,value in
            [('min_correspondences',m['correspondences']),('min_unique_points',min(m['unique_source'],m['unique_target'])),
             ('min_spread_m',m['correspondence_geometry']['spread_m']),('source_coverage',m['source_coverage']),('target_coverage',m['target_coverage'])])
        h['profile_eligible'] &= thresholds['max_rmse_m'] is None or m['rmse_m'] is not None and m['rmse_m']<=thresholds['max_rmse_m']
        if len(evaluation):
            distance,_=cKDTree(b).query(transformed(a[evaluation],t),workers=1)
            h['evaluation_rmse_m']=float(np.sqrt(np.mean(distance**2)))
        hypotheses.append(h)
    best,clusters,ambiguous=select_hypothesis(hypotheses,d); result['solution_clusters']=clusters
    if best is None:
        result['integration_validity']='REJECTED_BY_PROFILE'; result['reasons']=['NO_VALID_CORRESPONDENCE']; return result,hypotheses
    t=np.array(best['transformation']); m=best['metrics']; reference=np.asarray(context['reference_point'])
    current_mask=np.asarray(context.get('current_mask',[True]*max(len(bid),int(bid.max())+1)),bool)
    current_supported=int(current_mask[bid[m['target_support_indices']]].sum()) if len(bid) else 0
    displacement=transformed(reference[None,:],t)[0]-reference
    rotation=rotation_error(t,np.eye(4))
    result.update(transformation=t.tolist(),selected_hypothesis_id=best['hypothesis_id'],metrics=m,
        integration_rank=best['integration_rank'],model_reference_displacement_m=displacement.tolist(),
        displacement_m=float(np.linalg.norm(displacement)),rotation_deg=rotation,matrix_translation_m=t[:3,3].tolist(),
        observed_center_difference_m=(b.mean(axis=0)-a.mean(axis=0)).tolist(),
        selected_reason='VALID_POSE_SOLUTIONS_FIRST_THEN_FIXED_RANK_AND_ID',frame_status=context['frame_status'],
        current_supported_points=current_supported)
    reasons=applicable(profiles,context['dataset_role'],context['sensor_id'],float(np.linalg.norm(b.mean(axis=0))),[len(a),len(b)])
    if context['frame_status'] not in ('VERIFIED_FIXED','VERIFIED_TRANSFORM'): reasons.append('FRAME_UNVERIFIED')
    if not context.get('model_verified'): reasons.append('MODEL_GEOMETRY_UNVERIFIED')
    if context.get('current_count',0)<max(1,thresholds['min_unique_points'] or 1): reasons.append('INSUFFICIENT_VERIFIED_CURRENT_POINTS')
    if current_supported<max(1,thresholds['min_unique_points'] or 1):reasons.append('INSUFFICIENT_CURRENT_CORRESPONDENCE_SUPPORT')
    if not result['initialization_complete']: reasons.append('INITIALIZATION_BUDGET')
    if not best['pose_constrained']: reasons.append('POSE_CONSTRAINT_INSUFFICIENT')
    if ambiguous: reasons.append('AMBIGUOUS_TRANSFORMS_OR_UNSET_MARGIN')
    violated=[]
    for key,value,minimum in [('min_correspondences',m['correspondences'],True),('min_unique_points',min(m['unique_source'],m['unique_target']),True),
        ('min_spread_m',m['correspondence_geometry']['spread_m'],True),('max_rmse_m',m['rmse_m'],False),
        ('source_coverage',m['source_coverage'],True),('target_coverage',m['target_coverage'],True),
        ('max_displacement_m',result['displacement_m'],False),('max_rotation_deg',rotation,False)]:
        limit=thresholds[key]
        if limit is not None and (value<limit if minimum else value>limit): violated.append(key)
    result['reasons']=reasons+['THRESHOLD:'+key for key in violated]
    result['integration_validity']='HELD_DEGENERATE' if not best['pose_constrained'] else 'HELD_AMBIGUOUS' if ambiguous else 'REJECTED_BY_PROFILE' if violated else 'VALID_FOR_POSE'
    if not reasons and not violated:
        result['identity_status']='CONFIRMED'
        result['motion_status']='STATIC' if result['displacement_m']<=thresholds['static_translation_m'] and rotation<=thresholds['static_rotation_deg'] else 'MOVED'
        result['observation_status']='PARTIAL' if m['source_coverage']<0.95 else 'CURRENT_OBSERVED'
    elif ambiguous: result['identity_status']='AMBIGUOUS'
    elif violated and not reasons: result['identity_status']='REJECTED_UNDER_PROFILE'
    # A supported, unique local transform may support auxiliary observation even
    # when global model coverage is below the primary threshold. Assignment still
    # requires an independently confirmed primary and disjoint current pixels.
    if violated==['source_coverage'] and not reasons:
        result['integration_validity']='VALID_FOR_PARTIAL_OBSERVATION'
    return result,hypotheses
