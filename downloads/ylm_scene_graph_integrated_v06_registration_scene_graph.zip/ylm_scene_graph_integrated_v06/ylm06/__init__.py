"""YLM v0.6: observed geometry is not persistent model identity."""
__version__ = "0.6.0"
