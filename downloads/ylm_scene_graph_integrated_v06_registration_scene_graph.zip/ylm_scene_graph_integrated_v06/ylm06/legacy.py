"""Unmodified frozen B0 in a separate Python process; path-only adapter."""
import argparse
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
from .util import read, write, sha, require

B0_SHA = '3007d53e5cf8398477ced49098e8d308c0140ed10fb2438956a02c0d7dbd2bda'


def replay(inputs, out, python=sys.executable):
    env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
    subprocess.run([str(python), '-m', 'ylm06.legacy', '--inputs', str(Path(inputs).resolve()),
                    '--out', str(Path(out).resolve())], check=True, env=env)


def worker(inputs, out):
    import numpy as np
    inputs, out = Path(inputs).resolve(), Path(out).resolve()
    out.mkdir(parents=True, exist_ok=False)
    source = Path(__file__).parent / 'vendor/frozen/baseline_icp_B0.py'
    require(sha(source) == B0_SHA, 'Frozen B0 hash mismatch')
    spec = importlib.util.spec_from_file_location('frozen_B0', source)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    hashes = {}
    for t in ('t0', 't1'):
        path = inputs / (t + '_merged_clusters.json'); records = read(path); hashes[str(path)] = sha(path)
        for item in records:
            p = inputs / (t + '_clouds') / Path(item['pcd']).name
            require(p.is_file(), 'Missing frozen input ' + str(p)); hashes[str(p)] = sha(p)
            item['pcd'] = str(p)
        dest = out / (t + '_merged_clusters.json'); write(dest, records)
        setattr(module, t.upper() + '_JSON', dest)
    module.OUTPUT_JSON = out / 'partial_icp_results_fixed_repro.json'
    module.OUTPUT_HTML = out / 'partial_icp_results_fixed_repro.html'
    module.main()
    reference = inputs / 'reference_partial_icp_results.json'
    old = {(r['t0_id'], r['t1_id']): r for r in read(reference)}
    new = {(r['t0_id'], r['t1_id']): r for r in read(module.OUTPUT_JSON)}
    checks = []
    for key in sorted(old):
        for field in ['fitness', 'rmse', 'score', 't0_coverage', 't1_coverage', 'icp_translation_m', 'yaw_deg', 'transformation']:
            checks.append({'pair': key, 'field': field, 'pass': key in new and bool(np.allclose(old[key][field], new[key][field], atol=1e-6, rtol=1e-6))})
    result = {'source_sha256': sha(source), 'input_hashes': hashes, 'reference_sha256': sha(reference),
              'pair_sets_equal': old.keys() == new.keys(), 'numeric_checks': len(checks),
              'valid_equal': all(old[k]['valid'] == new[k]['valid'] for k in old if k in new), 'checks': checks,
              'tolerance': {'rtol': 1e-6, 'atol': 1e-6, 'purpose': 'numerical reproducibility, not accuracy'}}
    result['passed'] = result['pair_sets_equal'] and result['valid_equal'] and all(c['pass'] for c in checks)
    write(out / 'comparison.json', result)
    require(result['passed'], 'B0 numerical reproduction failed')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--inputs', required=True); parser.add_argument('--out', required=True)
    args = parser.parse_args(); worker(args.inputs, args.out)
