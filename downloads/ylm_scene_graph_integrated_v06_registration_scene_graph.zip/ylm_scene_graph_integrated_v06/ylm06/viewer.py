import html
import json
from pathlib import Path
from plotly.offline import get_plotlyjs
from .util import canonical


def render(out,candidates,observations,models,pairs,assignment,patch,manifest):
    from .pipeline import points
    # Display sampling is explicit; ICP and original point IDs remain separately stored.
    data={'candidates':[{k:v for k,v in c.items() if k not in ('original_record','current_mask')} for c in candidates],
        'clouds':{c['key']:points(c,observations)[::max(1,(c['point_count']+1999)//2000)].tolist() for c in candidates},
        'models':{m['object_id']:m['points'][::max(1,(len(m['points'])+1999)//2000)].tolist() for m in models},
        'pairs':pairs,'assignment':assignment,'patch':patch,'manifest':manifest}
    from .util import read,lines
    data.update(hypotheses=list(lines(Path(out)/'registration/hypotheses.jsonl')),
        visibility=list(lines(Path(out)/'visibility/evidence.jsonl')),
        observations=list(lines(Path(out)/'observations/records.jsonl')),
        frames=read(Path(out)/'frames/transforms.json'),inputs=read(Path(out)/'input_inventory.json'))
    encoded=canonical(data).decode().replace('</','<\\/')
    page='''<!doctype html><html lang="ja"><meta charset="utf-8"><title>YLM v0.6 統合監査</title>
<style>body{font:15px sans-serif;margin:24px;background:#f5f7fa;color:#18242d}select{max-width:90%;padding:8px}pre{white-space:pre-wrap;background:white;padding:16px;max-height:500px;overflow:auto}#plot{height:570px}button{margin:8px;padding:8px}</style>
<h1>YLM v0.6 候補・登録・グラフ更新監査</h1><p>物理的な正解率は独立評価が必要です。表示は最大約2,000点/候補。全画素IDと全初期値はJSON正本に保存しています。</p>
<div id="summary"></div><label>登録ペア <select id="pair"></select></label><button id="align">変換前／登録後</button>
<div id="plot"></div><pre id="detail"></pre><h2>工程別監査</h2><select id="stage"><option>manifest</option><option>inputs</option><option>frames</option><option>candidates</option><option>hypotheses</option><option>assignment</option><option>visibility</option><option>observations</option><option>patch</option></select><pre id="audit"></pre><script>'''+get_plotlyjs()+'''</script><script>
const data='''+encoded+''';let aligned=true;const menu=document.getElementById('pair');
data.pairs.forEach((p,i)=>{let o=document.createElement('option');o.value=i;o.textContent=p.pair_id+' '+p.evaluation_status+' '+p.identity_status;menu.appendChild(o)});
document.getElementById('summary').textContent=JSON.stringify(data.manifest.counts);
function trace(p,name,color){return {type:'scatter3d',mode:'markers',name,x:p.map(v=>v[0]),y:p.map(v=>v[1]),z:p.map(v=>v[2]),marker:{size:2,color}}}
function draw(){let p=data.pairs[Number(menu.value)||0];if(!p){document.getElementById('detail').textContent='評価可能なペアなし';return}let m=data.models[p.object_id]||[],c=data.clouds[p.candidate_key]||[];
if(aligned&&p.transformation){let t=p.transformation;m=m.map(v=>t.slice(0,3).map(r=>r[0]*v[0]+r[1]*v[1]+r[2]*v[2]+r[3]))}
Plotly.react('plot',[trace(m,'登録モデル','#3164ad'),trace(c,'現在候補','#ed7a30')],{scene:{aspectmode:'data'},margin:{l:0,r:0,t:20,b:0}});document.getElementById('detail').textContent=JSON.stringify(p,null,2)}
menu.onchange=draw;document.getElementById('align').onclick=()=>{aligned=!aligned;draw()};function stage(){document.getElementById('audit').textContent=JSON.stringify(data[document.getElementById('stage').value],null,2)}document.getElementById('stage').onchange=stage;draw();stage();
</script></html>'''
    from . import util
    if util.ACTIVE_BUDGET is not None:util.ACTIVE_BUDGET.preflight(len(page.encode('utf-8')))
    (Path(out)/'index.html').write_text(page,encoding='utf-8')
