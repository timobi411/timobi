from .util import digest, require

THRESHOLDS = ['min_correspondences', 'min_unique_points', 'min_spread_m', 'max_rmse_m',
              'source_coverage', 'target_coverage', 'max_displacement_m', 'max_rotation_deg',
              'eigen_ratio_min', 'cluster_translation_m', 'cluster_rotation_deg', 'solution_margin',
              'conflict_margin', 'freshness_ns', 'static_translation_m', 'static_rotation_deg',
              'visibility_min_rays', 'visibility_support_fraction', 'visibility_range_tolerance_m']


def seal(profile):
    profile = dict(profile); profile.pop('hash', None); profile['hash'] = digest(profile)
    return profile


def defaults(synthetic=False, dof='4DOF'):
    decision = {'profile_id': 'synthetic_fixture_v1' if synthetic else 'diagnostic_uncalibrated_v1',
                'version': 1, 'validation_status': 'SYNTHETIC_ONLY' if synthetic else 'UNCALIBRATED',
                'validation_record': 'tests/test_registration.py and tests/test_transactions.py' if synthetic else None,
                'source': 'Explicit fixture regression limits; no real sensor calibration',
                'scope': {'sensors': ['synthetic'] if synthetic else ['*'], 'distance_m': [0, 100],
                          'point_count': [4, 100000], 'dof': [dof]},
                'thresholds': {k: None for k in THRESHOLDS},
                'utility': {'coverage_weight': 1.0, 'residual_weight': 0.25,
                            'risk_cost': 0.0, 'unmatched_cost': 0.0, 'range': [-1, 1.25]},
                'shape_accumulation': False}
    if synthetic:
        decision['thresholds'].update(min_correspondences=12, min_unique_points=10, min_spread_m=0.01,
            max_rmse_m=0.025, source_coverage=0.60, target_coverage=0.9, max_displacement_m=1.0,
            max_rotation_deg=90, eigen_ratio_min=0.001, cluster_translation_m=0.01, cluster_rotation_deg=1.0,
            solution_margin=0.02, conflict_margin=0.02, freshness_ns=1000000000,
            static_translation_m=0.002, static_rotation_deg=0.1, visibility_min_rays=3,
            visibility_support_fraction=0.8, visibility_range_tolerance_m=0.03)
    return {'solver': {'mode': 'integration', 'dof': dof, 'gravity_verified': synthetic,
            'motion_assumption_verified': synthetic, 'voxel_m': 0.0, 'max_points': 5000,
            'outlier_filter': 'NONE', 'representative': 'smallest_source_index', 'normal_k': 12,
            'coarse_m': 0.35, 'fine_m': 0.04, 'iterations': 150, 'convergence_m': 1e-9,
            'yaw_degrees': [-30, -20, -10, 0, 10, 20, 30], 'extra_rotations': [],
            'evaluation_stride': 5, 'split_min_points': 100, 'numerical_tolerance': 1e-6},
            'decision': seal(decision)}


def validate(profiles, role):
    require(set(profiles) == {'solver', 'decision'}, 'Unknown profile fields')
    s, d = profiles['solver'], profiles['decision']
    require(set(s) == set(defaults()['solver']), 'Solver fields must be explicit')
    require(s['mode'] in ('integration', 'B0_COMPAT'), 'Unknown solver mode')
    require(s['dof'] in ('4DOF', '6DOF'), 'Explicit DOF required')
    require(s['outlier_filter'] == 'NONE' and s['representative'] == 'smallest_source_index', 'Unsupported preprocessing')
    require(s['coarse_m'] >= s['fine_m'] > 0 and s['voxel_m'] >= 0, 'Invalid registration distances')
    for k in ('max_points', 'iterations', 'normal_k', 'evaluation_stride', 'split_min_points'):
        require(isinstance(s[k], int) and s[k] > 0, 'Invalid solver count ' + k)
    require(s['evaluation_stride'] >= 2 and s['split_min_points'] >= 4, 'Invalid independent split')
    require(0 < s['numerical_tolerance'] <= 1e-4 and s['convergence_m'] > 0, 'Invalid numerical tolerance')
    from .util import transform
    import numpy as np
    for matrix in s['extra_rotations']:
        t=transform(matrix,s['numerical_tolerance'])
        if s['dof']=='4DOF':require(np.allclose(t[:3,2],[0,0,1],atol=s['numerical_tolerance'],rtol=0),'4DOF initializer must preserve gravity')
    require(d == seal(d), 'Decision profile hash mismatch')
    require(set(d) == set(defaults()['decision']), 'Decision metadata required / unknown fields')
    require(set(d['thresholds']) == set(THRESHOLDS), 'All decision thresholds must be explicit, nullable')
    require(d['validation_status'] in ('UNCALIBRATED', 'VALIDATED', 'SYNTHETIC_ONLY'), 'Unknown validation status')
    if d['validation_status'] == 'SYNTHETIC_ONLY':
        require(role == 'SYNTHETIC_ONLY', 'Synthetic profile cannot be applied to real data')
    if d['validation_status'] != 'UNCALIBRATED':
        require(bool(d['validation_record']), 'Validation record required')
    for k, v in d['thresholds'].items():
        require(v is None or isinstance(v, (int, float)) and not isinstance(v, bool) and v >= 0, 'Invalid threshold ' + k)
    for k in ('source_coverage', 'target_coverage', 'visibility_support_fraction', 'eigen_ratio_min'):
        require(d['thresholds'][k] is None or d['thresholds'][k] <= 1, 'Invalid fraction')
    u = d['utility']
    require(set(u) == {'coverage_weight', 'residual_weight', 'risk_cost', 'unmatched_cost', 'range'}, 'Utility formula fields required')
    require(all(u[k] >= 0 for k in ('coverage_weight', 'residual_weight', 'risk_cost', 'unmatched_cost')), 'Negative cost')
    return profiles


def applicable(profiles, role, sensor, distance, counts):
    d, s = profiles['decision'], profiles['solver']; scope = d['scope']
    reasons = []
    if d['validation_status'] == 'UNCALIBRATED': reasons.append('UNCALIBRATED_PROFILE')
    if d['validation_status'] == 'SYNTHETIC_ONLY' and role != 'SYNTHETIC_ONLY': reasons.append('SYNTHETIC_SCOPE')
    if any(v is None for v in d['thresholds'].values()): reasons.append('UNSET_DECISION_THRESHOLDS')
    if not d['validation_record']: reasons.append('NO_VALIDATION_RECORD')
    if sensor not in scope['sensors'] and '*' not in scope['sensors']: reasons.append('SENSOR_OUTSIDE_SCOPE')
    if not scope['distance_m'][0] <= distance <= scope['distance_m'][1]: reasons.append('RANGE_OUTSIDE_SCOPE')
    if any(not scope['point_count'][0] <= n <= scope['point_count'][1] for n in counts): reasons.append('POINT_COUNT_OUTSIDE_SCOPE')
    if s['dof'] not in scope['dof']: reasons.append('DOF_OUTSIDE_SCOPE')
    if s['dof'] == '4DOF' and not (s['gravity_verified'] and s['motion_assumption_verified']): reasons.append('4DOF_ASSUMPTIONS_UNVERIFIED')
    return reasons
