import os
# Set before importing numerical libraries. A dedicated process owns the numeric budget.
for _key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_key]='1'
import argparse
import json
import sys
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description='YLM v0.6 auditable registration and graph transactions')
    subs=parser.add_subparsers(dest='command',required=True)
    for cmd in ('inspect','run','bootstrap'):
        p=subs.add_parser(cmd); p.add_argument('--config',required=True)
        if cmd!='inspect': p.add_argument('--out',required=True)
        if cmd=='run': p.add_argument('--resume',action='store_true')
    p=subs.add_parser('verify'); p.add_argument('--run',required=True)
    p=subs.add_parser('evaluate'); p.add_argument('--run',required=True); p.add_argument('--evaluation-config',required=True)
    for cmd in ('validate-patch','apply'):
        p=subs.add_parser(cmd); p.add_argument('--patch',required=True); p.add_argument('--graph',required=True)
        if cmd=='apply': p.add_argument('--out',required=True); p.add_argument('--store')
    p=subs.add_parser('legacy-replay'); p.add_argument('--inputs',required=True); p.add_argument('--out',required=True); p.add_argument('--python',default=sys.executable)
    args=parser.parse_args()
    try:
        from .pipeline import run,verify
        from .contracts import load
        from .graph import validate_patch,apply_patch
        if args.command=='inspect':
            c,o,cs,g,inv=load(args.config); result={'input_valid':True,'observations':len(o),'candidates':len(cs),'graph_nodes':len(g['nodes']) if g else None,'frame_status':c['frame_contract']['status'],'input_assets':len(inv),'decision_profile':c['profiles']['decision']['validation_status']}
        elif args.command=='run': result=run(args.config,args.out,args.resume)
        elif args.command=='verify': result=verify(args.run)
        elif args.command=='bootstrap':
            from .bootstrap import bootstrap
            result=bootstrap(args.config,args.out)
        elif args.command=='evaluate':
            from .evaluate import evaluate
            result=evaluate(args.run,args.evaluation_config)
        elif args.command=='validate-patch':
            p,g,preview=validate_patch(args.patch,args.graph); result={'patch_valid':True,'operations':len(p['operations']),'graph_modified':False}
        elif args.command=='apply': result=apply_patch(args.patch,args.graph,args.out,args.store)
        elif args.command=='legacy-replay':
            from .legacy import replay
            replay(args.inputs,args.out,args.python); result={'legacy_replay_complete':True,'out':args.out}
        print(json.dumps(result,ensure_ascii=False,allow_nan=False))
        return 2 if result.get('partial') else 0
    except Exception as exc:
        print(json.dumps({'status':'INVALID_INPUT_OR_PROCESSING_ERROR','type':type(exc).__name__,'reason':str(exc)},ensure_ascii=False),file=sys.stderr)
        return 1


if __name__=='__main__':
    raise SystemExit(main())
