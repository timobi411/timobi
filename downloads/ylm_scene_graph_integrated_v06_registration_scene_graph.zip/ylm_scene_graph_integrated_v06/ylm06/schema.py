from importlib.resources import files
import json
from jsonschema import Draft202012Validator
from .util import Invalid


def validate(name,value):
    schema=json.loads((files('ylm06')/'schemas'/(name+'.json')).read_text())
    errors=list(Draft202012Validator(schema).iter_errors(value))
    if errors:
        first=errors[0];raise Invalid(name+' schema '+'.'.join(map(str,first.absolute_path))+': '+first.message)
