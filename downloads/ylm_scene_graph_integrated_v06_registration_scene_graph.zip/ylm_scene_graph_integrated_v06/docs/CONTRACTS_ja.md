# 入出力契約と設計上の判断

## 入力の正本

統合入力のschemaは `ylm.integration.input.v1`。実行可能な小例は `examples.make_fixture` で生成します。構造検証は `ylm06/schemas/integration_input.json`、参照・集合・幾何の意味検証は `contracts.py` です。

| 項目 | 契約 |
|---|---|
| observations | 時刻ns、窓、frame、画素H/W、namespace、実測/履歴の明示マッピング、mask、上流manifestのhash |
| candidate_runs | 元input、resolved config、manifest、候補JSONL、artifact/source hashes、実行時environment/source_modules、選択方式・選択manifest |
| graph_input | graph ID/version、元ファイルのSHA-256、graph_path。内部hashはhash欄を除くcanonical JSONのSHA-256 |
| bootstrap | `{"mode":"DIAGNOSTIC_ONLY_NO_GRAPH"}` は永続グラフなしの診断指定。空graphを暗黙に登録する機能ではない |
| frame_contract | G座標、観測ごとのT_G_from_S、status、独立根拠ファイル。未確認は明示恒等で診断可 |
| profiles | solverとdecision。decisionのhashはhash欄を除くcanonical JSONで計算 |
| resources | workers、数値threads、wall/RSS、詳細ペア・初期値・割当state、出力予算 |

assetは `path` とSHA-256を持ちます。入力config基準でのみ解決し、allowlistのない外部rootを拒否します。絶対パスを含む旧実験JSONのPCDだけは、凍結B0専用adapterでbasenameと明示入力ディレクトリから解決します。元PCDを変更しません。

候補画素配列は整数1次元NPYとして読みます。文字列を整数へ変換しません。重複、範囲外、namespace違い、ラベル所属違い、構造mask除去後の全断片和集合との差を拒否します。候補runのpixels/maskのfingerprintとobservationのfingerprintも一致させます。実行時v0.5.1.2 source hashはenvironment正本の内容を保存し、ソースが取得できない場合も名前から推測しません。

候補生成の型は既存v0.5.1.2を維持し、統合キーだけ `observation_id::candidate_id` を追加します。画素IDとfragment IDは観測内の識別子です。永続IDへ変換しません。

## 登録と判定

列ベクトル契約は `p_B=T_B_from_A@p_A`。コードの点群配列は行ベクトルなので `points@R.T+t` を使います。sensor変換を適用した後に、G座標内の物体変換を推定します。モデル基準点の変位で移動を判定します。

統合solverは4DOFと6DOFを明示選択します。4DOFは各反復でYawとXYZ並進を最小二乗推定します。6DOFはSVD剛体解です。小さい観測を大きなモデルへ対応させる経路では、不観測領域を観測境界へ引き寄せる影響を抑えるため逆向きnearest-neighbourを使い、保存変換は常にsource→targetへ統一します。

voxel代表と上限点数の代表は決定的な元index選択です。全元点との対応を残します。normal一致は絶対内積平均で記録し、存在しない場合はnull+reasonです。現在点と対応した一意点数も確認し、履歴点だけで現在存在を確定しません。

独立評価可能な大きさではsource点の決定的hold-outを使います。target表面は共有するため、`HELD_OUT_SOURCE_SHARED_TARGET` と記録します。これは幾何残差の検査であり、独立した物体同一性証拠ではありません。小入力はUNAVAILABLEです。fit/evaluationのsource indexは別保存し、複製していません。

有効で拘束された、profileの幾何条件を満たす解を先に選び、その中で固定utilityを比較します。異なる姿勢をクラスタ化し、同じ姿勢の反復収束を独立証拠として数えません。退化、未設定margin、近接scoreの別姿勢を保留します。UNCALIBRATEDの幾何結果にVALID_FOR_POSEが付いても、identityはCONFIRMEDにならずapplyできません。

## 割当

モデル、観測、空間tile、単独/複合の層を巡回して詳細評価順を決定します。単独候補を削除しません。中心距離は今回の未校正profileでは診断値としてのみ保存します。

主対応はモデル×観測につき最大1件。元画素または断片共有の候補は排他です。Hungarianは比較結果として残し、最終結果は未対応選択を含むbounded branch-and-boundです。固定utility、未対応cost、risk costを保存し、確率とは呼びません。

最良・次点の差が小さい場合、異なる採用を保留します。solver打切り、詳細未評価ペアがある場合は保守的に主対応を保留します。現版は未評価の競合範囲を細分化せず、run全体で確定を抑止するため、実際には無関係な対応も保留される場合があります。最適性を主張しません。

補助対応には確定主対応、整合変換、独立した現在画素、非重複モデル支持を要求します。複数部分候補の支持を重複加算しません。新規性の独立確認がない候補はprovisionalです。

## グラフと取引

`ylm.scene_graph.v1` は未知拡張属性、既存意味edge、全node、元モデル、最後の確認姿勢を保持します。古いcenter/extent形式をimportするとraw JSON全体、ID対応表、元nodeを保存し、geometryをUNVERIFIED_IMPORTED_GEOMETRYにします。

`ylm.graph_patch.v1` の各operationにはbefore/after、事前条件、証拠、reasonがあります。validate-patchは単なるCONFIRMED文字列ではなく、入力hash、profile適用範囲、全初期値の選択結果、現在支持、割当の再計算、操作の意味を確認します。poseは元model poseへの変換合成であることも検査します。

初版の自動pose更新・新規登録は条件が満たされた場合だけです。observed_center/extentは観測recordに保存します。削除、merge/split、unknownラベルでの登録ラベル上書きはありません。shape accumulationはOFFが既定です。

処理失敗、途中停止、出力容量不足では元graphを変更しません。途中の一時フォルダは調査用に残る場合があります。公開済み新versionはjournalで識別し、次のapplyがledger未更新を復旧します。訂正履歴も新transactionです。

## 実データの比較範囲

比較は4対象時刻×E0/S0・E1/S1の8条件です。各対象時刻を反対側時刻の候補モデルと比較します。正式な永続graph/modelが未提供なので、source側の30点以上の単独候補から点数順4件を明示的に診断モデルとして選びます。対象側の保存候補は全件読み込みます。選ばなかったsourceモデルはNOT_ENUMERATED一覧へ保存します。全モデル全候補の同一性探索を完了したという意味ではありません。

各runで最大32ペア、各モデル8件を詳細評価します。未評価・入力点不足・評価済みを区別します。E0/S0とE1/S1は同一下流profileです。候補の総数が同じでも、候補IDや画素集合の内容は同じとは限りません。旧330画素proxyはこの処理へ渡していません。

観測の窓時刻とsource_typeの意味は正式な確認がないため、値の配列を保持したうえでfreshness/current mappingをUNAVAILABLEにしています。frameもFRAME_UNVERIFIEDです。物体移動・不在・新規性・自動グラフ更新を確定しません。
