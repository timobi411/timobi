# YLM-X001 v0.6 候補形成・レジストレーション・シーングラフ更新 統合実装仕様書

版：v0.6-design-1／作成日：2026-10-21

実装先：`ylm_scene_graph_integrated_v06/`（新規フォルダ）

文書の性格：これから作成する統合版の実装指示。既存検証を反映するが、本書の機能が実装・精度検証済みという意味ではない。v0.6という名称は既存v0.5.1.2と区別するための新規実装版名とする。

## 1. 依頼と完成範囲

v0.5.1.2の単独／複合候補を入力し、ICP・部分一致評価・同一性／移動判定・候補競合を考慮した割当・シーングラフ更新案生成・確定差分の実反映までを実装する。診断だけで終わる配布物にはしない。実更新は後述のapplyコマンドとして実装・試験し、根拠が不足する実データは更新を保留する。

既存ソース・実験結果・既存グラフを上書きしない。旧処理は比較用に凍結し、新規モジュールとして修正を実装する。新版の出力へ旧時間統合・平面除去・クラスタリング・無条件遮蔽結合を重ねない。

### 初版必須

- v0.4系の既存出力とv0.5.1.2候補を読み込む契約・整合性検査。
- 凍結B0互換再現モードと、統合版用の登録・判定モード。
- 全初期値の結果・有効性・退化・曖昧性の監査。
- 断片共有候補の排他、永続物体への主対応と補助部分対応。
- 未評価・不一致・曖昧・競合・予算停止を区別した割当。
- 既存グラフの保持、更新案、検証、実反映、重複適用防止、訂正履歴。
- 登録モデルと現在観測・履歴観測の分離。
- 全工程の自己完結HTMLとJSON/JSONL、受入試験。

### 将来対応

raw bagからの上流一式再実装、学習による同一性モデル、自動キャリブレーション、一般的な変形・分裂・物理的結合の認識、意味クラス推定、関係エッジの新規推定、ROS常駐運用、Nav2/BT制御。

## 2. 使用資産と採用順位

| 資産 | 用途・扱い |
|---|---|
| `ylm_scene_graph_integrated_v0512_boundary_audit.zip` | 候補形成・保存・監査の主実装。入力／出力schemaとCLIは実ファイルで確認する |
| `ylm_v0512_experiment_audit_logs(1).zip` | 比較実験の監査資料。点群や正解データが全て含まれるとは仮定しない |
| `legacy_registration_sources.zip` | ICP・割当・接続版・旧更新処理の参照。複数版を名前だけで選ばない |
| `scene_graph_templates.zip` | 旧更新テンプレート3本。実質同一処理、実験名固定等をそのまま採用しない |
| `YLM_next_chat_handoff_20261021.zip` | 過去状態・参照コードの補足。最新v0.5.1.2の代わりに使わない |

ICP比較正本は`pipeline_phase2_downstream_frozen_20260929/baseline_icp_B0.py`。SHA-256：

```text
3007d53e5cf8398477ced49098e8d308c0140ed10fb2438956a02c0d7dbd2bda
```

接続版`ylm_v04_registration_bridge_v02/legacy/baseline_icp_B0.py`も同ハッシュ。`exp02/run_partial_icp_matching.py`（f1409235…）は別の6自由度ソルバであり、凍結B0の代用にしない。`pipeline_current/run_partial_icp_matching_v2.py`（9ce4d7ac…）も別版として差分を記録する。

割当参照は凍結`baseline_assignment_B0.py`（8b1c1150…）を主にし、current版との追加条件の差を文書化する。旧ゲートやscore値を校正済みルールとみなさない。

## 3. 確認済み結果と限界

以下はユーザーが共有した研究室PC実行ログ・整理資料に基づく。仕様書作成時に全実データを再実行したという意味ではない。

### 3.1 候補形成

v0.5.1.2について、共有整理では53テスト成功（共有側環境Python3.12）、基準4ケースの監査成功、追加16条件のログ・ソース照合を確認。研究室側のPython3.10で必要なテストを改めて実施し、環境差を記録する。

exp02 T1の旧M2近傍330画素に対する開発用代理指標：

| 条件 | 保存複合候補和集合 | 生成済み未保存 | 未生成 |
|---|---:|---:|---:|
| E0/S0 | 183 | 66 | 81 |
| E0/S1 | 244 | 5 | 81 |
| E1/S0 | 197 | 80 | 53 |
| E1/S1 | 266 | 11 | 53 |

候補1件の対象内最大は40画素のまま。266は複数候補の和集合であり、一物体を形成できた結果ではない。E0/S0を基準、E1/S1を比較用設定とし、正式既定への昇格は未決定。

330画素は旧M2の708点から3cm以内705点・重複除去611画素・構造除去281画素・残存330画素を得た代理領域。独立GTではなく、生成・選択・同一性判定に使用しない。

### 3.2 ICP再現・合成試験

凍結B0で旧exp02結果30ペアを再実行し、8数値項目×30=240比較はrtol/atol各1e-6内で一致。この照合は数値再現であり、同一性の正解保証ではない。validも比較コードで検査したが、ここで示す240件は数値項目の件数である。

| 合成試験 | B0回転誤差 | 登録中心誤差 |
|---|---:|---:|
| 恒等 | 約0° | 0 |
| 既知変換・全点 | 0.0107° | 0.037mm |
| 既知変換・部分観測 | 0.331° | 4.16mm |

別の6自由度実験版では同じ部分観測に回転誤差119.24°・中心誤差19.12cmが出た。初期化・閾値も異なるため差を自由度だけの効果と主張しない。

B0の空入力はnull、1点はvalid=falseかつRMSE=0。直線50点の既知並進[0.2,0.1,0]mに対し[0.14306,0.1,0]mを返し、約5.69cmの誤差でもscore約0.951・両側coverage1・valid=true。legacy_validだけで姿勢を確定できない。

### 3.3 割当・更新関数試験

- 正規化後にvalid・transformation・evaluation_statusが失われる。
- normalize_result→determine_stateだけを呼ぶと、高scoreのvalid=falseや未評価入力でもmovedを返す。Hungarian全体の誤採用まで確認した試験ではない。
- source_overlap/target_overlapが対応せずcoverage0となる。
- matched内unknown/heldはT0形状・位置を保持するが、matched外held/suppressedだけの既存ノードは出力されず0ノードとなる。
- movedはT1の部分観測中心・extent・PCDへ置換する。登録モデル姿勢・形状と観測の区別が必要。
- テンプレートのedgesは空。既存エッジ保持・関係更新を実装済みとみなさない。

研究室検証先：`organized_runs/baseline_B0_validation_gu8ojyvm/`、`legacy_icp_known_transform_2_08dbsv/`、`baseline_B0_degenerate_eikyiuyl/`、`assignment_graph_contract_audit_hamge9yv/`。実ファイルが実装環境へ未提供ならログに基づく確認と明記する。

## 4. アーキテクチャ

処理順：入力検査→上流出力読込→候補読込/明示的再生成→座標検査→ペア列挙→ICP→同一性/運動評価→競合付き割当→可視性評価→更新案→検証→apply。

候補形成・登録・割当・更新は独立モジュールとし、各段階の正本を保存する。runコマンドは更新案まで実行する。applyは検証済み更新案を新しいグラフ版へ実反映する。上流・候補生成は既存CLIのラッパーまたは契約読込で接続し、再実装による挙動変更を避ける。

凍結コードはvendor/に無変更で収録し、改修版は別モジュール。互換結果の項目欠損や推測変換は厳密に監査する。

## 5. 実行環境と配布

研究室の対象環境：Ubuntu22.04、Python3.10、ROS2 Humble。数値計算専用環境とraw bag用ROS環境は混在させず、保存済み出力だけの検証にROSを必須としない。

Open3Dを使う登録環境では、既知のNumPy1.26.4/SciPy1.11.4/Open3D0.19.0組合せを再現用候補とする。v0.5.1.2側のNumPy2系との同居可否を仮定せず、別Python子プロセスと版付きファイル契約で接続可能にする。requirementsは実際の検証環境で固定し、pip checkとimport/CLIを確認する。専用venvを用いシステム環境を書き換えない。

pyprojectの正しいメタデータと通常インストールを提供し、UNKNOWNパッケージや未定義extraを出さない。ワークディレクトリを変えてもimport・相対参照を解決できること。

## 6. 入力契約

統合入力JSONはschema_version=`ylm.integration.input.v1`。必須項目：run_id、dataset_role、units=m、observations、candidate_runs、graph_inputまたはbootstrap、frame_contract、profiles、resources。

各observation：observation_id、case/time/window/boundary、センサframe、基準時刻ns、窓始終、受信フレーム選択、pixels参照、上流manifest/hash、実測/履歴由来参照、構造マスク参照。既存run_idだけでは一意性を保証しない。

各candidate_run：元入力契約・resolved_config・候補JSONL・ID配列参照・v0.5.1.2ソースハッシュ・保存方式・探索停止状況。profile名だけでE0/S0等の値を推測せず実resolved値を読む。

graph_input：graph_id、version、content_sha256、graph_path、model asset参照。初期グラフなしの場合は第17章の明示bootstrapが必要。空グラフを暗黙生成し全候補を物体登録しない。

全相対参照は契約ファイルを基点とする。許可root外参照はallowlistで明示し、曖昧なcwd探索をしない。units・shape・dtype・時刻・fingerprint・画素集合・ラベル所属を照合する。source_point_idsが.npyパスなら配列として読み込み、文字列を整数へ変換しない。

欠落数値はnull＋reason。NaN/InfinityをJSON正本へ出力しない。版不明・不整合はINVALID_INPUTとし、採否判定へ進めない。

## 7. IDとデータの由来

観測ID、frame/sample ID、C-order画素ID、断片ID、候補ID、永続object_idを別型とする。pixel IDにはH/Wとobservation namespaceが必須。別時刻のC206等は同じ物体IDではない。

候補IDは元候補IDを保持し、統合内キーをobservation_id+candidate_idとする。永続IDはグラフ内一意で、再実行時に再発行しない。旧M番号はlegacy_source_idとして残すが永続IDへ無条件変換しない。

各候補の全画素集合を保持し、全点を再構成可能にする。表示間引き・ICP間引きは別の派生データ。voxel代表が複数由来を持つ場合は元画素への写像または決定的代表選択を保存する。現在点・履歴点・採用sample・時刻を追跡する。

## 8. 座標と変換契約

列ベクトルで`p_B = T_B_from_A @ p_A`、単位m、右手系。実装で行ベクトルを使う場合も契約は同じで変換テストを用意する。4×4行列・最下行・有限性・回転の直交性・det≈+1を検査し、許容値を数値整合用profileへ明記する。

frame_status：VERIFIED_FIXED、VERIFIED_TRANSFORM、FRAME_UNVERIFIED、INVALID。bag内固定の確認をbag間固定の確認へ流用しない。同じframe_id・原点[0,0,0]だけで姿勢一致としない。

元センサ観測を共通グラフ座標Gへ変換する`T_G_from_S0/T_G_from_S1`と、物体の登録変換`T_G1_from_G0_object`を別々に記録する。共通座標へそろえた後の物体ICP変換と、元センサ間で計算した変換を混用しない。

センサ整列には静的構造等の独立領域を用い、対象物体へフィットした変換を環境整列の証拠にしない。整列試行の残差・支持領域・leave-one-out安定性を保存する。未確認なら恒等変換の診断は可能だが、物体移動・元位置の不在・自動姿勢更新は確定しない。

移動量は登録モデルの基準点cに物体変換を適用した`T(c)-c`で計算する。行列並進t、観測重心差、登録基準点の変位を別欄にし、部分観測中心の変化をそのまま物体移動とみなさない。

## 9. 登録モデルと観測点群

永続物体はモデル座標系M、T_G_from_M、モデル形状version、基準点、形状品質、ラベル・由来、最終確認時刻を持つ。observed_center/extent/cloudは観測レコードへ保存し、モデルpose/shapeを直接置換しない。

登録は原則、既存モデル対現在候補で行う。T0候補対T1候補の比較も診断・初期登録支援として実装するが、確定物体IDがなければ直ちに永続ノード更新へ結び付けない。

前処理profileにvoxelサイズ・外れ値処理・点数上限・代表選択・normal推定条件・元点への写像を固定する。別候補サイズでscoreの意味が変わる点を監査し、点数の多さだけで採用しない。

現在存在の証拠は現在実測点を基本とする。履歴点だけの候補は幾何補助に使えても現在存在を確定しない。窓の期限切れ・代表時刻・観測鮮度の分母を引き継ぐ。

## 10. ペア列挙と予算

ペア正本にpair_id、model/candidate keys、列挙経路、簡易ゲート値・閾値、優先順位、詳細評価状態を保存する。中心距離・サイズのゲートは未校正値なら診断用と明記し、未確認frameで距離ゲートによる物体不在を主張しない。

計算可能なペア集合を最初に確定し、モデル/観測領域ごとの公平なround-robin等の決定的スケジュールを用いる。同じ物体候補の類似派生で予算を独占しない。単独候補を全削除しない。

pair_status：NOT_ENUMERATED、QUEUED、EXCLUDED_BY_PROFILE、NOT_EVALUATED_BUDGET、INVALID_INPUT、EVALUATED。除外・未評価はNOT_SAME_OBJECTへ変換しない。

既定の開発用資源profile：worker1、数値thread1、RSS8192MiB、wall1800秒、詳細ICPペア32、各ペア初期値上限32、出力合計2GiB。これらは安全な運用の設計値で精度較正値ではない。入力・候補生成の既存予算は別に保存し、全体上限との関係を明記する。予算を使い切った物体の新規/不在確定は抑止し、未評価の競合が残ることを記録する。

## 11. レジストレーション

### 11.1 B0互換経路

凍結コードと既存パラメータを変更せず別プロセスで実行し、旧30ペア再現を保つ。互換出力は診断正本であり、そのvalidを統合版のCONFIRMEDへ直接変換しない。

B0比較値：voxel0.01m、coarse0.35m、fine0.08m、反復150、Yaw初期値[-30,-20,-10,0,10,20,30]。これらは旧比較設定でセンサ精度の保証ではない。

### 11.2 統合用登録経路

solver_profileに4DOFまたは6DOFを必須指定する。4DOFは重力整合と運動仮定を検証した場合に使用。未確認時は診断のみ。6DOFも初版の明示オプションとして用意し、単なるYaw初期値列を4DOFと呼ばない。

初期値の経路：既存モデルposeによる無移動仮説、観測中心への位置合わせ、明示Yaw候補、必要時に設定された追加回転。初期値数・生成則・変換方向を保存する。約20cmという実験意図を正解変換として強制しない。

各初期値の変換・収束理由・対応点数・対応元/先の一意点数・fitness・RMSE・双方向coverage・分母・normal一致・観測領域・退化指標・実行時間を保存する。RMSE0かつ対応0を完全一致と解釈しない。

有効解を先に分離し、その集合内で固定profileのscoreと決定的tie-breakで代表を選ぶ。最高scoreの無効解が有効解を隠すことを防ぐ。legacy_scoreとintegration_rankを分離し、新scoreを旧scoreと同一尺度と主張しない。

同一の姿勢へ収束した初期値を独立証拠として数えない。変換の差で解クラスタを作り、異なる姿勢の近いscoreが残る場合はAMBIGUOUS。解クラスタ化閾値・marginはdecision_profileに必須とし、未設定なら姿勢確定を保留する。

### 11.3 退化・部分観測

異なる点数・点の広がり・共分散固有値・対応点配置・拘束自由度を診断する。1点や直線を単に点数だけで有効姿勢にしない。直線だけで一律別物体とはしないが、拘束不足の方向を持つ変換は主姿勢更新へ使わない。

独立評価可能な点が十分ある場合はfit/evaluationを分離し、分割元IDを保存する。困難な小断片は独立支持UNAVAILABLEとし、試験点を学習/fit点から複製して独立と称さない。

高い片方向coverageは部分対応を支持し得るが、物体全体の同一性や姿勢の一意性とは別。登録モデルのどの領域を説明するか、異なるモデルでも同じ局所部分へ一致しないかを比較する。対称形状・複数同形物体は曖昧解を残す。

## 12. 判定profileと状態

旧閾値はlegacy_reference.jsonへ保存する。新しいdecision_profileはprofile_id、version、hash、適用センサ/距離/点数/自由度、出典、validation_status、validation_recordを必須とする。

decision_profileに、最低対応点数/一意点数/空間広がり、許容残差、各方向coverageと分母、最大変位/回転、退化条件、解間margin、競合margin、観測鮮度、可視性支持条件を定義する。数値が未決定の項目はnullとし、当該確定操作をブロックする。都合のよいテスト結果から暗黙設定しない。

UNCALIBRATED profileでは幾何仮説と更新案を作れるが、自動的な同一性CONFIRMED/永続グラフ更新は不可。VALIDATED profileは適用範囲と検証記録を持つものに限る。合成テスト用profileはSYNTHETIC_ONLYで、実データへ転用しない。人が独立に確認した対応を使う場合は明示的adjudication記録を別入力とし、proxy領域を確認根拠にしない。

三軸状態：

| 軸 | 状態 |
|---|---|
| identity | CONFIRMED / AMBIGUOUS / UNRESOLVED / REJECTED_UNDER_PROFILE |
| motion | STATIC / MOVED / UNKNOWN_MOTION |
| observation | CURRENT_OBSERVED / PARTIAL / HISTORY_ONLY / OCCLUSION_SUPPORTED / OUT_OF_VIEW / UNKNOWN / ABSENCE_SUPPORTED_AT_OLD_POSE |

処理状態・入力状態・legacy_validは別欄。REJECTED_UNDER_PROFILEも物理的別物体の証明ではない。移動判定はidentity確定かつframe検証済み・姿勢評価可能な場合だけ行う。STATICでも現在観測は記録し、UNKNOWN_MOTIONをSTATICへ丸めない。

## 13. 割当と候補競合

候補ペアにvalid・全変換・evaluation_status・frame_status・provenanceを保持する。旧coverage名は明示マッピング表で変換し、複数別名が矛盾する場合はINVALID_INPUT。欠測coverageを0と同一視しない。空ペア集合・全不成立を正常な保留/未対応結果として処理する。

初版の主対応は「永続物体1件につき同じ観測時刻で最大1候補」。候補が異なる物体主対応へ重複採用されないこと。同じobservation内でsource_point_ids/fragment集合を共有する候補は排他とし、必要なら元画素集合でも照合する。

単純なHungarianだけでは断片共有制約を表せない。Hungarianは候補ペアを固定した比較基準として実装し、最終採用は明示した競合制約付き選択とする。初版は決定的なbounded branch-and-bound等で実装可能とし、依存solverを使う場合は版・制約・終了状態を保存する。

目的関数はsum(pair_utility)から未対応費用・明示したリスク費用を差し引く形とし、各項目の式・重み・範囲をprofileで固定する。raw ICP scoreを無校正な確率と解釈しない。未対応の選択肢を必ず含め、負の効用や全無効を無理に割り当てない。

探索打切りでは最適性未証明を保存し、競合に影響され得る採用を確定更新に使わない。最良・次点構成のscore差と異なる物体ID/姿勢を記録し、margin不足なら競合範囲を保留する。候補IDの辞書順は出力決定性に使えても、同一性の曖昧さを解消する根拠にはしない。

### 主対応と補助対応

主対応はpose更新可能な登録。補助対応は同じ物体への部分観測として保持し、主対応と整合する変換・モデル部分・非競合・独立した現在観測を検査する。複数補助候補の同じ点を重複加算しない。

断片を共有しない候補でも、同じモデル部分・同じ空間領域・競合する物体解釈を説明する場合は重複登録リスクを付ける。主対応の裏付けや独立した新規性判断がなければ、別の永続物体IDを発行しない。分離候補を強制結合する実装も不可。

## 14. 可視性と不在

同一画素が同じ光線方向を表すことを観測間で仮定しない。入力ray calibration、センサpose、投影関数、range定義、視野、鮮度を検証する。直接観測rayと近傍補間・推定rayは別状態とし、未検証補間をfree-space証拠にしない。

過去モデルを現在センサへ投影し、現在実測との前後関係を検査する。支持画素/一意ray/一意frame数、対象投影可能数、有効比較数、欠測数、投影不能数、時刻範囲を保存する。母数が不足する場合はUNKNOWN。

遮蔽支持、視野外、無応答、投影不能、時間統合履歴しかない状態を分ける。元位置の不在支持は「その位置での占有を支持しない観測」であり、物体消滅の証明ではない。消滅・削除へ自動変換しない。

初版は投影根拠がないデータでも動作するが可視性UNKNOWNとする。未検証投影を仮にverifiedへ変更して工程を通さない。

## 15. シーングラフ契約

schema_version=`ylm.scene_graph.v1`。graph_id/version/hash、frame、units、timestamp、nodes、edges、history参照を持つ。

node必須：object_id、lifecycle、identity/motion/observation状態、model asset/version、T_G_from_M、last_confirmed_pose/time、observations、semantic labelと出典、geometry status、更新由来。未知状態でも登録モデルや最後の確認姿勢を保持する。

edge必須：edge_id、source/target object IDs、relation_type、evidence、status、valid_time、由来。初版は既存意味エッジを保持し、新規関係推定は行わない。移動で妥当性が変わる空間エッジはSTALE/UNKNOWNへ遷移させ、現行と保証しない。既存属性・未知拡張フィールドを削除しない。

旧グラフのimportはID対応表を作り、元JSON全体を保全する。PCDの重心を確定物体poseとみなせるかをgeometry statusへ記録し、由来不明のモデルで確定更新しない。

## 16. 更新規則

更新案は既存グラフの深いコピーに確定差分だけ適用して生成する。観測リストに入っていないノードを走査漏れで消さない。

| 条件 | pose/model | 観測・状態 | 実反映 |
|---|---|---|---|
| identity確定＋姿勢有効＋frame検証済み＋MOVED | object ID維持、変換をモデルposeへ合成 | 新観測と変換根拠追加 | profile/競合/取引検証を満たせば可 |
| identity確定＋STATIC | 最終確認poseを維持、観測poseは別記録 | 現在観測追加 | 許可された属性のみ |
| identity確定＋部分観測だが姿勢不明 | pose/全体形状を維持 | PARTIAL、補助観測追加 | pose更新不可 |
| AMBIGUOUS / UNRESOLVED / 未評価 | 最終確認pose/modelを維持 | 保留理由・候補参照追加 | 確定姿勢変更不可 |
| 遮蔽／視野外／無応答 | 全ノード・モデルを保持 | 観測状態のみ更新 | 削除・消滅扱い不可 |
| 元位置の不在支持 | モデルと最終確認poseを保持 | ABSENCE_SUPPORTED_AT_OLD_POSE | 探索対象として保持 |
| HISTORY_ONLY | 最後の確認状態を保持 | 履歴由来を記録 | 現在存在の確定不可 |
| 新規性未確認 | 永続ノードを作らない | 仮観測poolへ保存 | 不可 |

部分観測の重心・AABB/OBBを登録モデルの全体center/extentへ上書きしない。形状蓄積は初版既定OFF。明示ONの場合はidentity/pose/鮮度/現在実測・整列誤差・重複由来を検査し、新モデルversionを作る。失敗時は旧モデルへ戻れること。

ラベルは旧登録値を維持し、候補段階のunknownで上書きしない。明示的な意味ラベル観測の融合規則は別profileがある場合だけ適用する。初版では物体の削除、分裂、合体を自動実行しない。

## 17. 初期登録・新規登録

既存グラフ入力を基本とする。空グラフからのbootstrapは独立コマンドとし、非競合な承認済み観測集合・frame根拠・登録モデル品質を入力する。全単独/複合候補の一括登録は禁止。

新規観測はprovisional_observation_idで保持する。永続ID発行には、既存物体との評価が必要範囲で完了、曖昧競合なし、現在実測支持、frame検証、登録可能形状、VALIDATED新規性profileまたは明示adjudicationを要する。探索予算で未評価の既存物体が残る場合、未対応を新規と断定しない。

観測の異なる部分だけを理由に別物体を作らない。新規性の追加証拠が足りなければ仮観測のまま保持する。provisionalと永続node数を分けて報告する。

## 18. 更新案・実反映・再実行

更新案schema=`ylm.graph_patch.v1`：transaction_id、input graph ID/version/hash、input fingerprints、profile/source hashes、operations、held_operations、preconditions、evidence refs、expected postconditions。

operationはADD_NODE、UPDATE_POSE、APPEND_OBSERVATION、UPDATE_STATUS、VERSION_MODEL、MARK_EDGE_STALEなどに限定し、各項目の変更前/後を記録する。初版はDELETE_NODE/物体merge/splitを許可しない。

applyは入力グラフhash/versionと操作の事前条件を再検査する。別の更新が適用済みならSTALE_BASEとして停止し、古い更新案を上書き適用しない。全操作を一時出力で検証後、新しいgraph versionを原子的に確定する。旧graph assetは保持する。

同じtransaction IDは二度適用しない。観測追加もobservation/candidate/evidenceキーで冪等にする。現在グラフへのpointerを変更する運用は明示graph storeだけで行い、fsync/atomic rename/lockまたは同等の一貫性制御を実装する。単純なshutil.rmtreeで出力先を消さない。

訂正は過去版を消すのではなく、新しい訂正transactionまたは旧版を基点とした新versionとして記録する。失敗・途中停止で元グラフが変わらないことを故障注入試験で確認する。

runの成功、更新案の妥当性、apply実行成功、物理的正解を別項目にする。実データでHELDが多くてもprocessing failureと混同しない。

## 19. 出力契約

```text
run/
  run_manifest.json
  resolved_config.json
  source_inventory.json
  input_inventory.json
  frames/transforms.json
  candidates/index.jsonl
  registration/pair_pipeline.jsonl
  registration/pairs.jsonl
  registration/hypotheses.jsonl
  registration/summary.json
  assignment/solutions.jsonl
  assignment/assignment.json
  visibility/evidence.jsonl
  observations/records.jsonl
  provisional/observations.jsonl
  scene_graph_proposal/patch.json
  scene_graph_proposal/preview_graph.json
  evaluation/status.json
  verification.json
  index.html
```

登録ペア正本は、pair_id、model/candidate IDs、evaluation_status、legacy_valid、integration_validity、identity/motion、全初期値参照、選択理由、source-to-target変換とframe、metric定義と分母、input/source/profile hashesを持つ。

assignment.jsonは主対応・補助対応・競合・保留・未評価・未対応を分け、未対応理由を列挙する。未対応配列だけからappeared/disappearedを生成しない。

apply出力はgraph version、transaction journal、diff、検証結果、入力版hash。候補点群・モデル・各派生配列はmanifestから到達可能とし、欠落参照を検査する。

## 20. CLI

以下の意味を満たすCLIを提供する。名称はこの版で固定しREADMEに実行可能な例を付ける。

```bash
python -m ylm06 inspect --config integration.json
python -m ylm06 run --config integration.json --out NEW_RUN
python -m ylm06 verify --run NEW_RUN
python -m ylm06 evaluate --run NEW_RUN --evaluation-config evaluation_only.json
python -m ylm06 bootstrap --config bootstrap.json --out NEW_GRAPH
python -m ylm06 validate-patch --patch PATCH --graph GRAPH
python -m ylm06 apply --patch PATCH --graph GRAPH --out NEW_GRAPH_VERSION
```

runは上流/候補参照のまま動くモードを必須とし、v0.5.1.2を再生成する場合だけ明示する。runだけでapplyしない。run出力既存時は停止し、明示resumeはhash照合して完了ステージだけ再利用する。新profileなのに旧stageを再利用しない。

終了コード：0=要求した工程の出力完了、2=予算/入力不足等で部分完了、1=不正入力/実装エラー。identity UNKNOWNや更新HELDだけを終了コード1にしない。applyは事前条件不成立時に非0、グラフ無変更を保証する。

## 21. 状態遷移と段階別検証

| 段階 | 進める条件 | 不成立時 |
|---|---|---|
| 入力→候補 | ID集合・hash・shape一致 | INVALID_INPUT、登録しない |
| 候補→ICP | ペア列挙済み・最低入力条件・予算あり | 入力不足または未評価 |
| ICP→同一性評価 | 有限な変換・対応支持・適用profile | 幾何保留/棄却 |
| 評価→主対応 | 非退化・曖昧性/競合解消・frame根拠 | AMBIGUOUS/UNRESOLVED |
| 対応→更新案 | 既存モデルと操作の意味が定義済み | held operation |
| 更新案→apply | profile・証拠・版・不変条件を検証 | グラフ無変更 |

「候補が生成された」から直接CONFIRMEDへ遷移しない。初期値最適化の成功から同一性へも直接遷移しない。CONFIRMEDはprofile適用範囲内のシステム判断で、evaluation側の物理的正解とは別に記録する。

## 22. 必須受入試験

### A. 契約・再現

1. 凍結B0のハッシュと旧30ペア・240数値項目の再現。元入力hashを記録し、数値照合許容値と精度閾値を区別。
2. v0.5.1.2を再生成しない読込経路で、候補集合・点ID・由来・上流マスクが不変。
3. valid=false、NOT_EVALUATED、欠損transform、coverage別名矛盾、NaN/Infを含む入力は確定操作へ進まない。
4.別cwd、パスに空白、欠落asset、単位違い、H/W違い、重複ID、別入力namespace混入を検出。

### B. 登録・座標

5. 恒等・既知Yaw/並進・部分切出し・密度差・異なる点数・逆変換方向を検査。正解変換を入力に使う試験と観測中心のみの試験を区別。
6. 空・1点・全同一点・直線・平面・対称形状を検査。直線誤変換を高score/legacy_validだけで主姿勢更新しない。
7. 無対応でRMSE0、最良score無効/別の有効解、異なる初期値で同程度scoreの別姿勢を検査。
8. センサだけ移動・物体だけ移動・両方移動を既知変換で検査。frame未検証なら運動確定を保留。

合成試験の数値基準はfixture専用として固定する。今回と同じ900点非対称形状について、恒等は対応点誤差最大1e-6m以内、既知変換全点は回転誤差0.1°以内・基準点誤差1mm以内、65%切出しは回転誤差1°以内・基準点誤差1cm以内を回帰目標とする。これは当該fixtureの検査基準であり、実センサの精度仕様・実環境の同一性採用閾値ではない。ソルバが許容誤差を超える場合は失敗を明示し、閾値を後から緩めて通さない。直線fixtureは正解に近い解を得ても姿勢拘束の評価を必須とし、今回の誤解へ更新許可を出さない。

### C. 割当

9. 全不成立・全未評価・空候補でも架空の対応を生成しない。
10. 同じ断片を共有する候補を別物体へ同時採用しない。断片非共有の同一モデル部分候補でも重複永続IDを作らない。
11. 同形物体2件、同score、対称解、物体ごとに片方しか詳細ICPを実行できない場合を保留できる。
12. 非競合な主対応＋補助部分対応、補助同士の重複支持、候補サイズでscoreが有利になる例を検査。
13. 競合solver予算終了時に最適性未証明を記録し、未解決競合を確定適用しない。

### D. 可視性・グラフ

14. 遮蔽・視野外・無応答・投影不能・HISTORY_ONLYで既存nodeと最終確認poseを保持。
15. matched外held/suppressedのnodeも残る。未知属性・既存意味edgeも保持する。
16. 移動時はモデルposeへ変換を適用し、部分観測extent/中心を全体モデルへ上書きしない。
17. 再観測でobject IDを維持、元位置不在だけで削除しない。新規性未確定ならprovisionalに留める。
18. pose変更で空間edgeの鮮度を更新し、既存edgeを空配列へ置換しない。

### E. 実反映・運用

19. SYNTHETIC_ONLYの検証済みfixtureで、run→patch検証→apply→新graph版生成を実行し期待JSONと一致させる。実反映機能を未実装にしない。
20. 同transaction再適用・同観測再追加・古いgraph版へapplyを防ぐ。
21. apply途中の例外・容量不足・プロセス停止で元graph無変更。訂正transactionを検証。
22. resumeの入力/profile/source不一致、予算停止、無効profileを検査。

ここで挙げた新受入試験は、今回の旧関数診断で全て実施済みではない。旧関数で問題が確認された項目は、新統合版で期待動作へ修正して試験する。

## 23. 評価と報告

processing_complete、integrity_passed、registration_evaluation、identity_accuracy、motion_accuracy、update_accuracy、graph_modifiedを独立に記録する。全テストPASSだけで実環境精度を確定しない。

評価専用に旧PCD代理領域や人手GTを別設定で読む。生成・選択・登録・割当・更新判定へのリークをテストする。GTのsame/different/unclearと判断根拠・作成者・時刻を保存する。unclearを正/負へ変換しない。

実環境4ケースの比較は、E0/S0基準とE1/S1比較を混ぜず同じ下流profileで行う。元入力のframe根拠が不足するケースは、診断のみ・移動確定なし・apply対象なしを正しく報告する。

候補生成→保存→ペア列挙→詳細ICP→有効解→競合解消→更新案→applyの各段階で件数・ID・除外/保留理由を追跡する。正解対応がどこで失われたかを区別し、下流失敗をすべてクラスタリングの責任にしない。

計測：wall/RSS/出力量、モデル別評価数、未評価数、退化数、曖昧数、競合数、主/補助対応数、仮観測/新規永続数、更新/保持node数、変更edge数。更新しなかったnodeも保持理由を集計する。

## 24. 実装手順と納品条件

1. 資産inventory・版/入出力契約・環境を確定し、B0互換再現を先に通す。
2. v0.5.1.2読込と出自・座標契約を実装する。
3. 全初期値登録・退化/曖昧評価・null安全な正規化を実装する。
4. 競合付き主/補助割当を実装し、全未評価を保留する。
5. 既存グラフ保持、観測分離、patch生成、validate/apply/冪等性を実装する。
6. 合成の全工程と故障注入試験を通す。
7. 4実データの診断と比較を行い、確定可能な範囲だけ実更新を検証する。

納品：新規ソースZIP、README日本語、pyproject/固定依存、JSON Schema、profile例（旧互換/未校正診断/合成受入）、小容量fixture、全テスト、実行・比較・受入レポート、自己完結HTML、SHA-256一覧、旧資産との差分表、既知の限界。

READMEはUbuntuでの展開→環境準備→テスト→入力確認→生成→検証→表示→更新案確認→applyの順で、コピー可能なコマンドを載せる。cwd失敗時に別プロジェクトで処理を続けない。大きいbag・cloudはソースZIPへ詰め込まず、必要資料と参照先を明記する。

完成の受入は「全機能の実装と適用条件に従った動作」であり、全実データの更新確定を強制しない。未確認profileやframeを勝手にverifiedへして完成扱いにしない。一方、実更新コード・合成apply試験を省いて更新案だけを完成版として納品しない。

## 25. 正本レコードの最低形式

登録結果の構造例（値は形式説明用で、実験結果ではない）：

```json
{
  "schema_version": "ylm.registration.pair.v1",
  "pair_id": "pair:001",
  "source_model": {"object_id": "obj:001", "model_version": 1},
  "target_candidate": {"observation_id": "obs:t1", "candidate_id": "H-example"},
  "evaluation_status": "EVALUATED",
  "legacy_valid": true,
  "integration_validity": "HELD_DEGENERATE",
  "identity_status": "UNRESOLVED",
  "motion_status": "UNKNOWN_MOTION",
  "frame_status": "VERIFIED_TRANSFORM",
  "selected_hypothesis_id": "icp:001",
  "transform_ref": "frames/objects/pair_001.json",
  "metric_denominators": {"source_points": 50, "target_points": 50},
  "reasons": ["POSE_CONSTRAINT_INSUFFICIENT"],
  "decision_profile_id": "diagnostic:001"
}
```

ここでintegration_validityはVALID_FOR_POSE、VALID_FOR_PARTIAL_OBSERVATION、HELD_DEGENERATE、HELD_AMBIGUOUS、INVALID_INPUT、REJECTED_BY_PROFILE、NOT_EVALUATED等の列挙型とする。数値計算が終了したこととpose採用可能を分離する。参照先transformにはfrom_frame/to_frame、4×4matrix、時間、計算経路、sensor/objectの種別を必須とする。

graph nodeの最小構造はobject_id、lifecycle、states、model、pose、last_confirmed、observation_refs、attributes、provenance。poseにはframe_idとmatrixを持たせる。center/extentだけの旧nodeはimport時にraw_legacy_nodeを保持し、モデルposeの定義が未確認ならpose_status=UNVERIFIED_IMPORTED_GEOMETRYとする。

更新案の操作はoperation_id、type、object_id、preconditions、before、after、evidence_refs、decision_status、reason_codesを持つ。操作の順序は決定的にし、同一transaction内の矛盾poseや重複IDをvalidate-patchで拒否する。CONFIRMEDの文字列だけを信用せず、profile・frame・評価完了・競合解消・証拠参照の条件を再検査する。

JSON Schemaはこれらの説明を実際の必須/列挙/型/参照検査へ落とし込み、サンプルJSONだけで契約実装済みとしない。

## 26. 実装開始時に確認する未確定項目

| 項目 | 初版での扱い |
|---|---|
| exp01/exp02のbag間センサ姿勢・整列根拠 | 実記録を確認。未提供ならFRAME_UNVERIFIEDで診断を継続 |
| 独立した同一物体GT | 未提供はNOT_EVALUATED。旧20cm成功記述を正解とみなさない |
| 床ID8/9の物理的妥当性 | 上流マスクは維持。真の床/家具未確定を制約へ記録 |
| 実運用の採用閾値・曖昧margin | 未較正なら自動確定を保留。合成試験専用profileと分離 |
| 既存graph/model assetの正式入力 | 明示提供を要求する契約を実装。なしの場合はbootstrapを別実行 |
| 旧SGのエッジ意味・拡張属性 | 消さず保全。意味不明な空間edgeは鮮度不明を明記 |

本書作成後も今回の実験コードの改変・統合・実グラフ更新は未実施。次の作業は本書と提供資産に沿った新統合版の実装である。
