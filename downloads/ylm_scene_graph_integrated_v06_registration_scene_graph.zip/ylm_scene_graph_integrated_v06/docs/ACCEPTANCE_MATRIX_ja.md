# 仕様第22章との対応

各試験の実行ログは `validation/tests_v06.log`、B0比較は `validation/B0_replay/comparison.json`。個別テスト数と仕様の項目数は異なります。

| 仕様 | 実装・確認先 |
|---|---|
| A1 正本B0/30ペア | legacy.py、B0_replay、240数値・valid・pair集合照合 |
| A2 保存候補・由来不変 | contracts.pyのfingerprint/全断片和集合検査、8実runのverify、source_consistency.json |
| A3 無効/未評価/欠損/coverage矛盾/非有限 | test_legacy_contract、test_valid_first_and_ambiguity、test_no_correspondences_not_perfect、test_nan_json |
| A4 cwd/空白/asset/units/HW/ID/namespace | ContractTests、空白を含むTransactionTestsの作業場所、installed_other_cwd.log |
| B5 変換・部分・密度・逆向き | RegistrationTests、registration_regression.json。GTを初期値に渡さない |
| B6 退化・対称 | test_degenerate、test_symmetric_shape_distinct_poses_remain_ambiguous |
| B7 無対応/最高score無効/別姿勢同score | test_no_correspondences_not_perfect、test_valid_first_and_ambiguity |
| B8 センサ/物体/両方移動 | test_sensor_movement_separated_from_object、test_known_full_center_initialization、test_sensor_and_object_movement、test_frame_and_profile_hold |
| C9 全無効/未評価/空 | test_empty_and_invalid、test_budget_and_unexamined_hold |
| C10 断片共有/重複永続ID | test_shared_fragments_exclusive、test_auxiliary_disjoint_support_and_no_duplicate_id、graph重複ID検査 |
| C11 同形/同score/予算不足 | test_equal_objects_held、test_symmetric_shape_distinct_poses_remain_ambiguous、test_pair_budget_prevents_confirmation |
| C12 主＋補助/支持重複/点数差 | test_auxiliary_disjoint_support_and_no_duplicate_id、test_density_and_inverse、coverage分母・固定utility監査 |
| C13 割当最適性未証明 | test_budget_and_unexamined_hold |
| D14 遮蔽/視野外/無応答/投影不能/履歴 | VisibilityTests、未知frameでは更新しない検査、graph全node保持試験 |
| D15 held/suppressed/未知属性/意味edge | test_pipeline_patch_apply_preserves_graph、test_legacy_import_keeps_unmatched_attributes_and_edges |
| D16 pose合成/観測形状分離 | test_pipeline_patch_apply_preserves_graph、expected_graph_projection.json |
| D17 ID維持/不在削除なし/未確認新規 | 上記graph保持、test_occlusion_absence_and_missing、provisional出力、test_adjudicated_novelty_adds_one_node |
| D18 空間edge鮮度 | test_pipeline_patch_apply_preserves_graph |
| E19 実apply | examples/run_acceptance.py、synthetic/acceptance.json、graph_v2/graph.json |
| E20 冪等性/stale | test_pipeline_patch_apply_preserves_graph、test_stale_base_and_conflicting_pose、APPEND_OBSERVATION重複キー検査 |
| E21 例外/容量/停止/訂正 | test_failures_do_not_change_base、test_process_stop_does_not_change_base、test_crash_after_publication_recovered_no_double_apply、test_correction_transaction_preserves_history |
| E22 resume/profile/source/予算 | test_resume_fingerprints、test_resume_input_and_source_mismatch、test_output_budget_stops_without_graph_change、test_profile_cannot_leak_synthetic_scope |

追加で、評価専用GT/proxyを渡しても登録・割当・patch正本が変わらないことを `test_posthoc_unclear_and_proxy_cannot_change_decisions` で確認しています。shape accumulationの明示ON、現在点による新model version、旧asset保持を試験しています。

この表は実装箇所・試験の対応であり、実環境における同一性・移動精度の受入を意味しません。正式graph、frame根拠、独立GT、採用profileがない実データは保留のままです。
