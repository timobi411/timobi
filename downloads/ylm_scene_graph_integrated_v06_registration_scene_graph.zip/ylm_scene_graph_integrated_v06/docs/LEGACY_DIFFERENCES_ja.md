# 旧資産との違い

添付 `integration_precheck_results.zip` は40ファイルのsize/SHA-256とZIP全体のSHA-256/CRCを照合しました。元ファイルは変更していません。収集manifestは `precheck_manifest.json` にあります。

| 資産 | 確認・採用 |
|---|---|
| 凍結B0 ICP | `3007d53e…d2bda`。無改変でvendor収録、別プロセスの比較正本 |
| bridge_v02のB0 | 同じハッシュの正本と一致。別の推定器で代用しない |
| current ICP v2 | `9ce4d7ac…ec98c`。別版として保存。数値定数が同じでも同一コードとは扱わない |
| 実験6DOF ICP | `f1409235…0d020`。voxel=.01、coarse=.25、fine=.08、反復120、Yaw step30。B0比較には使わない |
| 凍結assignment B0 | `8b1c1150…6fe14`。旧ゲート・移動条件・identity再判定・遮蔽補助を参照し、校正済みとはみなさない |
| current assignment | 今回のZIPに独立したcurrent assignmentソースなし。追加条件を推測して再現したとは主張しない |
| 旧更新template3本 | 2本のhashは同一、残る1本は異なる。実験名exp07固定、移動閾値.3m等の旧定数を保存。新版に固定実験名を持ち込まない |
| current generic graph writer | `a782d1d0…c3d`。参照保存。新版の実更新には使わない |

全ハッシュ・抽出可能な旧定数は `profiles/legacy_reference.json`。旧30ペアの再現は採用精度ではなく、同じ入力・実装・パラメータの数値再現です。新utilityを旧scoreと同じ尺度には扱いません。

| 旧関数の課題 | 新版 |
|---|---|
| normalizeでvalid/transform/status脱落 | 元recordを保持し、coverage別名矛盾をエラーにする |
| 高scoreの無効/未評価入力からmoved | 処理状態、legacy_valid、統合有効性、三軸状態を分離 |
| 最高score無効解で有効解を隠す | profileに適用可能な有効・拘束解を先に選ぶ |
| 直線でvalid=true、高coverage | unique点、広がり、共分散・対応分布、pose拘束を検査 |
| Hungarianで断片共有を表せない | 明示画素/断片排他、主・補助対応、次点・最適性の監査 |
| matched外heldノードの消失 | 既存graphのdeep copyから許可操作のみ反映 |
| movedの観測中心・extentで置換 | 登録model poseへ変換を合成。観測形状は別record |
| edgesを空にする | 意味edge・未知属性を保持、空間関係の鮮度を更新 |
| 未対応から新規/消滅 | 未評価・曖昧・競合・budgetを区別。新規性未確認はprovisional |
| 更新履歴・取引未実装 | base版/hash、lock、atomic publication、journal、重複防止、訂正transaction |

旧ソースを改変して混ぜるのではなく、`ylm06/` の独立モジュールに実装しました。`ylm051/` は前回版とファイル単位で一致する凍結参照です。
