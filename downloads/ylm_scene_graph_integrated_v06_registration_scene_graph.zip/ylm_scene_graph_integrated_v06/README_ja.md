# YLM v0.6 候補形成・登録・シーングラフ更新

v0.5.1.2の保存候補を読み、登録、部分一致の監査、競合付き割当、可視性、グラフ更新案、検証、実反映を行う新規実装です。旧出力を上書きしません。仕様原文は `docs/specification.md`、結果は `validation/REPORT_ja.md` を参照してください。

配布は本体とexp01/exp02詳細結果の3 ZIPです。本体にはソース・合成全工程・B0・8条件の比較レポートを含みます。実データの完全なrunとHTMLは `ylm_v06_exp01_registration_results.zip` と `ylm_v06_exp02_registration_results.zip` に収録し、本体と同じ場所へ展開すると `validation/real/` に追加されます。

**実データの同一性・移動・更新精度は未評価です。** 添付資料には正式な永続グラフ、bag間座標の独立検証、実運用の校正済み判定profileがないため、実データの比較は診断として実行します。合成fixtureでは実際に新graph版を生成し、期待する姿勢・モデル保持・エッジ状態・再適用防止を試験します。

## 1. Ubuntuで展開・環境準備

Ubuntu 22.04 / Python 3.10を対象に検証しています。保存済み出力の処理にはROSを使いません。raw bagの処理は既存のROS 2 Humble側環境を使用してください。

```bash
unzip ylm_scene_graph_integrated_v06_registration_scene_graph.zip
cd ylm_scene_graph_integrated_v06 || exit 1
sudo apt-get update
sudo apt-get install -y python3.10-venv libgl1 libgomp1 libx11-6 libglib2.0-0 libxext6 libxrender1
python3.10 -m venv .venv-registration
.venv-registration/bin/python -m pip install -r requirements-registration.lock
.venv-registration/bin/python -m pip install --no-deps .
.venv-registration/bin/python -m pip check
.venv-registration/bin/python -m ylm06 --help
```

通常インストールのpackage名は `ylm-scene-graph-integration`、版は `0.6.0` です。`UNKNOWN` ではありません。Open3Dを使わない統合用4DOF/6DOF経路だけなら `requirements.txt` と通常インストールで利用できます。旧B0にはOpen3D 0.19.0が必要です。検証した登録環境はNumPy 1.26.4 / SciPy 1.11.4。全依存の固定値をlockに収録しています。

候補形成用NumPy 2系環境は別venvのまま維持してください。統合入力は版付きJSON/NPZ/NPYで受け渡します。候補を再生成する場合は、元のv0.5.1.2フォルダで、その環境の `python -m ylm051 generate` を明示的に実行します。`ylm06 run` は既存候補の読込専用で、再クラスタリングしません。収録 `ylm051/` は無改変の参照・選択比較用ソースであり、pipでは `ylm06` のみをインストールします。

## 2. テストと小容量fixture

すべて新しい出力先を指定してください。既存フォルダを削除して続行する処理はありません。

```bash
.venv-registration/bin/python -m unittest discover -s tests -v
.venv-registration/bin/python -m examples.make_fixture --out "$PWD/work/fixture"
.venv-registration/bin/python -m ylm06 inspect --config "$PWD/work/fixture/integration.json"
.venv-registration/bin/python -m ylm06 run --config "$PWD/work/fixture/integration.json" --out "$PWD/work/run"
.venv-registration/bin/python -m ylm06 verify --run "$PWD/work/run"
```

別cwdから実行する場合はvenvのPythonとconfigを絶対パスで指定します。すべての入力相対参照はconfigファイル基準です。外部rootは `allowed_roots` に明記します。評価専用GT/proxyは統合入力に混ぜられません。

全工程の合成受入を一度に実行する場合：

```bash
.venv-registration/bin/python -m examples.run_acceptance --out "$PWD/work/acceptance"
```

このコマンドはSYNTHETIC_ONLYデータに限りrun、検証、apply、独立bootstrapを行います。900点fixtureの既知変換を登録初期値に渡していません。恒等、全点、65%切出しの数値基準は仕様書の値に固定しています。実環境の精度閾値には使いません。

## 3. 表示と更新案の確認

`work/run/index.html` はPlotly本体・表示点群・全初期値結果・工程別正本を埋め込んだ自己完結HTMLです。ペア選択、変換前/後、候補、入力、座標、初期値、割当、可視性、観測、patchを切り替えられます。

```bash
python3 -m http.server 8000 --directory "$PWD/work/run"
# ブラウザで http://localhost:8000/ を開く
```

各候補の表示は最大約2,000点です。登録用の間引きと元画素集合は別に保存します。`candidates/index.jsonl` の画素ID、`registration/hypotheses.jsonl` の前処理対応・全初期値、`frames/objects/*.json` の変換を確認してください。入力の複数の時刻・候補で同じ整数ラベルが出ても、永続物体IDと同一視しません。

## 4. validate → apply

`run` は更新案を作り、既存グラフへ適用しません。次のfixture例では入力グラフを明示して検証・適用します。

```bash
.venv-registration/bin/python -m ylm06 validate-patch \
  --patch "$PWD/work/run/scene_graph_proposal/patch.json" \
  --graph "$PWD/work/fixture/graph.json"
.venv-registration/bin/python -m ylm06 apply \
  --patch "$PWD/work/run/scene_graph_proposal/patch.json" \
  --graph "$PWD/work/fixture/graph.json" \
  --out "$PWD/work/graph_v2" --store "$PWD/work/graph_store"
```

新しい版は `graph_v2/graph.json`。旧graphとモデルは残り、モデルposeに物体変換を合成します。部分観測の重心・extentで登録モデルを置換しません。意味エッジを保持し、移動した端点を持つ空間エッジはSTALE、意味不明のエッジはUNKNOWNになります。

`--store` は明示的なgraph storeです。`ledger.json` の `current` が原子的に更新される現在版ポインタであり、journalも同じファイルへ記録します。CLIは常に `--graph` を要求します。storeを省略すると出力親フォルダの `.ylm_transactions/` に直列化・重複防止ledgerだけを保存します。同じグラフの運用では同じstoreを継続使用してください。互いに独立した別マシン・別storeのforkを横断する重複排除は行いません。

古いbase hash/version、二重transaction、重複観測、未解決競合、不足証拠を拒否します。lock、一時フォルダ、fsync、atomic rename、公開後停止のjournal復旧を実装しています。訂正は現在版をbaseにした新transactionへ `correction_of` を付け、履歴を残します。EMPTY_PATCHはapplyしません。

表示用の `input_graph.json` と `preview_graph.json` はモデル参照を配布フォルダ内へ正規化したコピーです。patchのbaseは元入力のgraph hashです。元入力を紛失した場合は、`run/integration.json` の `graph_input.graph_path` が指す保存snapshotを `--graph` に指定します。

## 5. 初期登録・新規登録・形状蓄積

```bash
.venv-registration/bin/python -m ylm06 bootstrap \
  --config "$PWD/work/fixture/bootstrap.json" --out "$PWD/work/bootstrap_graph"
```

bootstrapは明示承認された非競合の観測集合だけを登録します。frame根拠、現在点、3次元形状支持、承認記録が必要です。全候補の自動一括登録はしません。既存物体との評価が未完了なら、新規候補はprovisionalのままです。

新規性の明示adjudicationは `adjudications` のhash付きJSON参照で渡します。recordは `candidate_key`, `reviewer`, `timestamp`, `basis`, `novelty_confirmed:true` を持ちます。proxyを確認根拠にしません。全必要ペアの評価、競合、frame、現在支持を再検査します。生成した永続IDはgraph IDと観測キーから決定します。

形状蓄積は既定OFFです。明示ONはdecision profileの `shape_accumulation:true` と再hashを必要とし、主対応・現在点・整列誤差・由来重複を検査してモデルversionを増やします。旧点を保持し、旧asset参照と追加点の由来を残します。

## 6. 実入力とprofile

`ylm06/schemas/` と `docs/CONTRACTS_ja.md` を参照してください。profile例は `profiles/` にあります。数値未設定の閾値はnullのまま保留条件になります。

- `UNCALIBRATED`：診断用。実グラフの自動更新をしません。
- `SYNTHETIC_ONLY`：提供fixtureの回帰用。実データ入力で使用するとエラーになります。
- `VALIDATED`：対象センサ、距離、点数、自由度、検証記録、閾値を明示した適用範囲内だけで判断します。ファイル内のラベルを検証済みに書き換えて通さないでください。

4DOFは実際にYaw＋XYZ並進を解き、6DOFは3次元剛体最小二乗を解きます。4DOFの重力・運動仮定が未確認なら診断に留めます。frameは元センサ→共通座標変換と物体変換を分離します。部分観測中心差、行列並進、モデル基準点変位は別欄です。

可視性は独立に校正された直接pinhole rayの明示オプションです。rangeはユークリッド距離。入力点が宣言rayに乗ることも検査します。LiDARの未確認ray補間・同画素対応は仮定しません。該当する投影契約がない実データはUNKNOWNのまま動作します。

## 7. 凍結B0・比較・評価

```bash
.venv-registration/bin/python -m ylm06 legacy-replay \
  --inputs "$PWD/validation/legacy_inputs" --out "$PWD/work/B0_replay"
```

別プロセスで無改変B0を実行します。PCD参照だけを同梱入力へ解決し、旧パラメータ・OBBゲートを維持します。旧30ペアの8数値項目とvalidを比較します。統合configの `solver.mode:B0_COMPAT` は候補対モデル用の別プロセス診断経路です。この場合は旧merged-cluster OBBゲートを適用せず、全初期値の監査を添えます。どちらもlegacy_validを同一性確定へ直結させません。

`examples/prepare_real.py` は元v0.5.1.2のE0/E1保存runと選択方式から統合入力を作ります。入力場所は引数で明示し、研究室の絶対パスを推測しません。E1/S1の未保存画素配列は、選ばれた既存候補の全断片和集合から物理化します。探索の再実行ではありません。正式比較は `validation/real/comparison_summary.json` と `validation/REPORT_ja.md` を参照してください。

```bash
.venv-registration/bin/python -m ylm06 evaluate \
  --run "$PWD/work/run" --evaluation-config "$PWD/profiles/evaluation_only.example.json"
```

この例はGTなしでNOT_EVALUATEDを記録します。独立GTを与えるときはsame/different/unclear、根拠、作成者、時刻を記録します。unclearや未解決を正解・不正解へ丸めません。評価は別出力 `evaluations/` に保存され、登録・割当・更新へ戻しません。

## 8. 終了コード・再開・資源

0は要求工程完了、2は予算停止等の部分完了、1は不正入力または処理エラーです。実データ比較では詳細32ペアの上限で残りが未評価となるため、出力・整合性が正常でも終了コード2になります。UNKNOWN/HELD自体はエラーではありません。

`run --resume` は入力・profile・実装hashが一致し検証済みの完了runだけを再利用します。中断runは元の不完全出力を保持し、別 `attempt-N/` に再実行します。未完了段階の途中状態は再利用しません。

既定はworker/thread各1、RSS8192MiB、wall1800秒、詳細32ペア、初期値最大32、出力2GiBです。出力予算は再書込も含む保守的な累計、報告値は最終ファイル合計です。元候補生成の予算は元resolved configに別保存します。カウント・RSS・時間の打切りを不一致や物体消滅へ変換しません。

## 9. 配布の検証

```bash
python3 examples/verify_release.py
# 追加結果ZIPを展開した場合
python3 examples/verify_release.py --manifest validation/real/manifest_exp01.json
python3 examples/verify_release.py --manifest validation/real/manifest_exp02.json
sha256sum -c ../ylm_scene_graph_integrated_v06_registration_scene_graph.zip.sha256
```

モデル削除・物体のmerge/split、新規意味関係推定、raw bag上流の再実装、校正の自動化はこの版の対象外です。試験成功、処理完了、patchの妥当性、apply成功、物理的な正解は別項目として報告しています。
