"""Export saved v0512 candidates without regenerating clustering or candidate search."""
import argparse
import copy
import shutil
from pathlib import Path
import numpy as np
from ylm06.util import read,write,write_lines,lines,sha,inventory
from ylm06.profiles import defaults
from ylm051.selection_experiment import select_run


def export_run(source,out,policy):
    source,out=Path(source).resolve(),Path(out).resolve();out.mkdir(parents=True,exist_ok=False)
    for name in ['input_contract.json','run_manifest.json','resolved_config.json','source_hashes.json','environment.json']:
        shutil.copyfile(source/name,out/name)
    for r in read(source/'source_hashes.json'):
        dest=out/r['snapshot'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/r['snapshot'],dest)
    rows=list(lines(source/'hypotheses.jsonl'))
    if policy=='coverage_order_v1':
        selection=out/'selection';select_run(source,selection,policy)
        rows=[r for r in rows if r['is_singleton']]+list(lines(selection/'selected_candidates.jsonl'))
    write_lines(out/'hypotheses.jsonl',rows)
    inp=read(out/'input_contract.json');z={t:np.load(out/sp['pixels'],allow_pickle=False) for t,sp in inp['times'].items()}
    mats={t:np.load(out/sp['canonical_mask']['path'],allow_pickle=False)[sp['canonical_mask']['key']] for t,sp in inp['times'].items()}
    copied=0; reconstructed=0
    for r in rows:
        dest=out/r['source_point_ids'];dest.parent.mkdir(parents=True,exist_ok=True)
        if (source/r['source_point_ids']).exists():shutil.copyfile(source/r['source_point_ids'],dest);copied+=1
        else:
            t=r['namespace']['time'];a=z[t];ids=np.flatnonzero(a['valid']&~mats[t]&np.isin(a['labels'],r['fragment_ids']))
            assert len(ids)==r['point_count'];np.save(dest,ids.astype(np.int64),allow_pickle=False);reconstructed+=1
    write(out/'adapter_manifest.json',{'source_run':str(source),'original_manifest_sha256':sha(source/'run_manifest.json'),
       'original_hypotheses_sha256':sha(source/'hypotheses.jsonl'),'original_resolved_config_sha256':sha(source/'resolved_config.json'),
       'policy':policy,'clustering_regenerated':False,'candidate_search_regenerated':False,
       'point_arrays_copied':copied,'selected_unsaved_arrays_materialized_from_full_fragment_union':reconstructed,
       'source_modules':inventory(Path(__file__).resolve().parents[1]/'ylm051',{'.py'})})
    write(out/'artifact_hashes.json',inventory(out));return rows


def prepare(baseline,e1_exp02,e1_remaining,out):
    out=Path(out).resolve();out.mkdir(parents=True,exist_ok=False);paths={};rowmap={}
    for case in ['exp01_t0','exp01_t1','exp02_t0','exp02_t1']:
        for condition in ['E0_S0','E1_S1']:
            source=Path(baseline)/'validation/real'/case if condition=='E0_S0' else Path(e1_exp02 if case=='exp02_t1' else e1_remaining)/(case+'_E1')
            dest=out/'candidate_inputs'/condition/case;rows=export_run(source,dest,'S0' if condition=='E0_S0' else 'coverage_order_v1')
            paths[case,condition]=dest;rowmap[case,condition]=rows
    def asset(p,**kw):return {'path':str(Path(p).relative_to(out)),'sha256':sha(p),**kw}
    for case in ['exp01_t0','exp01_t1','exp02_t0','exp02_t1']:
        counterpart=case[:-1]+('1' if case.endswith('0') else '0')
        for condition in ['E0_S0','E1_S1']:
            observations=[];candidate_runs=[]
            for dataset in [counterpart,case]:
                root=paths[dataset,condition];inp=read(root/'input_contract.json');time=dataset[-2:];sp=inp['times'][time];z=np.load(root/sp['pixels'],allow_pickle=False)
                namespace={k:inp[k] for k in ['case','window','boundary','run_id']};namespace['time']=time
                observations.append({'observation_id':dataset,'case':inp['case'],'time':time,'window':inp['window'],'boundary':inp['boundary'],
                    'sensor_frame':'UNVERIFIED_SENSOR','sensor_id':'lab_sensor_UNVERIFIED','reference_time_ns':None,'window_start_ns':None,'window_end_ns':None,
                    'received_frames':[],'pixels':asset(root/sp['pixels']),'upstream_manifest':asset(root/'source_hashes.json'),
                    'structure_mask':asset(root/sp['canonical_mask']['path'],key=sp['canonical_mask']['key']),
                    'provenance':{'current_rule':'UNAVAILABLE','source_type_key':'source_type' if 'source_type' in z else None,
                        'time_key':'source_time_ns' if 'source_time_ns' in z else None,'frame_key':'source_frame_index' if 'source_frame_index' in z else None,
                        'sample_key':'source_sample_index' if 'source_sample_index' in z else None},
                    'shape':list(z['valid'].shape),'namespace':namespace,'freshness_status':'UNAVAILABLE','ray_calibration':None})
                candidate_runs.append({'observation_id':dataset,**{k:asset(root/f) for k,f in [('manifest','run_manifest.json'),('input_contract','input_contract.json'),
                    ('resolved_config','resolved_config.json'),('candidates','hypotheses.jsonl'),('artifact_hashes','artifact_hashes.json'),('source_hashes','source_hashes.json'),('source_environment','environment.json')]},
                    'selection_policy':'S0' if condition=='E0_S0' else 'coverage_order_v1','selection_manifest':asset(root/'selection/selection_manifest.json') if condition=='E1_S1' else None})
            # Explicit geometry-only diagnostic source subset, identical rule for each condition.
            # These candidates never become permanent nodes or adjudicated identities.
            rows=rowmap[counterpart,condition]
            chosen=sorted((r for r in rows if r['is_singleton'] and r['point_count']>=30),key=lambda r:(-r['point_count'],r['candidate_id']))[:4]
            config={'schema_version':'ylm.integration.input.v1','run_id':case+'_'+condition,'dataset_role':'REAL_DEVELOPMENT','units':'m',
                'observations':observations,'candidate_runs':candidate_runs,'bootstrap':{'mode':'DIAGNOSTIC_ONLY_NO_GRAPH'},
                'frame_contract':{'status':'FRAME_UNVERIFIED','graph_frame':'DIAGNOSTIC_G','evidence':[],'independent_support':False,
                    'transforms':{o['observation_id']:{'matrix':np.eye(4).tolist(),'from_frame':o['sensor_frame'],'to_frame':'DIAGNOSTIC_G'} for o in observations}},
                'profiles':defaults(False),'resources':{'workers':1,'numerical_threads':1,'rss_mib':8192,'wall_seconds':1800,'detailed_pairs':32,
                    'initializations':32,'output_bytes':2*1024**3,'assignment_states':100000},'allowed_roots':[],
                'diagnostic_sources':[{'observation_id':counterpart,'candidate_ids':[r['candidate_id'] for r in chosen],
                    'selection_reason':'Four largest singleton models with >=30 points; explicit diagnostic subset without proxy/GT; other source models NOT_ENUMERATED'}]}
            write(out/(case+'_'+condition+'.json'),config)
    write(out/'preparation_report.json',{'clustering_regenerated':False,'candidate_search_regenerated':False,'source_baseline':str(baseline),
        'conditions':['E0/S0','E1/S1'],'registration_profile_identical':True,'model_selection':'four largest singletons >=30 points',
        'frame_status':'FRAME_UNVERIFIED','formal_graph_or_models_received':False,'identity_GT_received':False,
        'current_measurement_type_mapping':'UNVERIFIED; raw provenance arrays retained; no current-presence confirmation'})


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--baseline',required=True);p.add_argument('--e1-exp02',required=True);p.add_argument('--e1-remaining',required=True);p.add_argument('--out',required=True)
    a=p.parse_args();prepare(a.baseline,a.e1_exp02,a.e1_remaining,a.out)
