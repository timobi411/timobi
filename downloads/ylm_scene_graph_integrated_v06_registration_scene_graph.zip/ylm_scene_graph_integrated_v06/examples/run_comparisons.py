import argparse
from pathlib import Path
import subprocess
import sys
from ylm06.util import read,write,sha


def main(inputs,out):
    inputs,out=Path(inputs).resolve(),Path(out).resolve();out.mkdir(parents=True,exist_ok=False);results=[]
    for case in ('exp01_t0','exp01_t1','exp02_t0','exp02_t1'):
        for condition in ('E0_S0','E1_S1'):
            name=case+'_'+condition;config=inputs/(name+'.json');dest=out/name
            with open(out/(name+'.log'),'w') as log:
                proc=subprocess.run([sys.executable,'-m','ylm06','run','--config',str(config),'--out',str(dest)],stdout=log,stderr=subprocess.STDOUT)
            if proc.returncode not in (0,2):raise RuntimeError(name+' failed; inspect '+str(out/(name+'.log')))
            manifest=read(dest/'run_manifest.json');verification=read(dest/'verification.json')
            assert verification['integrity_passed'];assert not manifest['graph_modified']
            results.append({'case':case,'condition':condition,'exit_code':proc.returncode,'config_sha256':sha(config),
                'manifest':manifest,'verification':verification})
            write(out/'comparison_summary.json',results);print(name,manifest['counts'],flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--inputs',required=True);p.add_argument('--out',required=True);a=p.parse_args();main(a.inputs,a.out)
