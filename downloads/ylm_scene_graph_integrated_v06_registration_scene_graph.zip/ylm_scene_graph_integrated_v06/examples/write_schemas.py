"""Generate explicit Draft 2020-12 structural contracts; semantic checks remain in Python."""
from pathlib import Path
import json

BASE={'$schema':'https://json-schema.org/draft/2020-12/schema'}
S={'type':'string','minLength':1}; N={'type':'number'}; I={'type':'integer'}; B={'type':'boolean'}
NULL={'type':'null'}
def array(item):return {'type':'array','items':item}
def enum(*values):return {'enum':list(values)}
def obj(props,required=None,extra=True):return {'type':'object','properties':props,'required':list(props) if required is None else required,'additionalProperties':extra}
def nullable(value):return {'anyOf':[value,NULL]}
matrix={'type':'array','minItems':4,'maxItems':4,'items':{'type':'array','minItems':4,'maxItems':4,'items':N}}
asset=obj({'path':S,'sha256':{'type':'string','pattern':'^[0-9a-f]{64}$'}})
pose=obj({'frame_id':S,'matrix':matrix})
states=obj({'identity':enum('CONFIRMED','AMBIGUOUS','UNRESOLVED','REJECTED_UNDER_PROFILE'),
 'motion':enum('STATIC','MOVED','UNKNOWN_MOTION'),
 'observation':enum('CURRENT_OBSERVED','PARTIAL','HISTORY_ONLY','OCCLUSION_SUPPORTED','OUT_OF_VIEW','UNKNOWN','ABSENCE_SUPPORTED_AT_OLD_POSE')})
node=obj({'object_id':S,'lifecycle':S,'states':states,'model':obj({'asset':asset,'version':{'type':'integer','minimum':1},
 'reference_point':{'type':'array','minItems':3,'maxItems':3,'items':N},'geometry_status':S}),
 'pose':pose,'last_confirmed':nullable({'type':'object'}),'observation_refs':array(obj({'key':S})),
 'attributes':{'type':'object'},'provenance':{'type':'object'}})
edge=obj({'edge_id':S,'source':S,'target':S,'relation_type':S,'evidence':array({}),'status':S,'valid_time':{},'provenance':{'type':'object'}})
graph=obj({'schema_version':{'const':'ylm.scene_graph.v1'},'graph_id':S,'version':{'type':'integer','minimum':1},'hash':S,
 'frame':S,'units':{'const':'m'},'timestamp':{},'nodes':array(node),'edges':array(edge),'history':array({'type':'object'})})
operation=obj({'operation_id':S,'type':enum('ADD_NODE','UPDATE_POSE','APPEND_OBSERVATION','UPDATE_STATUS','VERSION_MODEL','MARK_EDGE_STALE'),
 'object_id':nullable(S),'preconditions':obj({'before_sha256':S}),'before':{},'after':{},'evidence_refs':array(obj({'path':S,'sha256':S})),
 'decision_status':enum('CONFIRMED','HELD'),'reason_codes':array(S)})
patch=obj({'schema_version':{'const':'ylm.graph_patch.v1'},'transaction_id':S,'base':nullable(obj({'graph_id':S,'version':I,'hash':S})),
 'input_fingerprints':{'type':'object'},'profile_hash':S,'source_hashes':{'type':'object'},'operations':array(operation),
 'held_operations':array({'type':'object'}),'preconditions':{'type':'object'},'evidence_refs':{'type':'object'},'expected_postconditions':nullable({'type':'object'})})
observation=obj({'observation_id':S,'case':S,'time':enum('t0','t1'),'window':enum('fixed11','all'),'boundary':S,'sensor_frame':S,'sensor_id':S,
 'reference_time_ns':nullable(I),'window_start_ns':nullable(I),'window_end_ns':nullable(I),'received_frames':array(I),
 'pixels':asset,'upstream_manifest':asset,'provenance':{'type':'object'},'structure_mask':asset,
 'shape':{'type':'array','minItems':2,'maxItems':2,'items':{'type':'integer','minimum':1}},'namespace':{'type':'object'},
 'freshness_status':enum('VERIFIED','UNAVAILABLE','HISTORY_ONLY'),'ray_calibration':nullable({'type':'object'})},extra=False)
candidate_run=obj({k:asset for k in ['manifest','input_contract','resolved_config','candidates','artifact_hashes','source_hashes','source_environment']}|
 {'observation_id':S,'selection_policy':enum('S0','coverage_order_v1'),'selection_manifest':nullable(asset)},extra=False)
integration=obj({'schema_version':{'const':'ylm.integration.input.v1'},'run_id':S,'dataset_role':enum('SYNTHETIC_ONLY','REAL_DEVELOPMENT','REAL_EVALUATION'),
 'units':{'const':'m'},'observations':array(observation),'candidate_runs':array(candidate_run),'graph_input':{'type':'object'},'bootstrap':{'type':'object'},
 'frame_contract':obj({'status':enum('VERIFIED_FIXED','VERIFIED_TRANSFORM','FRAME_UNVERIFIED'),'graph_frame':S,'transforms':{'type':'object'},'evidence':array(asset)}),
 'profiles':obj({'solver':{'type':'object'},'decision':{'type':'object'}},extra=False),'resources':obj({k:{'type':'number','exclusiveMinimum':0} for k in
 ['workers','numerical_threads','rss_mib','wall_seconds','detailed_pairs','initializations','output_bytes','assignment_states']},extra=False),
 'allowed_roots':array(S),'diagnostic_sources':array({'type':'object'}),'adjudications':array(asset)},
 required=['schema_version','run_id','dataset_role','units','observations','candidate_runs','frame_contract','profiles','resources'],extra=False)
integration['oneOf']=[{'required':['graph_input'],'not':{'required':['bootstrap']}},{'required':['bootstrap'],'not':{'required':['graph_input']}}]
registration=obj({'pair_id':S,'object_id':S,'candidate_key':S,'observation_id':S,
 'evaluation_status':enum('NOT_ENUMERATED','QUEUED','EXCLUDED_BY_PROFILE','NOT_EVALUATED_BUDGET','INVALID_INPUT','EVALUATED'),
 'identity_status':states['properties']['identity'],'motion_status':states['properties']['motion'],
 'integration_validity':enum('VALID_FOR_POSE','VALID_FOR_PARTIAL_OBSERVATION','HELD_DEGENERATE','HELD_AMBIGUOUS','INVALID_INPUT','REJECTED_BY_PROFILE','NOT_EVALUATED'),
 'transformation':nullable(matrix),'legacy_valid':nullable(B)},required=['pair_id','object_id','candidate_key','observation_id','evaluation_status','identity_status','motion_status'])
root=Path(__file__).resolve().parents[1]/'ylm06/schemas';root.mkdir(exist_ok=True)
for name,schema in {'integration_input':integration,'observation':observation,'scene_graph':graph,'graph_patch':patch,'registration_pair':registration}.items():
 (root/(name+'.json')).write_text(json.dumps(BASE|{'$id':'https://ylm.local/schemas/'+name+'.json'}|schema,indent=2)+'\n')
