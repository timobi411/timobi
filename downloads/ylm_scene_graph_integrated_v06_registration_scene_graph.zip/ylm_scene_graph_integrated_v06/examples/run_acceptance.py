import argparse
import copy
from pathlib import Path
import numpy as np
from examples.make_fixture import create
from ylm06.pipeline import run,verify
from ylm06.graph import apply_patch,validate_patch
from ylm06.bootstrap import bootstrap
from ylm06.registration import register
from ylm06.profiles import defaults
from ylm06.util import read,write,transformed,rotation_error


def main(out):
    out=Path(out).resolve();out.mkdir(parents=True,exist_ok=False);create(out/'fixture')
    manifest=run(out/'fixture/integration.json',out/'run')
    patch=out/'run/scene_graph_proposal/patch.json';validate_patch(patch,out/'fixture/graph.json')
    applied=apply_patch(patch,out/'fixture/graph.json',out/'graph_v2',store=out/'graph_store')
    initial=read(out/'fixture/graph.json');actual=read(out/'graph_v2/graph.json');truth=np.array(read(out/'fixture/truth_evaluation_only.json')['known_object_transform'])
    def projection(g):
        return {'graph_id':g['graph_id'],'version':g['version'],'nodes':[{'object_id':n['object_id'],'pose':np.round(n['pose']['matrix'],6).tolist(),
            'model_version':n['model']['version'],'model_extent':n['model'].get('extent'),'attributes':n['attributes']} for n in g['nodes']],
            'edges':[{'edge_id':e['edge_id'],'status':e['status'],'relation_type':e['relation_type']} for e in g['edges']],
            'custom_graph_attribute':g['custom_graph_attribute']}
    expected=copy.deepcopy(initial);expected['version']=2;expected['nodes'][0]['pose']['matrix']=truth.tolist();expected['edges'][1]['status']='STALE'
    expected,observed=projection(expected),projection(actual)
    write(out/'expected_graph_projection.json',expected);write(out/'actual_graph_projection.json',observed)
    assert expected==observed
    bootstrap(out/'fixture/bootstrap.json',out/'bootstrap_graph')
    source=np.load(out/'fixture/model.npy');results=[]
    for name,t,subset,rotation_limit,reference_limit in [('identity',np.eye(4),source,1e-4,1e-6),
        ('known_full',truth,source,.1,.001),('known_partial65',truth,source[source[:,0]<=np.quantile(source[:,0],.65)],1,.01)]:
        context={'pair_id':name,'reference_point':source.mean(0).tolist(),'initialization_limit':32,'frame_status':'VERIFIED_FIXED',
                 'dataset_role':'SYNTHETIC_ONLY','sensor_id':'synthetic','model_verified':True,'current_count':len(subset)}
        r,h=register(source,transformed(subset,t),defaults(True),context);got=np.array(r['transformation'])
        re=rotation_error(got,t);ce=float(np.linalg.norm(transformed(source.mean(0)[None],got)-transformed(source.mean(0)[None],t)))
        maximum=float(np.linalg.norm(transformed(source,got)-transformed(source,t),axis=1).max())
        assert re<=rotation_limit and ce<=reference_limit
        if name=='identity':assert maximum<=1e-6
        results.append({'case':name,'source_points':len(source),'target_points':len(subset),'rotation_error_deg':re,
            'reference_error_m':ce,'max_known_correspondence_error_m':maximum,'passed':True,
            'ground_truth_transform_used_as_initializer':False,'result':r,'hypotheses':h})
    write(out/'registration_regression.json',results)
    write(out/'acceptance.json',{'expected_graph_projection_equal':True,'pose_comparison_decimal_places':6,
        'fixture_limits_only':True,'manifest':manifest,'apply':applied,'verify':verify(out/'run'),'bootstrap_complete':True})


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();main(a.out)
