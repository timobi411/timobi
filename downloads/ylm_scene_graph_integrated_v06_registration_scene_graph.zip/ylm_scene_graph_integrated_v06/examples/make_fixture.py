"""Small deterministic SYNTHETIC_ONLY fixture; truth never enters registration inputs."""
import argparse
import copy
from pathlib import Path
import numpy as np
from ylm06.util import write,write_lines,sha,digest,transformed
from ylm06.graph import seal_graph
from ylm06.profiles import defaults


def asset(path,base,**kw): return dict(path=str(Path(path).relative_to(base)),sha256=sha(path),**kw)


def candidate_run(root,xyz,time='t1',oid='obs:t1'):
    root=Path(root); root.mkdir(parents=True,exist_ok=True)
    n=len(xyz); h,w=1,n
    namespace={'case':'fixture','window':'fixed11','boundary':'boundary_false','run_id':'fixture-input','time':time}
    np.savez_compressed(root/'pixels.npz',xyz=xyz.reshape(h,w,3),valid=np.ones((h,w),bool),labels=np.zeros((h,w),np.int32),
        source_type=np.ones((h,w),np.int8),source_time_ns=np.full((h,w),100,np.int64),source_frame_index=np.zeros((h,w),np.int64),source_sample_index=np.arange(n).reshape(h,w))
    np.savez_compressed(root/'mask.npz',canonical_structure_mask=np.zeros((h,w),bool))
    np.save(root/'point_ids.npy',np.arange(n,dtype=np.int64))
    inp={'schema':'ylm051.input.v1','units':'m','run_id':'fixture-input','case':'fixture','window':'fixed11','boundary':'boundary_false',
         'times':{time:{'pixels':'pixels.npz','canonical_mask':{'path':'mask.npz','key':'canonical_structure_mask'}}}}
    write(root/'input_contract.json',inp); write(root/'resolved_config.json',{'fixture':'one full fragment, no search','budget':None})
    write(root/'run_manifest.json',{'version':'0.5.1.2','integrity_passed':True,'exploration_state':'EXHAUSTIVE','source_kind':'SYNTHETIC_CONTRACT_FIXTURE'})
    write(root/'source_hashes.json',[{'snapshot':p,'sha256':sha(root/p)} for p in ('pixels.npz','mask.npz')])
    write(root/'environment.json',{'source_modules':{'synthetic_contract_fixture':sha(Path(__file__))},'not_a_search_run':True})
    write(root/'artifact_hashes.json',{'point_ids.npy':sha(root/'point_ids.npy')})
    row={'candidate_id':'H-fixture','namespace':namespace,'fragment_ids':[0],'source_point_ids':'point_ids.npy',
         'point_count':n,'is_singleton':True}
    write_lines(root/'hypotheses.jsonl',[row])
    base=root.parent
    observation={'observation_id':oid,'case':'fixture','time':time,'window':'fixed11','boundary':'boundary_false',
        'sensor_frame':'S','sensor_id':'synthetic','reference_time_ns':100,'window_start_ns':0,'window_end_ns':100,
        'received_frames':[0],'pixels':asset(root/'pixels.npz',base),'upstream_manifest':asset(root/'run_manifest.json',base),
        'provenance':{'current_rule':'ALL_SYNTHETIC','source_type_key':'source_type','time_key':'source_time_ns','frame_key':'source_frame_index','sample_key':'source_sample_index'},
        'structure_mask':asset(root/'mask.npz',base,key='canonical_structure_mask'),'shape':[h,w],'namespace':namespace,
        'freshness_status':'VERIFIED','ray_calibration':None}
    candidate={'observation_id':oid,**{k:asset(root/f,base) for k,f in [('manifest','run_manifest.json'),('input_contract','input_contract.json'),
        ('resolved_config','resolved_config.json'),('candidates','hypotheses.jsonl'),('artifact_hashes','artifact_hashes.json'),('source_hashes','source_hashes.json'),('source_environment','environment.json')]},
        'selection_policy':'S0','selection_manifest':None}
    return observation,candidate


def create(root,source=None):
    root=Path(root).resolve(); root.mkdir(parents=True,exist_ok=False)
    if source is None: source=np.load(Path(__file__).resolve().parents[1]/'tests/synthetic_source.npy')
    theta=np.deg2rad(23); t=np.eye(4); t[:2,:2]=[[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]]
    t[:3,3]=source.mean(0)-t[:3,:3]@source.mean(0)+[0.2,-0.1,0.03]
    target=transformed(source,t); obs,cand=candidate_run(root/'candidate_t1',target)
    np.save(root/'model.npy',source)
    pose={'frame_id':'G','matrix':np.eye(4).tolist()}
    node={'object_id':'obj:fixture','lifecycle':'ACTIVE','states':{'identity':'CONFIRMED','motion':'UNKNOWN_MOTION','observation':'UNKNOWN'},
        'model':{'asset':asset(root/'model.npy',root),'version':1,'reference_point':source.mean(0).tolist(),'geometry_status':'VERIFIED',
                 'extent':np.ptp(source,axis=0).tolist()},'pose':pose,'last_confirmed':{'pose':pose,'time_ns':0},
        'observation_refs':[],'attributes':{'semantic_label':'fixture','unknown_extension':{'keep':True}},'provenance':{'fixture_only':True}}
    other=copy.deepcopy(node); other['object_id']='obj:held'; other['pose']=copy.deepcopy(pose); other['pose']['matrix'][0][3]=10
    graph=seal_graph({'schema_version':'ylm.scene_graph.v1','graph_id':'graph:fixture','version':1,'frame':'G','units':'m','timestamp':0,
        'nodes':[node,other],'edges':[{'edge_id':'edge:semantic','source':'obj:fixture','target':'obj:held','relation_type':'related_to',
          'category':'semantic','evidence':[],'status':'CURRENT','valid_time':None,'provenance':{'fixture':True},'custom':7},
         {'edge_id':'edge:spatial','source':'obj:fixture','target':'obj:held','relation_type':'near','category':'spatial',
          'evidence':[],'status':'CURRENT','valid_time':None,'provenance':{'fixture':True}}],'history':[],'custom_graph_attribute':42})
    write(root/'graph.json',graph); write(root/'frame_evidence.json',{'kind':'SYNTHETIC_KNOWN_SENSOR_POSE','independent_of_object':True})
    c={'schema_version':'ylm.integration.input.v1','run_id':'fixture-v06','dataset_role':'SYNTHETIC_ONLY','units':'m',
       'observations':[obs],'candidate_runs':[cand],'graph_input':{'graph_id':graph['graph_id'],'version':1,'content_sha256':sha(root/'graph.json'),'graph_path':'graph.json'},
       'frame_contract':{'status':'VERIFIED_FIXED','graph_frame':'G','transforms':{'obs:t1':{'matrix':np.eye(4).tolist(),'from_frame':'S','to_frame':'G'}},
         'evidence':[asset(root/'frame_evidence.json',root)],'independent_support':True},
       'profiles':defaults(True),'resources':{'workers':1,'numerical_threads':1,'rss_mib':8192,'wall_seconds':1800,'detailed_pairs':32,
         'initializations':32,'output_bytes':2*1024**3,'assignment_states':10000},'allowed_roots':[],'diagnostic_sources':[]}
    write(root/'integration.json',c)
    write(root/'truth_evaluation_only.json',{'known_object_transform':t.tolist(),'source_count':len(source),'thresholds':{'rotation_deg':0.1,'reference_m':0.001}})
    b=copy.deepcopy(c); b.pop('graph_input'); b['bootstrap']={'mode':'DIAGNOSTIC_ONLY_NO_GRAPH'}
    write(root/'bootstrap_input.json',b)
    write(root/'bootstrap.json',{'schema_version':'ylm.bootstrap.v1','graph_id':'graph:bootstrap-fixture','integration_config':'bootstrap_input.json',
        'approved_candidates':['obs:t1::H-fixture'],'adjudication':{'reviewer':'SYNTHETIC_FIXTURE_TEST','timestamp':'2026-10-21','basis':'Constructed asymmetric fixture; not a real identity judgement','approved':True}})
    return c


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();create(a.out)
