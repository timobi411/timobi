import copy
import unittest
from pathlib import Path
import numpy as np
from ylm06.profiles import defaults,seal,validate
from ylm06.registration import register,normalize_legacy,select_hypothesis
from ylm06.util import transformed,rotation_error,Invalid


class RegistrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.source=np.load(Path(__file__).parent/'synthetic_source.npy')
    def context(self,a):
        return dict(pair_id='p',reference_point=a.mean(0).tolist() if len(a) else [0,0,0],initialization_limit=32,
            frame_status='VERIFIED_FIXED',dataset_role='SYNTHETIC_ONLY',sensor_id='synthetic',model_verified=True,current_count=len(a))
    def motion(self):
        t=np.eye(4); angle=np.deg2rad(23);t[:2,:2]=[[np.cos(angle),-np.sin(angle)],[np.sin(angle),np.cos(angle)]]
        t[:3,3]=self.source.mean(0)-t[:3,:3]@self.source.mean(0)+[.2,-.1,.03];return t
    def test_identity(self):
        r,h=register(self.source,self.source,defaults(True),self.context(self.source)); t=np.array(r['transformation'])
        self.assertLessEqual(np.linalg.norm(transformed(self.source,t)-self.source,axis=1).max(),1e-6)
        self.assertEqual(r['identity_status'],'CONFIRMED');self.assertEqual(r['motion_status'],'STATIC')
    def test_known_full_center_initialization(self):
        t=self.motion();r,h=register(self.source,transformed(self.source,t),defaults(True),self.context(self.source)); got=np.array(r['transformation'])
        self.assertLessEqual(rotation_error(got,t),.1); self.assertLessEqual(np.linalg.norm(transformed(self.source.mean(0)[None],got)-transformed(self.source.mean(0)[None],t)),.001)
        self.assertEqual(r['identity_status'],'CONFIRMED');self.assertEqual(r['motion_status'],'MOVED')
    def test_partial65(self):
        a=self.source;t=self.motion();subset=a[a[:,0]<=np.quantile(a[:,0],.65)]
        r,h=register(a,transformed(subset,t),defaults(True),self.context(a));got=np.array(r['transformation'])
        self.assertLessEqual(rotation_error(got,t),1);self.assertLessEqual(np.linalg.norm(transformed(a.mean(0)[None],got)-transformed(a.mean(0)[None],t)),.01)
    def test_density_and_inverse(self):
        a=self.source;t=self.motion();r,_=register(transformed(a[::2],t),a,defaults(True),self.context(a))
        self.assertLessEqual(rotation_error(np.array(r['transformation']),np.linalg.inv(t)),1)
    def test_six_dof(self):
        from scipy.spatial.transform import Rotation
        a=self.source;t=np.eye(4);t[:3,:3]=Rotation.from_euler('xyz',[8,5,12],degrees=True).as_matrix();t[:3,3]=[.1,-.04,.02]
        r,_=register(a,transformed(a,t),defaults(True,'6DOF'),self.context(a));self.assertLess(rotation_error(np.array(r['transformation']),t),.1)
    def test_degenerate(self):
        fixtures=[np.empty((0,3)),np.zeros((1,3)),np.zeros((50,3)),np.c_[np.arange(50)*.01,np.zeros((50,2))],np.c_[np.random.default_rng(4).random((50,2)),np.zeros(50)]]
        for a in fixtures:
            with self.subTest(n=len(a)):
                r,_=register(a,a+[.2,.1,0],defaults(True),self.context(a));self.assertNotEqual(r['identity_status'],'CONFIRMED')
    def test_frame_and_profile_hold(self):
        a=self.source;c=self.context(a);c['frame_status']='FRAME_UNVERIFIED';r,_=register(a,a,defaults(True),c);self.assertEqual(r['motion_status'],'UNKNOWN_MOTION')
        r,_=register(a,a,defaults(False),self.context(a));self.assertNotEqual(r['identity_status'],'CONFIRMED')
    def test_no_correspondences_not_perfect(self):
        a=self.source;s=defaults(True);s['solver']['yaw_degrees']=[]
        # Direct ICP no-overlap metrics must remain null, never RMSE=0 perfect.
        from ylm06.registration import metrics
        m=metrics(a,a+100,np.eye(4),s['solver']);self.assertEqual(m['correspondences'],0);self.assertIsNone(m['rmse_m'])
    def test_valid_first_and_ambiguity(self):
        d=defaults(True)['decision'];a={'hypothesis_id':'bad','numerically_valid':False,'pose_constrained':True,'integration_rank':999,'transformation':np.eye(4).tolist()}
        b=dict(a,hypothesis_id='good',numerically_valid=True,integration_rank=1)
        best,_,_=select_hypothesis([a,b],d);self.assertEqual(best['hypothesis_id'],'good')
        t=np.eye(4);t[0,3]=.1;c=dict(b,hypothesis_id='other',transformation=t.tolist())
        self.assertTrue(select_hypothesis([b,c],d)[2])
    def test_legacy_contract(self):
        r=normalize_legacy({'score':1,'valid':False,'transformation':np.eye(4).tolist(),'source_overlap':.8,'target_overlap':.9})
        self.assertFalse(r['legacy_valid']);self.assertEqual(r['evaluation_status'],'NOT_EVALUATED');self.assertEqual(r['source_coverage'],.8);self.assertEqual(r['motion_status'],'UNKNOWN_MOTION')
        with self.assertRaises(Invalid):normalize_legacy({'source_overlap':.8,'t0_coverage':.7})
        with self.assertRaises(Invalid):normalize_legacy({'source_overlap':float('nan')})
    def test_profile_cannot_leak_synthetic_scope(self):
        with self.assertRaises(Invalid):validate(defaults(True),'REAL_DEVELOPMENT')
    def test_initialization_budget_is_not_confirmation(self):
        c=self.context(self.source);c['initialization_limit']=1
        r,_=register(self.source,self.source,defaults(True),c);self.assertFalse(r['initialization_complete']);self.assertNotEqual(r['identity_status'],'CONFIRMED')
    def test_symmetric_shape_distinct_poses_remain_ambiguous(self):
        grid=np.linspace(-.2,.2,5);a=np.array(np.meshgrid(grid,grid,grid)).reshape(3,-1).T
        p=defaults(True);quarter=np.eye(4);quarter[:2,:2]=[[0,-1],[1,0]];p['solver']['extra_rotations']=[quarter.tolist()]
        r,_=register(a,a,p,self.context(a));self.assertEqual(r['identity_status'],'AMBIGUOUS');self.assertEqual(r['motion_status'],'UNKNOWN_MOTION')


if __name__=='__main__':unittest.main()
