import tempfile
import unittest
from pathlib import Path
from examples.make_fixture import create
from ylm06.pipeline import run,verify
from ylm06.evaluate import evaluate
from ylm06.util import read,write,sha


class EvaluationBoundaryTests(unittest.TestCase):
    def test_posthoc_unclear_and_proxy_cannot_change_decisions(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);create(root/'fixture');run(root/'fixture/integration.json',root/'run')
            paths=['registration/pairs.jsonl','assignment/assignment.json','scene_graph_proposal/patch.json']
            before={p:sha(root/'run'/p) for p in paths}
            pair_id=read(root/'run/assignment/assignment.json')['primary'][0]
            config={'schema_version':'ylm.evaluation.v1','evaluation_id':'separate-gt','author':'fixture author','created_at':'2026-10-21',
                'basis':'Explicit synthetic GT posthoc','ground_truth':[{'pair_id':pair_id,'identity':'same','basis':'constructed fixture'},
                {'pair_id':'unobserved','identity':'unclear','basis':'no independent support'}],
                'proxy':{'legacy_M2_proxy':'evaluation-only-marker'}}
            write(root/'eval.json',config);result=evaluate(root/'run',root/'eval.json')
            self.assertEqual(result['identity_accuracy'],1);self.assertEqual(result['unclear_excluded'],1)
            self.assertEqual(before,{p:sha(root/'run'/p) for p in paths});self.assertTrue(verify(root/'run')['integrity_passed'])


if __name__=='__main__':unittest.main()
