"""Optional Playwright check; run separately from numerical unittest suite."""
import argparse
import functools
import http.server
import json
from pathlib import Path
import threading
from playwright.sync_api import sync_playwright


def main(root,out):
    root,out=Path(root).resolve(),Path(out).resolve();out.mkdir(parents=True,exist_ok=False)
    class QuietHandler(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*args):pass
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(root)))
    threading.Thread(target=server.serve_forever,daemon=True).start();port=server.server_port;errors=[];external=[]
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
            page=browser.new_page(viewport={'width':1280,'height':980});page.on('pageerror',lambda e:errors.append(str(e)))
            page.on('request',lambda r:external.append(r.url) if not r.url.startswith('http://127.0.0.1:') and not r.url.startswith('data:') else None)
            page.goto(f'http://127.0.0.1:{port}/',wait_until='networkidle');page.wait_for_function('document.querySelector("#plot").data?.length===2')
            result={'pair_options':page.locator('#pair option').count(),'stage_options':page.locator('#stage option').count()}
            before=page.evaluate('document.querySelector("#plot").data[0].x[0]');page.click('#align')
            after=page.evaluate('document.querySelector("#plot").data[0].x[0]');assert before!=after
            page.select_option('#stage','hypotheses');assert 'initialization_route' in page.locator('#audit').inner_text()
            page.select_option('#stage','patch');assert 'UPDATE_POSE' in page.locator('#audit').inner_text()
            page.screenshot(path=str(out/'viewer.png'),full_page=True);browser.close()
            result.update(transform_toggle_changes_points=True,all_initializers_visible=True,patch_visible=True,javascript_errors=errors,external_requests=external)
            assert not errors and not external and result['stage_options']==9
            (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
    finally:server.shutdown()


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--out',required=True);a=p.parse_args();main(a.run,a.out)
