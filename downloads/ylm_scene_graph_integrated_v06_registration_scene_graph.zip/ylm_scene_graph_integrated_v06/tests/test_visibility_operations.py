import copy
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
import numpy as np
from examples.make_fixture import create
from ylm06.visibility import assess
from ylm06.profiles import defaults,seal
from ylm06.util import read,write,sha,transformed,Invalid
from ylm06.pipeline import run
from ylm06.graph import apply_patch,check_graph


class VisibilityTests(unittest.TestCase):
    def setup_rays(self,range_scale=1):
        yy,xx=np.mgrid[0:3,0:3];xyz=np.stack([(xx-1)*.1,(yy-1)*.1,np.ones((3,3))],axis=-1)*range_scale
        meta={'observation_id':'o','window_start_ns':0,'window_end_ns':10,'freshness_status':'VERIFIED',
          'provenance':{'current_rule':'ALL_SYNTHETIC','frame_key':'frames'},
          'ray_calibration':{'status':'VERIFIED_DIRECT_RAYS','projection':'PINHOLE_DIRECT','range_definition':'EUCLIDEAN',
                             'fx':10,'fy':10,'cx':1,'cy':1,'pixel_tolerance':.01,'evidence':'synthetic independent calibration'}}
        obs={'meta':meta,'xyz':xyz,'valid':np.ones((3,3),bool),'T':np.eye(4),'arrays':{'frames':np.zeros((3,3),int)}}
        return obs,xyz.reshape(-1,3)/range_scale
    def test_occlusion_absence_and_missing(self):
        t=defaults(True)['decision']['thresholds']
        for scale,expected in [(.5,'OCCLUSION_SUPPORTED'),(2,'ABSENCE_SUPPORTED_AT_OLD_POSE'),(1,'UNKNOWN')]:
            obs,model=self.setup_rays(scale);r=assess(model,obs,'VERIFIED_FIXED',t);self.assertEqual(r['status'],expected);self.assertEqual(r['unique_rays'],9)
        obs,model=self.setup_rays();obs['valid'][:]=False;r=assess(model,obs,'VERIFIED_FIXED',t);self.assertEqual(r['status'],'UNKNOWN');self.assertEqual(r['missing'],9)
    def test_out_of_view_history_and_unverified(self):
        obs,model=self.setup_rays();t=defaults(True)['decision']['thresholds']
        self.assertEqual(assess(model+[100,0,0],obs,'VERIFIED_FIXED',t)['status'],'OUT_OF_VIEW')
        self.assertEqual(assess(model,obs,'FRAME_UNVERIFIED',t)['status'],'UNKNOWN')
        obs['meta']['freshness_status']='HISTORY_ONLY';self.assertEqual(assess(model,obs,'VERIFIED_FIXED',t)['status'],'HISTORY_ONLY')
    def test_same_pixel_is_not_assumed_same_ray(self):
        obs,model=self.setup_rays();obs['xyz'][1,1,0]=10
        r=assess(model,obs,'VERIFIED_FIXED',defaults(True)['decision']['thresholds']);self.assertEqual(r['status'],'UNKNOWN');self.assertEqual(r['reason'],'INPUT_RAY_MISMATCH')


class OperationalTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);create(self.root/'fixture');self.cfg=self.root/'fixture/integration.json'
    def tearDown(self):self.tmp.cleanup()
    def test_sensor_movement_separated_from_object(self):
        # Object is stationary in G; sensor moves. Known sensor transform is independent.
        c=read(self.cfg);root=self.cfg.parent;source=np.load(root/'model.npy');t=np.eye(4);t[:3,3]=[.3,.2,0]
        p=root/'candidate_t1/pixels.npz';a=dict(np.load(p,allow_pickle=False));a['xyz']=transformed(source,np.linalg.inv(t)).reshape(a['xyz'].shape);np.savez_compressed(p,**a)
        hashes=read(root/'candidate_t1/source_hashes.json');hashes[0]['sha256']=sha(p);write(root/'candidate_t1/source_hashes.json',hashes)
        c['observations'][0]['pixels']['sha256']=sha(p);c['candidate_runs'][0]['source_hashes']['sha256']=sha(root/'candidate_t1/source_hashes.json')
        c['frame_contract']['transforms']['obs:t1']['matrix']=t.tolist();c['frame_contract']['status']='VERIFIED_TRANSFORM';write(self.cfg,c)
        out=self.root/'sensor-run';run(self.cfg,out);patch=read(out/'scene_graph_proposal/patch.json')
        self.assertTrue(patch['operations']);self.assertFalse(any(op['type']=='UPDATE_POSE' for op in patch['operations']))
    def test_shape_version_opt_in(self):
        c=read(self.cfg);d=c['profiles']['decision'];d['shape_accumulation']=True;c['profiles']['decision']=seal(d);write(self.cfg,c)
        out=self.root/'shape-run';run(self.cfg,out);patch=out/'scene_graph_proposal/patch.json'
        p=read(patch);self.assertTrue(any(op['type']=='VERSION_MODEL' for op in p['operations']))
        apply_patch(patch,self.cfg.parent/'graph.json',self.root/'shape-graph')
        g=read(self.root/'shape-graph/graph.json');check_graph(g);self.assertEqual(g['nodes'][0]['model']['version'],2)
        self.assertEqual(np.load(self.root/'shape-graph'/g['nodes'][0]['model']['asset']['path']).shape[0],1800)
        self.assertEqual(read(self.cfg.parent/'graph.json')['nodes'][0]['model']['version'],1)
    def test_sensor_and_object_movement(self):
        c=read(self.cfg);root=self.cfg.parent;t=np.eye(4);t[:3,3]=[.3,.2,0]
        p=root/'candidate_t1/pixels.npz';a=dict(np.load(p,allow_pickle=False));a['xyz']=transformed(a['xyz'].reshape(-1,3),np.linalg.inv(t)).reshape(a['xyz'].shape);np.savez_compressed(p,**a)
        hashes=read(root/'candidate_t1/source_hashes.json');hashes[0]['sha256']=sha(p);write(root/'candidate_t1/source_hashes.json',hashes)
        c['observations'][0]['pixels']['sha256']=sha(p);c['candidate_runs'][0]['source_hashes']['sha256']=sha(root/'candidate_t1/source_hashes.json')
        c['frame_contract']['transforms']['obs:t1']['matrix']=t.tolist();c['frame_contract']['status']='VERIFIED_TRANSFORM';write(self.cfg,c)
        out=self.root/'both-run';run(self.cfg,out);patch=read(out/'scene_graph_proposal/patch.json')
        pose=next(op['after']['matrix'] for op in patch['operations'] if op['type']=='UPDATE_POSE')
        truth=read(root/'truth_evaluation_only.json')['known_object_transform'];self.assertTrue(np.allclose(pose,truth,atol=.001))
    def test_crash_after_publication_recovered_no_double_apply(self):
        out=self.root/'run';run(self.cfg,out);patch=out/'scene_graph_proposal/patch.json';graph=self.cfg.parent/'graph.json';dest=self.root/'published';store=self.root/'store'
        before=sha(graph);code='from ylm06.graph import apply_patch;import sys;apply_patch(*sys.argv[1:4],store=sys.argv[4],fault="after_publish_stop")'
        p=subprocess.run([sys.executable,'-c',code,str(patch),str(graph),str(dest),str(store)],capture_output=True)
        self.assertEqual(p.returncode,98,p.stderr);self.assertTrue((dest/'graph.json').exists());self.assertEqual(sha(graph),before)
        with self.assertRaises(Invalid):apply_patch(patch,graph,self.root/'duplicate',store=store)
        self.assertEqual(len(read(store/'ledger.json')['transactions']),1)
    def test_output_budget_stops_without_graph_change(self):
        c=read(self.cfg);c['resources']['output_bytes']=131072;write(self.cfg,c);before=sha(self.cfg.parent/'graph.json')
        result=run(self.cfg,self.root/'budget');self.assertTrue(result['partial']);self.assertFalse(result['processing_complete']);self.assertFalse(result['graph_modified'])
        self.assertEqual(sha(self.cfg.parent/'graph.json'),before)
        self.assertLess(sum(p.stat().st_size for p in (self.root/'budget').rglob('*') if p.is_file()),131072)
    def test_pair_budget_prevents_confirmation(self):
        c=read(self.cfg);c['resources']['detailed_pairs']=1;write(self.cfg,c);out=self.root/'limited';r=run(self.cfg,out)
        self.assertTrue(r['partial']);self.assertEqual(read(out/'scene_graph_proposal/patch.json')['operations'],[])
    def test_adjudicated_novelty_adds_one_node(self):
        from ylm06.graph import seal_graph
        c=read(self.cfg);gp=self.cfg.parent/'graph.json';g=read(gp)
        for i,n in enumerate(g['nodes']):n['pose']['matrix'][0][3]=10*(i+1)
        write(gp,seal_graph(g));c['graph_input']['content_sha256']=sha(gp)
        adjudication={'candidate_key':'obs:t1::H-fixture','reviewer':'synthetic-test-adjudicator','timestamp':'2026-10-21',
                      'basis':'Constructed independent novelty fixture record','novelty_confirmed':True}
        ap=self.cfg.parent/'adjudication.json';write(ap,adjudication);c['adjudications']=[{'path':'adjudication.json','sha256':sha(ap)}];write(self.cfg,c)
        out=self.root/'novelty';run(self.cfg,out);patch=out/'scene_graph_proposal/patch.json';p=read(patch)
        self.assertEqual(sum(op['type']=='ADD_NODE' for op in p['operations']),1)
        apply_patch(patch,gp,self.root/'novelty-graph');self.assertEqual(len(read(self.root/'novelty-graph/graph.json')['nodes']),3)


if __name__=='__main__':unittest.main()
