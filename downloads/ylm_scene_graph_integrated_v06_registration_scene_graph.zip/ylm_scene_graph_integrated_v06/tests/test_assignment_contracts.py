import copy
import tempfile
import unittest
from pathlib import Path
import numpy as np
from examples.make_fixture import create
from ylm06.assignment import solve
from ylm06.profiles import defaults
from ylm06.util import read,write,sha,Invalid
from ylm06.contracts import load


def candidate(key,ids): return {'key':key,'observation_id':'obs','fragment_ids':ids,'source_point_ids':ids,'current_count':len(ids)}
def pair(pid,obj,key,score=1):
    return {'pair_id':pid,'object_id':obj,'candidate_key':key,'observation_id':'obs','identity_status':'CONFIRMED',
      'integration_validity':'VALID_FOR_POSE','persistent_model':True,'evaluation_status':'EVALUATED','integration_rank':score,
      'transformation':np.eye(4).tolist(),'metrics':{'model_support_indices':[0,1]},'reasons':[]}


class AssignmentTests(unittest.TestCase):
    def solve(self,p,c,budget=1000):return solve(p,c,defaults(True)['decision'],budget)
    def test_empty_and_invalid(self):
        self.assertEqual(self.solve([],[])['primary'],[])
        p=pair('p','a','c');p['identity_status']='UNRESOLVED';self.assertEqual(self.solve([p],[candidate('c',[1])])['primary'],[])
    def test_shared_fragments_exclusive(self):
        c=[candidate('a',[1,2]),candidate('b',[2,3])];p=[pair('p','x','a',1),pair('q','y','b',.7)]
        r=self.solve(p,c);self.assertEqual(r['primary'],['p']);self.assertTrue(r['conflicts'])
    def test_equal_objects_held(self):
        r=self.solve([pair('p','x','a'),pair('q','y','a')],[candidate('a',[1])]);self.assertEqual(r['primary'],[])
    def test_budget_and_unexamined_hold(self):
        p=[pair('p','x','a'),pair('q','y','b')];c=[candidate('a',[1]),candidate('b',[2])]
        r=self.solve(p,c,1);self.assertFalse(r['optimality_proven']);self.assertEqual(r['primary'],[])
        p[1]['evaluation_status']='NOT_EVALUATED_BUDGET';p[1]['identity_status']='UNRESOLVED'
        self.assertEqual(self.solve(p,c)['primary'],[])
    def test_negative_utility_unmatched(self):
        self.assertEqual(self.solve([pair('p','x','a',-.1)],[candidate('a',[1])])['primary'],[])
    def test_auxiliary_disjoint_support_and_no_duplicate_id(self):
        p=pair('p','x','a');q=pair('q','x','b');q['identity_status']='UNRESOLVED';q['integration_validity']='VALID_FOR_PARTIAL_OBSERVATION';q['metrics']['model_support_indices']=[2,3]
        r=self.solve([p,q],[candidate('a',[1]),candidate('b',[2])]);self.assertEqual(r['primary'],['p']);self.assertEqual(len(r['auxiliary']),1)
        q['metrics']['model_support_indices']=[0,1];self.assertFalse(self.solve([p,q],[candidate('a',[1]),candidate('b',[2])])['auxiliary'])


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'fixture';create(self.root);self.config=self.root/'integration.json'
    def tearDown(self):self.tmp.cleanup()
    def reject(self,mutation):
        c=read(self.config);mutation(c);write(self.config,c)
        with self.assertRaises((Invalid,ValueError,KeyError)):load(self.config)
    def test_units(self):self.reject(lambda c:c.update(units='mm'))
    def test_shape(self):self.reject(lambda c:c['observations'][0].update(shape=[2,450]))
    def test_namespace(self):self.reject(lambda c:c['observations'][0]['namespace'].update(run_id='wrong'))
    def test_duplicates(self):self.reject(lambda c:c['candidate_runs'].append(copy.deepcopy(c['candidate_runs'][0])))
    def test_missing_asset(self):self.reject(lambda c:c['observations'][0]['pixels'].update(path='absent.npz'))
    def test_invalid_transform(self):self.reject(lambda c:c['frame_contract']['transforms']['obs:t1']['matrix'][0].__setitem__(0,2))
    def test_eval_leak(self):self.reject(lambda c:c.update(ground_truth={'target':'H-fixture'}))
    def test_allowlist_escape(self):self.reject(lambda c:c['observations'][0]['pixels'].update(path='/etc/passwd'))
    def test_hash_change(self):
        with open(self.root/'candidate_t1/point_ids.npy','ab') as f:f.write(b'changed')
        with self.assertRaises(Invalid):load(self.config)
    def test_nan_json(self):
        self.config.write_text('{"units":NaN}')
        with self.assertRaises(Invalid):load(self.config)


if __name__=='__main__':unittest.main()
