import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
import numpy as np
from examples.make_fixture import create
from ylm06.pipeline import run,verify
from ylm06.graph import apply_patch,validate_patch,seal_graph,check_graph,import_legacy
from ylm06.bootstrap import bootstrap
from ylm06.util import read,write,sha,Invalid,digest


class TransactionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(prefix='ylm path with spaces ');cls.root=Path(cls.tmp.name)
        create(cls.root/'fixture');cls.cfg=cls.root/'fixture/integration.json';cls.graph=cls.root/'fixture/graph.json'
        cls.run_dir=cls.root/'run';cls.manifest=run(cls.cfg,cls.run_dir);cls.patch=cls.run_dir/'scene_graph_proposal/patch.json'
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def test_pipeline_patch_apply_preserves_graph(self):
        patch,base,preview=validate_patch(self.patch,self.graph);self.assertTrue(patch['operations'])
        dest=self.root/'applied';result=apply_patch(self.patch,self.graph,dest)
        g=read(dest/'graph.json');self.assertEqual(g['version'],2);self.assertEqual(len(g['nodes']),2)
        self.assertEqual(g['custom_graph_attribute'],42);self.assertEqual(len(g['edges']),2)
        self.assertEqual(g['edges'][0],base['edges'][0]);self.assertEqual(g['edges'][1]['status'],'STALE')
        old={n['object_id']:n for n in base['nodes']};new={n['object_id']:n for n in g['nodes']}
        self.assertEqual(new['obj:held']['pose'],old['obj:held']['pose'])
        self.assertEqual(new['obj:fixture']['model']['extent'],old['obj:fixture']['model']['extent'])
        self.assertEqual(new['obj:fixture']['attributes'],old['obj:fixture']['attributes'])
        truth=np.array(read(self.root/'fixture/truth_evaluation_only.json')['known_object_transform'])
        self.assertTrue(np.allclose(new['obj:fixture']['pose']['matrix'],truth,atol=.001))
        self.assertEqual(read(self.graph),base)
        with self.assertRaises(Invalid):apply_patch(self.patch,self.graph,self.root/'duplicate')
        with self.assertRaises(Invalid):validate_patch(self.patch,dest/'graph.json')
    def test_failures_do_not_change_base(self):
        original=sha(self.graph)
        for fault in ('exception','capacity'):
            with self.subTest(fault=fault):
                dest=self.root/fault
                with self.assertRaises((OSError,RuntimeError)):apply_patch(self.patch,self.graph,dest,store=self.root/('store-'+fault),fault=fault)
                self.assertEqual(sha(self.graph),original);self.assertFalse(dest.exists())
    def test_process_stop_does_not_change_base(self):
        before=sha(self.graph);dest=self.root/'killed';store=self.root/'kill-store'
        code='from ylm06.graph import apply_patch; import sys; apply_patch(*sys.argv[1:4],store=sys.argv[4],fault="process_stop")'
        proc=subprocess.run([sys.executable,'-c',code,str(self.patch),str(self.graph),str(dest),str(store)],capture_output=True)
        self.assertEqual(proc.returncode,97,proc.stderr);self.assertFalse(dest.exists());self.assertEqual(sha(self.graph),before)
    def test_stale_base_and_conflicting_pose(self):
        g=read(self.graph);g['version']+=1;p=self.root/'stale.json';write(p,seal_graph(g))
        with self.assertRaises(Invalid):validate_patch(self.patch,p)
        from ylm06.graph import apply_operations
        patch=read(self.patch);pose=next(op for op in patch['operations'] if op['type']=='UPDATE_POSE')
        duplicate=copy.deepcopy(pose);duplicate['operation_id']='other'
        with self.assertRaises(Invalid):apply_operations(read(self.graph),[pose,duplicate])
    def test_missing_evidence_rejected(self):
        patch=read(self.patch);patch['operations'][0]['decision_status']='HELD';dest=self.patch.parent/'invalid.json';write(dest,patch)
        with self.assertRaises(Invalid):validate_patch(dest,self.graph)
    def test_resume_fingerprints(self):
        result=run(self.cfg,self.run_dir,resume=True);self.assertEqual(result['run_id'],self.manifest['run_id'])
        with self.assertRaises(Invalid):run(self.cfg,self.run_dir)
        cfg=read(self.cfg);cfg['resources']['detailed_pairs']=1;dest=self.cfg.parent/'changed.json';write(dest,cfg)
        with self.assertRaises(Invalid):run(dest,self.run_dir,resume=True)
    def test_resume_input_and_source_mismatch(self):
        from unittest.mock import patch
        cfg=read(self.cfg);cfg['run_id']='another-input';dest=self.cfg.parent/'changed_input.json';write(dest,cfg)
        with self.assertRaises(Invalid):run(dest,self.run_dir,resume=True)
        with patch('ylm06.pipeline.sources',return_value={'replacement_source.py':'different'}):
            with self.assertRaises(Invalid):run(self.cfg,self.run_dir,resume=True)
    def test_verify_and_relocation(self):
        result=verify(self.run_dir);self.assertTrue(result['integrity_passed'])
        import shutil
        dest=self.root/'relocated';shutil.copytree(self.run_dir,dest)
        self.assertTrue(verify(dest)['integrity_passed'])
    def test_bootstrap(self):
        dest=self.root/'bootstrap';r=bootstrap(self.cfg.parent/'bootstrap.json',dest);self.assertEqual(r['nodes'],1)
        g=read(dest/'graph.json');check_graph(g);self.assertEqual(g['nodes'][0]['model']['geometry_status'],'VERIFIED')
        with self.assertRaises(Invalid):bootstrap(self.cfg.parent/'bootstrap.json',dest)
    def test_legacy_import_keeps_unmatched_attributes_and_edges(self):
        raw={'nodes':[{'id':'M0','attributes':{'label':'chair'}},{'id':'M1','custom':5}],
            'edges':[{'source':'M0','target':'M1','relation_type':'next','custom':3}],'extra':7}
        model=read(self.graph)['nodes'][0]['model'];g=import_legacy(raw,'legacy','G',{'M0':model,'M1':model});check_graph(g)
        self.assertEqual(g['raw_legacy_graph'],raw);self.assertEqual(len(g['edges']),1)
        self.assertEqual(g['nodes'][0]['model']['geometry_status'],'UNVERIFIED_IMPORTED_GEOMETRY')
    def test_correction_transaction_preserves_history(self):
        # A correction is a new transaction on the current graph; it never rewrites history.
        from ylm06.graph import operation,apply_operations,content_hash
        base=read(self.graph);g=copy.deepcopy(base);g['history']=[{'transaction_id':'tx:earlier'}];g=seal_graph(g)
        gp=self.root/'fixture/correction_base.json';write(gp,g)
        patch=read(self.patch);patch['base']['hash']=g['hash'];patch['transaction_id']='tx:correction';patch['correction_of']='tx:earlier'
        preview=apply_operations(g,patch['operations']);patch['expected_postconditions']['content_hash_before_version_increment']=content_hash(preview)
        pp=self.patch.parent/'correction.json';write(pp,patch)
        dest=self.root/'correction';apply_patch(pp,gp,dest,store=self.root/'correction-store')
        after=read(dest/'graph.json');self.assertEqual(after['history'][0],{'transaction_id':'tx:earlier'});self.assertEqual(after['history'][-1]['correction_of'],'tx:earlier')


if __name__=='__main__':unittest.main()
