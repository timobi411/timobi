"""Verify the files shipped in this release using only the Python standard library."""
import hashlib
import json
from pathlib import Path


def main():
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / "release_manifest.json").read_text(encoding="utf-8"))
    failures = []
    for entry in manifest["files"]:
        path = root / entry["path"]
        if not path.is_file():
            failures.append({"path": entry["path"], "reason": "MISSING"})
            continue
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        if path.stat().st_size != entry["bytes"] or h.hexdigest() != entry["sha256"]:
            failures.append({"path": entry["path"], "reason": "SIZE_OR_HASH_MISMATCH"})
    print(json.dumps({"integrity_passed": not failures, "files_checked": len(manifest["files"]),
                      "failures": failures}, ensure_ascii=False, indent=2))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
