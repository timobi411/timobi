# v0.5.1.2 比較実験の完全監査ログ

主プログラムZIP `ylm_scene_graph_integrated_v0512_boundary_audit.zip` の追加資料です。E1～E4 × 4ケースの16実行について、生成archive、全拡張イベント、全接触幾何、全ペア幾何・ゲート、全保存選択履歴、元設定・hash・検証結果を格納します。主ZIPにはE0 × 4ケースの完全な表示・再生用出力を同梱しています。

各ディレクトリは監査記録の抜粋です。元Viewer・旧探索trace・候補画素NPYなどは重複していないため、単独のverify/replay用runではありません。全体の入力snapshotは主ZIPの同じデータ名の `validation/real/` にあります。元の入力絶対パスは歴史的記録として保持します。

完全出力を再生成する場合は、主ZIPのソースで次を実行します。

```bash
python -m ylm051 generate --input validation/real/exp02_t1/input_contract.json --profile validation/profiles/exp02_t1_E1.json --out outputs/exp02_t1_E1
python -m ylm051 audit-verify --run outputs/exp02_t1_E1
```

各runの `audit_verification.json` は、元の完全出力に対する検証結果です。この追加ZIPのファイル完全性は `python examples/verify_release.py` と `release_manifest.json` で別途検査できます。

全20条件の比較表・解釈・資源は主ZIPの `validation/REPORT_ja.md` と `comparison_summary.json` を参照してください。proxy330画素の評価資料は未受領であり、物体精度・同一性は未評価です。
