# T0–T1 物体レジストレーション v0.1 実験版

採用版のグラフを読み、新しい結果フォルダに物体ごとの判定・姿勢差分・関係の更新・点群・HTMLを保存します。実環境での成功率は未測定です。

## 最初に実行する例

Python 3 と Open3D、NumPy、SciPy、Plotly を使います。クラウドでは Python 3.12 と Open3D 0.20 で確認しました。研究PCでは仮想環境内で実行してください。

```bash
python -m pip install numpy scipy open3d plotly
python verify.py synthetic
python compare.py synthetic/job.json synthetic_comparison --truth synthetic/truth.json
python movement_trial.py synthetic_move
python prepare_job.py /path/to/t0_scene_graph_with_unknown_min301.json experiment.json
```

生成した experiment.json の objects に、実験前に決めた mobility、use_for_scene_alignment、reason を入力します。undecided は探索対象で、未確認unknownを基準にする初期設定はありません。照合しないノードは objects から除くと履歴が保留で残ります。グラフは nodes の id または object_id と source_ply を読みます。移設したPLYは paths でID別に指定できます。unknown_manifest は元の未割当PLYを参照します。

t1_ply は共通T1座標系の点群です。各視点の origin と rays_npz の directions（N×3 の単位方向）も同じT1座標系にそろえます。ranges は同じ順序の距離[m]で無反射・無効は NaN にします。センサー姿勢は視点ごとに適用してから保存してください。視野を円錐で表せる場合は fov_axis と half_angle_deg を指定できます。初期変換 initial_T_T0_from_T1 と、各固定基準に対応するT1の点番号（0始まり）を anchor_indices に設定します。単一平面などで拘束が不足すると更新を保留します。

正式な個別ICPは adaptive_icp_v11 に研究室版のPythonファイルを指定します。必要な入口は evaluate_pair(t0_cloud,t1_cloud) で、返り値には valid と transformation（モデルをT0内の新姿勢へ移す4×4行列）が必要です。異なる入口の場合はこの形式のアダプターが必要です。配布物の run_partial_icp_matching_v2.py を試す場合は experimental_icp にそのパスを指定します。比較時のB0用には b0_files に t0/t1_temporal_median.pcd と t0/t1で始まる *_occlusion_data.npz をファイル名から保存場所への辞書として指定します。B0の入力座標は位置合わせ済みのクラスタと一致させてください。

```bash
python registration.py experiment.json result_new
python compare.py experiment.json comparison_new --truth evaluation_truth.json
```

正解の例は verify.py が生成する synthetic/truth.json にあります。正解は集計でのみ読みます。対象IDごとの t1_indices、moved、既知であれば pose、固定物点の採点対象は fixed_indices に指定します。thresholds.json は未校正の初期値です。調整観測で設定した値を保存し、別の評価観測に同じファイルを指定してください。

## 結果の読み方

alignment.json の matrix は T1 → T0。candidates.json は候補ごとの姿勢・根拠・採否。ray_counts は距離一致、奥まで通過、手前で遮蔽、視野外の順で、複数視点では重複し得ます。matched_area は一致ボクセル数×幅の二乗で近似した面積です。spread は三次元の広がりで、特定の椅子部品に意味ラベルを付ける機能はありません。updated_scene_graph.json の t1_registration.pose は元のT0モデルに作用する変換です。移動確定時の near は点間最短距離を使います。壁 T0_W001 は0.30 m、物体同士は object_near_m です。既存辺は source/target/relation または from/to/type の形式に対応します。

fixed_*、observed_*、candidate_*、unknown.ply の元点番号は付属の indices.npy で追えます。candidate_* は選別前の候補で、観測点の所属を集計するときは fixed_*、observed_*、unknown を使います。reference_* は採用姿勢に置いたT0モデルです。overlay.html の凡例で表示を切り替えられます。既存グラフへの自動書き戻しは行いません。

## 試験範囲

validation/ に合成結果を収録しました。元姿勢の試験では改良版が固定基準と可動物の2 IDを保持し、個別ICPは0回。単一平面のケースは保留。移動試験は部分的に点を除いた物体を用い、旧局所ICPで移動を検出しました。これは研究室版V1.1の検証とは別の結果です。3個体同点の割当・視線状態は機能単位の試験です。実際の椅子やゴミ箱の5条件、全40ノードの読込、視点ごとの実測較正は未検証です。多視点の可視性評価は各視点を使いますが、再クラスタリングの距離基準は先頭視点です。

legacy/ は受領テンプレートです。これらは以前の割当結果を消失・出現として出力するため、新しい実行入口は registration.py にしました。Adaptive Clustering V2 と B0 の2スクリプト、実験用局所ICPは既配布の vNext ZIP から回収しました。
