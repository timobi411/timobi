"""Create an editable experiment job from the accepted node list."""
import argparse
from pathlib import Path
import registration as r
import numpy as np
ap=argparse.ArgumentParser()
ap.add_argument('graph',type=Path)
ap.add_argument('new_job',type=Path)
args=ap.parse_args()
graph=r.read(args.graph)
keys=[n.get('object_id',n.get('id')) for n in graph['nodes']]
if None in keys or len(keys)!=len(set(keys)): raise ValueError('Check node ID fields')
if args.new_job.exists(): raise FileExistsError(args.new_job)
r.write(args.new_job,dict(graph=str(args.graph.resolve()),config=str(Path(__file__).with_name('thresholds.json').resolve()),unknown_manifest=str(args.graph.resolve().with_name('unknown_clusters_manifest.json')),
                          paths={k:str((args.graph.resolve().parent/n['source_ply']).resolve()) for k,n in zip(keys,graph['nodes'])},
                          objects={k:dict(mobility='undecided',use_for_scene_alignment=False,reason='実験条件未指定') for k in keys},
                          anchor_indices={},frame_id='T1',initial_T_T0_from_T1=np.eye(4).tolist(),t1_ply='t1.ply',
                          views=[dict(origin=[0,0,0],rays_npz='view_0.npz')]))
