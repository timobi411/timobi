"""Synthetic movement test using the explicitly identified experimental ICP."""
import sys
from pathlib import Path
import numpy as np
import registration as r
from smoke import fixture

folder=Path(sys.argv[1]).resolve()
job=fixture(folder)
obj=r.load(folder/'object.ply')
anchor=r.load(folder/'anchor.ply')
# Remove part of the second surface in the moved observation.
part=obj[obj[:,1]<.28]+[.42,.10,.02]
target=np.vstack((anchor,part))
r.od.io.write_point_cloud(str(folder/'scene.ply'),r.cloud(target))
origin=np.array(job['views'][0]['origin'])
rays=target-origin
depth=np.linalg.norm(rays,axis=1)
np.savez(folder/'rays.npz',directions=rays/depth[:,None],ranges=depth)
job['experimental_icp']=str(Path(__file__).resolve().with_name('run_partial_icp_matching_v2.py'))
r.write(folder/'job.json',job)
r.main(folder/'job.json',folder/'result')
print(r.read(folder/'result/diff.json')['object'])
