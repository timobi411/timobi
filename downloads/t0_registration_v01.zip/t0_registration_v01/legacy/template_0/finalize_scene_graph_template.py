#!/usr/bin/env python3

import json
import shutil
from pathlib import Path

import numpy as np
import open3d as o3d
import plotly.graph_objects as go
from plotly.subplots import make_subplots


# ============================================================
# Experiment
# ============================================================

EXP_NAME = "exp07"

T0_JSON = Path("t0_merged_clusters.json")
T1_JSON = Path("t1_merged_clusters.json")
ASSIGNMENT_JSON = Path("hungarian_assignment_results.json")

OUTPUT_DIR = Path("exp07_final")

MOVED_TRANSLATION_THRESHOLD = 0.30


# ============================================================
# Utility
# ============================================================

def load_json(path):
    if not path.exists():
        raise FileNotFoundError(path)

    with open(path, "r") as f:
        return json.load(f)


def load_points(path):
    cloud = o3d.io.read_point_cloud(str(path))
    pts = np.asarray(cloud.points)

    if len(pts) == 0:
        return np.empty((0, 3))

    return pts[np.isfinite(pts).all(axis=1)]


def compute_geometry(info):
    pts = load_points(info["pcd"])

    if len(pts) == 0:
        return (
            np.zeros(3),
            np.zeros(3),
            0,
        )

    center = np.mean(pts, axis=0)
    extent = pts.max(axis=0) - pts.min(axis=0)

    return center, extent, len(pts)


def get_info_by_mid(data, mid):
    for x in data:
        if int(x["merged_id"]) == int(mid):
            return x

    return None


def object_id_for_t0(mid):
    return f"object_M{mid}"


# ============================================================
# T0 initial scene graph
# ============================================================

def build_initial_graph(t0_data):
    nodes = []

    for info in t0_data:
        mid = int(info["merged_id"])

        center, extent, count = compute_geometry(info)

        nodes.append({
            "id": object_id_for_t0(mid),
            "label": "unknown",
            "source_merged_id": mid,
            "state": "initial",
            "active": True,
            "center": center.tolist(),
            "extent": extent.tolist(),
            "points": count,
            "pcd": str(info["pcd"]),
        })

    return {
        "experiment": EXP_NAME,
        "time": "T0",
        "nodes": nodes,
        "edges": [],
    }


# ============================================================
# T1 estimated scene graph
# ============================================================

def build_updated_graph(t0_data, t1_data, assignment):
    nodes = []

    # --------------------------------------------------------
    # matched
    # --------------------------------------------------------

    for match in assignment["matched"]:
        t0_id = int(match["t0_id"])
        t1_id = int(match["t1_id"])

        t0_info = get_info_by_mid(t0_data, t0_id)
        t1_info = get_info_by_mid(t1_data, t1_id)

        if t0_info is None or t1_info is None:
            continue

        t0_center, t0_extent, t0_count = compute_geometry(t0_info)
        t1_center, t1_extent, t1_count = compute_geometry(t1_info)

        state = str(match["state"]).lower()

        # Scene Graph update rule:
        # STATIC -> registered T0 position is retained
        # MOVED  -> position/extent are updated to T1 observation
        if state == "moved":
            graph_center = t1_center
            graph_extent = t1_extent
            graph_pcd = str(t1_info["pcd"])
        else:
            graph_center = t0_center
            graph_extent = t0_extent
            graph_pcd = str(t0_info["pcd"])

        nodes.append({
            "id": object_id_for_t0(t0_id),
            "label": "unknown",
            "state": state,
            "active": True,

            "source_t0_merged_id": t0_id,
            "source_t1_merged_id": t1_id,

            "center": graph_center.tolist(),
            "extent": graph_extent.tolist(),
            "pcd": graph_pcd,

            "t0_center": t0_center.tolist(),
            "observed_t1_center": t1_center.tolist(),

            "t0_points": t0_count,
            "t1_points": t1_count,

            "t0_pcd": str(t0_info["pcd"]),
            "t1_pcd": str(t1_info["pcd"]),

            "registration": {
                "score": float(match["score"]),
                "fitness": float(match["fitness"]),
                "rmse_m": float(match["rmse"]),
                "t0_coverage": float(match["t0_coverage"]),
                "t1_coverage": float(match["t1_coverage"]),
                "icp_translation_m":
                    float(match["icp_translation_m"]),
                "center_translation_m":
                    float(match["obb_center_translation_m"]),
                "yaw_deg_record_only":
                    float(match["yaw_deg"]),
            },
        })

    # --------------------------------------------------------
    # disappeared
    # --------------------------------------------------------

    for item in assignment["disappeared"]:
        t0_id = int(item["t0_id"])

        t0_info = get_info_by_mid(t0_data, t0_id)

        if t0_info is None:
            continue

        center, extent, count = compute_geometry(t0_info)

        nodes.append({
            "id": object_id_for_t0(t0_id),
            "label": "unknown",
            "state": "disappeared",
            "active": False,

            "source_t0_merged_id": t0_id,

            # 最終観測位置を記録として保持
            "center": center.tolist(),
            "extent": extent.tolist(),
            "points": count,
            "pcd": str(t0_info["pcd"]),
        })

    # --------------------------------------------------------
    # appeared
    # --------------------------------------------------------

    for item in assignment["appeared"]:
        t1_id = int(item["t1_id"])

        t1_info = get_info_by_mid(t1_data, t1_id)

        if t1_info is None:
            continue

        center, extent, count = compute_geometry(t1_info)

        nodes.append({
            "id": f"appeared_M{t1_id}",
            "label": "unknown",
            "state": "appeared",
            "active": True,

            "source_t1_merged_id": t1_id,

            "center": center.tolist(),
            "extent": extent.tolist(),
            "points": count,
            "pcd": str(t1_info["pcd"]),
        })

    return {
        "experiment": EXP_NAME,
        "time": "T1_estimated",

        "state_decision": {
            "translation_threshold_m":
                MOVED_TRANSLATION_THRESHOLD,

            "rotation_used":
                False,

            "reason":
                (
                    "STATIC/MOVED classification uses "
                    "ICP translation. Yaw is recorded "
                    "but is not used for the state decision."
                ),
        },

        "nodes": nodes,
        "edges": [],
    }


# ============================================================
# HTML
# ============================================================

def make_html(t0_data, t1_data, assignment):

    fig = make_subplots(
        rows=2,
        cols=2,

        specs=[
            [
                {"type": "scene"},
                {"type": "table"},
            ],
            [
                {"type": "scene"},
                {"type": "scene"},
            ],
        ],

        column_widths=[
            0.72,
            0.28,
        ],

        row_heights=[
            0.58,
            0.42,
        ],

        subplot_titles=[
            "Estimated Scene Graph Update",
            "Assignment Result",
            "Top View (XY)",
            "Side View (XZ)",
        ],
    )

    table_rows = []

    # ========================================================
    # 共通点群追加関数
    # ========================================================

    def add_object_to_scenes(
        points,
        name,
        hovertemplate,
        marker_size=2,
        opacity=0.65,
        symbol="circle",
    ):

        if len(points) == 0:
            return

        # 3D自由視点
        fig.add_trace(
            go.Scatter3d(
                x=points[:, 0],
                y=points[:, 1],
                z=points[:, 2],
                mode="markers",
                name=name,
                marker=dict(
                    size=marker_size,
                    opacity=opacity,
                    symbol=symbol,
                ),
                hovertemplate=hovertemplate,
                legendgroup=name,
            ),
            row=1,
            col=1,
        )

        # XY上面
        fig.add_trace(
            go.Scatter3d(
                x=points[:, 0],
                y=points[:, 1],
                z=points[:, 2],
                mode="markers",
                name=name,
                marker=dict(
                    size=marker_size,
                    opacity=opacity,
                    symbol=symbol,
                ),
                hovertemplate=hovertemplate,
                legendgroup=name,
                showlegend=False,
            ),
            row=2,
            col=1,
        )

        # XZ側面
        fig.add_trace(
            go.Scatter3d(
                x=points[:, 0],
                y=points[:, 1],
                z=points[:, 2],
                mode="markers",
                name=name,
                marker=dict(
                    size=marker_size,
                    opacity=opacity,
                    symbol=symbol,
                ),
                hovertemplate=hovertemplate,
                legendgroup=name,
                showlegend=False,
            ),
            row=2,
            col=2,
        )


    def add_movement_to_scenes(
        c0,
        c1,
        name,
        hovertemplate,
    ):

        for row, col in [
            (1, 1),
            (2, 1),
            (2, 2),
        ]:

            fig.add_trace(
                go.Scatter3d(
                    x=[c0[0], c1[0]],
                    y=[c0[1], c1[1]],
                    z=[c0[2], c1[2]],
                    mode="lines+markers",
                    name=name,
                    line=dict(
                        width=7
                    ),
                    marker=dict(
                        size=5
                    ),
                    hovertemplate=hovertemplate,
                    legendgroup=name,
                    showlegend=(
                        row == 1
                        and
                        col == 1
                    ),
                ),
                row=row,
                col=col,
            )

    # ========================================================
    # Matched objects
    # ========================================================

    for match in assignment["matched"]:

        t0_id = int(
            match["t0_id"]
        )

        t1_id = int(
            match["t1_id"]
        )

        state = str(
            match["state"]
        ).lower()

        stage = match.get(
            "assignment_stage",
            "hungarian"
        )

        t0_info = get_info_by_mid(
            t0_data,
            t0_id
        )

        t1_info = get_info_by_mid(
            t1_data,
            t1_id
        )

        if (
            t0_info is None
            or
            t1_info is None
        ):
            continue

        p0 = load_points(
            t0_info["pcd"]
        )

        p1 = load_points(
            t1_info["pcd"]
        )

        c0, _, _ = compute_geometry(
            t0_info
        )

        c1, _, _ = compute_geometry(
            t1_info
        )

        # ----------------------------------------------------
        # 表示する現在形状
        #
        # STATIC:
        #   現在のT1点群を表示
        #
        # MOVED:
        #   移動後のT1点群を表示
        #
        # つまり最終Scene GraphはT1現在状態で統一
        # ----------------------------------------------------

        display_points = p1
        display_center = c1

        add_object_to_scenes(
            display_points,
            f"M{t0_id} {state.upper()}",
            (
                f"T0 M{t0_id} → "
                f"T1 M{t1_id}"
                f"<br>{state.upper()}"
                f"<br>stage={stage}"
                "<extra></extra>"
            ),
            marker_size=2,
            opacity=0.65,
        )

        # ----------------------------------------------------
        # MOVEDだけ移動ベクトル表示
        # ----------------------------------------------------

        if state == "moved":

            add_movement_to_scenes(
                c0,
                c1,
                f"M{t0_id} movement",
                (
                    f"M{t0_id} MOVED"
                    f"<br>ICP="
                    f"{match['icp_translation_m']:.3f} m"
                    "<extra></extra>"
                ),
            )

        # ----------------------------------------------------
        # Table
        # ----------------------------------------------------

        if (
            state == "static"
            and
            stage == "identity_static_first"
        ):

            metric = (
                "identity "
                f"cov={match.get('identity_max_coverage', 0.0):.3f}"
            )

            motion = (
                "center "
                f"{match.get('identity_center_distance_m', 0.0):.3f}"
            )

        else:

            metric = (
                f"{match['score']:.3f}"
            )

            motion = (
                f"{match['icp_translation_m']:.3f}"
            )

        table_rows.append([
            f"M{t0_id} → M{t1_id}",
            state.upper(),
            metric,
            motion,
        ])

    # ========================================================
    # Appeared
    # ========================================================

    for item in assignment["appeared"]:

        t1_id = int(
            item["t1_id"]
        )

        info = get_info_by_mid(
            t1_data,
            t1_id
        )

        if info is None:
            continue

        pts = load_points(
            info["pcd"]
        )

        add_object_to_scenes(
            pts,
            f"T1 M{t1_id} APPEARED",
            (
                f"T1 M{t1_id}"
                "<br>APPEARED"
                "<extra></extra>"
            ),
            marker_size=2.5,
            opacity=0.8,
            symbol="diamond",
        )

        table_rows.append([
            f"- → M{t1_id}",
            "APPEARED",
            "-",
            "-",
        ])

    # ========================================================
    # Disappeared
    # ========================================================

    for item in assignment["disappeared"]:

        t0_id = int(
            item["t0_id"]
        )

        table_rows.append([
            f"M{t0_id} → -",
            "DISAPPEARED",
            "-",
            "-",
        ])

    # ========================================================
    # Result table
    # ========================================================

    if table_rows:
        columns = list(
            zip(*table_rows)
        )
    else:
        columns = [
            [],
            [],
            [],
            [],
        ]

    fig.add_trace(
        go.Table(
            header=dict(
                values=[
                    "Correspondence",
                    "State",
                    "Metric",
                    "Motion / Center [m]",
                ]
            ),
            cells=dict(
                values=[
                    list(columns[0]),
                    list(columns[1]),
                    list(columns[2]),
                    list(columns[3]),
                ]
            ),
        ),
        row=1,
        col=2,
    )

    # ========================================================
    # Scene settings
    # ========================================================

    common_scene = dict(
        xaxis_title="X [m]",
        yaxis_title="Y [m]",
        zaxis_title="Z [m]",
        aspectmode="data",
    )

    # 自由視点
    fig.update_layout(
        scene=common_scene,
    )

    # --------------------------------------------------------
    # XY top view
    #
    # cameraをZ軸上から原点方向へ向ける
    # --------------------------------------------------------

    fig.update_layout(
        scene2=dict(
            **common_scene,
            camera=dict(
                eye=dict(
                    x=0.0,
                    y=0.0,
                    z=2.5,
                ),
                up=dict(
                    x=0.0,
                    y=1.0,
                    z=0.0,
                ),
            ),
        ),
    )

    # --------------------------------------------------------
    # XZ side view
    #
    # Y軸方向から見る
    # --------------------------------------------------------

    fig.update_layout(
        scene3=dict(
            **common_scene,
            camera=dict(
                eye=dict(
                    x=0.0,
                    y=-2.5,
                    z=0.0,
                ),
                up=dict(
                    x=0.0,
                    y=0.0,
                    z=1.0,
                ),
            ),
        ),
    )

    fig.update_layout(
        title=(
            "Experiment 07 - "
            "Dynamic Scene Graph Update"
        ),

        width=1750,
        height=1300,

        margin=dict(
            l=20,
            r=20,
            b=20,
            t=90,
        ),
    )

    output = (
        OUTPUT_DIR
        /
        "scene_graph_update.html"
    )

    fig.write_html(
        output,
        include_plotlyjs=True,
    )


# ============================================================
# main
# ============================================================

def main():
    t0_data = load_json(T0_JSON)
    t1_data = load_json(T1_JSON)
    assignment = load_json(ASSIGNMENT_JSON)

    if OUTPUT_DIR.exists():
        shutil.rmtree(OUTPUT_DIR)

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    initial_graph = build_initial_graph(
        t0_data
    )

    updated_graph = build_updated_graph(
        t0_data,
        t1_data,
        assignment,
    )

    with open(
        OUTPUT_DIR / "initial_scene_graph.json",
        "w"
    ) as f:
        json.dump(
            initial_graph,
            f,
            indent=2,
        )

    with open(
        OUTPUT_DIR / "updated_scene_graph.json",
        "w"
    ) as f:
        json.dump(
            updated_graph,
            f,
            indent=2,
        )

    states = {
        "static": 0,
        "moved": 0,
        "appeared": 0,
        "disappeared": 0,
    }

    for node in updated_graph["nodes"]:
        state = node["state"]

        if state in states:
            states[state] += 1

    summary = {
        "experiment": EXP_NAME,

        "input": {
            "t0_objects": len(t0_data),
            "t1_objects": len(t1_data),
        },

        "assignment": {
            "matched":
                len(assignment["matched"]),

            "appeared":
                len(assignment["appeared"]),

            "disappeared":
                len(assignment["disappeared"]),
        },

        "estimated_scene_graph": {
            "static": states["static"],
            "moved": states["moved"],
            "appeared": states["appeared"],
            "disappeared": states["disappeared"],
        },

        "decision": {
            "moved_translation_threshold_m":
                MOVED_TRANSLATION_THRESHOLD,

            "rotation_used_for_state":
                False,
        },
    }

    with open(
        OUTPUT_DIR / "experiment_summary.json",
        "w"
    ) as f:
        json.dump(
            summary,
            f,
            indent=2,
        )

    make_html(
        t0_data,
        t1_data,
        assignment,
    )

    print()
    print("==========================================")
    print("Experiment 07 COMPLETE")
    print("==========================================")
    print()

    print("T0 objects   :", len(t0_data))
    print("T1 objects   :", len(t1_data))
    print()

    print("STATIC       :", states["static"])
    print("MOVED        :", states["moved"])
    print("APPEARED     :", states["appeared"])
    print("DISAPPEARED  :", states["disappeared"])

    print()
    print("------------------------------------------")
    print("Matched objects")
    print("------------------------------------------")

    for x in assignment["matched"]:
        print(
            f"T0 M{x['t0_id']} -> "
            f"T1 M{x['t1_id']}  "
            f"{str(x['state']).upper():<10} "
            f"score={x['score']:.4f}  "
            f"ICP={x['icp_translation_m']:.4f} m"
        )

    print()
    print("Disappeared :",
          [f"M{x['t0_id']}"
           for x in assignment["disappeared"]])

    print("Appeared    :",
          [f"M{x['t1_id']}"
           for x in assignment["appeared"]])

    print()
    print("------------------------------------------")
    print("Files")
    print("------------------------------------------")

    for name in [
        "initial_scene_graph.json",
        "updated_scene_graph.json",
        "experiment_summary.json",
        "scene_graph_update.html",
    ]:
        print(OUTPUT_DIR / name)

    print()
    print("==========================================")


if __name__ == "__main__":
    main()
