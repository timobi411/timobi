import sys
from pathlib import Path
import numpy as np
import registration as r

def fixture(folder):
    folder.mkdir()
    grid=np.linspace(-.32,.32,20)
    x,y=np.meshgrid(grid,grid)
    face=np.column_stack((x.ravel(),y.ravel(),np.zeros(x.size)))
    anchors=np.vstack((face+[0,0,2],face[:,[2,0,1]]+[1,0,2],face[:,[0,2,1]]+[0,1,2]))
    obj=np.vstack((face+[0,0,3], face[:,[2,0,1]]+[.34,0,3]))
    origin=np.array([-1.,-1.,0.])
    combined=np.vstack((anchors,obj))
    for name,points in [('anchor',anchors),('object',obj),('scene',combined)]:
        r.od.io.write_point_cloud(str(folder/(name+'.ply')),r.cloud(points))
    vec=combined-origin
    dist=np.linalg.norm(vec,axis=1)
    np.savez(folder/'rays.npz',directions=vec/dist[:,None],ranges=dist)
    keys=['anchor','object']
    r.write(folder/'graph.json',dict(nodes=[dict(id=k,source_ply=k+'.ply') for k in keys],edges=[]))
    job=dict(frame_id='synthetic',graph='graph.json',config=str(Path(__file__).resolve().with_name('thresholds.json')),t1_ply='scene.ply',
             initial_T_T0_from_T1=np.eye(4).tolist(),views=[dict(origin=origin.tolist(),rays_npz='rays.npz')],
             objects={k:dict(mobility=m,reason='synthetic fixture',use_for_scene_alignment=k=='anchor') for k,m in zip(keys,['fixed','movable'])},
             anchor_indices=dict(anchor=list(range(len(anchors)))))
    r.write(folder/'job.json',job)
    return job

if __name__=='__main__':
    folder=Path(sys.argv[1]).resolve()
    job=fixture(folder)
    r.main(folder/'job.json',folder/'result')
    print(r.read(folder/'result/run.json'),r.read(folder/'result/diff.json')['object'])
    assert r.read(folder/'result/alignment.json')['verified']
    assert r.assignment(np.ones((3,3)),.01)=={}
    job['anchor_indices']['anchor']=list(range(400))
    r.write(folder/'plane.json',job)
    r.main(folder/'plane.json',folder/'degenerate')
    assert not r.read(folder/'degenerate/alignment.json')['verified']
