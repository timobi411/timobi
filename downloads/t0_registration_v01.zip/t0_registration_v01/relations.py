import numpy as np
from scipy.spatial import cKDTree


def update(graph, keys, models, decisions, cfg, frame):
    field = 'relations' if 'relations' in graph else 'edges'
    edges = graph.setdefault(field, [])
    updated = []
    changes = []
    existing = {}
    for e in edges:
        a = e.get('source', e.get('from'))
        b = e.get('target', e.get('to'))
        kind = e.get('relation', e.get('type', e.get('predicate')))
        if kind == 'near' and a in models and b in models:
            existing[frozenset((a,b))] = e
        else:
            updated.append(e)
    for i,a in enumerate(keys):
        for b in keys[i+1:]:
            edge = existing.get(frozenset((a,b)))
            status = [decisions[k]['status'] for k in (a,b)]
            if any(s not in ('static','moved') for s in status) or 'moved' not in status:
                if edge is not None:
                    updated.append(dict(edge,last_confirmed_frame=edge.get('last_confirmed_frame','T0')))
                continue
            pair=[]
            for k in (a,b):
                m=np.array(decisions[k].get('pose',np.eye(4)))
                pair.append(models[k]@m[:3,:3].T+m[:3,3])
            distance=float(cKDTree(pair[0]).query(pair[1])[0].min())
            near=distance <= (0.30 if 'T0_W001' in (a,b) else cfg['object_near_m'])
            if near:
                updated.append(dict(edge or {'source':a,'target':b,'relation':'near'},distance_m=distance,last_confirmed_frame=frame))
            changes.append(dict(source=a,target=b,was_near=edge is not None,near=near,distance_m=distance))
    graph[field]=updated
    return changes
