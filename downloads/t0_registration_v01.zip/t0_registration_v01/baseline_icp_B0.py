#!/usr/bin/env python3

import json
import math
from copy import deepcopy
from pathlib import Path

import numpy as np
import open3d as o3d
from scipy.spatial import cKDTree
import plotly.graph_objects as go


# ============================================================
# Input
# ============================================================

T0_JSON = Path("t0_merged_clusters.json")
T1_JSON = Path("t1_merged_clusters.json")

OUTPUT_JSON = Path("partial_icp_results_fixed_repro.json")
OUTPUT_HTML = Path("partial_icp_results_fixed_repro.html")


# ============================================================
# ICP
# ============================================================

VOXEL = 0.01

COARSE_DISTANCE = 0.35
FINE_DISTANCE = 0.08

MAX_ITER = 150

# Global scene registration後なので、
# 大回転を最初から許さず局所的に探索する。
YAW_CANDIDATES = [
    -30, -20, -10,
    0,
    10, 20, 30
]


# ============================================================
# Partial-match criteria
# ============================================================

MIN_NORMAL_SCORE = 0.65

MIN_PARTIAL_COVERAGE = 0.90
MAX_PARTIAL_RMSE = 0.05

MAX_ICP_MOVEMENT = 1.20

# ============================================================
# OBB candidate gate
# ============================================================

MAX_OBB_CENTER_DISTANCE = 1.50
MIN_OBB_DIAG_RATIO = 0.45


def load_json(path):
    with open(path) as f:
        return json.load(f)


def load_cloud(path):

    cloud = o3d.io.read_point_cloud(
        str(path)
    )

    pts = np.asarray(
        cloud.points
    )

    pts = pts[
        np.isfinite(pts).all(axis=1)
    ]

    result = o3d.geometry.PointCloud()

    result.points = (
        o3d.utility.Vector3dVector(
            pts
        )
    )

    return result


def rotation_about_center(
    center,
    yaw_deg
):

    yaw = math.radians(
        yaw_deg
    )

    c = math.cos(yaw)
    s = math.sin(yaw)

    R = np.array([
        [c, -s, 0.0],
        [s,  c, 0.0],
        [0.0, 0.0, 1.0],
    ])

    T = np.eye(4)

    T[:3, :3] = R

    # source自身の中心回りにだけ回転
    # target中心へ強制移動しない
    T[:3, 3] = (
        center
        -
        R @ center
    )

    return T


def compute_coverage(
    source,
    target,
    transform,
):

    transformed = deepcopy(
        source
    )

    transformed.transform(
        transform
    )

    d0 = np.asarray(
        transformed.compute_point_cloud_distance(
            target
        )
    )

    d1 = np.asarray(
        target.compute_point_cloud_distance(
            transformed
        )
    )

    t0_cov = float(
        np.mean(
            d0 <= FINE_DISTANCE
        )
    )

    t1_cov = float(
        np.mean(
            d1 <= FINE_DISTANCE
        )
    )

    return (
        t0_cov,
        t1_cov
    )


def transformed_center_movement(
    center,
    transform
):

    c_after = (
        transform[:3, :3] @ center
        +
        transform[:3, 3]
    )

    return float(
        np.linalg.norm(
            c_after - center
        )
    )


def yaw_from_transform(T):

    return float(
        math.degrees(
            math.atan2(
                T[1, 0],
                T[0, 0]
            )
        )
    )


# ============================================================
# 4DoF planar ICP
#
# 許可:
#   x / y / z translation
#   yaw rotation
#
# 禁止:
#   roll / pitch
# ============================================================

class PlanarICPResult:

    def __init__(
        self,
        transformation,
        fitness,
        inlier_rmse
    ):
        self.transformation = transformation
        self.fitness = fitness
        self.inlier_rmse = inlier_rmse


def planar_rigid_fit(
    source_points,
    target_points
):

    src_center = np.mean(
        source_points,
        axis=0
    )

    dst_center = np.mean(
        target_points,
        axis=0
    )

    src_xy = (
        source_points[:, :2]
        -
        src_center[:2]
    )

    dst_xy = (
        target_points[:, :2]
        -
        dst_center[:2]
    )

    H = (
        src_xy.T
        @
        dst_xy
    )

    U, _, Vt = np.linalg.svd(
        H
    )

    R2 = (
        Vt.T
        @
        U.T
    )

    # reflection防止
    if np.linalg.det(R2) < 0.0:

        Vt[-1, :] *= -1.0

        R2 = (
            Vt.T
            @
            U.T
        )

    R = np.eye(3)

    R[:2, :2] = R2

    translation = (
        dst_center
        -
        R @ src_center
    )

    T = np.eye(4)

    T[:3, :3] = R
    T[:3, 3] = translation

    return T


def transform_points(
    points,
    T
):

    return (
        points
        @
        T[:3, :3].T
        +
        T[:3, 3]
    )


def registration_icp_4dof(
    source,
    target,
    max_correspondence_distance,
    init,
    max_iteration
):

    source_points = np.asarray(
        source.points
    )

    target_points = np.asarray(
        target.points
    )

    if (
        len(source_points) == 0
        or
        len(target_points) == 0
    ):

        return PlanarICPResult(
            init.copy(),
            0.0,
            0.0
        )

    target_tree = cKDTree(
        target_points
    )

    T = init.copy()

    previous_rmse = None

    for _ in range(max_iteration):

        transformed = transform_points(
            source_points,
            T
        )

        distances, indices = (
            target_tree.query(
                transformed,
                k=1
            )
        )

        mask = (
            distances
            <=
            max_correspondence_distance
        )

        count = int(
            np.count_nonzero(
                mask
            )
        )

        if count < 3:
            break

        src_corr = transformed[
            mask
        ]

        dst_corr = target_points[
            indices[mask]
        ]

        delta = planar_rigid_fit(
            src_corr,
            dst_corr
        )

        T = (
            delta
            @
            T
        )

        transformed_after = transform_points(
            source_points[mask],
            T
        )

        errors = np.linalg.norm(
            transformed_after
            -
            dst_corr,
            axis=1
        )

        rmse = float(
            np.sqrt(
                np.mean(
                    errors ** 2
                )
            )
        )

        if previous_rmse is not None:

            if (
                abs(
                    previous_rmse
                    -
                    rmse
                )
                <
                1e-6
            ):
                break

        previous_rmse = rmse

    # 最終評価
    transformed = transform_points(
        source_points,
        T
    )

    distances, _ = target_tree.query(
        transformed,
        k=1
    )

    mask = (
        distances
        <=
        max_correspondence_distance
    )

    count = int(
        np.count_nonzero(
            mask
        )
    )

    fitness = (
        count
        /
        len(source_points)
    )

    if count > 0:

        inlier_rmse = float(
            np.sqrt(
                np.mean(
                    distances[mask] ** 2
                )
            )
        )

    else:

        inlier_rmse = 0.0

    return PlanarICPResult(
        T,
        float(fitness),
        float(inlier_rmse)
    )


def evaluate_pair(
    t0_cloud,
    t1_cloud
):

    t0 = t0_cloud.voxel_down_sample(
        VOXEL
    )

    t1 = t1_cloud.voxel_down_sample(
        VOXEL
    )

    p0 = np.asarray(
        t0.points
    )

    p1 = np.asarray(
        t1.points
    )

    if (
        len(p0) == 0
        or
        len(p1) == 0
    ):
        return None

    c0 = np.mean(
        p0,
        axis=0
    )

    c1 = np.mean(
        p1,
        axis=0
    )

    raw_center_distance = float(
        np.linalg.norm(
            c1 - c0
        )
    )

    criteria = (
        o3d.pipelines.registration
        .ICPConvergenceCriteria(
            max_iteration=MAX_ITER
        )
    )

    best = None

    for start_yaw in YAW_CANDIDATES:

        initial = rotation_about_center(
            c0,
            start_yaw
        )

        coarse = registration_icp_4dof(
            t0,
            t1,
            COARSE_DISTANCE,
            initial,
            MAX_ITER
        )

        fine = registration_icp_4dof(
            t0,
            t1,
            FINE_DISTANCE,
            coarse.transformation,
            MAX_ITER
        )

        t0_cov, t1_cov = (
            compute_coverage(
                t0,
                t1,
                fine.transformation
            )
        )

        partial_coverage = max(
            t0_cov,
            t1_cov
        )

        # correspondenceが0の場合に
        # RMSE=0で高評価しないようにする
        if fine.fitness <= 1e-9:

            rmse_score = 0.0
            score = 0.0

        else:

            rmse_score = max(
                0.0,
                1.0
                -
                fine.inlier_rmse
                /
                FINE_DISTANCE
            )

            # 部分観測を重視
            score = (
                0.45 * partial_coverage
                +
                0.25 * fine.fitness
                +
                0.30 * rmse_score
            )

        movement = (
            transformed_center_movement(
                c0,
                fine.transformation
            )
        )

        yaw = yaw_from_transform(
            fine.transformation
        )

        partial_match = (
            partial_coverage
            >=
            MIN_PARTIAL_COVERAGE
            and
            fine.inlier_rmse
            <=
            MAX_PARTIAL_RMSE
            and
            fine.fitness
            >
            0.0
        )

        normal_match = (
            score
            >=
            MIN_NORMAL_SCORE
        )

        movement_ok = (
            movement
            <=
            MAX_ICP_MOVEMENT
        )

        valid = (
            (
                normal_match
                or
                partial_match
            )
            and
            movement_ok
        )

        result = {
            "start_yaw_deg":
                int(start_yaw),

            "score":
                float(score),

            "fitness":
                float(
                    fine.fitness
                ),

            "rmse":
                float(
                    fine.inlier_rmse
                ),

            "t0_coverage":
                float(t0_cov),

            "t1_coverage":
                float(t1_cov),

            "partial_coverage":
                float(
                    partial_coverage
                ),

            "raw_center_distance_m":
                raw_center_distance,

            "icp_translation_m":
                float(movement),

            "yaw_deg":
                float(yaw),

            "normal_match":
                bool(normal_match),

            "partial_match":
                bool(partial_match),

            "movement_ok":
                bool(movement_ok),

            "valid":
                bool(valid),

            "transformation":
                fine.transformation.tolist(),
        }

        if (
            best is None
            or
            result["score"]
            >
            best["score"]
        ):
            best = result

    return best


def obb_candidate_gate(
    t0_info,
    t1_info
):

    c0 = np.asarray(
        t0_info.get(
            "center",
            [0.0, 0.0, 0.0]
        ),
        dtype=float
    )

    c1 = np.asarray(
        t1_info.get(
            "center",
            [0.0, 0.0, 0.0]
        ),
        dtype=float
    )

    e0 = np.asarray(
        t0_info.get(
            "extent",
            [0.0, 0.0, 0.0]
        ),
        dtype=float
    )

    e1 = np.asarray(
        t1_info.get(
            "extent",
            [0.0, 0.0, 0.0]
        ),
        dtype=float
    )

    center_distance = float(
        np.linalg.norm(
            c1 - c0
        )
    )

    d0 = float(
        np.linalg.norm(
            e0
        )
    )

    d1 = float(
        np.linalg.norm(
            e1
        )
    )

    if (
        d0 > 1e-9
        and
        d1 > 1e-9
    ):

        diag_ratio = (
            min(d0, d1)
            /
            max(d0, d1)
        )

    else:

        diag_ratio = 0.0

    center_ok = (
        center_distance
        <=
        MAX_OBB_CENTER_DISTANCE
    )

    diag_ok = (
        diag_ratio
        >=
        MIN_OBB_DIAG_RATIO
    )

    candidate = (
        center_ok
        and
        diag_ok
    )

    return {
        "candidate": bool(candidate),
        "center_distance_m":
            float(center_distance),
        "diag_ratio":
            float(diag_ratio),
        "center_ok":
            bool(center_ok),
        "diag_ok":
            bool(diag_ok),
    }


def main():

    t0_meta = load_json(
        T0_JSON
    )

    t1_meta = load_json(
        T1_JSON
    )

    print()
    print("======================================")
    print("Partial ICP Matching V2")
    print("======================================")

    print(
        "T0 objects:",
        len(t0_meta)
    )

    print(
        "T1 objects:",
        len(t1_meta)
    )

    print()
    print(
        "Normal score threshold:",
        MIN_NORMAL_SCORE
    )

    print(
        "Partial coverage threshold:",
        MIN_PARTIAL_COVERAGE
    )

    print(
        "Partial RMSE threshold:",
        MAX_PARTIAL_RMSE,
        "m"
    )

    print(
        "Maximum ICP movement:",
        MAX_ICP_MOVEMENT,
        "m"
    )

    # ========================================================
    # 全組合せを評価
    #
    # OBBサイズ差だけで事前除外しない。
    # 部分観測された物体をICPまで通す。
    # ========================================================

    results = []

    for t0_info in t0_meta:

        t0_id = int(
            t0_info["merged_id"]
        )

        t0_cloud = load_cloud(
            t0_info["pcd"]
        )

        for t1_info in t1_meta:

            t1_id = int(
                t1_info["merged_id"]
            )

            t1_cloud = load_cloud(
                t1_info["pcd"]
            )

            print()
            print("--------------------------------------")
            print(
                f"T0 M{t0_id} <-> T1 M{t1_id}"
            )

            gate = obb_candidate_gate(
                t0_info,
                t1_info
            )

            print(
                f"OBB center dist  = "
                f"{gate['center_distance_m']:.4f} m "
                f"{gate['center_ok']}"
            )

            print(
                f"OBB diag ratio   = "
                f"{gate['diag_ratio']:.4f} "
                f"{gate['diag_ok']}"
            )

            if not gate["candidate"]:

                print(
                    "OBB candidate     = False"
                )

                result = {
                    "start_yaw_deg": 0,
                    "score": 0.0,
                    "fitness": 0.0,
                    "rmse": 0.0,
                    "t0_coverage": 0.0,
                    "t1_coverage": 0.0,
                    "partial_coverage": 0.0,
                    "raw_center_distance_m":
                        gate["center_distance_m"],
                    "icp_translation_m": 0.0,
                    "yaw_deg": 0.0,
                    "normal_match": False,
                    "partial_match": False,
                    "movement_ok": True,
                    "valid": False,
                    "obb_candidate": False,
                    "obb_diag_ratio":
                        gate["diag_ratio"],
                    "transformation":
                        np.eye(4).tolist(),
                }

            else:

                print(
                    "OBB candidate     = True"
                )

                result = evaluate_pair(
                    t0_cloud,
                    t1_cloud
                )

                if result is not None:

                    result[
                        "obb_candidate"
                    ] = True

                    result[
                        "obb_diag_ratio"
                    ] = gate[
                        "diag_ratio"
                    ]

            if result is None:
                continue

            result[
                "t0_id"
            ] = t0_id

            result[
                "t1_id"
            ] = t1_id

            results.append(
                result
            )

            print(
                f"score            = "
                f"{result['score']:.4f}"
            )

            print(
                f"fitness          = "
                f"{result['fitness']:.4f}"
            )

            print(
                f"RMSE             = "
                f"{result['rmse']:.4f} m"
            )

            print(
                f"T0 coverage      = "
                f"{result['t0_coverage']:.4f}"
            )

            print(
                f"T1 coverage      = "
                f"{result['t1_coverage']:.4f}"
            )

            print(
                f"partial coverage = "
                f"{result['partial_coverage']:.4f}"
            )

            print(
                f"ICP movement     = "
                f"{result['icp_translation_m']:.4f} m"
            )

            print(
                f"yaw              = "
                f"{result['yaw_deg']:.2f} deg"
            )

            print(
                "normal match      =",
                result["normal_match"]
            )

            print(
                "partial match     =",
                result["partial_match"]
            )

            print(
                "movement OK       =",
                result["movement_ok"]
            )

            print(
                "RESULT            =",
                (
                    "VALID"
                    if result["valid"]
                    else "INVALID"
                )
            )

    # ========================================================
    # Ranking
    # ========================================================

    ranking = sorted(
        results,
        key=lambda x:
            x["score"],
        reverse=True
    )

    print()
    print("======================================")
    print("Ranking")
    print("======================================")

    for rank, x in enumerate(
        ranking,
        start=1
    ):

        print(
            f"{rank:2d}. "
            f"T0 M{x['t0_id']} "
            f"-> T1 M{x['t1_id']} "
            f"score={x['score']:.3f} "
            f"cov={x['partial_coverage']:.3f} "
            f"rmse={x['rmse']:.3f} "
            f"move={x['icp_translation_m']:.3f} "
            f"{'VALID' if x['valid'] else 'INVALID'}"
        )

    with open(
        OUTPUT_JSON,
        "w"
    ) as f:

        json.dump(
            results,
            f,
            indent=2
        )

    # ========================================================
    # Score matrix HTML
    # ========================================================

    t0_ids = [
        int(x["merged_id"])
        for x in t0_meta
    ]

    t1_ids = [
        int(x["merged_id"])
        for x in t1_meta
    ]

    matrix = np.full(
        (
            len(t0_ids),
            len(t1_ids)
        ),
        np.nan
    )

    text = np.empty(
        matrix.shape,
        dtype=object
    )

    text[:] = ""

    t0_index = {
        x: i
        for i, x in enumerate(
            t0_ids
        )
    }

    t1_index = {
        x: i
        for i, x in enumerate(
            t1_ids
        )
    }

    for x in results:

        i = t0_index[
            x["t0_id"]
        ]

        j = t1_index[
            x["t1_id"]
        ]

        matrix[i, j] = (
            x["score"]
        )

        if x["valid"]:

            state = "VALID"

        else:

            state = "INVALID"

        if x["partial_match"]:

            state += "<br>PARTIAL"

        text[i, j] = (
            f"{x['score']:.3f}"
            f"<br>{state}"
            f"<br>cov={x['partial_coverage']:.2f}"
            f"<br>move={x['icp_translation_m']:.2f}"
        )

    fig = go.Figure(
        data=go.Heatmap(
            z=matrix,

            x=[
                f"T1 M{x}"
                for x in t1_ids
            ],

            y=[
                f"T0 M{x}"
                for x in t0_ids
            ],

            zmin=0,
            zmax=1,

            colorscale="Viridis",

            text=text,

            texttemplate="%{text}",

            colorbar=dict(
                title="score"
            )
        )
    )

    fig.update_layout(
        title=(
            "Partial ICP V2 "
            "- Full Candidate Evaluation"
        ),

        width=1200,
        height=850
    )

    fig.write_html(
        OUTPUT_HTML,
        include_plotlyjs=True
    )

    print()
    print("======================================")
    print("Finished")
    print("======================================")

    print(
        "JSON:",
        OUTPUT_JSON
    )

    print(
        "HTML:",
        OUTPUT_HTML
    )

    print("======================================")


if __name__ == "__main__":
    main()
