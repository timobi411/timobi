"""Deterministic synthetic observations. No laboratory inputs needed."""
import argparse
from pathlib import Path
import numpy as np
import registration as r
from smoke import fixture

def organized(points, origin):
    v=points-origin
    dist=np.linalg.norm(v,axis=1)
    u=np.floor((np.arctan2(v[:,1],v[:,0])+np.pi)*512/(2*np.pi)).astype(int)%512
    h=np.clip(np.floor((np.arcsin(v[:,2]/dist)+np.pi/2)*256/np.pi).astype(int),0,255)
    xyz=np.zeros((256,512,3))
    ranges=np.zeros((256,512))
    for i in np.argsort(-dist):
        xyz[h[i],u[i]]=points[i]
        ranges[h[i],u[i]]=dist[i]
    return dict(xyz=xyz,valid=ranges>0,range_image=ranges)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('output',type=Path)
    folder=ap.parse_args().output.resolve()
    job=fixture(folder)
    xyz=r.load(folder/'scene.ply')
    origin=np.array(job['views'][0]['origin'])
    job['b0_files']={}
    for frame in ['t0','t1']:
        for name in [frame+'_temporal_median.pcd',frame+'_occlusion_data.npz']:
            if name.endswith('.pcd'):
                r.od.io.write_point_cloud(str(folder/name),r.cloud(xyz))
            else:
                np.savez(folder/name,**organized(xyz,origin))
            job['b0_files'][name]=name
    r.write(folder/'job.json',job)
    objects={k:dict(moved=False,pose=np.eye(4).tolist(),t1_indices=ids) for k,ids in [('anchor',list(range(1200))),('object',list(range(1200,len(xyz))))]}
    r.write(folder/'truth.json',dict(iou_threshold=.5,objects=objects,fixed_indices={'anchor':list(range(1200))}))
    r.main(folder/'job.json',folder/'static')
    assert r.read(folder/'static/diff.json')['object']['status']=='static'
    assert r.read(folder/'static/run.json')['icp_calls']==0
    job['anchor_indices']['anchor']=list(range(400))
    r.write(folder/'plane.json',job)
    r.main(folder/'plane.json',folder/'plane')
    assert not r.read(folder/'plane/alignment.json')['verified']
    cfg=r.read(job['config'])
    pts=np.eye(3)
    obs=[(np.zeros(3),np.eye(3),np.array([.4,2.,np.nan]),None)]
    flags=r.visibility(pts,obs,cfg)
    assert flags[0,2] and flags[1,1] and not flags[2].any()
    assert r.assignment(np.ones((3,3)),.1)=={}
