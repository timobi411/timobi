#!/usr/bin/env python3

import json
from pathlib import Path

import numpy as np
import open3d as o3d
from scipy.optimize import linear_sum_assignment
import plotly.graph_objects as go
from plotly.subplots import make_subplots


# ============================================================
# 入力
# ============================================================

PARTIAL_JSON = Path(
    "partial_icp_results_fixed_repro.json"
)

T0_JSON = Path("t0_merged_clusters.json")

T1_JSON = Path("t1_merged_clusters.json")


# ============================================================
# 候補ゲート
# ============================================================

MIN_MATCH_SCORE = 0.65

# 実環境で同一物体として探索する最大移動量
MAX_ICP_TRANSLATION = 1.2

# ============================================================
# 形状サイズ整合性ゲート
# ============================================================

MIN_POINT_RATIO = 0.20
MIN_DIAG_RATIO = 0.55


# ============================================================
# 変化判定
# ============================================================

MOVED_TRANSLATION = 0.30
MOVED_ROTATION_DEG = 20.0


# ============================================================
# Global MOVED Assignment
#
# Strong MOVED:
# 従来の信頼度が高い移動対応。
#
# Partial MOVED:
# 遮蔽・部分観測により片方向coverageだけが非常に高い場合を
# 別の厳しい条件で候補へ戻す。
#
# MOVED_TRANSLATION自体は緩めない。
# ============================================================

STRONG_MOVED_MIN_BIDIR_COV = 0.75
STRONG_MOVED_MAX_RMSE_M = 0.030
STRONG_MOVED_MIN_ICP_MOVE_M = 0.30

PARTIAL_MOVED_MAX_COV_MIN = 0.95
PARTIAL_MOVED_MIN_COV_MIN = 0.40
PARTIAL_MOVED_MAX_RMSE_M = 0.030

PARTIAL_MOVED_MIN_ICP_MOVE_M = 0.20
PARTIAL_MOVED_MIN_CENTER_MOVE_M = 0.30

PARTIAL_MOVED_MIN_EXTENT_SIM = 0.60
PARTIAL_MOVED_MIN_POINT_RATIO = 0.15

# ============================================================
# STATIC first-pass
# ============================================================

STATIC_CENTER_DISTANCE = 0.30
STATIC_MAX_ICP_TRANSLATION = 0.10
STATIC_MIN_SCORE = 0.65

# ============================================================
# Identity-based STATIC gate
# ============================================================

IDENTITY_VOXEL = 0.01
IDENTITY_DISTANCE = 0.08

IDENTITY_MAX_CENTER_DISTANCE = 0.30
IDENTITY_MIN_COVERAGE = 0.60
IDENTITY_MAX_RMSE = 0.03


# ============================================================
# Dummy Hungarian
# ============================================================

UNMATCHED_COST = 0.25
INVALID_COST = 1000.0


# ============================================================
# 出力
# ============================================================

OUTPUT_JSON = Path(
    "hungarian_assignment_fixed_repro.json"
)

HTML_PATH = Path(
    "hungarian_assignment_fixed_repro.html"
)


def load_json(path):

    if not path.exists():
        raise FileNotFoundError(path)

    with open(path, "r") as f:
        return json.load(f)



# ============================================================
# Identity-based STATIC evaluation
# ============================================================

def load_object_cloud(info):

    path = Path(
        info["pcd"]
    )

    cloud = o3d.io.read_point_cloud(
        str(path)
    )

    return cloud.voxel_down_sample(
        IDENTITY_VOXEL
    )


def compute_identity_metrics(
    t0_cloud,
    t1_cloud
):

    p0 = np.asarray(
        t0_cloud.points
    )

    p1 = np.asarray(
        t1_cloud.points
    )

    if (
        len(p0) == 0
        or
        len(p1) == 0
    ):
        return {
            "center_distance": float("inf"),
            "t0_coverage": 0.0,
            "t1_coverage": 0.0,
            "max_coverage": 0.0,
            "rmse": float("inf"),
        }

    c0 = np.mean(
        p0,
        axis=0
    )

    c1 = np.mean(
        p1,
        axis=0
    )

    center_distance = float(
        np.linalg.norm(
            c1 - c0
        )
    )

    # T0 -> T1
    d01 = np.asarray(
        t0_cloud.compute_point_cloud_distance(
            t1_cloud
        )
    )

    # T1 -> T0
    d10 = np.asarray(
        t1_cloud.compute_point_cloud_distance(
            t0_cloud
        )
    )

    mask01 = (
        d01 <= IDENTITY_DISTANCE
    )

    mask10 = (
        d10 <= IDENTITY_DISTANCE
    )

    t0_coverage = float(
        np.mean(mask01)
    )

    t1_coverage = float(
        np.mean(mask10)
    )

    max_coverage = max(
        t0_coverage,
        t1_coverage
    )

    inlier_distances = np.concatenate([
        d01[mask01],
        d10[mask10],
    ])

    if len(inlier_distances) > 0:

        rmse = float(
            np.sqrt(
                np.mean(
                    inlier_distances ** 2
                )
            )
        )

    else:

        rmse = float("inf")

    return {
        "center_distance":
            center_distance,

        "t0_coverage":
            t0_coverage,

        "t1_coverage":
            t1_coverage,

        "max_coverage":
            max_coverage,

        "rmse":
            rmse,
    }


def identity_static_ok(metrics):

    return (
        metrics["center_distance"]
        <=
        IDENTITY_MAX_CENTER_DISTANCE

        and

        metrics["max_coverage"]
        >=
        IDENTITY_MIN_COVERAGE

        and

        metrics["rmse"]
        <=
        IDENTITY_MAX_RMSE
    )


def extract_results(data):

    if isinstance(data, list):
        return data

    if isinstance(data, dict):

        for key in [
            "results",
            "pairs",
            "candidates",
            "matches",
        ]:

            if (
                key in data
                and isinstance(data[key], list)
            ):
                return data[key]

    raise RuntimeError(
        "partial_icp_results.json の"
        "候補リストを検出できません。"
    )


def first_value(
    item,
    keys,
    default=None
):

    for key in keys:

        if (
            key in item
            and item[key] is not None
        ):
            return item[key]

    return default


def normalize_result(item):

    t0_id = first_value(
        item,
        [
            "t0_id",
            "source_id",
            "t0",
        ]
    )

    t1_id = first_value(
        item,
        [
            "t1_id",
            "target_id",
            "t1",
        ]
    )

    score = first_value(
        item,
        ["score"],
        0.0
    )

    fitness = first_value(
        item,
        ["fitness"],
        0.0
    )

    rmse = first_value(
        item,
        [
            "rmse",
            "inlier_rmse",
        ],
        float("inf")
    )

    t0_coverage = first_value(
        item,
        [
            "t0_coverage",
            "source_coverage",
        ],
        0.0
    )

    t1_coverage = first_value(
        item,
        [
            "t1_coverage",
            "target_coverage",
        ],
        0.0
    )

    size_similarity = first_value(
        item,
        [
            "size_similarity",
            "size_score",
        ],
        0.0
    )

    icp_translation = first_value(
        item,
        [
            "icp_translation_m",
            "translation_m",
            "translation",
        ],
        float("inf")
    )

    center_translation = first_value(
        item,
        [
            "obb_center_translation_m",
            "center_translation_m",
            "center_movement_m",
        ],
        float("nan")
    )

    yaw = first_value(
        item,
        [
            "yaw_deg",
            "yaw",
        ],
        0.0
    )

    if t0_id is None or t1_id is None:
        raise RuntimeError(
            f"T0/T1 IDを取得できません: {item}"
        )

    return {
        "t0_id": int(t0_id),
        "t1_id": int(t1_id),

        "score": float(score),
        "fitness": float(fitness),
        "rmse": float(rmse),

        "t0_coverage":
            float(t0_coverage),

        "t1_coverage":
            float(t1_coverage),

        "size_similarity":
            float(size_similarity),

        "icp_translation_m":
            float(icp_translation),

        "obb_center_translation_m":
            float(center_translation),

        "yaw_deg":
            float(yaw),
    }


def determine_state(result):

    # ========================================================
    # Change detection
    #
    # 実LiDARの部分点群では、欠損・視点差・形状対称性により
    # ICP yawが約180°反転することがある。
    #
    # ICP自体は同一物体対応に利用するが、
    # 現段階のMOVED/STATIC判定では並進量を主指標とする。
    # ========================================================

    translation = abs(
        result["icp_translation_m"]
    )

    if translation >= MOVED_TRANSLATION:
        return "moved"

    return "static"



def main():

    partial_data = load_json(
        PARTIAL_JSON
    )

    raw_results = extract_results(
        partial_data
    )

    results = [
        normalize_result(x)
        for x in raw_results
    ]

    t0_meta = load_json(
        T0_JSON
    )

    t1_meta = load_json(
        T1_JSON
    )

    t0_ids = [
        int(x["merged_id"])
        for x in t0_meta
    ]

    t1_ids = [
        int(x["merged_id"])
        for x in t1_meta
    ]

    t0_index = {
        object_id: i
        for i, object_id
        in enumerate(t0_ids)
    }

    t1_index = {
        object_id: i
        for i, object_id
        in enumerate(t1_ids)
    }

    # ========================================================
    # T0 / T1 の物体中心
    #
    # Partial ICP JSON側にcenter movementが入っていない場合でも、
    # merged cluster JSONに保存された中心座標から直接算出する。
    # ========================================================

    def get_object_center(info):

        for key in [
            "center",
            "obb_center",
            "centroid",
        ]:

            if key in info and info[key] is not None:

                center = np.asarray(
                    info[key],
                    dtype=float
                )

                if center.shape == (3,):
                    return center

        return None


    t0_center_map = {
        int(info["merged_id"]):
            get_object_center(info)
        for info in t0_meta
    }

    t1_center_map = {
        int(info["merged_id"]):
            get_object_center(info)
        for info in t1_meta
    }


    # ========================================================
    # T0 / T1 の点数・サイズ
    # ========================================================

    def get_object_size_info(info):

        points = int(
            info.get(
                "points",
                0
            )
        )

        extent = np.asarray(
            info.get(
                "extent",
                [0.0, 0.0, 0.0]
            ),
            dtype=float
        )

        if extent.shape != (3,):
            extent = np.zeros(
                3,
                dtype=float
            )

        diagonal = float(
            np.linalg.norm(
                extent
            )
        )

        return {
            "points": points,
            "diagonal": diagonal,
        }


    t0_size_map = {
        int(info["merged_id"]):
            get_object_size_info(info)
        for info in t0_meta
    }

    t1_size_map = {
        int(info["merged_id"]):
            get_object_size_info(info)
        for info in t1_meta
    }


    for result in results:

        current = result[
            "obb_center_translation_m"
        ]

        # Partial ICPから取得できなかった場合だけ補完
        if np.isnan(current):

            t0_id = result["t0_id"]
            t1_id = result["t1_id"]

            c0 = t0_center_map.get(
                t0_id
            )

            c1 = t1_center_map.get(
                t1_id
            )

            if (
                c0 is not None
                and
                c1 is not None
            ):

                result[
                    "obb_center_translation_m"
                ] = float(
                    np.linalg.norm(
                        c1 - c0
                    )
                )

    n0 = len(t0_ids)
    n1 = len(t1_ids)

    print()
    print("======================================")
    print("Gated Dummy Hungarian Assignment")
    print("======================================")

    print(
        "T0 objects:",
        n0
    )

    print(
        "T1 objects:",
        n1
    )

    print(
        "Minimum match score:",
        MIN_MATCH_SCORE
    )

    print(
        "Maximum ICP translation:",
        MAX_ICP_TRANSLATION,
        "m"
    )

    print(
        "Unmatched cost:",
        UNMATCHED_COST
    )

    # ========================================================
    # score matrix
    # ========================================================

    score_matrix = np.full(
        (n0, n1),
        np.nan,
        dtype=float
    )

    valid_matrix = np.zeros(
        (n0, n1),
        dtype=bool
    )

    result_map = {}

    print()
    print("======================================")
    print("Candidate Gate")
    print("======================================")

    for result in results:

        t0_id = result["t0_id"]
        t1_id = result["t1_id"]

        if (
            t0_id not in t0_index
            or
            t1_id not in t1_index
        ):
            continue

        i = t0_index[t0_id]
        j = t1_index[t1_id]

        score = result["score"]

        move = result[
            "icp_translation_m"
        ]

        # ====================================================
        # 形状サイズ整合性
        # ====================================================

        size0 = t0_size_map[
            t0_id
        ]

        size1 = t1_size_map[
            t1_id
        ]

        p0 = size0["points"]
        p1 = size1["points"]

        d0 = size0["diagonal"]
        d1 = size1["diagonal"]

        if (
            p0 > 0
            and
            p1 > 0
        ):

            point_ratio = (
                min(p0, p1)
                /
                max(p0, p1)
            )

        else:

            point_ratio = 0.0

        if (
            d0 > 1e-9
            and
            d1 > 1e-9
        ):

            diag_ratio = (
                min(d0, d1)
                /
                max(d0, d1)
            )

        else:

            diag_ratio = 0.0

        size_ok = (
            point_ratio
            >=
            MIN_POINT_RATIO
            and
            diag_ratio
            >=
            MIN_DIAG_RATIO
        )


        # ====================================================
        # 形状サイズ整合性
        # ====================================================

        size0 = t0_size_map[
            t0_id
        ]

        size1 = t1_size_map[
            t1_id
        ]

        p0 = size0["points"]
        p1 = size1["points"]

        d0 = size0["diagonal"]
        d1 = size1["diagonal"]

        if (
            p0 > 0
            and
            p1 > 0
        ):

            point_ratio = (
                min(p0, p1)
                /
                max(p0, p1)
            )

        else:

            point_ratio = 0.0

        if (
            d0 > 1e-9
            and
            d1 > 1e-9
        ):

            diag_ratio = (
                min(d0, d1)
                /
                max(d0, d1)
            )

        else:

            diag_ratio = 0.0

        size_ok = (
            point_ratio
            >=
            MIN_POINT_RATIO
            and
            diag_ratio
            >=
            MIN_DIAG_RATIO
        )


        score_ok = (
            score
            >=
            MIN_MATCH_SCORE
        )

        partial_coverage = max(
            result["t0_coverage"],
            result["t1_coverage"]
        )

        partial_ok = (
            partial_coverage >= 0.90
            and
            result["rmse"] <= 0.05
        )

        translation_ok = (
            move
            <=
            MAX_ICP_TRANSLATION
        )

        valid = (
            (
                score_ok
                or
                partial_ok
            )
            and
            translation_ok
            and
            size_ok
        )

        score_matrix[i, j] = score
        valid_matrix[i, j] = valid

        result_map[
            (i, j)
        ] = result

        print()
        print(
            f"T0 M{t0_id} "
            f"<-> "
            f"T1 M{t1_id}"
        )

        print(
            f" score       = "
            f"{score:.4f} "
            f"{score_ok}"
        )

        print(
            f" ICP move    = "
            f"{move:.4f} m "
            f"{translation_ok}"
        )

        print(
            f" point ratio = "
            f"{point_ratio:.4f} "
            f"{point_ratio >= MIN_POINT_RATIO}"
        )

        print(
            f" diag ratio  = "
            f"{diag_ratio:.4f} "
            f"{diag_ratio >= MIN_DIAG_RATIO}"
        )

        print(
            f" size OK     = "
            f"{size_ok}"
        )

        print(
            " RESULT       =",
            "VALID"
            if valid
            else "INVALID"
        )

    # ========================================================
    # Augmented Hungarian cost matrix
    #
    # [ real-real    T0-dummy ]
    # [ T1-dummy     dummy    ]
    # ========================================================

    # ========================================================
    # Identity-based STATIC first-pass
    #
    # 登録位置に物体が残っているかを、
    # 移動探索ICPを行う前に確認する。
    #
    # ここではT0/T1点群を変換せず、そのまま比較する。
    #
    # 条件:
    #   center distance <= threshold
    #   identity coverage >= threshold
    #   identity RMSE <= threshold
    #
    # STATIC確認ではsize gateを使用しない。
    # T0/T1で遮蔽・部分観測・depth splitが異なると
    # 点数やOBB寸法が変わるため。
    #
    # STATIC確定後、そのT0/T1は後段Hungarianから除外する。
    # ========================================================

    static_matches = []
    static_t0 = set()
    static_t1 = set()

    static_candidates = []

    print()
    print("======================================")
    print("Identity STATIC Candidate Evaluation")
    print("======================================")

    # --------------------------------------------------------
    # 全T0/T1組について、変換なしで元位置一致度を評価
    # --------------------------------------------------------

    for i, t0_info in enumerate(t0_meta):

        t0_id = t0_ids[i]

        t0_cloud = load_object_cloud(
            t0_info
        )

        npts0 = int(
            t0_info.get(
                "points",
                len(t0_cloud.points)
            )
        )

        extent0 = np.asarray(
            t0_info.get(
                "extent",
                [0.0, 0.0, 0.0]
            ),
            dtype=float
        )

        diag0 = float(
            np.linalg.norm(
                extent0
            )
        )

        for j, t1_info in enumerate(t1_meta):

            t1_id = t1_ids[j]

            t1_cloud = load_object_cloud(
                t1_info
            )

            metrics = compute_identity_metrics(
                t0_cloud,
                t1_cloud
            )

            npts1 = int(
                t1_info.get(
                    "points",
                    len(t1_cloud.points)
                )
            )

            extent1 = np.asarray(
                t1_info.get(
                    "extent",
                    [0.0, 0.0, 0.0]
                ),
                dtype=float
            )

            diag1 = float(
                np.linalg.norm(
                    extent1
                )
            )

            # ----------------------------------------------
            # size gate
            # ----------------------------------------------

            if (
                npts0 > 0
                and
                npts1 > 0
            ):

                point_ratio = (
                    min(npts0, npts1)
                    /
                    max(npts0, npts1)
                )

            else:

                point_ratio = 0.0

            if (
                diag0 > 1e-9
                and
                diag1 > 1e-9
            ):

                diag_ratio = (
                    min(diag0, diag1)
                    /
                    max(diag0, diag1)
                )

            else:

                diag_ratio = 0.0

            size_ok = (
                point_ratio
                >=
                MIN_POINT_RATIO
                and
                diag_ratio
                >=
                MIN_DIAG_RATIO
            )

            # ==============================================
            # STATIC判定
            #
            # 登録位置にその物体が存在するかを判定する段階では、
            # size gateを使用しない。
            #
            # ・center distance
            # ・identity coverage
            # ・identity RMSE
            #
            # のみで元位置一致を判定する。
            #
            # point_ratio / diag_ratio は診断用として保持する。
            # ==============================================

            identity_ok = (
                identity_static_ok(
                    metrics
                )
            )

            # 候補になったものだけログ表示
            if identity_ok:

                print()
                print(
                    f"T0 M{t0_id} "
                    f"<-> T1 M{t1_id}"
                )

                print(
                    " center       = "
                    f"{metrics['center_distance']:.4f} m"
                )

                print(
                    " T0 coverage  = "
                    f"{metrics['t0_coverage']:.4f}"
                )

                print(
                    " T1 coverage  = "
                    f"{metrics['t1_coverage']:.4f}"
                )

                print(
                    " max coverage = "
                    f"{metrics['max_coverage']:.4f}"
                )

                print(
                    " identity RMSE= "
                    f"{metrics['rmse']:.4f} m"
                )

                print(
                    " point ratio  = "
                    f"{point_ratio:.4f}"
                )

                print(
                    " diag ratio   = "
                    f"{diag_ratio:.4f}"
                )

                print(
                    " RESULT       = STATIC CANDIDATE"
                )

                # ------------------------------------------------
                # STATIC候補の優先順位
                #
                # 1. center distanceが小さい
                #    -> 登録位置に最も近い物体を最優先
                #
                # 2. coverageが高い
                #
                # 3. RMSEが小さい
                # ------------------------------------------------

                static_candidates.append(
                    (
                        float(
                            metrics[
                                "center_distance"
                            ]
                        ),
                        -float(
                            metrics[
                                "max_coverage"
                            ]
                        ),
                        float(
                            metrics[
                                "rmse"
                            ]
                        ),
                        i,
                        j,
                        metrics,
                        point_ratio,
                        diag_ratio,
                    )
                )

    # --------------------------------------------------------
    # 1対1になるようにSTATICを確定
    # --------------------------------------------------------

    static_candidates.sort()

    for (
        center_distance,
        negative_coverage,
        identity_rmse,
        i,
        j,
        metrics,
        point_ratio,
        diag_ratio,
    ) in static_candidates:

        t0_id = t0_ids[i]
        t1_id = t1_ids[j]

        if t0_id in static_t0:
            continue

        if t1_id in static_t1:
            continue

        # partial ICP側の情報が存在すれば、
        # 最終JSON用にそれをベースとして利用する。
        original_result = result_map.get(
            (i, j)
        )

        if original_result is not None:

            result = dict(
                original_result
            )

        else:

            result = {
                "t0_id": int(t0_id),
                "t1_id": int(t1_id),

                "score": 0.0,
                "fitness": 0.0,
                "rmse": float(
                    metrics["rmse"]
                ),

                "t0_coverage": float(
                    metrics["t0_coverage"]
                ),

                "t1_coverage": float(
                    metrics["t1_coverage"]
                ),

                "size_similarity": 0.0,

                "icp_translation_m": 0.0,

                "obb_center_translation_m":
                    float(center_distance),

                "yaw_deg": 0.0,
            }

        # ----------------------------------------------------
        # 状態判定はidentity結果でSTATIC確定
        # ----------------------------------------------------

        result["state"] = "static"

        result[
            "assignment_stage"
        ] = "identity_static_first"

        result[
            "identity_center_distance_m"
        ] = float(
            metrics["center_distance"]
        )

        result[
            "identity_t0_coverage"
        ] = float(
            metrics["t0_coverage"]
        )

        result[
            "identity_t1_coverage"
        ] = float(
            metrics["t1_coverage"]
        )

        result[
            "identity_max_coverage"
        ] = float(
            metrics["max_coverage"]
        )

        result[
            "identity_rmse_m"
        ] = float(
            metrics["rmse"]
        )

        result[
            "identity_point_ratio"
        ] = float(
            point_ratio
        )

        result[
            "identity_diag_ratio"
        ] = float(
            diag_ratio
        )

        static_matches.append(
            result
        )

        static_t0.add(
            t0_id
        )

        static_t1.add(
            t1_id
        )

    print()
    print("======================================")
    print("Identity STATIC First-pass")
    print("======================================")

    if not static_matches:

        print(
            "No STATIC objects were confirmed."
        )

    for result in static_matches:

        print()

        print(
            f"T0 M{result['t0_id']} "
            f"-> T1 M{result['t1_id']}"
        )

        print(
            " identity center = "
            f"{result['identity_center_distance_m']:.4f} m"
        )

        print(
            " identity cover  = "
            f"{result['identity_max_coverage']:.4f}"
        )

        print(
            " identity RMSE   = "
            f"{result['identity_rmse_m']:.4f} m"
        )

        print(
            " state           = STATIC"
        )

    # ========================================================
    # Global Assignment Candidate Matrix
    #
    # Identity STATICで確定した物体を除いた残りについて、
    #
    #   1. Strong MOVED
    #   2. Partial MOVED
    #   3. 従来の通常Hungarian候補
    #
    # を同じglobal assignmentへ入れる。
    #
    # 特定のM番号は一切使用しない。
    # ========================================================

    assignment_utility_matrix = np.full(
        (n0, n1),
        np.nan,
        dtype=float
    )

    assignment_valid_matrix = np.zeros(
        (n0, n1),
        dtype=bool
    )

    assignment_stage_matrix = np.empty(
        (n0, n1),
        dtype=object
    )

    assignment_stage_matrix[:] = None


    t0_meta_by_id = {
        int(x["merged_id"]): x
        for x in t0_meta
    }

    t1_meta_by_id = {
        int(x["merged_id"]): x
        for x in t1_meta
    }


    def global_extent_similarity(
        info0,
        info1
    ):

        e0 = np.sort(
            np.asarray(
                info0.get(
                    "extent",
                    [0.0, 0.0, 0.0]
                ),
                dtype=float
            )
        )

        e1 = np.sort(
            np.asarray(
                info1.get(
                    "extent",
                    [0.0, 0.0, 0.0]
                ),
                dtype=float
            )
        )

        denom = np.maximum(
            e0,
            e1
        )

        valid_axes = (
            denom > 1e-9
        )

        if not np.all(valid_axes):
            return 0.0

        ratio = (
            np.minimum(
                e0,
                e1
            )
            /
            denom
        )

        return float(
            np.mean(ratio)
        )


    print()
    print("======================================")
    print("Global MOVED Candidate Evaluation")
    print("======================================")


    for i in range(n0):

        for j in range(n1):

            t0_id = int(
                t0_ids[i]
            )

            t1_id = int(
                t1_ids[j]
            )


            # Identity STATICはロック
            if (
                t0_id in static_t0
                or
                t1_id in static_t1
            ):
                continue


            original_result = result_map.get(
                (i, j)
            )

            if original_result is None:
                continue


            score = float(
                original_result.get(
                    "score",
                    0.0
                )
            )

            t0_cov = float(
                original_result.get(
                    "t0_coverage",
                    0.0
                )
            )

            t1_cov = float(
                original_result.get(
                    "t1_coverage",
                    0.0
                )
            )

            min_cov = min(
                t0_cov,
                t1_cov
            )

            max_cov = max(
                t0_cov,
                t1_cov
            )

            rmse = float(
                original_result.get(
                    "rmse",
                    float("inf")
                )
            )

            icp_move = float(
                original_result.get(
                    "icp_translation_m",
                    float("inf")
                )
            )


            # ------------------------------------------------
            # center movement
            # ------------------------------------------------

            c0 = t0_center_map.get(
                t0_id
            )

            c1 = t1_center_map.get(
                t1_id
            )

            if (
                c0 is None
                or
                c1 is None
            ):

                center_move = float(
                    original_result.get(
                        "obb_center_translation_m",
                        float("inf")
                    )
                )

            else:

                center_move = float(
                    np.linalg.norm(
                        c1 - c0
                    )
                )


            # ------------------------------------------------
            # point ratio
            # ------------------------------------------------

            info0 = t0_meta_by_id[
                t0_id
            ]

            info1 = t1_meta_by_id[
                t1_id
            ]

            p0 = int(
                info0.get(
                    "points",
                    0
                )
            )

            p1 = int(
                info1.get(
                    "points",
                    0
                )
            )

            if (
                p0 > 0
                and
                p1 > 0
            ):

                point_ratio = (
                    min(p0, p1)
                    /
                    max(p0, p1)
                )

            else:

                point_ratio = 0.0


            extent_sim = (
                global_extent_similarity(
                    info0,
                    info1
                )
            )


            # =================================================
            # Strong MOVED
            #
            # 元のvalid_matrixも要求することで、
            # 従来のcandidate gateを壊さない。
            # =================================================

            strong_moved = (
                bool(
                    valid_matrix[
                        i, j
                    ]
                )

                and
                score
                >=
                MIN_MATCH_SCORE

                and
                min_cov
                >=
                STRONG_MOVED_MIN_BIDIR_COV

                and
                rmse
                <=
                STRONG_MOVED_MAX_RMSE_M

                and
                icp_move
                >=
                STRONG_MOVED_MIN_ICP_MOVE_M

                and
                icp_move
                <=
                MAX_ICP_TRANSLATION
            )


            # =================================================
            # Partial MOVED
            #
            # 一方向のcoverageだけが高い部分点群を許可する。
            #
            # ただし、
            # ・反対方向coverage
            # ・RMSE
            # ・移動量
            # ・中心変化
            # ・OBB寸法
            # ・点数比
            # を同時に要求する。
            # =================================================

            partial_moved = (
                max_cov
                >=
                PARTIAL_MOVED_MAX_COV_MIN

                and
                min_cov
                >=
                PARTIAL_MOVED_MIN_COV_MIN

                and
                rmse
                <=
                PARTIAL_MOVED_MAX_RMSE_M

                and
                icp_move
                >=
                PARTIAL_MOVED_MIN_ICP_MOVE_M

                and
                icp_move
                <=
                MAX_ICP_TRANSLATION

                and
                center_move
                >=
                PARTIAL_MOVED_MIN_CENTER_MOVE_M

                and
                extent_sim
                >=
                PARTIAL_MOVED_MIN_EXTENT_SIM

                and
                point_ratio
                >=
                PARTIAL_MOVED_MIN_POINT_RATIO
            )


            # =================================================
            # Common assignment utility
            # =================================================

            if strong_moved:

                stage = "strong_moved"

                utility = float(
                    score
                )


            elif partial_moved:

                stage = "partial_moved"

                rmse_quality = max(
                    0.0,
                    1.0
                    -
                    rmse
                    /
                    PARTIAL_MOVED_MAX_RMSE_M
                )

                utility = float(
                    0.30
                    *
                    max_cov

                    +
                    0.25
                    *
                    min_cov

                    +
                    0.20
                    *
                    extent_sim

                    +
                    0.10
                    *
                    point_ratio

                    +
                    0.10
                    *
                    rmse_quality
                )


            # 従来valid候補はそのまま残す。
            # これにより、Identity STATICから漏れた
            # T0 M5 -> T1 M8のような通常STATICも失わない。
            elif valid_matrix[
                i, j
            ]:

                stage = "hungarian"

                utility = float(
                    score_matrix[
                        i, j
                    ]
                )


            else:
                continue


            assignment_valid_matrix[
                i, j
            ] = True

            assignment_utility_matrix[
                i, j
            ] = utility

            assignment_stage_matrix[
                i, j
            ] = stage


            print()
            print(
                f"T0 M{t0_id} "
                f"-> T1 M{t1_id}"
            )

            print(
                f" stage       = {stage}"
            )

            print(
                f" utility     = {utility:.4f}"
            )

            print(
                f" raw score   = {score:.4f}"
            )

            print(
                f" coverage    = "
                f"{t0_cov:.4f} / "
                f"{t1_cov:.4f}"
            )

            print(
                f" RMSE        = {rmse:.4f} m"
            )

            print(
                f" ICP move    = "
                f"{icp_move:.4f} m"
            )

            print(
                f" center move = "
                f"{center_move:.4f} m"
            )

            print(
                f" extent sim  = "
                f"{extent_sim:.4f}"
            )

            print(
                f" point ratio = "
                f"{point_ratio:.4f}"
            )


    size = n0 + n1

    cost = np.full(
        (size, size),
        INVALID_COST,
        dtype=float
    )

    # --------------------------------------------------------
    # real T0 -> real T1
    # --------------------------------------------------------

    for i in range(n0):

        for j in range(n1):

            # STATIC first-passで使用済みの物体は
            # 後段Hungarianでは使用しない
            if (
                t0_ids[i] in static_t0
                or
                t1_ids[j] in static_t1
            ):
                continue

            if not assignment_valid_matrix[
                i, j
            ]:
                continue

            cost[i, j] = (
                1.0
                -
                assignment_utility_matrix[
                    i, j
                ]
            )

    # --------------------------------------------------------
    # T0 -> disappeared dummy
    # --------------------------------------------------------

    for i in range(n0):

        cost[
            i,
            n1 + i
        ] = UNMATCHED_COST

    # --------------------------------------------------------
    # appeared dummy -> T1
    # --------------------------------------------------------

    for j in range(n1):

        cost[
            n0 + j,
            j
        ] = UNMATCHED_COST

    # --------------------------------------------------------
    # dummy -> dummy
    # --------------------------------------------------------

    cost[
        n0:,
        n1:
    ] = 0.0

    row_ind, col_ind = (
        linear_sum_assignment(
            cost
        )
    )

    # STATIC first-passで確定した対応を
    # 最終matchedへ最初から登録
    matched = list(
        static_matches
    )

    disappeared = []
    appeared = []

    matched_t0 = set(
        static_t0
    )

    matched_t1 = set(
        static_t1
    )

    # ========================================================
    # real-real assignment
    # ========================================================

    for row, col in zip(
        row_ind,
        col_ind
    ):

        if (
            row < n0
            and
            col < n1
        ):

            if (
                t0_ids[row] in static_t0
                or
                t1_ids[col] in static_t1
            ):
                continue

            if not assignment_valid_matrix[
                row,
                col
            ]:
                continue

            result = dict(
                result_map[
                    (row, col)
                ]
            )

            stage = (
                assignment_stage_matrix[
                    row,
                    col
                ]
            )

            result[
                "assignment_utility"
            ] = float(
                assignment_utility_matrix[
                    row,
                    col
                ]
            )

            result[
                "global_candidate_stage"
            ] = stage


            # Strong / Partial MOVEDは
            # 通常の0.30m state判定へ戻さず、
            # candidate class自体を根拠にMOVED確定。
            if stage in [
                "strong_moved",
                "partial_moved",
            ]:

                result[
                    "state"
                ] = "moved"

                result[
                    "assignment_stage"
                ] = stage


            else:

                result[
                    "state"
                ] = determine_state(
                    result
                )

                result[
                    "assignment_stage"
                ] = "hungarian"


            matched.append(
                result
            )

            matched_t0.add(
                result["t0_id"]
            )

            matched_t1.add(
                result["t1_id"]
            )

    # ========================================================
    # unmatched
    #
    # Stage 1:
    # Raw temporal-median presence gate
    #
    # Stage 2:
    # Visibility / occlusion gate
    #
    # 「点が存在しない」と
    # 「物体が存在しない」を区別する。
    # ========================================================

    RAW_EXIST_DISTANCE_M = 0.03
    RAW_EXIST_COVERAGE = 0.90

    # ========================================================
    # STATIC Partial Recovery
    #
    # 通常STATIC / Hungarianで対応できなかった物体のうち、
    # 同一位置に部分点群が残っているものだけを
    # 保守的にSTATICとして回収する。
    #
    # move_clearでの暫定値。
    # 複数実験で回帰試験して最終決定する。
    # ========================================================

    STATIC_PARTIAL_CENTER_MAX_M = 0.25

    STATIC_PARTIAL_DIRECT_5CM_MIN = 0.45
    STATIC_PARTIAL_DIRECT_8CM_MIN = 0.55

    STATIC_PARTIAL_RAW_3CM_MIN = 0.65

    STATIC_PARTIAL_ICP_MOVE_MAX_M = 0.20
    STATIC_PARTIAL_ICP_MIN_BIDIR_COV = 0.50
    STATIC_PARTIAL_ICP_RMSE_MAX_M = 0.04

    VIS_MAP_MAX_DIST_M = 0.05
    VIS_DEPTH_MARGIN_M = 0.10
    VIS_SEARCH_RADIUS = 2

    # 暫定値。
    # exp07だけで最終決定せず、複数実験で回帰試験する。
    VIS_MIN_OBSERVABLE_RATIO = 0.50
    VIS_MIN_BACKGROUND_RATIO = 0.10

    static_partial_recoveries = []

    suppressed_disappeared = []
    suppressed_appeared = []

    unknown_disappeared = []
    unknown_appeared = []


    # --------------------------------------------------------
    # Utility
    # --------------------------------------------------------

    from pathlib import Path


    def load_points_from_pcd(pcd_path):

        cloud = o3d.io.read_point_cloud(
            str(pcd_path)
        )

        return np.asarray(
            cloud.points
        )


    def point_coverage(
        query_points,
        reference_points,
        threshold
    ):

        if (
            len(query_points) == 0
            or
            len(reference_points) == 0
        ):
            return 0.0

        cloud = (
            o3d.geometry.PointCloud()
        )

        cloud.points = (
            o3d.utility.Vector3dVector(
                reference_points
            )
        )

        tree = (
            o3d.geometry.KDTreeFlann(
                cloud
            )
        )

        threshold2 = (
            threshold
            *
            threshold
        )

        matched_count = 0

        for point in query_points:

            k, _, dist2 = (
                tree.search_knn_vector_3d(
                    point,
                    1
                )
            )

            if (
                k > 0
                and
                dist2[0] <= threshold2
            ):
                matched_count += 1

        return (
            matched_count
            /
            len(query_points)
        )


    def find_occlusion_file(prefix):

        candidates = sorted(
            Path(".").glob(
                prefix
                +
                "*_occlusion_data.npz"
            )
        )

        if len(candidates) == 0:

            raise FileNotFoundError(
                "No occlusion data found for "
                + prefix
            )

        if len(candidates) > 1:

            raise RuntimeError(
                "Multiple occlusion files found for "
                + prefix
                + ": "
                + str(candidates)
            )

        return candidates[0]


    def build_organized_index(occ):

        xyz = occ["xyz"]
        valid = occ["valid"]

        flat_xyz = (
            xyz.reshape(-1, 3)
        )

        flat_valid = (
            valid.reshape(-1)
        )

        valid_indices = (
            np.flatnonzero(
                flat_valid
            )
        )

        valid_xyz = (
            flat_xyz[
                valid_indices
            ]
        )

        cloud = (
            o3d.geometry.PointCloud()
        )

        cloud.points = (
            o3d.utility.Vector3dVector(
                valid_xyz
            )
        )

        tree = (
            o3d.geometry.KDTreeFlann(
                cloud
            )
        )

        return (
            tree,
            valid_indices
        )


    def map_object_to_pixels(
        points,
        occ
    ):

        xyz = occ["xyz"]

        H, W, _ = xyz.shape

        tree, valid_indices = (
            build_organized_index(
                occ
            )
        )

        mapped = set()

        for point in points:

            k, idx, dist2 = (
                tree.search_knn_vector_3d(
                    point,
                    1
                )
            )

            if k == 0:
                continue

            distance = np.sqrt(
                dist2[0]
            )

            if (
                distance
                >
                VIS_MAP_MAX_DIST_M
            ):
                continue

            flat_idx = int(
                valid_indices[
                    idx[0]
                ]
            )

            v = flat_idx // W
            u = flat_idx % W

            mapped.add(
                (v, u)
            )

        return sorted(
            mapped
        )


    def nearest_valid_range(
        occ,
        v,
        u
    ):

        valid = occ["valid"]

        ranges = (
            occ["range_image"]
        )

        H, W = valid.shape

        # 同一pixelが有効なら優先
        if (
            0 <= v < H
            and
            0 <= u < W
            and
            valid[v, u]
        ):

            value = ranges[v, u]

            if (
                np.isfinite(value)
                and
                value > 0
            ):
                return float(value)

        candidates = []

        for dv in range(
            -VIS_SEARCH_RADIUS,
            VIS_SEARCH_RADIUS + 1
        ):

            for du in range(
                -VIS_SEARCH_RADIUS,
                VIS_SEARCH_RADIUS + 1
            ):

                vv = v + dv
                uu = u + du

                if not (
                    0 <= vv < H
                    and
                    0 <= uu < W
                ):
                    continue

                if not valid[vv, uu]:
                    continue

                value = ranges[vv, uu]

                if (
                    not np.isfinite(value)
                    or
                    value <= 0
                ):
                    continue

                pixel_distance = (
                    np.hypot(
                        dv,
                        du
                    )
                )

                candidates.append(
                    (
                        pixel_distance,
                        float(value)
                    )
                )

        if not candidates:
            return None

        candidates.sort(
            key=lambda x: x[0]
        )

        return candidates[0][1]


    def visibility_statistics(
        object_points,
        reference_occ,
        opposite_occ
    ):

        pixels = (
            map_object_to_pixels(
                object_points,
                reference_occ
            )
        )

        reference_range = (
            reference_occ[
                "range_image"
            ]
        )

        occluded = 0
        same_depth = 0
        background_visible = 0
        no_return = 0

        classified = 0

        for v, u in pixels:

            target_range = float(
                reference_range[v, u]
            )

            if (
                not np.isfinite(
                    target_range
                )
                or
                target_range <= 0
            ):
                continue

            observed_range = (
                nearest_valid_range(
                    opposite_occ,
                    v,
                    u
                )
            )

            classified += 1

            if observed_range is None:

                no_return += 1
                continue

            delta = (
                observed_range
                -
                target_range
            )

            if (
                delta
                <
                -VIS_DEPTH_MARGIN_M
            ):

                occluded += 1

            elif (
                delta
                >
                VIS_DEPTH_MARGIN_M
            ):

                background_visible += 1

            else:

                same_depth += 1

        if classified == 0:

            return {
                "mapped_pixels": 0,
                "classified_pixels": 0,
                "occluded_ratio": 0.0,
                "same_depth_ratio": 0.0,
                "background_visible_ratio": 0.0,
                "no_return_ratio": 1.0,
                "observable_ratio": 0.0,
            }

        observable = (
            classified
            -
            no_return
        )

        return {
            "mapped_pixels":
                int(len(pixels)),

            "classified_pixels":
                int(classified),

            "occluded_ratio":
                float(
                    occluded
                    /
                    classified
                ),

            "same_depth_ratio":
                float(
                    same_depth
                    /
                    classified
                ),

            "background_visible_ratio":
                float(
                    background_visible
                    /
                    classified
                ),

            "no_return_ratio":
                float(
                    no_return
                    /
                    classified
                ),

            "observable_ratio":
                float(
                    observable
                    /
                    classified
                ),
        }


    # --------------------------------------------------------
    # Input data
    # --------------------------------------------------------

    with open(
        "t0_merged_clusters.json"
    ) as f:

        gate_t0_objects = (
            json.load(f)
        )


    with open(
        "t1_merged_clusters.json"
    ) as f:

        gate_t1_objects = (
            json.load(f)
        )


    gate_t0_by_id = {
        int(x["merged_id"]): x
        for x in gate_t0_objects
    }

    gate_t1_by_id = {
        int(x["merged_id"]): x
        for x in gate_t1_objects
    }


    t0_temporal_points = (
        load_points_from_pcd(
            "t0_temporal_median.pcd"
        )
    )

    t1_temporal_points = (
        load_points_from_pcd(
            "t1_temporal_median.pcd"
        )
    )


    t0_occ_path = (
        find_occlusion_file(
            "t0"
        )
    )

    t1_occ_path = (
        find_occlusion_file(
            "t1"
        )
    )


    print()
    print(
        "Visibility data:"
    )

    print(
        " T0:",
        t0_occ_path
    )

    print(
        " T1:",
        t1_occ_path
    )


    t0_occ = np.load(
        t0_occ_path
    )

    t1_occ = np.load(
        t1_occ_path
    )


    # ========================================================
    # T0 unmatched
    #
    # T1 rawに存在
    # -> segmentation / clustering mismatch
    #
    # T1 rawに存在しない
    # -> visibility確認
    # ========================================================

    # ========================================================
    # STATIC PARTIAL RECOVERY
    #
    # Identity STATIC
    #     ↓ fail
    # Hungarian / MOVED
    #     ↓ unmatched
    # Partial STATIC recovery
    #     ↓
    # Raw Presence / Visibility
    #
    # MOVED gateそのものは緩めない。
    # ========================================================

    unmatched_t0_ids = [
        int(t0_id)
        for t0_id in t0_ids
        if int(t0_id) not in matched_t0
    ]

    unmatched_t1_ids = [
        int(t1_id)
        for t1_id in t1_ids
        if int(t1_id) not in matched_t1
    ]


    t0_index_by_id = {
        int(t0_id): i
        for i, t0_id in enumerate(t0_ids)
    }

    t1_index_by_id = {
        int(t1_id): j
        for j, t1_id in enumerate(t1_ids)
    }


    t0_partial_points = {}

    for t0_id in unmatched_t0_ids:

        entry = gate_t0_by_id[
            int(t0_id)
        ]

        t0_partial_points[
            int(t0_id)
        ] = load_points_from_pcd(
            entry["pcd"]
        )


    t1_partial_points = {}

    for t1_id in unmatched_t1_ids:

        entry = gate_t1_by_id[
            int(t1_id)
        ]

        t1_partial_points[
            int(t1_id)
        ] = load_points_from_pcd(
            entry["pcd"]
        )


    # --------------------------------------------------------
    # Raw temporal presenceは物体ごとに1回だけ計算
    # --------------------------------------------------------

    t0_partial_raw_cov = {}

    for t0_id in unmatched_t0_ids:

        t0_partial_raw_cov[
            int(t0_id)
        ] = point_coverage(
            t0_partial_points[
                int(t0_id)
            ],
            t1_temporal_points,
            RAW_EXIST_DISTANCE_M
        )


    t1_partial_raw_cov = {}

    for t1_id in unmatched_t1_ids:

        t1_partial_raw_cov[
            int(t1_id)
        ] = point_coverage(
            t1_partial_points[
                int(t1_id)
            ],
            t0_temporal_points,
            RAW_EXIST_DISTANCE_M
        )


    recovery_candidates = []


    for t0_id in unmatched_t0_ids:

        p0 = t0_partial_points[
            int(t0_id)
        ]

        if len(p0) == 0:
            continue

        t0_entry = gate_t0_by_id[
            int(t0_id)
        ]

        c0 = np.asarray(
            t0_entry["center"],
            dtype=float
        )


        for t1_id in unmatched_t1_ids:

            p1 = t1_partial_points[
                int(t1_id)
            ]

            if len(p1) == 0:
                continue

            t1_entry = gate_t1_by_id[
                int(t1_id)
            ]

            c1 = np.asarray(
                t1_entry["center"],
                dtype=float
            )


            # -----------------------------------------------
            # OBB center distance
            # -----------------------------------------------

            center_distance = float(
                np.linalg.norm(
                    c1 - c0
                )
            )


            # -----------------------------------------------
            # direct bidirectional coverage
            # -----------------------------------------------

            direct_5_t0 = point_coverage(
                p0,
                p1,
                0.05
            )

            direct_5_t1 = point_coverage(
                p1,
                p0,
                0.05
            )

            direct_8_t0 = point_coverage(
                p0,
                p1,
                0.08
            )

            direct_8_t1 = point_coverage(
                p1,
                p0,
                0.08
            )


            direct_5_min = min(
                direct_5_t0,
                direct_5_t1
            )

            direct_8_min = min(
                direct_8_t0,
                direct_8_t1
            )


            # -----------------------------------------------
            # Raw temporal presence
            # -----------------------------------------------

            raw_t0 = t0_partial_raw_cov[
                int(t0_id)
            ]

            raw_t1 = t1_partial_raw_cov[
                int(t1_id)
            ]

            raw_min = min(
                raw_t0,
                raw_t1
            )


            # -----------------------------------------------
            # ICP result
            #
            # result_mapはmatrix indexで保持されているため
            # merged_id -> indexへ変換して取得する。
            # INVALIDだった候補でも診断値は使用する。
            # -----------------------------------------------

            i = t0_index_by_id[
                int(t0_id)
            ]

            j = t1_index_by_id[
                int(t1_id)
            ]

            icp_result = result_map.get(
                (i, j)
            )

            if icp_result is None:
                continue


            icp_t0_cov = float(
                icp_result.get(
                    "t0_coverage",
                    0.0
                )
            )

            icp_t1_cov = float(
                icp_result.get(
                    "t1_coverage",
                    0.0
                )
            )

            icp_bidir = min(
                icp_t0_cov,
                icp_t1_cov
            )

            icp_move = float(
                icp_result.get(
                    "icp_translation_m",
                    float("inf")
                )
            )

            rmse = float(
                icp_result.get(
                    "rmse",
                    float("inf")
                )
            )


            recovery_ok = (
                center_distance
                <=
                STATIC_PARTIAL_CENTER_MAX_M

                and
                direct_5_min
                >=
                STATIC_PARTIAL_DIRECT_5CM_MIN

                and
                direct_8_min
                >=
                STATIC_PARTIAL_DIRECT_8CM_MIN

                and
                raw_min
                >=
                STATIC_PARTIAL_RAW_3CM_MIN

                and
                icp_move
                <=
                STATIC_PARTIAL_ICP_MOVE_MAX_M

                and
                icp_bidir
                >=
                STATIC_PARTIAL_ICP_MIN_BIDIR_COV

                and
                rmse
                <=
                STATIC_PARTIAL_ICP_RMSE_MAX_M
            )


            if not recovery_ok:
                continue


            recovery_candidates.append(
                {
                    "t0_id":
                        int(t0_id),

                    "t1_id":
                        int(t1_id),

                    "center_distance_m":
                        float(
                            center_distance
                        ),

                    "direct_5cm_t0_coverage":
                        float(
                            direct_5_t0
                        ),

                    "direct_5cm_t1_coverage":
                        float(
                            direct_5_t1
                        ),

                    "direct_5cm_min_coverage":
                        float(
                            direct_5_min
                        ),

                    "direct_8cm_t0_coverage":
                        float(
                            direct_8_t0
                        ),

                    "direct_8cm_t1_coverage":
                        float(
                            direct_8_t1
                        ),

                    "direct_8cm_min_coverage":
                        float(
                            direct_8_min
                        ),

                    "raw_t0_to_t1_coverage":
                        float(
                            raw_t0
                        ),

                    "raw_t1_to_t0_coverage":
                        float(
                            raw_t1
                        ),

                    "raw_min_coverage":
                        float(
                            raw_min
                        ),

                    "icp_t0_coverage":
                        float(
                            icp_t0_cov
                        ),

                    "icp_t1_coverage":
                        float(
                            icp_t1_cov
                        ),

                    "icp_min_coverage":
                        float(
                            icp_bidir
                        ),

                    "icp_translation_m":
                        float(
                            icp_move
                        ),

                    "rmse":
                        float(
                            rmse
                        ),

                    "icp_result":
                        dict(
                            icp_result
                        ),
                }
            )


    # --------------------------------------------------------
    # 1対1制約
    #
    # recovery候補が複数ある場合も、
    # 同じT0/T1を二重使用しない。
    #
    # 優先順位:
    # 1. direct 8cm min coverage
    # 2. direct 5cm min coverage
    # 3. raw min coverage
    # 4. ICP bidirectional coverage
    # 5. center distance
    # 6. RMSE
    # --------------------------------------------------------

    recovery_candidates.sort(
        key=lambda x: (
            -x[
                "direct_8cm_min_coverage"
            ],
            -x[
                "direct_5cm_min_coverage"
            ],
            -x[
                "raw_min_coverage"
            ],
            -x[
                "icp_min_coverage"
            ],
            x[
                "center_distance_m"
            ],
            x[
                "rmse"
            ],
        )
    )


    print()
    print(
        "======================================"
    )
    print(
        "STATIC Partial Recovery"
    )
    print(
        "======================================"
    )


    for candidate in recovery_candidates:

        t0_id = int(
            candidate["t0_id"]
        )

        t1_id = int(
            candidate["t1_id"]
        )


        # 既に他candidateによって回収済みなら使用しない
        if (
            t0_id in matched_t0
            or
            t1_id in matched_t1
        ):
            continue


        result = dict(
            candidate[
                "icp_result"
            ]
        )

        result[
            "state"
        ] = "static"

        result[
            "assignment_stage"
        ] = "static_partial_recovery"


        result[
            "partial_center_distance_m"
        ] = float(
            candidate[
                "center_distance_m"
            ]
        )


        result[
            "partial_direct_5cm_t0_coverage"
        ] = float(
            candidate[
                "direct_5cm_t0_coverage"
            ]
        )

        result[
            "partial_direct_5cm_t1_coverage"
        ] = float(
            candidate[
                "direct_5cm_t1_coverage"
            ]
        )

        result[
            "partial_direct_5cm_min_coverage"
        ] = float(
            candidate[
                "direct_5cm_min_coverage"
            ]
        )


        result[
            "partial_direct_8cm_t0_coverage"
        ] = float(
            candidate[
                "direct_8cm_t0_coverage"
            ]
        )

        result[
            "partial_direct_8cm_t1_coverage"
        ] = float(
            candidate[
                "direct_8cm_t1_coverage"
            ]
        )

        result[
            "partial_direct_8cm_min_coverage"
        ] = float(
            candidate[
                "direct_8cm_min_coverage"
            ]
        )


        result[
            "partial_raw_t0_to_t1_coverage"
        ] = float(
            candidate[
                "raw_t0_to_t1_coverage"
            ]
        )

        result[
            "partial_raw_t1_to_t0_coverage"
        ] = float(
            candidate[
                "raw_t1_to_t0_coverage"
            ]
        )

        result[
            "partial_raw_min_coverage"
        ] = float(
            candidate[
                "raw_min_coverage"
            ]
        )


        result[
            "partial_icp_min_coverage"
        ] = float(
            candidate[
                "icp_min_coverage"
            ]
        )


        matched.append(
            result
        )

        matched_t0.add(
            t0_id
        )

        matched_t1.add(
            t1_id
        )

        static_partial_recoveries.append(
            dict(
                result
            )
        )


        print()
        print(
            f"T0 M{t0_id} "
            f"-> T1 M{t1_id}"
        )

        print(
            " state           = STATIC"
        )

        print(
            " center          = "
            f"{candidate['center_distance_m']:.4f} m"
        )

        print(
            " direct 5cm     = "
            f"{candidate['direct_5cm_t0_coverage']:.4f} / "
            f"{candidate['direct_5cm_t1_coverage']:.4f}"
        )

        print(
            " direct 8cm     = "
            f"{candidate['direct_8cm_t0_coverage']:.4f} / "
            f"{candidate['direct_8cm_t1_coverage']:.4f}"
        )

        print(
            " raw 3cm        = "
            f"{candidate['raw_t0_to_t1_coverage']:.4f} / "
            f"{candidate['raw_t1_to_t0_coverage']:.4f}"
        )

        print(
            " ICP coverage   = "
            f"{candidate['icp_t0_coverage']:.4f} / "
            f"{candidate['icp_t1_coverage']:.4f}"
        )

        print(
            " ICP move       = "
            f"{candidate['icp_translation_m']:.4f} m"
        )

        print(
            " RMSE           = "
            f"{candidate['rmse']:.4f} m"
        )


    if not static_partial_recoveries:

        print(
            "No partial STATIC objects were recovered."
        )


    # ========================================================
    # T0 unmatched
    # Raw Presence -> Visibility
    # ========================================================

    for t0_id in t0_ids:

        if t0_id in matched_t0:
            continue

        entry = (
            gate_t0_by_id[
                int(t0_id)
            ]
        )

        query_points = (
            load_points_from_pcd(
                entry["pcd"]
            )
        )

        raw_cov = (
            point_coverage(
                query_points,
                t1_temporal_points,
                RAW_EXIST_DISTANCE_M
            )
        )

        if (
            raw_cov
            >=
            RAW_EXIST_COVERAGE
        ):

            suppressed_disappeared.append(
                {
                    "t0_id":
                        int(t0_id),

                    "reason":
                        "still_present_in_t1_raw",

                    "raw_coverage":
                        float(raw_cov),

                    "raw_distance_m":
                        RAW_EXIST_DISTANCE_M,
                }
            )

            continue


        vis = visibility_statistics(
            query_points,
            t0_occ,
            t1_occ
        )

        confirmed = (
            vis[
                "observable_ratio"
            ]
            >=
            VIS_MIN_OBSERVABLE_RATIO
            and
            vis[
                "background_visible_ratio"
            ]
            >=
            VIS_MIN_BACKGROUND_RATIO
        )


        result = {
            "t0_id":
                int(t0_id),

            "raw_coverage":
                float(raw_cov),

            "visibility":
                vis,
        }


        if confirmed:

            result[
                "reason"
            ] = (
                "visible_background_supports_disappearance"
            )

            disappeared.append(
                result
            )

        else:

            result[
                "reason"
            ] = (
                "insufficient_visibility_for_disappearance"
            )

            unknown_disappeared.append(
                result
            )


    # ========================================================
    # T1 unmatched
    #
    # T0 rawに存在
    # -> segmentation / clustering mismatch
    #
    # T0 rawに存在しない
    # -> visibility確認
    # ========================================================

    for t1_id in t1_ids:

        if t1_id in matched_t1:
            continue

        entry = (
            gate_t1_by_id[
                int(t1_id)
            ]
        )

        query_points = (
            load_points_from_pcd(
                entry["pcd"]
            )
        )

        raw_cov = (
            point_coverage(
                query_points,
                t0_temporal_points,
                RAW_EXIST_DISTANCE_M
            )
        )

        if (
            raw_cov
            >=
            RAW_EXIST_COVERAGE
        ):

            suppressed_appeared.append(
                {
                    "t1_id":
                        int(t1_id),

                    "reason":
                        "already_present_in_t0_raw",

                    "raw_coverage":
                        float(raw_cov),

                    "raw_distance_m":
                        RAW_EXIST_DISTANCE_M,
                }
            )

            continue


        vis = visibility_statistics(
            query_points,
            t1_occ,
            t0_occ
        )

        confirmed = (
            vis[
                "observable_ratio"
            ]
            >=
            VIS_MIN_OBSERVABLE_RATIO
            and
            vis[
                "background_visible_ratio"
            ]
            >=
            VIS_MIN_BACKGROUND_RATIO
        )


        result = {
            "t1_id":
                int(t1_id),

            "raw_coverage":
                float(raw_cov),

            "visibility":
                vis,
        }


        if confirmed:

            result[
                "reason"
            ] = (
                "visible_background_supports_appearance"
            )

            appeared.append(
                result
            )

        else:

            result[
                "reason"
            ] = (
                "insufficient_visibility_for_appearance"
            )

            unknown_appeared.append(
                result
            )


    # ========================================================
    # Terminal result
    # ========================================================

    print()
    print("======================================")
    print("Final Assignment")
    print("======================================")

    for result in matched:

        print()
        print(
            f"T0 M{result['t0_id']} "
            f"→ "
            f"T1 M{result['t1_id']}"
        )

        state = (
            result["state"]
            .upper()
        )

        stage = result.get(
            "assignment_stage",
            "hungarian"
        )

        print(
            " state           =",
            state
        )

        print(
            " assignment      =",
            stage
        )

        # ====================================================
        # STATIC:
        # identity-based first-passの指標を表示
        # ====================================================

        if (
            state == "STATIC"
            and
            stage == "identity_static_first"
        ):

            print(
                " identity center =",
                f"{result['identity_center_distance_m']:.4f}",
                "m"
            )

            print(
                " identity T0 cov =",
                f"{result['identity_t0_coverage']:.4f}"
            )

            print(
                " identity T1 cov =",
                f"{result['identity_t1_coverage']:.4f}"
            )

            print(
                " identity coverage=",
                f"{result['identity_max_coverage']:.4f}"
            )

            print(
                " identity RMSE   =",
                f"{result['identity_rmse_m']:.4f}",
                "m"
            )

            print(
                " ICP             =",
                "not used for STATIC decision"
            )

        # ====================================================
        # STATIC partial recovery
        # ====================================================

        elif (
            state == "STATIC"
            and
            stage == "static_partial_recovery"
        ):

            print(
                " partial center  =",
                f"{result['partial_center_distance_m']:.4f}",
                "m"
            )

            print(
                " direct 5cm      =",
                (
                    f"{result['partial_direct_5cm_t0_coverage']:.4f}"
                    " / "
                    f"{result['partial_direct_5cm_t1_coverage']:.4f}"
                )
            )

            print(
                " direct 8cm      =",
                (
                    f"{result['partial_direct_8cm_t0_coverage']:.4f}"
                    " / "
                    f"{result['partial_direct_8cm_t1_coverage']:.4f}"
                )
            )

            print(
                " raw 3cm         =",
                (
                    f"{result['partial_raw_t0_to_t1_coverage']:.4f}"
                    " / "
                    f"{result['partial_raw_t1_to_t0_coverage']:.4f}"
                )
            )

            print(
                " ICP coverage    =",
                (
                    f"{result['t0_coverage']:.4f}"
                    " / "
                    f"{result['t1_coverage']:.4f}"
                )
            )

            print(
                " ICP translation =",
                f"{result['icp_translation_m']:.4f}",
                "m"
            )

            print(
                " RMSE            =",
                f"{result['rmse']:.4f}",
                "m"
            )

        # ====================================================
        # MOVED / normal Hungarian:
        # ICP指標を表示
        # ====================================================

        else:

            print(
                " score           =",
                f"{result['score']:.4f}"
            )

            if (
                "assignment_utility"
                in result
            ):

                print(
                    " assignment util =",
                    f"{result['assignment_utility']:.4f}"
                )

            print(
                " fitness         =",
                f"{result['fitness']:.4f}"
            )

            print(
                " RMSE            =",
                f"{result['rmse']:.4f}",
                "m"
            )

            print(
                " T0 coverage     =",
                f"{result['t0_coverage']:.4f}"
            )

            print(
                " T1 coverage     =",
                f"{result['t1_coverage']:.4f}"
            )

            print(
                " ICP translation =",
                f"{result['icp_translation_m']:.4f}",
                "m"
            )

            print(
                " Center movement =",
                f"{result['obb_center_translation_m']:.4f}",
                "m"
            )

            print(
                " yaw             =",
                f"{result['yaw_deg']:.2f}",
                "deg"
            )

    print()
    print("--------------------------------------")

    print(
        "Disappeared:",
        [
            "M" + str(x["t0_id"])
            for x in disappeared
        ]
    )

    print(
        "Appeared:",
        [
            "M" + str(x["t1_id"])
            for x in appeared
        ]
    )


    print(
        "Suppressed disappeared:",
        [
            (
                "M"
                + str(x["t0_id"])
                + f"({x['raw_coverage']:.3f})"
            )
            for x in suppressed_disappeared
        ]
    )

    print(
        "Suppressed appeared:",
        [
            (
                "M"
                + str(x["t1_id"])
                + f"({x['raw_coverage']:.3f})"
            )
            for x in suppressed_appeared
        ]
    )


    print(
        "Unknown disappeared:",
        [
            (
                "M"
                + str(x["t0_id"])
                + "("
                + f"obs={x['visibility']['observable_ratio']:.3f},"
                + f"bg={x['visibility']['background_visible_ratio']:.3f}"
                + ")"
            )
            for x in unknown_disappeared
        ]
    )

    print(
        "Unknown appeared:",
        [
            (
                "M"
                + str(x["t1_id"])
                + "("
                + f"obs={x['visibility']['observable_ratio']:.3f},"
                + f"bg={x['visibility']['background_visible_ratio']:.3f}"
                + ")"
            )
            for x in unknown_appeared
        ]
    )

    # ========================================================
    # JSON
    # ========================================================

    output = {
        "settings": {
            "min_match_score":
                MIN_MATCH_SCORE,

            "max_icp_translation_m":
                MAX_ICP_TRANSLATION,

            "unmatched_cost":
                UNMATCHED_COST,

            "moved_translation_m":
                MOVED_TRANSLATION,

            "moved_rotation_deg":
                MOVED_ROTATION_DEG,

            "static_partial_recovery": {
                "center_max_m":
                    STATIC_PARTIAL_CENTER_MAX_M,

                "direct_5cm_min":
                    STATIC_PARTIAL_DIRECT_5CM_MIN,

                "direct_8cm_min":
                    STATIC_PARTIAL_DIRECT_8CM_MIN,

                "raw_3cm_min":
                    STATIC_PARTIAL_RAW_3CM_MIN,

                "icp_move_max_m":
                    STATIC_PARTIAL_ICP_MOVE_MAX_M,

                "icp_min_bidirectional_coverage":
                    STATIC_PARTIAL_ICP_MIN_BIDIR_COV,

                "icp_rmse_max_m":
                    STATIC_PARTIAL_ICP_RMSE_MAX_M,
            },
        },

        "matched":
            matched,

        "disappeared":
            disappeared,

        "appeared":
            appeared,

        "static_partial_recovery":
            static_partial_recoveries,

        "suppressed_disappeared":
            suppressed_disappeared,

        "suppressed_appeared":
            suppressed_appeared,

        "unknown_disappeared":
            unknown_disappeared,

        "unknown_appeared":
            unknown_appeared,
    }

    with open(
        OUTPUT_JSON,
        "w"
    ) as f:

        json.dump(
            output,
            f,
            indent=2
        )

    # ========================================================
    # HTML
    # ========================================================

    z = np.full(
        (n0, n1),
        np.nan
    )

    text = np.empty(
        (n0, n1),
        dtype=object
    )

    text[:] = ""

    assigned_pairs = {
        (
            x["t0_id"],
            x["t1_id"]
        )
        for x in matched
    }

    for i, t0_id in enumerate(
        t0_ids
    ):

        for j, t1_id in enumerate(
            t1_ids
        ):

            if np.isnan(
                score_matrix[
                    i, j
                ]
            ):
                continue

            z[
                i, j
            ] = score_matrix[
                i, j
            ]

            status = (
                "VALID"
                if valid_matrix[
                    i, j
                ]
                else "INVALID"
            )

            check = (
                " ✓"
                if (
                    t0_id,
                    t1_id
                )
                in assigned_pairs
                else ""
            )

            text[
                i, j
            ] = (
                f"{score_matrix[i,j]:.3f}"
                f"<br>{status}"
                f"{check}"
            )

    fig = make_subplots(
        rows=1,
        cols=2,

        specs=[
            [
                {"type": "xy"},
                {"type": "table"},
            ]
        ],

        column_widths=[
            0.62,
            0.38
        ],

        subplot_titles=[
            "Gated ICP Score Matrix",
            "Final Assignment"
        ]
    )

    fig.add_trace(
        go.Heatmap(
            z=z,

            x=[
                f"T1 M{x}"
                for x in t1_ids
            ],

            y=[
                f"T0 M{x}"
                for x in t0_ids
            ],

            zmin=0.0,
            zmax=1.0,

            colorscale="Viridis",

            text=text,

            texttemplate="%{text}",

            colorbar=dict(
                title="score"
            )
        ),

        row=1,
        col=1
    )

    table_t0 = []
    table_t1 = []
    table_state = []
    table_score = []
    table_move = []

    for x in matched:

        table_t0.append(
            f"M{x['t0_id']}"
        )

        table_t1.append(
            f"M{x['t1_id']}"
        )

        state = (
            x["state"]
            .upper()
        )

        stage = x.get(
            "assignment_stage",
            "hungarian"
        )

        table_state.append(
            state
        )

        if (
            state == "STATIC"
            and
            stage == "identity_static_first"
        ):

            table_score.append(
                "identity "
                f"cov={x['identity_max_coverage']:.3f}"
            )

            table_move.append(
                "center "
                f"{x['identity_center_distance_m']:.3f} m"
            )

        elif (
            state == "STATIC"
            and
            stage == "static_partial_recovery"
        ):

            table_score.append(
                "partial "
                f"cov={x['partial_direct_8cm_min_coverage']:.3f}"
            )

            table_move.append(
                "center "
                f"{x['partial_center_distance_m']:.3f} m"
            )

        else:

            table_score.append(
                f"{x['score']:.3f}"
            )

            table_move.append(
                f"{x['icp_translation_m']:.3f} m"
            )

    for x in disappeared:

        table_t0.append(
            f"M{x['t0_id']}"
        )

        table_t1.append("-")
        table_state.append(
            "DISAPPEARED"
        )
        table_score.append("-")
        table_move.append("-")

    for x in appeared:

        table_t0.append("-")

        table_t1.append(
            f"M{x['t1_id']}"
        )

        table_state.append(
            "APPEARED"
        )

        table_score.append("-")
        table_move.append("-")

    fig.add_trace(
        go.Table(

            header=dict(
                values=[
                    "T0",
                    "T1",
                    "State",
                    "Metric",
                    "Motion / Center",
                ]
            ),

            cells=dict(
                values=[
                    table_t0,
                    table_t1,
                    table_state,
                    table_score,
                    table_move,
                ]
            )
        ),

        row=1,
        col=2
    )

    fig.update_layout(

        title=(
            "Gated Dummy Hungarian Assignment "
            f"(score ≥ {MIN_MATCH_SCORE}, "
            f"ICP move ≤ {MAX_ICP_TRANSLATION} m)"
        ),

        width=1500,
        height=800,

        margin=dict(
            l=30,
            r=30,
            b=30,
            t=80
        )
    )

    fig.write_html(
        HTML_PATH,
        include_plotlyjs=True
    )

    print()
    print("======================================")
    print("Finished")
    print("======================================")

    print(
        "JSON:",
        OUTPUT_JSON
    )

    print(
        "HTML:",
        HTML_PATH
    )

    print("======================================")


if __name__ == "__main__":
    main()
