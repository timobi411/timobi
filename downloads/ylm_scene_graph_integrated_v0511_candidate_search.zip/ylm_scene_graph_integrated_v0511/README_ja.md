# YLM-X001 v0.5.1.1 物体候補探索改良

v0.5.1を比較基準として保全し、画像4近傍の完全列挙、公平な幾何評価、Grid境界をまたぐgraph_frontier拡張、候補保存の多様性、段階別監査を追加した版です。旧版ZIPは `vendor/` にバイト同一で同梱しています。

対象は候補形成と診断です。registration=NOT_RUN、identity=UNKNOWN、update=HELD、既存グラフ書込0です。ICP、T0/T1割当、移動判定、永続物体IDは実行しません。v0.4のxyz・valid・labels・構造マスクをそのまま保存し、元断片全体の実測画素ID集合を候補の正本とします。

## 結果を見る

ZIPをフォルダ全体で展開し、`validation/index.html` を開いてください。4データの比較結果と、同梱した実データサンプルの候補／ペアViewerへ移動できます。詳細な数値・試験・資源は `validation/REPORT_ja.md` と `comparison_summary.json` にあります。

展開ファイルの完全性は `python3 examples/verify_release.py` で確認できます。`release_manifest.json` に同梱全ファイルのサイズとSHA-256を記録しています（manifest自身を除く）。ZIP自体のSHA-256はダウンロード先に別ファイルで掲載します。

各結果フォルダの `index.html` は候補表示、`pair_viewer.html` は画像接触と探索段階の監査です。数字による元断片IDは完全一致、候補IDは部分一致、ペアは `206,245` のように2つのIDを入力して完全一致検索します。横／縦／両方向、共有Core有無、評価状態、ゲートで絞れます。

ペア画面は列挙→幾何評価→拡張試行→拡張根拠への使用→候補共所属→保存を区別します。検索でペアが見つかることは結合成功や同一物体認定を意味しません。元断片、画像接触edge、Core境界・共有領域、生成候補・保存候補のレイヤーを切り替えられます。表示点数と元データ数は別記し、表示間引きを数値評価に使いません。

JSは相対パスに同梱し、外部CDNやファイルfetchを使いません。このクラウドのChromiumはfile://を管理ポリシーで拒否するため、操作試験はHTTP経由です。PC側で直接表示が制限される場合は、展開フォルダで `python3 -m http.server 8000 --bind 127.0.0.1` を起動し、そのPCのブラウザから表示してください。

## Ubuntu 22.04 / Python 3.10

Linuxの `resource` によるRSS計測を使います。Ubuntu 22.04・Python 3.10で依存導入、試験、実データ比較を行う構成です。依存はNumPy 2.2.6、SciPy 1.14.1、Plotly 6.3.1、jsonschema 4.25.1です。Python 3.12専用の依存は要求しません。ROSは不要です。

```bash
cd ylm_scene_graph_integrated_v0511
python3.10 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-dev.txt
python -m compileall -q ylm051 examples
python -m unittest discover -s tests -v
```

Ubuntu側では `python3.10-venv`、テストのJS構文検査にはNode.jsが必要です。Dockerによる同じ環境の作成例は次です。

```bash
docker build -t ylm0511-ubuntu2204 -f docs/Dockerfile .
docker run --rm -v "$PWD:/app" -w /app ylm0511-ubuntu2204 python3.10 -m unittest discover -s tests -v
```

管理プロキシがある環境では、その環境のDNS・プロキシ・認証局設定を使います。Dockerfileは必要時に `--secret id=ca_bundle,src=/path/to/approved-ca-bundle.pem` を受け取り、TLS証明書検証を維持します。初回依存導入後の生成・検査にネットワークは不要です。

旧PCDを事後評価に使う場合のみOpen3D 0.19.0が追加で必要です。今回の実データ比較は物体GT・旧PCDを生成や調整に使っていません。実データにGTがないため、物体Recall/Purity/False Mergeは未評価です。

## 生成 → 整合性確認 → 表示 → 再生

```bash
python examples/make_fixture.py --out outputs/fixture
python -m ylm051 generate --input outputs/fixture/input.json --profile outputs/fixture/profiles/B3.json --out outputs/run
python -m ylm051 verify --run outputs/run
python -m ylm051 view --run outputs/run
python -m ylm051 replay --run outputs/run --out outputs/replay
python -m ylm051 evaluate --run outputs/run --evaluation outputs/fixture/evaluation.json --out outputs/evaluation
```

CLI名は `ylm051` を維持します。保存先は毎回新しいディレクトリを指定します。生成とevaluateは別プロセス・別入力・別出力です。GT・代理点群の追加や変更で生成結果が変わらないことを試験しています。

結果フォルダ全体を移動しても、入力コピーと相対参照からverify/replayが可能です。原本がまだ存在すれば原本hashも比較します。bagを読み直す必要はありません。改ざん・欠損・候補画素集合の不整合を検出すると停止します。

## 設定の準備と互換性

```bash
python -m ylm051 prepare-config --out outputs/new_profile.json
python -m ylm051 prepare-config --existing old_profile.json --out outputs/upgraded_profile.json
```

新規ひな型では未校正の幾何値はnullです。必要値が未設定なら生成を拒否します。旧profileからの準備はgeometryをそのまま引き継ぎ、`candidate_search` の新ポリシーを明示して出力します。旧profileを直接新生成CLIへ渡すと、新ポリシー未指定として停止します。旧挙動そのものを比較する場合は、vendorの旧ZIPを別ディレクトリへ展開して実行してください。

入力schemaは `ylm051.input.v1`、profile schemaは互換の `ylm051.profile.v1` に新設定を追加、新ポリシー版は `ylm0511.search.v1` です。生成入力は各時刻のNPZ（xyz/valid/labels）、clusters JSON、任意のcanonical mask・特徴配列・明示的正規化関係を受け取ります。原本のキーやパスを推測しません。実データの追加アダプターは `examples/prepare_handoff.py` です。

## 予算と新ポリシー

| 設定／カウンタ | 意味 |
|---|---|
| `max_image_pixels_scanned` | 右・下への画像接触走査で処理する元画素数。最近傍評価予算と独立 |
| `max_unique_pairs_enumerated` | 全経路を統合した一意ペアinventoryの上限 |
| `max_spatial_pairs_enumerated` / `max_spatial_proposals` | core/halo経路ごとの一意ペア保存数／重複を含む組合せ走査上限 |
| `max_gap_pairs_enumerated` / `max_gap_proposals` | gap>1経路の列挙数上限。4近傍とは別の完全性 |
| `max_pair_checks` | 幾何評価を試行する一意ペア数。接触edge本数でもICP呼出数でもない |
| `max_expanded_states` | 新しい断片集合の監査・展開数上限 |
| `combined_per_time` | 保存する結合候補の上限。全singletonは別枠 |
| `max_saved_bytes` | 全入力コピー・ログ・Viewer・診断予約を含む出力容量上限 |

既定の `budget_scope=per_time_reserved` ではpair、expanded、点コピー、領域数／所属数の枠を各時刻へ予約します。wall/RSS/保存容量は実行全体です。T0/T1で5,000ずつなら合計最大10,000幾何評価です。`global_shared` も明示設定できます。旧global共有5,000と新各時刻5,000を同一資源条件と呼びません。

件数制限による幾何評価・探索打切りは、残る保存余力で診断を出力できます。画像走査が完遂できない場合は、処理済み元行範囲と未知範囲を保存して部分失敗とし、完全列挙100%とは表示しません。wall/RSS/容量のhard limitでは途中出力までとなります。終了コード0は「指定範囲の出力・原本整合」の意味で、探索網羅・精度改善とは別です。

画像4近傍はvalidかつ非負異ラベルの右・下だけを走査します。完全接触リストは時刻別 `image_contacts_t0.npz` / `image_contacts_t1.npz`（列: fragment_a,fragment_b,pixel_from,pixel_to,direction、0=横/1=縦）に保存します。重複ペアの横・縦件数と全接触indexをinventoryに残します。

`image_first_fair_v1` は画像4近傍を先に評価します。上限を超えるとH_ONLY/V_ONLY/BOTH×共有Core有無の6層を巡回し、各層内は代表接触位置のtileを巡回、同tileはペアキー順です。代表位置は最初のrow-major接触元画素、tileは32画素を診断値として明示しています。画像後は保存関係・core・halo・gap>1の経路をround-robinで巡回します。同じペアの幾何評価は1回です。

`graph_frontier` は評価済みで探索適格な画像4近傍／保存関係を使ってseedの元領域を越えます。空間・gapのみの経路は元領域の制約を維持し、haloは別の補完です。未評価ペアを支持に使わず、元断片全体を追加して旧gap・直径上界・成長比・リスクを再評価します。ペア探索適格と候補全体ゲートの通過は別です。

## 保存多様性

`archive_policy=legacy_size_rank` と `diverse_v1` を比較できます。生成済みの同じ候補集合を使う保存段階だけの比較も同梱しています。候補集合の重複を除去し、到達したregion/seedを統合、所有者は(region,seed)の最小キーで決めます。全到達記録は `candidate_arrivals.jsonl` です。

diverse_v1は2～4／5～16／17以上の階級に均等枠を割当し、領域→seedをround-robinで巡回します。各seed内は従来rank順です。類似群はrank順で固定した代表とのJaccardで作り、推移的な鎖連結で群を広げません。診断値はthreshold=0.85、1群上限2、類似性を緩和する補充=false。物体精度で校正した値ではありません。余枠は同じ巡回規則で補充し、制約を黙って緩めません。

元候補の幾何・証拠rankは維持しています。candidate_idにはprofileを含むため、5k/12kやAB/ABCでIDが異なります。条件間比較は元断片集合キーを使います。全停止仮説は `generated_archive.jsonl` に残し、選択・除外と理由は `archive_selection.jsonl`、seed/領域/サイズ分布・断片登場率・Jaccard分布は `candidate_diversity.json` です。保存の多様性を物体精度と呼びません。

## 正式データの準備と比較

受領ZIPはSHA-256 `1bb89e483aebb4b35fcc8b6b112a41e64cf17968dd7d42678d95049131f49896`、548ファイルの個別hashを照合しています。全handoffやall条件の余分な大容量データは必須同梱ではありません。利用者が提供したhandoffを展開して次を実行できます。

```bash
python examples/prepare_handoff.py --handoff /path/to/extracted_handoff --out outputs/real_inputs
python examples/run_real_comparison.py --inputs outputs/real_inputs --baseline /path/to/frozen_v051 --out outputs/comparison
python examples/run_real_comparison.py --inputs outputs/real_inputs --baseline /path/to/frozen_v051 --modes A_12k,AB_12k,ABC_12k --out outputs/sensitivity
python examples/prepare_equal_total.py --inputs outputs/real_inputs --out outputs/equal_inputs
python examples/run_real_comparison.py --inputs outputs/equal_inputs --baseline /path/to/frozen_v051 --modes L,ABC --datasets exp01_pair,exp02_pair --out outputs/equal_total
```

初期対象はexp01/exp02のT0/T1・fixed11・boundary_falseです。主比較は各時刻独立プロセス、幾何評価5k、cell=0.75m、halo=0、結合候補128。受領B1 profileのgeometryと既存予算を維持し、切替は次の通りです。

| モード | ソース／ポリシー |
|---|---|
| L | 凍結v0.5.1そのもの。新エンジンによる模倣ではない |
| A | 画像4近傍＋公平スケジューラ、seed_region、legacy_size_rank |
| AB | A＋graph_frontier |
| ABC | AB＋diverse_v1 |

exp02 T0の旧B1実行profileは未収録のため、提供されたexp02 T1の数値設定を固定してT0にも適用した新規比較と明記します。過去にその条件で実行済みと扱いません。研究室PCのinline-onlyアダプターコードは収録されていませんが、保存されたinput JSONの対応キー・パスを使えます。旧研究室実行のsource hash記録が未収録のため、過去結果とコード同一とは断定せず、今回凍結ZIPから再実行したLを基準にします。

B0/B1/B2/B3の機能名は維持します。B2は正規化関係入力がなければ明示的に未評価として停止します。handoffのraw v0.4関係JSONを、そのまま新交換形式と仮定しません。今回の主比較はB1であり、B2やhaloの改善効果を主張しません。

## 指標と状態

I=完全走査で得た画像一意ペア、E=列挙ペア、G=幾何評価済みペアです。列挙率は|I∩E|/|I|、評価率は|I∩G|/|I|。空集合はnull/NOT_APPLICABLE、走査途中は分母UNKNOWNです。無効入力を評価成功へ数えません。横・縦・両方向は排他的な一意ペア分類で、接触edge本数は別です。共有Coreは全実測点による複数所属の共通集合から判定します。

拡張試行数と実際の使用数、生成／保存候補の共所属数は独立です。実際の使用は、追加可能な適格frontierリンクのうち最小実測gap・ペアキー順で決定したwitnessを記録します。全体監査は候補内の他の関係も参照します。ペア画面にはgapゲートや候補全体ゲートで止まった理由も残します。

`run_manifest.json` は画像列挙・幾何評価・拡張・archiveの段階別完了、原本整合、処理完了、探索打切りを別に保持します。`pair_pipeline.jsonl` は全列挙ペアの最終状態、`pair_evaluation.jsonl` は評価実行履歴です。保存前のinventoryから最終状態を推測しないでください。

## 検証の範囲

旧26件の要件を維持した回帰試験に、画像端・空画像・単一行列・invalid・多接触・6層公平性・共有Core・境界横断・低予算・走査途中停止・多様性の順序不変性を追加しています。新画像4近傍がhalo専用試験を迂回しないよう、その合成fixtureにはinvalid行を挟みました。旧global600の試験は、新版の各時刻600・合計1200を検査する期待値へ変更しています。理由は `docs/IMPLEMENTATION_STATUS_ja.md` に記載します。

固定件数・同一入力・設定・ソフトウェアで再現を確認します。wall/RSS停止位置は実行機の負荷に依存します。8GiB未満という主張は今回の各実行のRSS実測に限定し、任意の大規模入力まで保証しません。PCAの重複固有値では軸が環境依存になり得ます。exp08は今回未実施で、将来使う場合も厳密な未見testとは呼びません。

ブラウザ操作試験は追加でPlaywrightとChromiumが必要です。`python -m pip install playwright` と環境に対応するChromiumの導入後、`python tests/browser_pairs.py --run validation/real/exp02_t1 --out outputs/browser --chromium /path/to/chromium` で実行できます。通常の生成・表示にPlaywrightは不要です。
