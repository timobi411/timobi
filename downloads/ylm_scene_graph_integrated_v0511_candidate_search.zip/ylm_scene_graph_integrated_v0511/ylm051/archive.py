"""Deterministic region/seed round robin over a fixed generated archive."""
from collections import defaultdict,Counter
import itertools
import numpy as np
from .contacts import round_robin
from .policies import policy

def size_class(c): return '2-4' if len(c['fragment_ids'])<=4 else '5-16' if len(c['fragment_ids'])<=16 else '17+'
def owner(c):
    origins=c.get('origins',[])
    return min((tuple(o['region']),o['seed_fragment_id']) for o in origins) if origins else ((),c['seed_fragment_id'])
def jaccard(a,b):
    a,b=set(a),set(b)
    return len(a&b)/len(a|b) if a|b else 1.
def rank_key(c):
    # JSON round trips turn nested tuples into lists; canonical comparison is recursive.
    def freeze(x): return tuple(map(freeze,x)) if isinstance(x,(tuple,list)) else x
    return freeze(c['rank_tuple'])

def select_archive(values,profile):
    from .search import diverse
    values=sorted(values,key=lambda c:(rank_key(c),c['candidate_id']))
    cap=profile['budgets']['combined_per_time'];s=policy(profile)
    if s['archive_policy']=='legacy_size_rank':
        chosen=diverse(values,cap); ids={c['candidate_id'] for c in chosen}
        return chosen,[{'candidate_id':c['candidate_id'],'fragment_ids':c['fragment_ids'],'owner':owner(c),
                       'state':'KEPT' if c['candidate_id'] in ids else 'PRUNED_RANK','similarity_group':None} for c in values]
    buckets=defaultdict(lambda:defaultdict(lambda:defaultdict(list)))
    for c in values:
        region,seed=owner(c);buckets[size_class(c)][region][seed].append(c)
    streams={size:list(round_robin({r:list(round_robin(seeds)) for r,seeds in regions.items()})) for size,regions in buckets.items()}
    # Fixed representative groups avoid transitive chaining from a small common fragment core.
    groups=[]; membership={}; group_counts=Counter()
    for c in values:
        matched=next((i for i,g in enumerate(groups) if jaccard(c['fragment_ids'],g['fragment_ids'])>=s['similarity_threshold']),None)
        if matched is None: matched=len(groups);groups.append(c)
        membership[c['candidate_id']]=matched
    chosen=[];selected=set();quota=cap//max(1,len(streams));remaining={};blocked=[]
    def accept(c,relax=False):
        group=membership[c['candidate_id']]
        if not relax and group_counts[group]>=s['similarity_group_limit']:return False
        chosen.append(c);selected.add(c['candidate_id']);group_counts[group]+=1;return True
    for size,stream in sorted(streams.items()):
        count=0;rest=[]
        for c in stream:
            if count<quota:
                if accept(c):count+=1
                else:blocked.append(c)
            else:rest.append(c)
        remaining[size]=rest
    for c in round_robin(remaining):
        if len(chosen)>=cap:break
        if not accept(c):blocked.append(c)
    if s['relax_similarity_to_fill'] and len(chosen)<cap:
        for c in round_robin(streams):
            if c['candidate_id'] not in selected:accept(c,True)
            if len(chosen)>=cap:break
    records=[]
    for c in values:
        group=membership[c['candidate_id']]
        state='KEPT' if c['candidate_id'] in selected else 'PRUNED_DIVERSITY' if group_counts[group]>=s['similarity_group_limit'] else 'PRUNED_RANK'
        records.append({'candidate_id':c['candidate_id'],'fragment_ids':c['fragment_ids'],'owner':owner(c),'state':state,
                        'similarity_group':groups[group]['candidate_id'],'similarity_relaxation_enabled':s['relax_similarity_to_fill']})
    return sorted(chosen,key=rank_key),records

def diversity(candidates,records):
    cs=[c for c in candidates if len(c['fragment_ids'])>1];n=len(cs)
    fragments=Counter(f for c in cs for f in c['fragment_ids']);seeds=Counter();regions=Counter();sizes=Counter()
    for c in cs:
        r,s=owner(c);seeds[str((r,s))]+=1;regions[str(r)]+=1;sizes[size_class(c)]+=1
    # At most saved archive cap squared, never all generated hypotheses squared for audit.
    similarities=[jaccard(a['fragment_ids'],b['fragment_ids']) for a,b in itertools.combinations(cs,2)]
    return {'combined_count':n,'unique_owner_seeds':len(seeds),'unique_owner_regions':len(regions),
            'seed_counts':dict(seeds),'region_counts':dict(regions),'size_classes':dict(sizes),
            'fragment_appearance':{str(k):{'count':v,'rate':v/n if n else None} for k,v in sorted(fragments.items())},
            'maximum_fragment_concentration':max(fragments.values())/n if n else None,
            'jaccard_distribution':{'pairs':len(similarities),'quantiles_0_25_50_75_100':np.quantile(similarities,[0,.25,.5,.75,1]).tolist() if similarities else None,
                                    'histogram_bins':[0,.25,.5,.75,.85,1.000001],
                                    'histogram_counts':np.histogram(similarities,[0,.25,.5,.75,.85,1.000001])[0].tolist()},
            'similarity_groups':len({r['similarity_group'] for r in records if r.get('similarity_group')}),
            'pruning_counts':dict(Counter(r['state'] for r in records)),
            'interpretation':'storage diversity, not object accuracy'}
