"""Set resource/thread limits before importing numerical runtimes."""
import argparse
import json
import os
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description='YLM saved v0.4 -> diagnostic scene graph proposal')
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('run'); p.add_argument('--config', required=True); p.add_argument('--out', required=True)
    p = sub.add_parser('replay'); p.add_argument('--from-run', required=True); p.add_argument('--out', required=True)
    p.add_argument('--stage', required=True, choices=['structure_audit', 'object_candidates', 'registration', 'assignment'])
    p = sub.add_parser('verify'); p.add_argument('--out', required=True)
    args = parser.parse_args()
    for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
        os.environ[name] = '1'
    if args.command != 'verify':
        config_path = Path(args.config if args.command == 'run' else Path(args.from_run) / 'resolved_config.json').resolve()
        config = json.loads(config_path.read_text(encoding='utf-8'))
        limit = int(config.get('memory_limit_mib', 8192))
        if not 64 <= limit <= 8192:
            parser.error('memory_limit_mib must be 64..8192')
        if sys.platform == 'linux':
            import resource
            soft, hard = resource.getrlimit(resource.RLIMIT_AS)
            ceiling = limit * 1024 ** 2
            if hard != resource.RLIM_INFINITY:
                ceiling = min(ceiling, hard)
            resource.setrlimit(resource.RLIMIT_AS, (ceiling, hard))
        def absolute(value):
            p = Path(value).expanduser()
            return str(p.resolve() if p.is_absolute() else (config_path.parent / p).resolve())
        config['v04_results'] = absolute(config['v04_results'])
        for spec in config.get('audit', {}).values():
            for key in ('arrays', 'planes', 'old_points'):
                if spec.get(key):
                    spec[key] = absolute(spec[key])
        for groups in config.get('candidates', {}).get('groups', {}).values():
            for group in groups:
                if group.get('legacy_evidence_file'):
                    group['legacy_evidence_file'] = absolute(group['legacy_evidence_file'])
    try:
        from .pipeline import run, verify_run
        if args.command == 'verify':
            result = verify_run(args.out)
        else:
            result = run(config, args.out, replay=args.from_run if args.command == 'replay' else None,
                         start=args.stage if args.command == 'replay' else 'fragments')
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if args.command == 'verify' or (result['processing_complete'] and result['integrity_passed']) else 2
    except Exception as exc:
        print(json.dumps({'processing_complete': False, 'error': type(exc).__name__, 'message': str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
