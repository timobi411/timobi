"""Auditable v0.4 saved-output integration; no upstream re-clustering."""
__version__ = '0.5.0-diagnostic'
