"""Only the actual bridge-v02 contract is accepted as v0.4 input."""
from pathlib import Path
import shutil
import zipfile
import numpy as np
from .common import read, write, jsonl, sha, ensure_budget


def load_side(base, case, window, boundary, limit_mib=8192):
    sub = Path(base) / 'cases' / f'{case}' / window / boundary
    meta_path, pixels_path = sub / 'measured/clusters.json', sub / 'pixel_correspondence.npz'
    meta = read(meta_path)
    with zipfile.ZipFile(pixels_path) as z:
        # Reserve space for decompression, copies, and numerical intermediates.
        ensure_budget(sum(i.file_size for i in z.infolist()) * 6, limit_mib, 'organized input')
    with np.load(pixels_path, allow_pickle=False) as z:
        xyz, valid, labels = (z[k].copy() for k in ('xyz', 'valid', 'labels'))
    if xyz.ndim != 3 or xyz.shape[2] != 3 or valid.shape != xyz.shape[:2] or labels.shape != valid.shape:
        raise ValueError('v04 organized shapes disagree')
    if valid.dtype.kind != 'b' or labels.dtype.kind not in 'iu':
        raise ValueError('valid must be boolean and labels integral')
    if np.any((labels >= 0) & ~valid) or not np.isfinite(xyz[valid]).all():
        raise ValueError('invalid measured pixels')
    clusters = meta['clusters']
    ids = [int(c['id']) for c in clusters]
    unique, counts = np.unique(labels[labels >= 0], return_counts=True)
    count_map = dict(zip(unique.tolist(), counts.tolist()))
    if len(set(ids)) != len(ids) or set(ids) != set(count_map):
        raise ValueError('declared fragments disagree with labels')
    for c in clusters:
        if int(c['point_count']) != count_map[int(c['id'])] or int(c.get('MODEL_INFERRED', 0)) != 0:
            raise ValueError('fragment count mismatch or inferred points')
    return xyz, valid, labels, clusters, [meta_path, pixels_path]


def ingest(config, out):
    records = []
    for side in ('t0', 't1'):
        xyz, valid, labels, clusters, paths = load_side(
            config['v04_results'], config.get('case', 'exp02') + '_' + side,
            config.get('window', 'fixed11'), config.get('boundary', 'boundary_false'),
            config.get('memory_limit_mib', 8192))
        folder = out / 'fragments' / side
        folder.mkdir(parents=True)
        # Byte-for-byte source copy retains all extra NPZ arrays and all tiny fragments.
        for src, dst in zip(paths, ('clusters.json', 'pixel_correspondence.npz')):
            before = sha(src)
            shutil.copy2(src, folder / dst)
            if before != sha(folder / dst) or before != sha(src):
                raise ValueError('input changed while reading')
            records.append({'path': str(src.resolve()), 'sha256': before,
                            'snapshot': str((folder / dst).relative_to(out))})
        jsonl(folder / 'fragments.jsonl', (
            {'fragment_id': int(c['id']), 'point_count': int(c['point_count']),
             'point_namespace': side + ':organized_flat_pixel',
             'source_point_ids': np.flatnonzero(labels.ravel() == int(c['id'])).tolist(),
             'identity_status': 'UNKNOWN', 'source_metadata': c} for c in clusters))
        write(folder / 'observation.json', {
            'side': side, 'units': config['units'], 'frame_id': config.get('frames', {}).get(side),
            'reference_time': config.get('reference_times', {}).get(side),
            'history': 'retained_if_present_in_source_arrays; unavailable_otherwise',
            'time_integration': 'upstream_saved_output_only',
            'window': config.get('window', 'fixed11'),
            'all_window_caution': 'all may have expired integration; do not compare as frame-count-only',
            'preprocessing_reapplied': False, 'total_fragments': len(clusters),
            'tiny_fragments_retained': sum(int(c['point_count']) < 50 for c in clusters)})
    write(out / 'source_hashes.json', records)


def check_sources(out):
    for item in read(out / 'source_hashes.json'):
        # Snapshot is the replay source. Also verify originals when still present.
        if sha(out / item['snapshot']) != item['sha256']:
            raise ValueError('source snapshot changed: ' + item['snapshot'])
        original = Path(item['path'])
        if original.exists() and sha(original) != item['sha256']:
            raise ValueError('original input changed: ' + item['path'])
    return True
