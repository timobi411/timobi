"""Hungarian comparison and conservative, non-destructive graph proposals."""
import numpy as np
from scipy.optimize import linear_sum_assignment
from .common import read, write, rows, ensure_budget


def assign(candidates, pairs, memory_mib=8192):
    left, right = candidates['t0'], candidates['t1']
    n, m = len(left), len(right)
    ensure_budget((n + m) ** 2 * 8 * 3, memory_mib, 'assignment matrix')
    li = {c['candidate_id']: i for i, c in enumerate(left)}
    ri = {c['candidate_id']: i for i, c in enumerate(right)}
    cost = np.full((n + m, n + m), 1e6)
    # Explicit unmatched alternatives: matching only helps with positive geometric score.
    cost[:n, m:] = 0.0; cost[n:, :m] = 0.0; cost[n:, m:] = 0.0
    by_pair = {}
    for p in pairs:
        key = (p['source'], p['target']); by_pair[key] = p
        if p['legacy_valid'] and p['score'] > 0 and not p['ambiguous']:
            cost[li[key[0]], ri[key[1]]] = -p['score']
    aa, bb = linear_sum_assignment(cost)
    baseline = [(left[i]['candidate_id'], right[j]['candidate_id']) for i, j in zip(aa, bb)
                if i < n and j < m and cost[i, j] < 0]
    by_id = {c['candidate_id']: c for c in left + right}
    used = {'t0': set(), 't1': set()}
    accepted, rejected = [], []
    for a, b in sorted(baseline, key=lambda k: (-by_pair[k]['score'], k)):
        p = by_pair[(a, b)]
        reasons = []
        alternatives = [q for q in pairs if q is not p and q['legacy_valid'] and
                        (q['source'] == a or q['target'] == b)]
        if any(q['score'] >= p['score'] - 0.02 for q in alternatives):
            reasons.append('competing_correspondence_similar_score')
        if set(by_id[a]['source_point_ids']) & used['t0'] or set(by_id[b]['source_point_ids']) & used['t1']:
            reasons.append('overlapping_candidate_already_selected')
        item = {'source': a, 'target': b, 'score': p['score'], 'identity_status': 'UNKNOWN',
                'hold_reasons': reasons, 'evidence': p.get('detail')}
        if reasons:
            rejected.append(item)
        else:
            accepted.append(item)
            used['t0'].update(by_id[a]['source_point_ids']); used['t1'].update(by_id[b]['source_point_ids'])
    return {'geometric_assignments': accepted, 'held_assignments': rejected,
            'hungarian_with_unmatched_baseline': [list(p) for p in baseline],
            'unmatched_t0': [c['candidate_id'] for c in left if c['candidate_id'] not in {p['source'] for p in accepted}],
            'unmatched_t1': [c['candidate_id'] for c in right if c['candidate_id'] not in {p['target'] for p in accepted}],
            'identity_evaluation': 'UNKNOWN', 'ambiguity_margin': 0.02,
            'baseline_note': 'new geometric Hungarian with dummies; original visibility-aware Hungarian is preserved in vendor'}


def proposals(config, assignment, candidates, out):
    alignment = config.get('frame_alignment', {'status': 'unknown'})
    aligned = alignment.get('status') == 'verified' and bool(alignment.get('evidence'))
    node_refs = config.get('node_references', {})
    all_candidates = {c['candidate_id']: c for side in candidates.values() for c in side}
    updates = []
    for pair in assignment['geometric_assignments'] + assignment['held_assignments']:
        holds = ['object_identity_unverified'] + pair['hold_reasons']
        if config.get('registration_pairs') is not None:
            holds.append('registration_search_limited_to_explicit_subset')
        if not aligned:
            holds.append('static_frame_alignment_unverified')
        for key in ('source', 'target'):
            holds.extend(all_candidates[pair[key]]['formation_hold_reasons'])
        estimate = None
        if pair.get('evidence'):
            detail = read(out / pair['evidence'])
            best = detail['hypotheses'][detail['selected_hypothesis']]
            estimate = {'point_displacement_m': best['metrics']['point_displacement_m'],
                        'center_displacement_m': best['metrics']['center_displacement_m'],
                        'rotation_angle_deg': best['metrics']['rotation_angle_deg'],
                        'transform': best['common_t0_to_common_t1'],
                        'interpretation': 'aligned_geometric_motion_hypothesis' if aligned else 'frame_and_object_effects_unseparated'}
        updates.append({'proposal_id': f'proposal:{len(updates):06d}', 'candidate_pair': [pair['source'], pair['target']],
                        'original_node_reference': node_refs.get(pair['source']), 'status': 'HELD',
                        'motion_state': 'UNKNOWN_MOTION', 'hold_reasons': sorted(set(holds)),
                        'evidence': pair.get('evidence'), 'adoption_basis': 'geometric_comparison_only',
                        'diagnostic_estimate': estimate, 'apply_to_existing_graph': False})
    for side in ('t0', 't1'):
        for cid in assignment['unmatched_' + side]:
            updates.append({'proposal_id': f'proposal:{len(updates):06d}', 'candidate_pair': [cid] if side == 't0' else [None, cid],
                            'original_node_reference': node_refs.get(cid), 'status': 'HELD',
                            'change_hypothesis': 'unobserved_later' if side == 't0' else 'newly_observed',
                            'hold_reasons': ['visibility_or_occlusion_not_established', 'structure_removal_effect_unknown', 'identity_unverified'],
                            'adoption_basis': 'unmatched_observation_only', 'apply_to_existing_graph': False})
    return {'schema': 'ylm.graph_proposals.v05', 'updates': updates, 'existing_graph_modified': False,
            'identity_evaluation': 'UNKNOWN', 'update_evaluation': 'UNKNOWN'}


def run_decision(config, out):
    candidates = {s: list(rows(out / 'object_candidates' / s / 'candidates.jsonl')) for s in ('t0', 't1')}
    result = assign(candidates, list(rows(out / 'registration/pairs.jsonl')), config.get('memory_limit_mib', 8192))
    write(out / 'assignment/assignment.json', result)
    write(out / 'scene_graph_proposal/proposals.json', proposals(config, result, candidates, out))
    return result
