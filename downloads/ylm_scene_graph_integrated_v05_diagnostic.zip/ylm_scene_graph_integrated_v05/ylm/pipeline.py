import importlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import traceback
import html
from .common import ROOT, read, write, sha
from .inputs import ingest, check_sources
from .audit import run_audit
from .candidates import run_candidates
from .registration import run_registration
from .decision import run_decision

STAGES = ['fragments', 'structure_audit', 'object_candidates', 'registration', 'assignment']


def environment():
    modules = {}
    for name in ('numpy', 'scipy', 'open3d', 'plotly', 'rclpy', 'rosbag2_py'):
        spec = importlib.util.find_spec(name)
        if spec:
            try:
                mod = importlib.import_module(name)
                modules[name] = {'path': getattr(mod, '__file__', None), 'version': getattr(mod, '__version__', None)}
            except Exception as exc:
                modules[name] = {'path': spec.origin, 'import_error': type(exc).__name__}
        else:
            modules[name] = {'available': False}
    names = ['ROS_DISTRO', 'AMENT_PREFIX_PATH', 'COLCON_PREFIX_PATH', 'PYTHONPATH', 'LD_LIBRARY_PATH']
    script = 'import os,json,hashlib; names=' + repr(names) + '; print(json.dumps({k:hashlib.sha256(os.environ[k].encode()).hexdigest() for k in names if k in os.environ}))'
    child = json.loads(subprocess.check_output([sys.executable, '-c', script], env=os.environ.copy(), text=True))
    import hashlib
    inherited = {k: {'present': k in os.environ, 'inherited': child.get(k) == hashlib.sha256(os.environ[k].encode()).hexdigest() if k in os.environ else None} for k in names}
    return {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(), 'modules': modules,
            'ros_environment_inheritance_probe': inherited, 'ros_processing_executed': False,
            'workers': 1, 'thread_limit': 1}


def snapshot_auxiliary(config, out):
    records = read(out / 'source_hashes.json')
    config = json.loads(json.dumps(config))
    directory = out / 'auxiliary_inputs'; directory.mkdir()
    def snapshot(value):
        src = Path(value).expanduser().resolve()
        if not src.is_file():
            raise FileNotFoundError(src)
        name = f'{len(records):04d}_{src.name}'
        dst = directory / name
        before = sha(src); shutil.copy2(src, dst)
        if sha(dst) != before or sha(src) != before:
            raise ValueError('auxiliary source changed during read')
        records.append({'path': str(src), 'sha256': before, 'snapshot': str(dst.relative_to(out))})
        return str(dst.resolve())
    for spec in config.get('audit', {}).values():
        for key in ('arrays', 'planes', 'old_points'):
            if spec.get(key):
                spec[key] = snapshot(spec[key])
    for groups in config.get('candidates', {}).get('groups', {}).values():
        for group in groups:
            if group.get('legacy_evidence_file'):
                group['legacy_evidence_file'] = snapshot(group['legacy_evidence_file'])
    write(out / 'source_hashes.json', records)
    return config


def check_vendor():
    for record in read(ROOT / 'source_inventory.json')['received']:
        if record['filename'].startswith('vendor/') and sha(ROOT / record['filename']) != record['sha256']:
            raise ValueError('frozen vendor source changed: ' + record['filename'])


def validate_config(config):
    allowed = {'v04_results', 'case', 'window', 'boundary', 'units', 'frames', 'reference_times', 'transforms',
               'frame_alignment', 'audit', 'candidates', 'registration_pairs', 'max_pairs', 'memory_limit_mib',
               'workers', 'node_references', 'dataset_kind'}
    extra = set(config) - allowed
    if extra:
        raise ValueError('unsupported configuration keys: ' + ','.join(sorted(extra)))
    if config.get('units') != 'm':
        raise ValueError('units must explicitly be m; no unverified unit conversion')
    if config.get('workers', 1) != 1:
        raise ValueError('this diagnostic release supports exactly one worker')
    if not 64 <= config.get('memory_limit_mib', 8192) <= 8192:
        raise ValueError('memory_limit_mib must be between 64 and 8192')
    if config.get('window', 'fixed11') not in ('fixed11', 'all'):
        raise ValueError('unsupported v04 window')
    if config.get('boundary', 'boundary_false') not in ('boundary_false', 'boundary_true'):
        raise ValueError('unsupported v04 boundary')
    if config.get('frame_alignment', {}).get('status') == 'verified' and not config['frame_alignment'].get('evidence'):
        raise ValueError('verified alignment requires an external evidence reference')


def finalize(out, state):
    try:
        state['integrity_passed'] = check_sources(out)
    except Exception as exc:
        state['integrity_passed'] = False
        state['integrity_error'] = str(exc)
    state['processing_complete'] = all(state['stages'].get(s) == 'COMPLETED' for s in STAGES)
    state['candidate_evaluation'] = 'DIAGNOSTIC_ONLY' if state['stages'].get('object_candidates') == 'COMPLETED' else 'NOT_RUN'
    state['identity_evaluation'] = 'UNKNOWN'
    state['update_evaluation'] = 'UNKNOWN'
    write(out / 'run_manifest.json', state)
    write(out / 'evaluation/status.json', {k: state[k] for k in ('processing_complete', 'integrity_passed', 'candidate_evaluation', 'identity_evaluation', 'update_evaluation')})
    links = []
    for path in sorted(out.rglob('*.html')):
        if path.name != 'index.html':
            rel = path.relative_to(out).as_posix()
            links.append(f'<li><a href="{html.escape(rel, quote=True)}">{html.escape(rel)}</a></li>')
    for rel in ('run_manifest.json', 'evaluation/status.json', 'assignment/assignment.json', 'scene_graph_proposal/proposals.json'):
        if (out / rel).exists():
            links.append(f'<li><a href="{rel}">{rel}</a></li>')
    (out / 'index.html').write_text('<!doctype html><meta charset="utf-8"><title>YLM v0.5 diagnostic results</title>'
                                  '<h1>YLM v0.5 診断結果</h1><p>処理完了・整合性と、物体同一性・更新精度の評価は別です。</p><pre>'
                                  + html.escape(json.dumps(state, ensure_ascii=False, indent=2)) + '</pre><ul>' + ''.join(links) + '</ul>', encoding='utf-8')
    hashes = {p.relative_to(out).as_posix(): sha(p) for p in out.rglob('*') if p.is_file() and p.name != 'artifact_hashes.json'}
    write(out / 'artifact_hashes.json', hashes)
    return state


def verify_run(out):
    out = Path(out).resolve()
    for rel, expected in read(out / 'artifact_hashes.json').items():
        p = (out / rel).resolve()
        if not p.is_relative_to(out) or sha(p) != expected:
            raise ValueError('artifact integrity failed: ' + rel)
    check_sources(out)
    return {'integrity_passed': True, 'processing_complete': read(out / 'run_manifest.json')['processing_complete'],
            'identity_evaluation': 'UNKNOWN'}


def run(config, out, replay=None, start='fragments'):
    out = Path(out).expanduser().resolve()
    if out.exists():
        raise FileExistsError('refusing to overwrite an existing output: ' + str(out))
    validate_config(config); check_vendor()
    source_root = Path(config['v04_results']).expanduser().resolve()
    if out.is_relative_to(source_root) or source_root.is_relative_to(out):
        raise ValueError('outputs must be separate from the v04 baseline tree')
    if replay and out.is_relative_to(Path(replay).resolve()):
        raise ValueError('replay output must be outside previous run')
    out.mkdir(parents=True)
    state = {'version': '0.5.0-diagnostic', 'dataset_kind': config.get('dataset_kind', 'user_input_unverified'),
             'stages': {}, 'processing_complete': False, 'integrity_passed': False,
             'upstream_processing': 'saved_v04_only; clustering source not supplied', 'scene_graph_modified': False}
    write(out / 'run_manifest.json', state)
    stage = 'initialization'
    try:
        write(out / 'environment.json', environment())
        if replay:
            replay = Path(replay).resolve(); verify_run(replay)
            old = read(replay / 'run_manifest.json')
            if start not in ('structure_audit', 'object_candidates', 'registration', 'assignment'):
                raise ValueError('invalid replay stage')
            needed = STAGES[:STAGES.index(start)]
            for name in needed:
                if old['stages'].get(name) not in ('COMPLETED', 'BLOCKED_MISSING_INPUT', 'PARTIAL_RECONSTRUCTION'):
                    raise ValueError('cannot replay from incomplete prerequisite ' + name)
                shutil.copytree(replay / name, out / name)
                state['stages'][name] = old['stages'][name]
            shutil.copy2(replay / 'source_hashes.json', out / 'source_hashes.json')
            shutil.copytree(replay / 'auxiliary_inputs', out / 'auxiliary_inputs')
            if start == 'registration':
                shutil.copytree(replay / 'registration/legacy_input', out / 'registration/legacy_input')
            if (out / 'registration/legacy_input').exists():
                for side in ('t0', 't1'):
                    path = out / 'registration/legacy_input' / f'{side}_merged_clusters.json'
                    values = read(path)
                    for value in values:
                        value['pcd'] = str((path.parent / Path(value['pcd']).name).resolve())
                    write(path, values)
            # Auxiliary paths point to the new immutable snapshot; never rewrite source run.
            for spec in config.get('audit', {}).values():
                for key in ('arrays', 'planes', 'old_points'):
                    if spec.get(key):
                        spec[key] = str(out / 'auxiliary_inputs' / Path(spec[key]).name)
                        if not Path(spec[key]).is_file():
                            raise ValueError('missing saved auxiliary input for replay')
            for groups in config.get('candidates', {}).get('groups', {}).values():
                for group in groups:
                    if group.get('legacy_evidence_file'):
                        group['legacy_evidence_file'] = str(out / 'auxiliary_inputs' / Path(group['legacy_evidence_file']).name)
            state['replay_of'] = {'run': str(replay), 'manifest_sha256': sha(replay / 'run_manifest.json'), 'from_stage': start}
        else:
            stage = 'fragments'; ingest(config, out); state['stages'][stage] = 'COMPLETED'
            config = snapshot_auxiliary(config, out)
        config.setdefault('workers', 1); config.setdefault('memory_limit_mib', 8192)
        write(out / 'resolved_config.json', config)
        for stage, operation in [('structure_audit', run_audit), ('object_candidates', run_candidates),
                                 ('registration', run_registration), ('assignment', run_decision)]:
            if stage in state['stages']:
                continue
            result = operation(config, out)
            state['stages'][stage] = 'COMPLETED'
            if stage == 'structure_audit':
                if any(v['status'] == 'BLOCKED_MISSING_AUDIT_INPUT' for v in result.values()):
                    state['stages'][stage] = 'BLOCKED_MISSING_INPUT'
                elif any(v['status'] == 'PARTIAL_RECONSTRUCTION' for v in result.values()):
                    state['stages'][stage] = 'PARTIAL_RECONSTRUCTION'
            write(out / 'run_manifest.json', state)
    except Exception as exc:
        state['stages'][stage] = 'FAILED_RESOURCE_LIMIT' if isinstance(exc, MemoryError) else 'FAILED'
        state['error'] = {'type': type(exc).__name__, 'message': str(exc)}
        (out / 'failure.txt').write_text(traceback.format_exc(), encoding='utf-8')
    return finalize(out, state)
