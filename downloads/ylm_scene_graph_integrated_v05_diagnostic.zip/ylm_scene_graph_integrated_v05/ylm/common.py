import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    with Path(path).open(encoding='utf-8') as f:
        return json.load(f)


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.write('\n')
    tmp.replace(path)


def jsonl(path, values):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as f:
        for value in values:
            json.dump(value, f, ensure_ascii=False, allow_nan=False)
            f.write('\n')


def rows(path):
    with Path(path).open(encoding='utf-8') as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def bridge():
    return module('frozen_bridge', ROOT / 'vendor/bridge_v02/bridge.py')


def rigid(matrix):
    t = np.asarray(matrix, dtype=float)
    if t.shape != (4, 4) or not np.isfinite(t).all():
        raise ValueError('rigid transform must be finite 4x4')
    if not np.allclose(t[3], [0, 0, 0, 1], atol=1e-8, rtol=0):
        raise ValueError('invalid homogeneous row')
    r = t[:3, :3]
    if not np.allclose(r.T @ r, np.eye(3), atol=1e-6, rtol=0) or not np.isclose(np.linalg.det(r), 1):
        raise ValueError('transform must have a proper rotation')
    return t


def transform(points, matrix):
    t = rigid(matrix)
    return np.asarray(points) @ t[:3, :3].T + t[:3, 3]


def obb(points, supplied=None):
    """No jitter: explicitly reject underdetermined 3D boxes."""
    p = np.asarray(points, dtype=float)
    if p.ndim != 2 or p.shape[1:] != (3,) or not np.isfinite(p).all():
        raise ValueError('expected finite Nx3 points')
    if len(p) < 4:
        return {'status': 'unavailable', 'reason': 'fewer_than_four_points'}
    singular = np.linalg.svd(p - p.mean(0), compute_uv=False)
    rank = int(np.count_nonzero(singular > max(1e-10, singular[0] * 1e-6)))
    if rank < 3:
        return {'status': 'unavailable', 'reason': ['empty', 'linear', 'planar'][rank], 'rank': rank}
    if supplied is not None:
        c, r, e = [np.asarray(supplied[k], dtype=float) for k in ('center', 'rotation', 'extent')]
        if c.shape != (3,) or r.shape != (3, 3) or e.shape != (3,) or not all(np.isfinite(a).all() for a in (c, r, e)):
            raise ValueError('invalid saved OBB shape/value')
        if (e <= 0).any() or not np.allclose(r.T @ r, np.eye(3), atol=1e-5):
            raise ValueError('invalid saved OBB axes/extent')
        return dict(status='available', method='saved_v04_obb', center=c.tolist(), rotation=r.tolist(), extent=e.tolist())
    _, eigenvectors = np.linalg.eigh(np.cov(p.T))
    axes = eigenvectors[:, ::-1]
    if np.linalg.det(axes) < 0:
        axes[:, -1] *= -1
    local = p @ axes
    low, high = local.min(0), local.max(0)
    return dict(status='available', method='deterministic_PCA_not_legacy_minimum_box',
                center=(axes @ ((low + high) / 2)).tolist(), rotation=axes.tolist(), extent=(high - low).tolist())


def ensure_budget(needed_bytes, limit_mib, label):
    if needed_bytes > limit_mib * 1024 ** 2:
        raise MemoryError(f'{label}: estimated {needed_bytes} bytes exceeds {limit_mib} MiB budget')
