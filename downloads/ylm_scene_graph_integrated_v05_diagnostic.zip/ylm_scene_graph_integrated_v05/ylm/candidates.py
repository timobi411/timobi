import numpy as np
from .common import read, write, jsonl, rows, obb, bridge, rigid, transform


def groups_for(fragments, requested, mode):
    by_id = {f['fragment_id']: f for f in fragments}
    if mode == 'single':
        return [{'fragment_ids': [fid], 'evidence': {'single_fragment_baseline': True}} for fid in sorted(by_id)]
    if mode not in ('relations', 'manual', 'legacy_occlusion'):
        raise ValueError('unknown candidate mode')
    for group in requested:
        ids = group['fragment_ids']
        if not ids or not set(ids).issubset(by_id):
            raise ValueError('candidate references unknown/empty fragments')
        if mode == 'relations' and not group.get('evidence'):
            raise ValueError('relation hypotheses require explicit evidence; proximity is not identity')
        if mode == 'legacy_occlusion' and not group.get('legacy_evidence_file'):
            raise ValueError('legacy comparison requires a saved merge evidence file')
    # Never compute transitive closure: each explicit group is an independent hypothesis.
    return requested


def form_side(config, out, side):
    spec = config.get('candidates', {})
    mode = spec.get('mode', 'single')
    fragments = list(rows(out / 'fragments' / side / 'fragments.jsonl'))
    by_id = {f['fragment_id']: f for f in fragments}
    groups = groups_for(fragments, spec.get('groups', {}).get(side, []), mode)
    folder = out / 'object_candidates' / side
    folder.mkdir(parents=True)
    with np.load(out / 'fragments' / side / 'pixel_correspondence.npz', allow_pickle=False) as z:
        xyz = z['xyz'].reshape(-1, 3)
    matrix = rigid(config.get('transforms', {}).get(side, np.eye(4).tolist()))
    min_points = int(spec.get('min_icp_points', 50))
    if min_points < 4:
        raise ValueError('min_icp_points must be >=4')
    legacy_dir = out / 'registration' / 'legacy_input'
    legacy_dir.mkdir(parents=True, exist_ok=True)
    records, exports = [], []
    b = bridge()
    for index, group in enumerate(groups):
        fids = sorted(set(map(int, group['fragment_ids'])))
        point_ids = sorted({pid for fid in fids for pid in by_id[fid]['source_point_ids']})
        native = xyz[point_ids]
        pts = transform(native, matrix)
        supplied = by_id[fids[0]]['source_metadata'].get('obb') if len(fids) == 1 else None
        box = obb(native, supplied)
        if box['status'] == 'available':
            box['center'] = transform([box['center']], matrix)[0].tolist()
            box['rotation'] = (matrix[:3, :3] @ np.asarray(box['rotation'])).tolist()
        cid = f'{side}:candidate:{index:06d}'
        name = f'candidate_{index:06d}.npz'
        np.savez_compressed(folder / name, source_point_ids=np.asarray(point_ids, dtype=np.int64), points=pts)
        reasons = []
        if len(pts) < min_points:
            reasons.append('below_minimum_standalone_icp_points')
        if box['status'] != 'available':
            reasons.append('obb_' + box['reason'])
        formation_holds = [] if mode == 'single' else ['diagnostic_candidate_formation_not_calibrated']
        candidate = {'candidate_id': cid, 'legacy_id': index, 'source_fragment_ids': fids,
                     'source_point_ids': point_ids, 'point_namespace': side + ':organized_flat_pixel',
                     'source_membership': {str(fid): by_id[fid]['source_point_ids'] for fid in fids},
                     'formation_method': mode, 'formation_evidence': group.get('evidence', {}),
                     'legacy_merge_evidence_file': group.get('legacy_evidence_file'),
                     'formation_hold_reasons': formation_holds, 'identity_status': 'UNKNOWN',
                     'manual_diagnostic': mode == 'manual', 'automatic_adoption': False,
                     'geometry_file': name, 'point_count': len(pts), 'obb': box,
                     'icp_eligible': not reasons, 'icp_exclusion_reasons': reasons,
                     'native_to_common': matrix.tolist(), 'persistent_object_id': None}
        records.append(candidate)
        if not reasons:
            pcd = legacy_dir / f'{side}_candidate_{index:06d}.pcd'
            b.write_pcd(pcd, pts)
            exports.append({'merged_id': index, 'source_clusters': fids, 'points': len(pts),
                            'pcd': str(pcd.resolve()), 'center': box['center'], 'extent': box['extent'],
                            'rotation': box['rotation'], 'candidate_id': cid})
    jsonl(folder / 'candidates.jsonl', records)
    # The same organized pixel may be part of several diagnostic hypotheses.
    owners = {}
    for c in records:
        for pid in c['source_point_ids']:
            owners.setdefault(pid, []).append(c['candidate_id'])
    jsonl(folder / 'overlap.jsonl', ({'source_point_id': pid, 'candidate_ids': cids} for pid, cids in owners.items() if len(cids) > 1))
    write(legacy_dir / f'{side}_merged_clusters.json', exports)
    write(folder / 'summary.json', {'mode': mode, 'candidate_count': len(records), 'eligible_count': len(exports),
                                    'fragment_count': len(fragments), 'identity_evaluation': 'UNKNOWN',
                                    'relation_search_completeness': spec.get('relation_search_completeness', 'UNKNOWN'),
                                    'transitive_closure': False})
    return records


def run_candidates(config, out):
    return {s: form_side(config, out, s) for s in ('t0', 't1')}
