"""Explicit diagnostic plane contract, never guessed from upstream fields."""
from pathlib import Path
import zipfile
import numpy as np
from scipy.spatial import cKDTree
from .common import read, write, jsonl, ensure_budget, transform, rigid


def polygon_inside_distance(uv, polygon):
    polygon = np.asarray(polygon, float)
    if polygon.ndim != 2 or polygon.shape[1] != 2 or len(polygon) < 3 or not np.isfinite(polygon).all():
        raise ValueError('footprint needs a finite simple polygon in plane UV')
    area = np.sum(polygon[:, 0] * np.roll(polygon[:, 1], -1) - polygon[:, 1] * np.roll(polygon[:, 0], -1))
    if abs(area) < 1e-12:
        raise ValueError('degenerate footprint polygon')
    inside = np.zeros(len(uv), dtype=bool)
    distance = np.full(len(uv), np.inf)
    for a, b in zip(polygon, np.roll(polygon, -1, axis=0)):
        edge = b - a
        if np.dot(edge, edge) < 1e-20:
            raise ValueError('duplicate consecutive polygon vertex')
        t = np.clip(((uv - a) @ edge) / np.dot(edge, edge), 0, 1)
        distance = np.minimum(distance, np.linalg.norm(uv - (a + t[:, None] * edge), axis=1))
        if a[1] != b[1]:
            crossing = ((a[1] > uv[:, 1]) != (b[1] > uv[:, 1])) & (
                uv[:, 0] < (b[0] - a[0]) * (uv[:, 1] - a[1]) / (b[1] - a[1]) + a[0])
            inside ^= crossing
    return inside | (distance <= 1e-12), distance


def plane_conditions(points, plane):
    coeff = np.asarray(plane['coefficients'], dtype=float)
    if coeff.shape != (4,) or not np.isfinite(coeff).all() or np.linalg.norm(coeff[:3]) < 1e-12:
        raise ValueError('invalid plane coefficients')
    coeff = coeff / np.linalg.norm(coeff[:3])
    width, margin = float(plane['distance_width_m']), float(plane.get('footprint_margin_m', 0))
    if not np.isfinite([width, margin]).all() or min(width, margin) < 0:
        raise ValueError('invalid plane thresholds')
    distance = np.abs(points @ coeff[:3] + coeff[3])
    footprint = plane.get('footprint')
    within = None
    if footprint is not None:
        origin, axes = np.asarray(footprint['origin'], float), np.asarray(footprint['axes'], float)
        if origin.shape != (3,) or axes.shape != (3, 2) or not np.isfinite(origin).all() or not np.isfinite(axes).all():
            raise ValueError('invalid plane basis')
        if not np.allclose(axes.T @ axes, np.eye(2), atol=1e-6) or not np.allclose(coeff[:3] @ axes, 0, atol=1e-6):
            raise ValueError('footprint axes must be orthonormal and parallel to plane')
        if abs(origin @ coeff[:3] + coeff[3]) > 1e-6:
            raise ValueError('footprint origin must lie on plane')
        inside, edge_distance = polygon_inside_distance((points - origin) @ axes, footprint['polygon_uv'])
        within = inside | (edge_distance <= margin)
    rule = plane.get('rule_kind')
    if rule == 'infinite_band':
        matches = distance <= width
    elif rule == 'finite_polygon_band' and within is not None:
        matches = (distance <= width) & within
    else:
        raise ValueError('missing/unsupported original rule: cannot reconstruct removal')
    return coeff, distance, within, matches


def correspondence(old_points, xyz, valid, canonical, radius=0.03):
    old = np.asarray(old_points, float)
    if old.ndim != 2 or old.shape[1] != 3 or not np.isfinite(old).all():
        raise ValueError('old points must be finite Nx3')
    ids = np.flatnonzero(valid.ravel())
    if not len(ids):
        return dict(old_point_ids=np.arange(len(old)), nearest_pixel_ids=np.full(len(old), -1),
                    distance_m=np.full(len(old), np.inf), within_radius=np.zeros(len(old), bool),
                    unique_matched_pixels=np.array([], dtype=int), unique_masked_pixels=np.array([], dtype=int))
    dist, near = cKDTree(xyz.reshape(-1, 3)[ids]).query(old)
    close = dist <= radius
    matched = np.unique(ids[near[close]])
    return dict(old_point_ids=np.arange(len(old)), nearest_pixel_ids=ids[near], distance_m=dist,
                within_radius=close, unique_matched_pixels=matched,
                unique_masked_pixels=matched[canonical.ravel()[matched]])


def review(folder, xyz, valid, canonical, planes, old=None, matched=None):
    import plotly.graph_objects as go
    fig = go.Figure()
    points, colors = [], []
    def trace(label, p, color):
        p = np.asarray(p, float).reshape(-1, 3)
        # Display-only reduction. Numerical evaluation uses all input points.
        shown = p[::max(1, int(np.ceil(len(p) / 12000)))]
        points.extend(shown.tolist()); colors.extend([color] * len(shown))
        fig.add_trace(go.Scatter3d(x=shown[:, 0], y=shown[:, 1], z=shown[:, 2], mode='markers',
                                  marker=dict(size=2, color='rgb(%s)' % ','.join(map(str, color))),
                                  name=f'{label} (display {len(shown)}/{len(p)})'))
    trace('remaining observation', xyz[valid & ~canonical], (100, 150, 210))
    trace('canonical removed', xyz[valid & canonical], (210, 80, 70))
    if old is not None:
        trace('old candidate; identity unknown', old, (255, 190, 0))
    if matched is not None:
        trace('unique matched removed pixels', xyz.reshape(-1, 3)[matched], (230, 0, 200))
    for p in planes:
        if p.get('support_xyz') is not None:
            trace('plane ' + str(p['plane_id']) + ' support', p['support_xyz'], (80, 220, 80))
        fp = p.get('footprint')
        if fp:
            vertices = np.asarray(fp['polygon_uv']) @ np.asarray(fp['axes']).T + np.asarray(fp['origin'])
            vertices = np.vstack([vertices, vertices[0]])
            fig.add_trace(go.Scatter3d(x=vertices[:, 0], y=vertices[:, 1], z=vertices[:, 2], mode='lines', name='footprint ' + str(p['plane_id'])))
    fig.update_layout(title='Structure audit — diagnostic; physical plane roles unverified', scene_aspectmode='data')
    fig.write_html(folder / 'review.html', include_plotlyjs=True)
    with (folder / 'overlay.ply').open('w') as f:
        f.write(f'ply\nformat ascii 1.0\ncomment DISPLAY ONLY, not numeric evaluation\nelement vertex {len(points)}\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n')
        for p, c in zip(points, colors):
            f.write(' '.join(map(str, p + list(c))) + '\n')


def audit_side(spec, folder, memory_mib=8192):
    folder.mkdir(parents=True)
    if not spec:
        result = {'status': 'BLOCKED_MISSING_AUDIT_INPUT', 'A': 'unavailable', 'B': 'unavailable', 'C': 'unavailable',
                  'missing': ['pre-removal organized points', 'canonical mask', 'plane rules/support/provenance'],
                  'historical_removal_causes': 'UNKNOWN'}
        write(folder / 'audit.json', result)
        return result
    with zipfile.ZipFile(spec['arrays']) as archive:
        ensure_budget(sum(i.file_size for i in archive.infolist()) * 6, memory_mib, 'audit input decompression')
    with np.load(spec['arrays'], allow_pickle=False) as z:
        xyz, valid, canonical = (z[k] for k in ('xyz', 'valid', 'canonical_mask'))
    if xyz.ndim != 3 or xyz.shape[2] != 3 or valid.shape != xyz.shape[:2] or canonical.shape != valid.shape:
        raise ValueError('audit arrays must have matching organized shapes')
    if valid.dtype.kind != 'b' or canonical.dtype.kind != 'b' or not np.isfinite(xyz[valid]).all():
        raise ValueError('invalid audit mask/coordinates')
    model = read(spec['planes'])
    planes = model['planes']
    ids = [str(p['plane_id']) for p in planes]
    if len(ids) != len(set(ids)):
        raise ValueError('plane IDs must be unique within this run')
    point_ids = np.flatnonzero(valid.ravel())
    pts = xyz.reshape(-1, 3)[point_ids]
    ensure_budget(len(planes) * len(pts) + xyz.nbytes * 8, memory_mib, 'structure audit')
    hits = np.zeros((len(planes), len(pts)), bool)
    missing = []
    for index, plane in enumerate(planes):
        try:
            coeff, distance, inside, matches = plane_conditions(pts, plane)
            hits[index] = matches
            np.savez_compressed(folder / f'plane_{index:04d}.npz', source_pixel_ids=point_ids,
                                distance_m=distance, footprint_inside=inside if inside is not None else np.full(len(pts), -1),
                                condition=matches)
            record = dict(plane, normalized_coefficients=coeff.tolist(), condition_file=f'plane_{index:04d}.npz',
                          missing_provenance=[k for k in ('support_xyz', 'support_pixel_ids', 'measurement_provenance') if k not in plane])
            write(folder / f'plane_{index:04d}.json', record)
        except (ValueError, KeyError) as exc:
            missing.append({'plane_id': ids[index], 'reason': str(exc)})
    complete = bool(model.get('plane_set_complete', False)) and not missing
    excluded = set(map(str, spec.get('exclude_plane_ids', [])))
    if not excluded.issubset(set(ids)):
        raise ValueError('excluded plane ID does not exist in this run')
    b = np.zeros(valid.size, bool); c = b.copy()
    b[point_ids] = hits.any(axis=0)
    keep = [i for i, pid in enumerate(ids) if pid not in excluded]
    c[point_ids] = hits[keep].any(axis=0) if keep else False
    np.savez_compressed(folder / 'mask_comparison.npz', A_canonical=canonical,
                        B_model_reconstruction=b.reshape(valid.shape), C_model_exclusion=c.reshape(valid.shape),
                        A_B_disagreement=canonical ^ b.reshape(valid.shape))
    jsonl(folder / 'pixel_reasons.jsonl', (
        {'source_pixel_id': int(pid), 'all_matching_plane_ids': [ids[j] for j in np.flatnonzero(hits[:, i])],
         'canonical_removed': bool(canonical.ravel()[pid]), 'model_removed': bool(b[pid]),
         'exclusion_model_removed': bool(c[pid]), 'historical_cause': 'UNKNOWN'}
        for i, pid in enumerate(point_ids)))
    result = {'status': 'MODEL_DIAGNOSTIC_COMPLETE' if complete else 'PARTIAL_RECONSTRUCTION',
              'A': 'canonical_unchanged', 'B': 'model_reconstruction_not_verified_original_code',
              'C': 'model_exclusion' if complete else 'partial_model_exclusion_not_restoration',
              'plane_set_complete': complete, 'unreconstructable': missing,
              'historical_removal_causes': 'UNKNOWN', 'physical_plane_roles': 'UNKNOWN',
              'excluded_plane_ids': sorted(excluded), 'canonical_removed': int(canonical.sum()),
              'model_removed': int(b.sum()), 'A_B_disagreement': int(np.count_nonzero(canonical.ravel() ^ b)),
              'model_exclusion_removed': int(c.sum()), 'improvement_evaluation': 'UNKNOWN',
              'original_predicate_provenance': model.get('predicate_provenance'),
              'coordinate_frame': spec.get('frame_id'), 'display_only_decimation': True}
    old = None; masked = None
    if spec.get('old_points'):
        if 'old_to_observation' not in spec:
            raise ValueError('old points require explicit old_to_observation transform, including identity')
        old = transform(np.load(spec['old_points'], allow_pickle=False), rigid(spec['old_to_observation']))
        corr = correspondence(old, xyz, valid, canonical)
        np.savez_compressed(folder / 'correspondence.npz', **corr)
        masked = corr['unique_masked_pixels']
        result['old_correspondence'] = {'old_count': len(old), 'within_3cm_old_points': int(corr['within_radius'].sum()),
                                        'unique_pixels': len(corr['unique_matched_pixels']), 'unique_masked_pixels': len(masked),
                                        'point_identity': 'UNKNOWN'}
    write(folder / 'audit.json', result)
    review(folder, xyz, valid, canonical, planes, old, masked)
    return result


def run_audit(config, out):
    return {side: audit_side(config.get('audit', {}).get(side), out / 'structure_audit' / side,
                             config.get('memory_limit_mib', 8192)) for side in ('t0', 't1')}
