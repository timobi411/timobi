"""Frozen legacy ICP with all initial hypotheses and full-resolution audit metrics."""
import math
import json
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
from .common import ROOT, module, read, write, rows, jsonl, transform, rigid, sha


def distance_summary(distance, threshold):
    d = np.asarray(distance)
    mask = d <= threshold
    return {'point_count': len(d), 'correspondence_count': int(mask.sum()),
            'coverage': float(mask.mean()) if len(d) else 0.0,
            'mean_distance_m': float(d.mean()) if len(d) else None,
            'median_distance_m': float(np.median(d)) if len(d) else None,
            'p95_distance_m': float(np.percentile(d, 95)) if len(d) else None,
            'inlier_rmse_m': float(np.sqrt(np.mean(d[mask] ** 2))) if mask.any() else None}


def metrics(source, target, t, threshold):
    moved = transform(source, t)
    if not len(source) or not len(target):
        raise ValueError('empty ICP evaluation cloud')
    d0, i0 = cKDTree(target).query(moved)
    d1, i1 = cKDTree(moved).query(target)
    displacement = np.linalg.norm(moved - source, axis=1)
    # Transform translation is coordinate-dependent and is not center displacement.
    center = source.mean(axis=0)
    angle = math.degrees(math.acos(float(np.clip((np.trace(t[:3, :3]) - 1) / 2, -1, 1))))
    def spacing(p):
        return float(np.median(cKDTree(p).query(p, k=2)[0][:, 1])) if len(p) > 1 else None
    value = {'source_to_target': distance_summary(d0, threshold), 'target_to_source': distance_summary(d1, threshold),
             'distance_threshold_m': threshold, 'evaluation_points': 'all candidate measured points; no display decimation',
             'density': {'source_median_nn_spacing_m': spacing(source), 'target_median_nn_spacing_m': spacing(target)},
             'overlap': {'unique_target_points': int(len(np.unique(i0[d0 <= threshold]))),
                         'unique_source_points': int(len(np.unique(i1[d1 <= threshold])))},
             'point_displacement_m': {'median': float(np.median(displacement)), 'mean': float(displacement.mean()),
                                      'p95': float(np.percentile(displacement, 95))},
             'center_displacement_m': float(np.linalg.norm(transform([center], t)[0] - center)),
             'rotation_angle_deg': angle, 'matrix_translation_m': t[:3, 3].tolist(),
             'independent_validation': False}
    return value, {'forward_distance_m': d0, 'reverse_distance_m': d1, 'forward_target_indices': i0,
                   'reverse_source_indices': i1, 'point_displacement_m': displacement}


def evaluate(legacy, source, target, pair_folder, t0_matrix, t1_matrix, solver_source=None, solver_target=None):
    import open3d as o3d
    def cloud(p):
        c = o3d.geometry.PointCloud()
        c.points = o3d.utility.Vector3dVector(p)
        return c
    a = cloud(source if solver_source is None else solver_source)
    b = cloud(target if solver_target is None else solver_target)
    initial_yaws = list(legacy.YAW_CANDIDATES)
    hypotheses = []
    original_icp, original_fit = legacy.registration_icp_4dof, legacy.planar_rigid_fit
    calls, count = [], [0]
    def tracked_fit(*args, **kwargs):
        count[0] += 1
        return original_fit(*args, **kwargs)
    def tracked_icp(*args, **kwargs):
        count[0] = 0
        result = original_icp(*args, **kwargs)
        calls.append({'update_iterations': count[0], 'fitness': result.fitness,
                      'inlier_rmse': result.inlier_rmse, 'convergence_reason': 'not_exposed_by_frozen_solver'})
        return result
    legacy.planar_rigid_fit, legacy.registration_icp_4dof = tracked_fit, tracked_icp
    try:
        for index, yaw in enumerate(initial_yaws):
            legacy.YAW_CANDIDATES = [yaw]
            calls.clear()
            result = legacy.evaluate_pair(a, b)
            if result is None:
                continue
            t = rigid(result['transformation'])
            extra, arrays = metrics(source, target, t, legacy.FINE_DISTANCE)
            filename = f'hypothesis_{index:02d}_correspondences.npz'
            np.savez_compressed(pair_folder / filename, **arrays)
            native = np.linalg.inv(rigid(t1_matrix)) @ t @ rigid(t0_matrix)
            hypotheses.append({'legacy_result': result, 'metrics': extra, 'solver_stages': list(calls),
                               'convergence_status': 'UNKNOWN_LEGACY_REASON_NOT_EXPOSED',
                               'correspondence_file': filename, 'common_t0_to_common_t1': t.tolist(),
                               'native_t0_to_native_t1': native.tolist(), 'native_t1_to_native_t0': np.linalg.inv(native).tolist()})
    finally:
        legacy.YAW_CANDIDATES = initial_yaws
        legacy.planar_rigid_fit, legacy.registration_icp_4dof = original_fit, original_icp
    if not hypotheses:
        raise ValueError('frozen ICP produced no hypotheses')
    best = max(range(len(hypotheses)), key=lambda i: hypotheses[i]['legacy_result']['score'])
    best_h = hypotheses[best]
    reference = transform(source, best_h['common_t0_to_common_t1'])
    differences = []
    ambiguous = False
    for i, h in enumerate(hypotheses):
        delta = float(np.median(np.linalg.norm(transform(source, h['common_t0_to_common_t1']) - reference, axis=1)))
        gap = best_h['legacy_result']['score'] - h['legacy_result']['score']
        differences.append({'hypothesis': i, 'score_gap': gap, 'point_transform_difference_m': delta})
        if i != best and gap <= 0.02 and delta > 0.02:
            ambiguous = True
    return {'hypotheses': hypotheses, 'selected_hypothesis': best, 'hypothesis_differences': differences,
            'ambiguous': ambiguous, 'ambiguity_rule': {'score_gap_max': 0.02, 'point_transform_difference_min_m': 0.02,
                                                       'status': 'diagnostic_uncalibrated'},
            'score': best_h['legacy_result']['score'], 'legacy_valid': best_h['legacy_result']['valid'],
            'identity_status': 'UNKNOWN',
            'preprocessing': {'voxel_m': legacy.VOXEL, 'centering': 'yaw initialization about voxel source centroid only',
                              'structure_removal_repeated': False, 'coarse_distance_m': legacy.COARSE_DISTANCE,
                              'fine_distance_m': legacy.FINE_DISTANCE, 'max_iterations_per_stage': legacy.MAX_ITER,
                              'dof': 'yaw + xyz translation', 'normalization': 'none',
                              'adapter_storage': 'float32 ASCII XYZ PCD, same as frozen bridge'}}


def run_registration(config, out):
    path = ROOT / 'vendor/bridge_v02/legacy/baseline_icp_B0.py'
    legacy = module('frozen_icp', path)
    inputs = out / 'registration/legacy_input'
    meta = {s: read(inputs / f'{s}_merged_clusters.json') for s in ('t0', 't1')}
    candidates = {s: {c['candidate_id']: c for c in rows(out / 'object_candidates' / s / 'candidates.jsonl')} for s in ('t0', 't1')}
    root = out / 'registration'
    selected = config.get('registration_pairs')
    selected = {tuple(p) for p in selected} if selected is not None else None
    if selected is not None:
        for a, b in selected:
            if a not in candidates['t0'] or b not in candidates['t1']:
                raise ValueError('requested pair references unknown candidate')
    max_pairs = int(config.get('max_pairs', 10000))
    expected = len(selected) if selected is not None else len(meta['t0']) * len(meta['t1'])
    if expected > max_pairs:
        raise MemoryError(f'pair search limit exceeded: {expected}>{max_pairs}; no claim of absent relations')
    results = []
    for a in meta['t0']:
        for b in meta['t1']:
            pair = (a['candidate_id'], b['candidate_id'])
            if selected is not None and pair not in selected:
                continue
            record = {'source': pair[0], 'target': pair[1], 'identity_status': 'UNKNOWN'}
            gate = legacy.obb_candidate_gate(a, b)
            record['obb_gate'] = gate
            if not gate['candidate']:
                record.update(status='GATE_REJECTED', score=0.0, legacy_valid=False, ambiguous=False)
            else:
                folder = root / f'pair_{a["merged_id"]:06d}_{b["merged_id"]:06d}'
                folder.mkdir()
                ca, cb = candidates['t0'][pair[0]], candidates['t1'][pair[1]]
                with np.load(out / 'object_candidates/t0' / ca['geometry_file'], allow_pickle=False) as z:
                    source = z['points']
                with np.load(out / 'object_candidates/t1' / cb['geometry_file'], allow_pickle=False) as z:
                    target = z['points']
                solver_source = np.asarray(legacy.load_cloud(inputs / Path(a['pcd']).name).points)
                solver_target = np.asarray(legacy.load_cloud(inputs / Path(b['pcd']).name).points)
                detail = evaluate(legacy, source, target, folder, ca['native_to_common'], cb['native_to_common'], solver_source, solver_target)
                detail.update(frame_alignment=config.get('frame_alignment', {'status': 'unknown'}),
                              candidate_pair=list(pair), legacy_script_sha256=sha(path))
                write(folder / 'result.json', detail)
                record.update(status='EVALUATED', detail=str((folder / 'result.json').relative_to(out)),
                              **{k: detail[k] for k in ('score', 'legacy_valid', 'ambiguous')})
            results.append(record)
            # Preserve progress incrementally without serializing the whole history per pair.
            with (root / 'pairs.jsonl').open('a', encoding='utf-8') as stream:
                json.dump(record, stream, ensure_ascii=False, allow_nan=False)
                stream.write('\n')
    jsonl(root / 'pairs.jsonl', results)
    if selected is not None and len(results) != len(selected):
        raise ValueError('requested pair includes an ICP-ineligible candidate')
    write(root / 'summary.json', {'planned_pairs': expected, 'processed_pairs': len(results),
                                  'evaluated_pairs': sum(r['status'] == 'EVALUATED' for r in results),
                                  'scope': 'explicit_subset' if selected is not None else 'all_eligible_candidates',
                                  'identity_evaluation': 'UNKNOWN', 'legacy_script_sha256': sha(path)})
    return results
