# 監査入力契約（新規診断用、上流の形式ではない）

`config.audit.t0` と `t1` はそれぞれ次の形式です。相対パスはconfigファイルの位置を基準とします。

```json
{
  "arrays": "audit_t1.npz",
  "planes": "planes_t1.json",
  "frame_id": "confirmed_frame_name",
  "exclude_plane_ids": ["8"],
  "old_points": "old_M2.npy",
  "old_to_observation": [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]
}
```

`old_points` と `old_to_observation` は任意ですが、旧点群を指定する場合は変換も必須です。同一フレームを確認できた場合にのみidentityを指定します。旧点群が未確認の位置合わせの場合は床監査の数値を確定した再現として扱えません。

NPZは `xyz`（除去前のH×W×3、m）、`valid`（H×W bool）、`canonical_mask`（H×W bool、true=実際に除去）。JSONは以下です。

```json
{
  "plane_set_complete": false,
  "predicate_provenance": {"source_file":"actual_mask_code.py", "sha256":"要実確認", "notes":"未確認ならその旨を記録"},
  "planes": [{
    "plane_id":"8", "role":"floor_hypothesis",
    "coefficients":[0,0,1,0],
    "distance_width_m":0.04, "footprint_margin_m":0.0,
    "rule_kind":"finite_polygon_band",
    "footprint":{
      "origin":[0,0,0], "axes":[[1,0],[0,1],[0,0]],
      "polygon_uv":[[-1,-1],[1,-1],[1,1],[-1,1]]
    },
    "support_xyz":[[0,0,0],[1,0,0],[0,1,0]],
    "support_pixel_ids":[0,1,2],
    "measurement_provenance":{"status":"ここに実際の測定・フレーム来歴を記載"}
  }]
}
```

上は**形式説明用の架空値**です。床ID 8の実測モデルではありません。係数は `ax+by+cz+d=0` として正規化します。axesは3×2の直交単位基底、polygon_uvは単純な有限多角形。距離幅以下、かつ多角形内または境界からmargin以内を満たす点がfinite_polygon_bandに該当します。実際の旧判定が無限平面なら `rule_kind: "infinite_band"` を明示します。有限footprintの保存と除去時の使用有無は別です。

各平面の支持点・元画素・測定来歴はそのまま保存します。不足項目は `missing_provenance` に記録します。IDはこの実行内だけの識別子です。

出力：

- `plane_NNNN.npz`：全valid画素の平面距離、footprint内外、条件。footprintなしの内外は-1（不明）。
- `plane_NNNN.json`：正規化係数、設定、支持点、来歴。
- `pixel_reasons.jsonl`：画素ごとの全該当ID、実mask、再計算mask、除外後mask。過去の除去原因はUNKNOWN。
- `mask_comparison.npz`：A canonical、Bモデル、C除外診断とA/B差分。
- `correspondence.npz`：旧点のID、距離、最近傍画素、3 cm以内の旧点数と一意画素を分離できる配列。
- `review.html` / `overlay.ply`：除去点、残存点、旧点、対応除去画素、支持点、footprintの3D表示。PLYは表示用間引き。数値は全点を使用。

平面条件が不明ならB/Cは部分再現です。完全な平面集合がなくても既知の平面を診断しますが、Cで復活可能な点が確定したとは扱いません。モデル条件のAとの一致も、元コードの完全再現や平面の物理的な正しさの証明にはなりません。
