"""Generate labeled SYNTHETIC inputs; never substitutes for the formal v0.4 baseline."""
import argparse
import json
from pathlib import Path
import numpy as np


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2), encoding='utf-8')


def make(root):
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=False)
    rng = np.random.default_rng(9173)
    obj = rng.uniform([-0.12, -0.08, 0.15], [0.18, 0.11, 0.46], (100, 3)).astype(np.float32)
    config = {'v04_results': str(root / 'v04'), 'case': 'exp02', 'window': 'fixed11', 'boundary': 'boundary_false',
              'units': 'm', 'frames': {'t0': 'synthetic', 't1': 'synthetic'},
              'reference_times': {'t0': 'synthetic_T0', 't1': 'synthetic_T1'},
              'frame_alignment': {'status': 'unknown'}, 'audit': {}, 'dataset_kind': 'SYNTHETIC',
              'candidates': {'mode': 'single', 'min_icp_points': 50}, 'memory_limit_mib': 8192, 'workers': 1}
    plane = {'plane_id': 'example_floor', 'role': 'floor_hypothesis', 'coefficients': [0, 0, 2, 0],
             'distance_width_m': 0.04, 'footprint_margin_m': 0, 'rule_kind': 'finite_polygon_band',
             'footprint': {'origin': [0, 0, 0], 'axes': [[1, 0], [0, 1], [0, 0]],
                           'polygon_uv': [[-1, -1], [1, -1], [1, 1], [-1, 1]]},
             'support_xyz': [[0, 0, 0], [0.5, 0, 0], [0, 0.5, 0]], 'support_pixel_ids': [],
             'measurement_provenance': {'kind': 'synthetic', 'support_pixel_mapping': 'not applicable'}}
    for side in ('t0', 't1'):
        xyz = np.zeros((11, 10, 3), np.float32)
        xyz.reshape(-1, 3)[:100] = obj + ([0.025, -0.01, 0] if side == 't1' else [0, 0, 0])
        xyz.reshape(-1, 3)[100:103] = [[0.8, 0, 0.2], [0.8, 0.01, 0.2], [0.8, 0.02, 0.2]]
        xyz.reshape(-1, 3)[103:] = [[0, 0, 0.01], [0.1, 0.1, 0.02], [2, 0, 0.01],
                                   [0.3, 0, 0.03], [0.4, 0, 0], [0.5, 0, 0.02], [0.6, 0, 0.01]]
        valid = np.ones((11, 10), bool)
        labels = np.full((11, 10), -1, np.int32)
        labels.ravel()[:100] = 7; labels.ravel()[100:103] = 8
        canonical = np.zeros((11, 10), bool); canonical.ravel()[103:] = True; canonical.ravel()[105] = False
        sub = root / 'v04/cases' / ('exp02_' + side) / 'fixed11/boundary_false'
        sub.mkdir(parents=True)
        np.savez_compressed(sub / 'pixel_correspondence.npz', xyz=xyz, valid=valid, labels=labels)
        pts = xyz.reshape(-1, 3)[:100]
        save(sub / 'measured/clusters.json', {'clusters': [
            {'id': 7, 'point_count': 100, 'MODEL_INFERRED': 0,
             'obb': {'center': ((pts.max(0) + pts.min(0)) / 2).tolist(), 'extent': (pts.max(0) - pts.min(0)).tolist(), 'rotation': np.eye(3).tolist()}},
            {'id': 8, 'point_count': 3, 'MODEL_INFERRED': 0}]})
        folder = root / 'audit' / side; folder.mkdir(parents=True)
        np.savez_compressed(folder / 'arrays.npz', xyz=xyz, valid=valid, canonical_mask=canonical)
        save(folder / 'planes.json', {'plane_set_complete': True, 'planes': [plane],
                                     'predicate_provenance': 'synthetic example, not historical v04'})
        config['audit'][side] = {'arrays': str(folder / 'arrays.npz'), 'planes': str(folder / 'planes.json'), 'exclude_plane_ids': ['example_floor']}
    save(root / 'config.json', config)
    return root / 'config.json'


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--out', required=True)
    print(make(p.parse_args().out))
