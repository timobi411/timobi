"""Real received EXP02 pair: solver equivalence only, NOT identity/accuracy ground truth."""
import argparse
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ylm.common import module, sha, write
from ylm.registration import evaluate


def main(out):
    out = Path(out).resolve(); out.mkdir(parents=True, exist_ok=False)
    legacy = module('real_pair_legacy', ROOT / 'vendor/bridge_v02/legacy/baseline_icp_B0.py')
    paths = [ROOT / 'validation/fixtures' / name for name in ('exp02_t0_M1.pcd', 'exp02_t1_M2.pcd')]
    clouds = [legacy.load_cloud(p) for p in paths]
    source, target = [np.asarray(c.points) for c in clouds]
    detail = evaluate(legacy, source, target, out, np.eye(4), np.eye(4))
    baseline = legacy.evaluate_pair(*clouds)
    chosen = detail['hypotheses'][detail['selected_hypothesis']]['legacy_result']
    np.testing.assert_allclose(chosen['transformation'], baseline['transformation'], atol=1e-12, rtol=0)
    if abs(chosen['score'] - baseline['score']) > 1e-12:
        raise AssertionError('legacy score changed')
    detail['scope'] = 'real historical EXP02 T0 M1 -> T1 M2; not v04 fragments, not ground truth'
    detail['frame_alignment'] = 'snapshot claims alignment; not independently verified here'
    write(out / 'result.json', detail)
    write(out / 'verification.json', {'status': 'PASS_SOLVER_EQUIVALENCE_ONLY', 'source_points': len(source),
                                     'target_points': len(target), 'initial_hypotheses': len(detail['hypotheses']),
                                     'identity_evaluation': 'UNKNOWN', 'update_evaluation': 'UNKNOWN',
                                     'sources': [{'filename': p.name, 'sha256': sha(p)} for p in paths],
                                     'legacy_score': baseline['score'], 'legacy_valid': baseline['valid'],
                                     'legacy_script_sha256': sha(ROOT / 'vendor/bridge_v02/legacy/baseline_icp_B0.py')})
    print('PASS: same frozen solver output for real historical pair; identity UNKNOWN')


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--out', required=True)
    main(p.parse_args().out)
