# YLM-X001 シーングラフ更新案・診断統合 v0.5

**配布状態：保存済みv0.4出力からの下流統合を実装した診断版です。仕様書全体の実装・実データ検証完了版ではありません。**

指定された `ylm_v04_registration_bridge_v02` の入力形式と旧ICPを採用しました。クラスタリング方式を旧adaptive版へ置き換えていません。受領した2つのZIPにはv0.4クラスタリング本体・正式なv0.4出力がないため、上流の時間統合・構造除去・organizedクラスタリングは再実行しません。

原本と正式結果は別に保持し、このディレクトリと新規の出力ディレクトリだけを使用します。ICP・Hungarianの結果を永続シーングラフへ自動反映するコマンドはありません。

## 内容

- `vendor/bridge_v02/`：受領した接続版と旧ICP・旧割当を内容変更せず保存。
- `vendor/progress_downstream/`：progressの凍結ICP・割当・遮蔽結合コードを内容変更せず保存。
- `ylm/`：監査、断片保持、候補生成、旧ICPの初期値別診断、幾何割当、更新案。
- `examples/`：合成データ生成と受領実点群での旧ICP一致検査。
- `validation/`：実行済み検証結果と、旧exp02 M1→M2の点群2個。これは正解対応ではありません。
- `docs/specification_v05_design_1.txt`：受領仕様書。
- `docs/IMPLEMENTATION_STATUS.md`：実装範囲・未実装・未検証の一覧。
- `source_inventory.json`：受領ファイル・原本コードのSHA-256。

## 環境

Linux / Python 3.12、CPUで確認しました。CUDAは不要です。

```bash
cd ylm_scene_graph_integrated_v05
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python -m unittest discover -s tests -v
python -m unittest discover -s vendor/bridge_v02/tests -v
```

統合CLIは1 worker・数値ライブラリ1 threadを使用します。Linuxでは `memory_limit_mib`（既定8192）の仮想アドレス空間上限を設定し、入力展開と割当行列にも事前上限検査を行います。8192 MiBを常時確保する意味ではありません。ROSが必要な上流処理は未同梱です。既存ROS環境を使うときは、その `setup.bash` を先に読み込んでください。子プロセスへのROS変数の引き継ぎ確認結果は `environment.json` に記録し、値は出力しません。

## まず合成データで実行確認

以下の出力先は存在しない新規ディレクトリにしてください。

```bash
python examples/make_demo.py --out /tmp/ylm_demo_input
python -m ylm run --config /tmp/ylm_demo_input/config.json --out /tmp/ylm_demo_run
python -m ylm verify --out /tmp/ylm_demo_run
python -m ylm replay --from-run /tmp/ylm_demo_run --stage registration --out /tmp/ylm_demo_replay
```

`index.html` をブラウザで開くと処理状態と監査の3D表示を確認できます。合成データの完走を、正式なv0.4実験再現の合格として扱わないでください。

## 実際のv0.4保存結果に接続

接続版で確認済みの構造だけを読み込みます。

```text
RESULTS/cases/exp02_t0/fixed11/boundary_false/measured/clusters.json
RESULTS/cases/exp02_t0/fixed11/boundary_false/pixel_correspondence.npz
RESULTS/cases/exp02_t1/fixed11/boundary_false/measured/clusters.json
RESULTS/cases/exp02_t1/fixed11/boundary_false/pixel_correspondence.npz
```

NPZの `xyz` はH×W×3、`valid` はH×Wのbool、`labels` はH×Wの整数です。JSONは `{"clusters":[{"id":...,"point_count":...,"obb":...}]}`。これは受領bridge.pyを調査して使用した形式です。監査用平面・canonical maskの上流キーは未確認なので推測して読み取りません。

`examples/config_v04.json` を複製し、`v04_results` と単位・フレーム・時刻などを確認してください。パスは設定JSONの位置を基準に解決します。

```bash
python -m ylm run --config my_config.json --out /path/to/new_run
python -m ylm verify --out /path/to/new_run
```

`units: "m"` は必須です。座標補正が必要なら `transforms.t0/t1` に**各元座標→共通座標**の4×4剛体変換を指定します。ICPは共通T0→共通T1で評価し、元T0→元T1は `inverse(T1) @ ICP @ T0` として保存します。変換を与えただけで静的整列が証明されたとは扱いません。

`frame_alignment.status` は既定 `unknown`。`verified` を指定するには `evidence` が必要ですが、プログラムが根拠の真偽を認定するわけではありません。同一物体性は常に別途評価し、現版の更新案はすべて `HELD` です。

## 構造除去の監査

`docs/AUDIT_INPUT.md` に明示的な診断入力契約を定義しています。これは未受領の上流形式を推測したものではありません。実際の平面抽出コードと来歴を確認して、この契約へ対応付ける必要があります。

監査入力を省略しても下流処理は進みますが、監査は `BLOCKED_MISSING_INPUT`、全体の `processing_complete` はfalse、終了コードは2です。Aは保存canonical mask、B/Cは指定された平面モデルによる再計算です。Bを元の除去コードの厳密再現や確定した過去の除去理由と呼びません。未確認平面や不完全な平面集合があれば `PARTIAL_RECONSTRUCTION` です。

床ID 8専用の除去ロジックはありません。除外する実行内IDを `exclude_plane_ids` に指定します。Cでも残りの全平面を評価するため、重複する他平面に該当する点は除去されたままです。

## 候補形成の比較

`candidates.mode` を個別の実行ごとに指定します。監査は診断出力であり、B/Cのマスクを既存v0.4断片へ自動適用しません。

- `single`：元断片を単独候補として保持。50点未満も残し、ICP不適用理由を保存。
- `relations`：`groups.t0/t1` に明示された複数断片仮説を保存。各groupに `fragment_ids` と `evidence` が必須。連鎖的な自動結合はしません。
- `manual`：手動指定仮説。自動評価と区別するフラグを保存。
- `legacy_occlusion`：旧結合の結果を明示的に対応付けたgroupを取り込み。`legacy_evidence_file` が必須。旧遮蔽結合の自動再実行ではありません。

```json
{"mode":"relations","min_icp_points":50,"relation_search_completeness":"UNKNOWN",
 "groups":{"t0":[{"fragment_ids":[7,8],"evidence":{"relation_kind":"parts_hypothesis","source":"review.json"}}],
           "t1":[{"fragment_ids":[7],"evidence":{"relation_kind":"single_reference"}}]}}
```

source_point_idsは各時刻のorganized配列をC順にflattenした画素IDです。複数候補の重複は `overlap.jsonl` に記録します。候補内部は重複排除し、元断片ごとの所属も保持します。候補IDはシーングラフの永続IDとは別です。

空・微小・線状・平面状点群のOBBは不成立理由を残してICPから除外します。ノイズ注入はしません。単独候補では保存済みOBBを使い、複数断片仮説の3D OBBは明示的にPCA方式と記録します。

## ICP・割当・更新案

旧ICPの7つのyaw初期値と既定パラメータを維持します。内部1 cm voxel化は旧ICP内の処理だけです。構造除去・旧前処理は重複適用しません。各初期値について変換、fitness、RMSE、反復回数、双方向距離・coverage、対応点、全候補点での変位、仮説間差を保存します。旧solverは停止理由を公開しないため収束状態は `UNKNOWN_LEGACY_REASON_NOT_EXPOSED` と明記します。

新しい幾何Hungarian比較は未対応のdummyを許容し、競合候補・重複画素を保留します。類似score差0.02と変換差2 cmは曖昧性診断用の未校正値であり、同一物体採用条件や20 cmの実験値への調整ではありません。

旧visibility-aware Hungarianは `vendor/bridge_v02/bridge.py assignment` に原形のまま残しています。必要なraw観測4ファイルと座標・時刻来歴が未確認なので、統合CLIはそれを自動実行しません。新しい `assignment.json` を旧Hungarianの完全再現結果と呼ばないでください。

`scene_graph_proposal/proposals.json` は候補ペア、元ノードへの参照（`node_references` で指定）、根拠、保留理由を保持します。欠測は `unobserved_later`、初観測は `newly_observed` の仮説に留め、disappeared/appearedを確定しません。既存グラフに書き込みません。

## 保存結果から再実行

`replay --stage` は `structure_audit` / `object_candidates` / `registration` / `assignment` に対応します。入力スナップショットと上流結果のハッシュを検査し、新しい出力先に必要な段階をコピーして以降を再実行します。bagは読みません。同じ設定の再実行用です。比較条件を変える場合は設定を複製し、同じv0.4入力を指定した別の `run` を使用してください。

`artifact_hashes.json` は生成物、`source_hashes.json` は入力と保存コピーを検査します。`verify` のPASSは整合性のみです。全条件の完了・候補形成評価・同一物体評価・更新精度は `run_manifest.json` に別項目で記録します。出力が部分失敗した場合も完了扱いにしません。

## 受領実点群による旧ICP一致検査

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python examples/check_legacy_real_pair.py --out /tmp/ylm_real_pair_check
```

旧exp02 T0 M1（2745点）とT1 M2（708点）の1組で、統合ラッパーと凍結旧ICPの変換・scoreを比較します。元のv0.4正式結果、床監査、物体同一性の検証ではありません。

## 完全な統合・実データ検証に必要な追加資料

1. `ylm_integrated_clustering_v04` のソース、設定、依存情報。
2. 正式なv0.4結果（まずexp02のT0/T1・fixed11・boundary_false、全16条件検査には全条件）。
3. canonical構造マスク、除去前organized点群、平面の支持点・有限footprint・実判定コード・来歴。
4. 旧遮蔽結合とvisibility判定を比較する場合は元のraw観測と時刻・座標対応。
5. 任意のスケール比較には該当ソースと評価データ。

これらが揃うまで、上流クラスタリングを含む仕様書全体の完了、床ID 8の正しい分類、対応性能改善は主張できません。
