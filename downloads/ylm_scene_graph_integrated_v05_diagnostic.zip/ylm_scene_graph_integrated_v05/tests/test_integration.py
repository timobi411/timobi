import copy
import importlib.util
import json
import os
import shutil
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ylm.common import obb, rigid, transform, read, write, rows, module, sha, bridge
from ylm.audit import plane_conditions, audit_side, correspondence
from ylm.candidates import groups_for, run_candidates
from ylm.decision import assign, proposals
from ylm.inputs import ingest, check_sources, load_side
from ylm.registration import metrics, evaluate
from ylm.pipeline import run, verify_run


def plane(pid='one'):
    return {'plane_id': pid, 'role': 'unverified_floor', 'coefficients': [0, 0, 2, 0],
            'distance_width_m': 0.04, 'footprint_margin_m': 0, 'rule_kind': 'finite_polygon_band',
            'footprint': {'origin': [0, 0, 0], 'axes': [[1, 0], [0, 1], [0, 0]],
                          'polygon_uv': [[-1, -1], [1, -1], [1, 1], [-1, 1]]}}


class GeometryTests(unittest.TestCase):
    def test_footprint_outside_and_normalization(self):
        coeff, d, inside, matches = plane_conditions(np.array([[0, 0, .02], [2, 0, .02], [0, 0, .05]]), plane())
        np.testing.assert_allclose(coeff, [0, 0, 1, 0])
        self.assertEqual(matches.tolist(), [True, False, False])
        p = plane(); p['rule_kind'] = 'infinite_band'
        self.assertEqual(plane_conditions(np.array([[2, 0, .02]]), p)[3].tolist(), [True])

    def test_empty_small_linear_planar_obb(self):
        for p in (np.empty((0, 3)), np.ones((3, 3)), np.array([[i, 0, 0] for i in range(5)]), np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1, 0]])):
            self.assertEqual(obb(p)['status'], 'unavailable')
        self.assertEqual(obb(np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]]))['status'], 'available')

    def test_transform_inverse_and_center_motion(self):
        t = np.eye(4); t[:2, :2] = [[0, -1], [1, 0]]; t[:3, 3] = [2, 0, 0]
        p = np.array([[1, 0, 0], [2, 0, 0], [1, 1, 0], [1, 0, 1]], float)
        np.testing.assert_allclose(transform(transform(p, t), np.linalg.inv(t)), p)
        m, _ = metrics(p, transform(p, t), t, .08)
        self.assertEqual(m['source_to_target']['coverage'], 1)
        self.assertNotAlmostEqual(m['center_displacement_m'], np.linalg.norm(t[:3, 3]))
        bad = t.copy(); bad[0, 0] = 2
        with self.assertRaises(ValueError): rigid(bad)

    def test_duplicate_old_points_vs_unique_pixels(self):
        xyz = np.array([[[0, 0, 0], [1, 0, 0]]], float)
        r = correspondence(np.array([[0, 0, 0], [.001, 0, 0], [1, 0, 0]]), xyz, np.ones((1, 2), bool), np.array([[True, False]]))
        self.assertEqual(int(r['within_radius'].sum()), 3)
        self.assertEqual(len(r['unique_matched_pixels']), 2)
        self.assertEqual(len(r['unique_masked_pixels']), 1)

    def test_relations_not_transitive(self):
        f = [{'fragment_id': i} for i in range(3)]
        g = [{'fragment_ids': [0, 1], 'evidence': {'kind': 'surface'}}, {'fragment_ids': [1, 2], 'evidence': {'kind': 'parts'}}]
        self.assertEqual(len(groups_for(f, g, 'relations')), 2)
        with self.assertRaises(ValueError): groups_for(f, [{'fragment_ids': [0, 1]}], 'relations')


class AuditTests(unittest.TestCase):
    def test_overlapping_planes_exclusion_preserves_other_reason(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            np.savez(root / 'input.npz', xyz=np.array([[[0, 0, .02], [2, 0, .02]]]),
                     valid=np.ones((1, 2), bool), canonical_mask=np.array([[True, False]]))
            write(root / 'planes.json', {'plane_set_complete': True, 'planes': [plane('a'), plane('b')]})
            result = audit_side({'arrays': str(root / 'input.npz'), 'planes': str(root / 'planes.json'), 'exclude_plane_ids': ['a']}, root / 'out')
            self.assertEqual(result['model_exclusion_removed'], 1)
            with np.load(root / 'out/mask_comparison.npz') as z:
                np.testing.assert_array_equal(z['A_canonical'], [[True, False]])
            reasons = list(rows(root / 'out/pixel_reasons.jsonl'))
            self.assertEqual(reasons[0]['all_matching_plane_ids'], ['a', 'b'])

    def test_partial_missing_rules_not_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            np.savez(root / 'input.npz', xyz=np.zeros((1, 1, 3)), valid=np.ones((1, 1), bool), canonical_mask=np.ones((1, 1), bool))
            p = plane(); del p['rule_kind']
            write(root / 'planes.json', {'plane_set_complete': True, 'planes': [p]})
            r = audit_side({'arrays': str(root / 'input.npz'), 'planes': str(root / 'planes.json')}, root / 'out')
            self.assertEqual(r['status'], 'PARTIAL_RECONSTRUCTION')
            self.assertIn('partial', r['C'])


class AssignmentTests(unittest.TestCase):
    def candidate(self, cid, points):
        return {'candidate_id': cid, 'source_point_ids': points, 'formation_hold_reasons': []}

    def test_overlap_is_not_two_objects(self):
        c = {'t0': [self.candidate('a', [1, 2]), self.candidate('b', [2, 3])],
             't1': [self.candidate('x', [8]), self.candidate('y', [9])]}
        p = [dict(source=a, target=b, score=s, legacy_valid=True, ambiguous=False) for a, b, s in [('a', 'x', .9), ('b', 'y', .8)]]
        r = assign(c, p)
        self.assertEqual(len(r['geometric_assignments']), 1)
        self.assertEqual(r['held_assignments'][0]['hold_reasons'], ['overlapping_candidate_already_selected'])

    def test_ambiguous_and_missing_are_held(self):
        c = {'t0': [self.candidate('a', [1])], 't1': [self.candidate('x', [8]), self.candidate('y', [9])]}
        p = [dict(source='a', target=b, score=.9, legacy_valid=True, ambiguous=False) for b in ('x', 'y')]
        r = assign(c, p)
        self.assertFalse(r['geometric_assignments'])
        result = proposals({}, r, c, Path('.'))
        self.assertFalse(result['existing_graph_modified'])
        self.assertTrue(all(u['status'] == 'HELD' for u in result['updates']))
        self.assertTrue(all(u.get('change_hypothesis') not in ('appeared', 'disappeared') for u in result['updates']))

    def test_resource_limit_rejects_matrix(self):
        c = {'t0': [self.candidate(str(i), [i]) for i in range(30)], 't1': []}
        with self.assertRaises(MemoryError): assign(c, [], memory_mib=.001)


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.root = Path(self.tmp.name)
        demo = module('make_demo', ROOT / 'examples/make_demo.py')
        self.config = read(demo.make(self.root / 'demo'))

    def tearDown(self): self.tmp.cleanup()

    def test_ingest_exact_arrays_and_tiny_candidates(self):
        out = self.root / 'run'; out.mkdir()
        ingest(self.config, out)
        result = run_candidates(self.config, out)
        self.assertEqual(len(result['t0']), 2)
        self.assertFalse(result['t0'][1]['icp_eligible'])
        self.assertTrue(check_sources(out))
        source = Path(self.config['v04_results']) / 'cases/exp02_t0/fixed11/boundary_false/pixel_correspondence.npz'
        self.assertEqual(sha(source), sha(out / 'fragments/t0/pixel_correspondence.npz'))
        source.write_bytes(b'changed')
        with self.assertRaises(ValueError): check_sources(out)

    def test_candidate_point_deduplication_and_overlap(self):
        out = self.root / 'run'; out.mkdir(); ingest(self.config, out)
        self.config['candidates'] = {'mode': 'manual', 'groups': {s: [{'fragment_ids': [7, 7, 8]}, {'fragment_ids': [7]}] for s in ('t0', 't1')}}
        result = run_candidates(self.config, out)
        self.assertEqual(result['t0'][0]['point_count'], 103)
        self.assertEqual(len(list(rows(out / 'object_candidates/t0/overlap.jsonl'))), 100)
        self.assertTrue(result['t0'][0]['manual_diagnostic'])

    def test_single_fragment_adapter_matches_received_bridge(self):
        from types import SimpleNamespace
        original = self.root / 'bridge'
        b = bridge()
        b.prepare(SimpleNamespace(v04_results=self.config['v04_results'], case='exp02', window='fixed11',
                                  boundary='boundary_false', min_points=50, out=str(original),
                                  t0_transform=None, t1_transform=None, frame_status='unknown'))
        b.verify(original, silent=True)
        out = self.root / 'new'; out.mkdir(); ingest(self.config, out); run_candidates(self.config, out)
        for side in ('t0', 't1'):
            before = read(original / f'{side}_merged_clusters.json')[0]
            after = read(out / 'registration/legacy_input' / f'{side}_merged_clusters.json')[0]
            self.assertEqual(before['source_clusters'], after['source_clusters'])
            np.testing.assert_array_equal(b.read_pcd(before['pcd']), b.read_pcd(after['pcd']))
            for key in ('center', 'extent', 'rotation'):
                np.testing.assert_array_equal(before[key], after[key])

    def test_full_pipeline_and_saved_stage_replay(self):
        out = self.root / 'run'
        state = run(self.config, out)
        self.assertTrue(state['processing_complete'], state)
        self.assertEqual(state['identity_evaluation'], 'UNKNOWN')
        self.assertTrue(verify_run(out)['integrity_passed'])
        graph = read(out / 'scene_graph_proposal/proposals.json')
        self.assertTrue(all(u['status'] == 'HELD' for u in graph['updates']))
        for u in graph['updates']:
            if u.get('diagnostic_estimate'):
                self.assertIn('static_frame_alignment_unverified', u['hold_reasons'])
        for stage in ('registration', 'assignment'):
            new = self.root / ('replay_' + stage)
            replayed = run(read(out / 'resolved_config.json'), new, replay=out, start=stage)
            self.assertTrue(replayed['processing_complete'], replayed)
            self.assertTrue(verify_run(new)['integrity_passed'])
        with self.assertRaises(FileExistsError): run(self.config, out)

    def test_failure_status_and_missing_audit(self):
        config = copy.deepcopy(self.config); config.pop('audit')
        config['max_pairs'] = 0
        result = run(config, self.root / 'failed')
        self.assertFalse(result['processing_complete'])
        self.assertEqual(result['stages']['structure_audit'], 'BLOCKED_MISSING_INPUT')
        self.assertEqual(result['stages']['registration'], 'FAILED_RESOURCE_LIMIT')
        self.assertNotIn('assignment', result['stages'])

    def test_replay_after_moving_saved_run_without_original_inputs(self):
        out = self.root / 'original'
        state = run(self.config, out)
        self.assertTrue(state['processing_complete'], state)
        moved = self.root / 'moved'
        out.rename(moved)
        shutil.rmtree(self.root / 'demo')
        result = run(read(moved / 'resolved_config.json'), self.root / 'replayed', replay=moved, start='structure_audit')
        self.assertTrue(result['processing_complete'], result)
        self.assertTrue(verify_run(self.root / 'replayed')['integrity_passed'])

    def test_legacy_output_equivalence_and_inverse(self):
        import open3d as o3d
        legacy = module('legacy_test', ROOT / 'vendor/bridge_v02/legacy/baseline_icp_B0.py')
        rng = np.random.default_rng(73)
        p = rng.uniform(-.2, .2, (80, 3))
        q = p + [.02, .01, .005]
        folder = self.root / 'pair'; folder.mkdir()
        result = evaluate(legacy, p, q, folder, np.eye(4), np.eye(4))
        a = o3d.geometry.PointCloud(); a.points = o3d.utility.Vector3dVector(p)
        b = o3d.geometry.PointCloud(); b.points = o3d.utility.Vector3dVector(q)
        original = legacy.evaluate_pair(a, b)
        selected = result['hypotheses'][result['selected_hypothesis']]
        self.assertAlmostEqual(original['score'], selected['legacy_result']['score'], places=12)
        np.testing.assert_allclose(original['transformation'], selected['common_t0_to_common_t1'], atol=1e-12)
        np.testing.assert_allclose(np.asarray(selected['native_t1_to_native_t0']) @ selected['native_t0_to_native_t1'], np.eye(4), atol=1e-12)
        self.assertEqual(len(result['hypotheses']), 7)

    def test_symmetric_partial_shape_keeps_identity_unknown(self):
        legacy = module('legacy_symmetry', ROOT / 'vendor/bridge_v02/legacy/baseline_icp_B0.py')
        angle = np.linspace(0, 2 * np.pi, 72, endpoint=False)
        p = np.vstack([np.column_stack([.2 * np.cos(angle), .2 * np.sin(angle), np.full(len(angle), z)]) for z in (0, .1, .2)])
        q = p[:144]
        folder = self.root / 'pair'; folder.mkdir()
        result = evaluate(legacy, p, q, folder, np.eye(4), np.eye(4))
        self.assertEqual(result['identity_status'], 'UNKNOWN')
        self.assertTrue(result['ambiguous'])
        self.assertEqual(len(result['hypotheses']), 7)


if __name__ == '__main__': unittest.main()
