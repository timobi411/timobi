# 現在の状態

更新日時：2026-11-17（JST）
更新担当：Codex（受領ZIPのコピーで調査）

## 研究目標
色付き点群から作る物体ID付きT0地図を基準に、任意位置のYLMによるT1観測を位置合わせし、部屋全体の物体対応とシーングラフ更新を検証する。

## 現行の動作確認済み
- YLM固定センサーのbagから前処理、クラスタリング、19 cm断片結合、候補抽出、個別レジストレーション、診断HTMLまで。
- 遮蔽なし／ありを比較する診断モード。
- 現行ZIPの平面経路にある「はみ出し・格子支持」ゲートは通常実行では無効。

## 今進めているもの
- T0色付き点群の物体分割・意味ラベル・永続ID：壁際追加除去後の RGB 点群 `ylm_wall_cleanup_retry.ply`（148,727点）を分割入力候補として特定。HTMLの object_### は比較用クラスタ名で、家具の意味ラベル・永続IDは未付与。
- T0とYLMの座標系・自己位置推定：
- 部屋全体のT1照合：

## 次の一手
1. 研究室PCで生成コードと設定を確認し、同じPLY・閾値・クラスタ処理を確定する。
2. `ylm_wall_cleanup_retry.ply` を読み取り専用の基準入力として固定し、別出力先で家具分離とID付与を行う。

## 確認が必要な点
- 生成コード・設定ファイルは受領ZIPに含まれない。7/9 cmの詳細パラメータとクラスタ名の永続性は未確認。
- 壁除去が家具を誤除去していないかは目視・対象物単位の点群確認が必要。

## 主要な場所
- 現行プログラム：
- T0地図：
- YLM bag：
- 最新実験job：

## 確認済みの実体パス
- 現行YLM診断スイート: /home/cslab/122M043/Scene_Graph/real_experiment/diagnostic_suite_v1_4KqxpY/ylm_diagnostic_suite
- exp01の診断job: /home/cslab/122M043/Scene_Graph/real_experiment/exp01/current_registration_8AKkILSn/ylm_diagnostic_jp0036tr
- 色付きT0地図: 分割用入力候補 `/home/cslab/122M043/mid360_processing_F0z8Za/fastlio_full_KQ67ZF/trajectory/ylm_rgb_full_05s_SHW8t6/ylm_objects_pmNrJi/wall_radius_compare_lCzFSs/wall_cleanup_retry_W9X0VB/ylm_wall_cleanup_retry.ply` (SHA256 c0abe9688b82f78c3c8413b3201a4475ec9f58e2f1d63d01b5cd2174c4abf6c0, 148727点)。採用最終判断は元環境で保留。

## 2026-11-18｜Codex｜T0–T1 実験版
引継ぎで指定された採用T0は t0_unknown_min301_20261118_141909（40ノード・14辺）。最新の実験版は t0_registration_v01。採用グラフ・各PLYとT1、固定条件、V1.1を研究PCで接続して実測する段階。

## 2026-11-20｜Codex｜exp001 比較版
/workspace/t0_registration_exp001 に前回版を複製。exp001*.py、registration.py、compare.py にA〜D比較・入力抽出・結果接続を追加。exp001_check.py で共通5039点、C/D・強制フォールバック・混在窓棄却を確認。verify.py で旧入口も実行。実bag・deployment・目視ラベルの検証は研究PCで行う。
