# 作業履歴

各作業の末尾に次の形式で追記する。

## YYYY-MM-DD HH:MM｜担当｜作業名
- 目的：
- 変更・実行したこと：
- 変更ファイル／実験jobの絶対パス：
- 実行コマンド：
- 結果・確認した数値：
- 未解決・失敗：
- 次に行うこと：

## 2026-11-17｜Codex｜色付きT0のHTMLとPLY対応調査
- 目的：全体版HTMLの参照点群と表示モードを特定する。
- 変更・実行したこと：受領した3分割ZIPを番号順に結合し、SHA256 `f2a1b7775e2026d1a1dbf640dd4966da09331c67aeaa14b1b97f0cb33740a631` と全12ファイルのCRCを確認。Plotly描画データの座標とRGBを同梱PLYに全点照合した。元ファイルは未変更。
- 変更ファイル／実験jobの絶対パス：本ログと CURRENT_STATE.md の受領コピー `/workspace/colored_t0_investigation/122M043/Scene_Graph/real_experiment/project_coordination/`。研究室PCの元パスは未変更。
- 実行コマンド：`python /workspace/analyze_colored_t0_exact.py`、Python標準zipfileによるCRC検査とSHA256計算。
- 結果・確認した数値：追加除去前 `ylm_extra_walls_removed.ply` 156,771点、今回除去 `removed_this_pass.ply` 8,044点、追加除去後 `ylm_wall_cleanup_retry.ply` 148,727点。後者と除去点は前者を点レコード単位で完全分割する。追加除去後RGBモード10万点の座標・RGBは後者と全点一致。追加除去前7cmモード10万点は前者に全点一致し、うち5,173点は今回除去点。追加除去後7cm/9cm各10万点は後者に全点一致。画面の31/21/18候補と44.3/44.8/46.1%はHTMLの表示ラベルであり、独立再計算した値ではない。
- 未解決・失敗：生成コード・実行設定はZIPに含まれず、クラスタリングの細部は未確認。object_### は表示用クラスタ名で永続IDと確認できない。家具を誤除去していないか未確認。研究室PCの共有フォルダへ本ログを直接反映するアクセスはない。
- 次に行うこと：生成コード・設定を確認し、上記PLYを読み取り専用入力候補として家具単位の分割を別出力先で実施する。

## 2026-11-18｜Codex｜T0–T1 実験版
/workspace/t0_registration_v01 に登録・照合・グラフ更新・比較コードを追加。verify.py と compare.py を合成データで実行し改良版2件、B0 1件正解、ICP 0/8回。movement_trial.py は旧局所ICPで移動を検出。実データ・正式V1.1は未検証。

## 2026-11-20｜Codex｜exp001 比較版
/workspace/t0_registration_exp001 に前回版を複製。exp001*.py、registration.py、compare.py にA〜D比較・入力抽出・結果接続を追加。exp001_check.py で共通5039点、C/D・強制フォールバック・混在窓棄却を確認。verify.py で旧入口も実行。実bag・deployment・目視ラベルの検証は研究PCで行う。
