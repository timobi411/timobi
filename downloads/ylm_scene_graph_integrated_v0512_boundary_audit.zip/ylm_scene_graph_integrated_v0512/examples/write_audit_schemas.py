"""Generate v0.5.1.2 audit schemas; input/profile schemas remain unchanged."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
integer={'type':'integer','minimum':0}
ids={'type':'array','items':integer,'uniqueItems':True}
pair={**ids,'minItems':2,'maxItems':2}
schemas={
 'expansion_event':{'schema':{'const':'ylm0512.expansion.v1'},'event_id':{'type':'string','pattern':'^E-'},'sequence':integer,
  'time':{'type':'string'},'namespace':{'type':'object'},'seed':integer,'seed_region':{'type':'array'},'depth':{'type':'integer','minimum':1},
  'parent_candidate_id':{'type':'string'},'parent_fragment_ids':ids,'added_fragment':integer,'result_fragment_ids':ids,
  'result_candidate_id':{'type':'string'},'candidate_reused':{'type':'boolean'},'all_links':{'type':'array','items':pair},
  'eligible_links':{'type':'array','items':pair},'all_links_minimum':{'type':'object'},'eligible_links_minimum':{'type':'object'},
  'decision':{'type':'object','required':['set','distance_m','limit_m','passed'],'properties':{'set':{'const':'legacy_all_links'},'passed':{'type':'boolean'}}},
  'shadow_only':{'const':True},'witness_pair':{'anyOf':[pair,{'type':'null'}]},
  'result':{'enum':['GENERATED_HYPOTHESIS','MAX_ADDED_GAP','VALIDATED_CONTRADICTION','WHOLE_CANDIDATE_GEOMETRY_LIMIT','BUDGET_STOP']},
  'added_point_count':integer,'result_point_count':integer,'risk_flags':{'type':'array'}},
 'contact_geometry_summary':{'schema':{'const':'ylm0512.contact_summary.v1'},'time':{'type':'string'},'namespace':{'type':'object'},
  'input_fingerprint':{'type':'string'},'fragment_ids':pair,'array':{'type':'string'},'offset':{'type':'array','items':integer,'minItems':2,'maxItems':2},
  'status':{'enum':['DIRECT_CONTACT','NO_DIRECT_CONTACT']},'contact_count':integer,'horizontal_count':integer,'vertical_count':integer,
  'precision':{'const':'float64'},'nearest_3d':{'type':['object','null']},'distance_min_p05_p50_p95_max_m':{'type':['array','null']},
  'abs_range_min_p05_p50_p95_max_m':{'type':['array','null']},'signed_range_min_p50_max_m':{'type':['array','null']},'signed_range_counts':{'type':'object'}},
 'selection_event':{'schema':{'const':'ylm0512.selection_event.v1'},'time':{'type':'string'},'sequence':integer,'candidate_id':{'type':'string'},
  'visited':{'type':'boolean'},'phase':{'enum':['QUOTA','REDISTRIBUTION','EXPLICIT_SIMILARITY_RELAXATION','FINAL_UNVISITED']},
  'owner':{'type':'array'},'size_class':{'enum':['2-4','5-16','17+']},'quota':integer,'similarity_representative':{'type':'string'},
  'group_count_before':{'type':['integer','null']},'remaining_total_before':integer,'accepted':{'type':'boolean'},
  'reason':{'enum':['ACCEPT','SIMILARITY_GROUP_LIMIT','UNVISITED_TOTAL_CAP','UNVISITED_QUOTA']},'selection_policy':{'enum':['S0','coverage_order_v1']}}
}
for name,props in schemas.items():
 schema={'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'ylm0512.'+name,'type':'object','required':list(props),'properties':props,'additionalProperties':True}
 (ROOT/'schemas'/'audit').mkdir(exist_ok=True)
 (ROOT/'schemas'/'audit'/(name+'.schema.json')).write_text(json.dumps(schema,indent=2)+'\n')
print('Wrote 3 audit schemas; retained existing input/profile definitions')
