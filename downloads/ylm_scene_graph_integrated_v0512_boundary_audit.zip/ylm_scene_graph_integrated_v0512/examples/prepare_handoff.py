"""Verify received records; remap paths only, never edit upstream arrays or gates."""
import argparse,copy,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ylm051.io import read,sha,Output
from ylm051.policies import defaults

def prepare(handoff,destination):
    handoff=Path(handoff).resolve();destination=Path(destination).resolve();destination.mkdir(exist_ok=False,parents=True)
    manifest=read(handoff/'collection_manifest.json');mapping={}
    for item in manifest['files']:
        path=handoff/item['archive_path']
        if not path.is_relative_to(handoff) or sha(path)!=item['sha256']:raise ValueError('handoff hash mismatch: '+str(path))
        mapping[item['original_path']]=str(path)
    out=Output(destination);records=[]
    for case in ('exp01','exp02'):
        base=handoff/('03_v051_inputs/v051_exp01_compare_tiYWj55C' if case=='exp01' else '03_v051_inputs/v051_exp02_B1_t1_nPIpBQUt')
        profile=read(base/'B1_profile.json')
        for time in ('t0','t1'):
            original_input=base/(f'B1_{time}_input.json' if case=='exp01' else 'input_t1.json')
            config=read(original_input)
            if case=='exp02' and time=='t0':
                config=json.loads(json.dumps(config).replace('exp02_t1','exp02_t0'))
                config['times']={'t0':config['times']['t1']}
            for t,spec in config['times'].items():
                for key in ('pixels','clusters','relations'):
                    if spec.get(key):spec[key]=mapping[spec[key]]
                for key in ('canonical_mask','feature_arrays'):
                    if spec.get(key):spec[key]['path']=mapping[spec[key]['path']]
                spec['source_code']=[mapping[p] for p in spec.get('source_code',[])]
            name=case+'_'+time
            out.json(name+'/input.json',config)
            out.json(name+'/L.json',profile)
            for mode in ('A','AB','ABC'):
                p=copy.deepcopy(profile);p['candidate_search']=defaults()
                p['candidate_search']['expansion_scope']='seed_region' if mode=='A' else 'graph_frontier'
                p['candidate_search']['archive_policy']='diverse_v1' if mode=='ABC' else 'legacy_size_rank'
                p['budget_scope']['global']='wall/RSS/storage global; pair/expanded/copy/regions count limits reserved per time'
                out.json(name+'/'+mode+'.json',p)
                sensitivity=copy.deepcopy(p);sensitivity['budgets']['max_pair_checks']=12000
                out.json(name+'/'+mode+'_12k.json',sensitivity)
            records.append({'dataset':name,'source_profile':str(base/'B1_profile.json'),'source_profile_sha256':sha(base/'B1_profile.json'),
                            'geometry_unchanged':True,'new_B1_T0_comparison_using_received_T1_numeric_profile':case=='exp02' and time=='t0',
                            'input_hashes':{k:sha(Path(config['times'][time][k])) for k in ('pixels','clusters')}})
    out.json('preparation.json',{'verified_files':len(mapping),'datasets':records,
        'lab_adapter_status':'received serialized input contracts; inline-only adapter code not present in collection',
        'lab_source_hash_status':'environment/source_hashes artifacts absent; historical run code identity unverified',
        'baseline_code':'frozen delivered v0.5.1 ZIP, executed separately; do not assume lab code identical',
        'B2':'NOT_EVALUATED: normalized upstream relation adapter not supplied; raw relations preserved in handoff',
        'GT':'UNAVAILABLE'})
    return destination

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--handoff',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    print(prepare(a.handoff,a.out))
