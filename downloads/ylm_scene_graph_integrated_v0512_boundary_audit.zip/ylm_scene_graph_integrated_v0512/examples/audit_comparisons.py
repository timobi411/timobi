"""Post-hoc audit only; consumes runs, never feeds generator settings."""
import argparse,collections,itertools,json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from ylm051.io import read,rows,sha,Output

def audit(run):
    m=read(run/'run_manifest.json');config=read(run/'input_contract.json');results={}
    candidates=list(rows(run/'hypotheses.jsonl'));pairs=list(rows(run/'pair_evidence.jsonl'))
    for t,spec in config['times'].items():
        with np.load(run/spec['pixels']) as z: lab,valid=z['labels'],z['valid']
        inventory={}
        for direction,(left,right,vl,vr) in enumerate(((lab[:,:-1],lab[:,1:],valid[:,:-1],valid[:,1:]),(lab[:-1],lab[1:],valid[:-1],valid[1:]))):
            mask=vl&vr&(left>=0)&(right>=0)&(left!=right)
            keys,counts=np.unique(np.sort(np.column_stack((left[mask],right[mask])),axis=1),axis=0,return_counts=True)
            for pair,n in zip(keys,counts):inventory.setdefault(tuple(map(int,pair)),[0,0])[direction]+=int(n)
        measured={tuple(p['fragment_ids']) for p in pairs if p['time']==t}
        saved=[c for c in candidates if c['namespace']['time']==t and not c['is_singleton']]
        concentration=collections.Counter(f for c in saved for f in c['fragment_ids'])
        core=collections.defaultdict(set)
        for r in rows(run/'regions.jsonl'):
            if r['time']==t:
                for f in r['core_fragment_ids']:core[f].add(tuple(r['cell']))
        strata={}
        for d,shared in itertools.product(('H_ONLY','V_ONLY','BOTH'),(False,True)):
            keys=[p for p,(h,v) in inventory.items() if ('BOTH' if h and v else 'H_ONLY' if h else 'V_ONLY')==d and bool(core[p[0]]&core[p[1]])==shared]
            strata[f'{d}/shared_core={shared}']={'image_pairs':len(keys),'evaluated_pairs':sum(p in measured for p in keys),
                                               'evaluation_rate':sum(p in measured for p in keys)/len(keys) if keys else None}
        results[t]={'image_unique_pairs':len(inventory),'image_contact_edges':sum(sum(v) for v in inventory.values()),
            'evaluated_image_pairs':len(set(inventory)&measured),'evaluation_rate':len(set(inventory)&measured)/len(inventory) if inventory else None,
            'geometry_pairs_evaluated':len(measured),'strata':strata,'saved_combined':len(saved),
            'singleton_count':sum(c['namespace']['time']==t and c['is_singleton'] for c in candidates),
            'maximum_fragment_concentration':max(concentration.values())/len(saved) if saved else None,
            'fragment_appearance':dict(sorted(concentration.items())),
            'old_discovery_completeness':'UNKNOWN_LEGACY_HAS_NO_FULL_DISCOVERY_LEDGER' if m['version']=='0.5.1' else 'see image_scan and final pair inventory'}
        if (run/'pair_pipeline_summary.json').exists():results[t]['pipeline']=read(run/'pair_pipeline_summary.json')['times'][t]
        if (run/'candidate_diversity.json').exists():results[t]['diversity']=read(run/'candidate_diversity.json')['times'].get(t)
        if config['case']=='exp02' and t=='t1':
            old_pair=next((p for p in pairs if p['time']==t and p['fragment_ids']==[206,245]),None)
            final_pair=next((p for p in rows(run/'pair_pipeline.jsonl') if p['time']==t and p['fragment_ids']==[206,245]),None) if (run/'pair_pipeline.jsonl').exists() else None
            results[t]['regression_206_245']={'evaluated':old_pair is not None,'geometry':old_pair['geometry'] if old_pair else None,
                                             'pipeline':final_pair,'identity':'UNKNOWN_NOT_GT'}
    return {'version':m['version'],'processing_complete':m['processing_complete'],'stages':m['stages'],
            'resources':m['resources'],'actual_saved_bytes':sum(p.stat().st_size for p in run.rglob('*') if p.is_file()),
            'times':results,'source_modules':read(run/'environment.json')['source_modules'],
            'input_hashes':read(run/'source_hashes.json'),'geometry':read(run/'resolved_config.json')['geometry']}

def main():
    p=argparse.ArgumentParser();p.add_argument('--main',required=True);p.add_argument('--exp01-final',required=True)
    p.add_argument('--sensitivity',required=True);p.add_argument('--equal',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    roots={k:Path(v) for k,v in vars(a).items() if k!='out'};dest=Path(a.out);dest.mkdir(exist_ok=False,parents=True);o=Output(dest)
    runs=[];same_archive=[];expected={p.relative_to(ROOT).as_posix():sha(p) for p in (ROOT/'ylm051').glob('*.py')}
    for dataset in ('exp01_t0','exp01_t1','exp02_t0','exp02_t1'):
        collected={}
        for mode in ('L','A','AB','ABC'):
            root=roots['exp01_final'] if dataset.startswith('exp01') and mode!='L' else roots['main']
            run=root/(dataset+'_'+mode);result=audit(run)
            if mode!='L':assert result['source_modules']==expected,(dataset,mode,'source hashes differ')
            collected[mode]=result;runs.append({'axis':'main','dataset':dataset,'mode':mode,'run_path':str(run),**result})
        assert all(v['geometry']==collected['L']['geometry'] for v in collected.values())
        root=roots['exp01_final'] if dataset.startswith('exp01') else roots['main']
        fixed=read(root/(dataset+'_same_archive_selector.json'))
        ab=list(rows(root/(dataset+'_AB')/'generated_archive.jsonl'));abc=list(rows(root/(dataset+'_ABC')/'generated_archive.jsonl'))
        signature=lambda c:(tuple(c['fragment_ids']),json.dumps(c['rank_tuple'],sort_keys=True))
        assert {signature(c) for c in ab}=={signature(c) for c in abc},'archive policy changed generation'
        saved=[c for c in rows(root/(dataset+'_ABC')/'hypotheses.jsonl') if not c['is_singleton']]
        assert {tuple(v) for v in fixed['selected_fragment_sets']}=={tuple(c['fragment_ids']) for c in saved}
        same_archive.append({'dataset':dataset,'generated_sets_and_ranks_identical':True,'reselection_matches_ABC':True,
                             'generated_hypotheses':len(ab),'comparison':fixed})
    for axis,key in [('sensitivity_12k','sensitivity'),('same_total_budget','equal')]:
        root=roots[key]
        for entry in read(root/'comparison_summary.json')['runs']:
            run=root/(entry['dataset']+'_'+entry['mode']);result=audit(run)
            if entry['mode']!='L':assert result['source_modules']==expected
            runs.append({'axis':axis,'dataset':entry['dataset'],'mode':entry['mode'],'run_path':str(run),**result})
    o.json('comparison_summary.json',{'runs':runs,'same_archive':same_archive,'GT':'UNAVAILABLE','object_accuracy':'NOT_EVALUATED',
                                     'registration':'NOT_RUN','graph_writes':0,'all_new_source_hashes_match_release':True})
    print(json.dumps({'audited_runs':len(runs),'same_archive_comparisons':len(same_archive)}))

if __name__=='__main__':main()
