"""One-process-per-run E0..E4, frozen baseline replay, and fixed-archive S0/S1."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,copy,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from ylm051.io import read,rows,Output,sha
from ylm051.selection_experiment import observation_metrics

def execute(source,args,log):
    with log.open('w') as f:return subprocess.run([sys.executable,'-m','ylm051',*args],cwd=source,stdout=f,stderr=subprocess.STDOUT).returncode

def compatible(old,new):
    files=['hypotheses.jsonl','generated_archive.jsonl','search_trace.jsonl','archive_selection.jsonl','pair_evidence.jsonl']
    result={'byte_identical':{f:sha(old/f)==sha(new/f) for f in files},'source_point_ids_identical':True}
    for c in rows(old/'hypotheses.jsonl'):
        if sha(old/c['source_point_ids'])!=sha(new/c['source_point_ids']):result['source_point_ids_identical']=False
    a=read(old/'run_manifest.json')['resources']['counts'];b=read(new/'run_manifest.json')['resources']['counts']
    result['search_counters_identical']={k:a[k]==b[k] for k in a if k!='saved_bytes'}
    result['profile_identical']=sha(old/'resolved_config.json')==sha(new/'resolved_config.json')
    result['input_hashes_identical']=[r['sha256'] for r in read(old/'source_hashes.json')]==[r['sha256'] for r in read(new/'source_hashes.json')]
    result['pass']=all(result['byte_identical'].values()) and result['source_point_ids_identical'] and all(result['search_counters_identical'].values()) and result['profile_identical'] and result['input_hashes_identical']
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--inputs',required=True);p.add_argument('--baseline',required=True);p.add_argument('--baseline-results',required=True);p.add_argument('--out',required=True)
    p.add_argument('--datasets',default='exp02_t1,exp01_t0,exp01_t1,exp02_t0');p.add_argument('--modes',default='E0,E1,E2,E3,E4');a=p.parse_args()
    dest=Path(a.out).resolve();dest.mkdir(parents=True,exist_ok=False);o=Output(dest);inputs=Path(a.inputs).resolve();baseline=Path(a.baseline).resolve();oldresults=Path(a.baseline_results).resolve()
    results=[]
    for dataset in a.datasets.split(','):
        prof=read(inputs/dataset/'ABC.json');source_input=inputs/dataset/'input.json'
        assert prof['budgets']['max_expanded_states']==5000 and prof['budgets']['max_pair_checks']==5000 and prof['budgets']['beam_per_seed']==4 and prof['budgets']['max_fragments']==16
        frozen=dest/(dataset+'_frozen0511')
        print('START',dataset,'frozen0511',flush=True)
        rc=execute(baseline,['generate','--input',str(source_input),'--profile',str(inputs/dataset/'ABC.json'),'--out',str(frozen)],dest/(frozen.name+'.log'))
        if rc:raise RuntimeError('frozen baseline failed '+dataset)
        old_repeat=compatible(oldresults/dataset,frozen);o.json(dataset+'_old_repeat.json',old_repeat)
        if not old_repeat['pass']:raise RuntimeError('frozen baseline not reproducible')
        for mode in a.modes.split(','):
            config=copy.deepcopy(prof);changes={}
            if mode=='E1':changes={'max_expanded_states':10000}
            elif mode=='E2':changes={'max_pair_checks':10000}
            elif mode=='E3':changes={'beam_per_seed':8}
            elif mode=='E4':changes={'max_fragments':32,'max_depth':31}
            elif mode!='E0':raise ValueError(mode)
            config['budgets'].update(changes);o.json('profiles/'+dataset+'_'+mode+'.json',config)
            profile_path=dest/'profiles'/(dataset+'_'+mode+'.json');run=dest/(dataset+'_'+mode)
            print('START',dataset,mode,flush=True)
            rc=execute(ROOT,['generate','--input',str(source_input),'--profile',str(profile_path),'--out',str(run)],dest/(run.name+'.log'))
            m=read(run/'run_manifest.json');result={'dataset':dataset,'mode':mode,'changes':changes,'returncode':rc,'run_path':str(run),
                 'processing_complete':m['processing_complete'],'audit_complete':m['audit_complete'],'search_exhaustive':m['search_exhaustive'],
                 'resources':m['resources'],'actual_saved_bytes':sum(p.stat().st_size for p in run.rglob('*') if p.is_file()),
                 'profile_sha256':sha(run/'resolved_config.json'),'source_modules':read(run/'environment.json')['source_modules'],
                 'input_hashes':read(run/'source_hashes.json'),'error':m.get('error')}
            result['verify_returncode']=execute(ROOT,['audit-verify','--run',str(run)],dest/(run.name+'_audit.json'))
            result['audit']=read(run/'audit_status.json')
            if mode=='E0':
                result['compatibility']=compatible(frozen,run)
                if not result['compatibility']['pass'] or result['verify_returncode']:raise RuntimeError('E0 compatibility/audit failed '+dataset)
            if m['processing_complete']:
                cs=list(rows(run/'generated_archive.jsonl'));saved=[c for c in rows(run/'hypotheses.jsonl') if not c['is_singleton']];decisions=list(rows(run/'archive_selection.jsonl'))
                t=dataset.rsplit('_',1)[1];result['observation_metrics']=observation_metrics(run,t,cs,saved,decisions)
                result['generated_archive_sha256']=sha(run/'generated_archive.jsonl');result['saved_candidate_count']=sum(1 for _ in rows(run/'hypotheses.jsonl'))
                if mode=='E0':
                    selections={}
                    for policy in ('S0','coverage_order_v1'):
                        sd=dest/(dataset+'_'+policy)
                        sr=execute(ROOT,['select','--run',str(run),'--policy',policy,'--out',str(sd)],dest/(sd.name+'.log'))
                        selections[policy]={'returncode':sr,'manifest':read(sd/'selection_manifest.json'),'path':str(sd)}
                        if sr:raise RuntimeError('selector failed '+dataset+' '+policy)
                    result['selections']=selections
            results.append(result);o.json('comparison_summary.json',{'runs':results,'proxy_evaluation':'NOT_EVALUATED_MATERIALS_NOT_RECEIVED','accuracy':'NOT_EVALUATED','default':'E0/S0','numerical_threads_per_run':1,'workers_per_run':1})
            print('DONE',dataset,mode,'processing',m['processing_complete'],'audit',m['audit_complete'],'seconds',round(m['resources']['wall_seconds'],2),flush=True)
    return 0

if __name__=='__main__':raise SystemExit(main())
