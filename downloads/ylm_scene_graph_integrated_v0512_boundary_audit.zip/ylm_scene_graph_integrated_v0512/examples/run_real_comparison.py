"""Independent processes: frozen L and A/AB/ABC with identical numeric gates."""
import argparse,copy,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from ylm051.io import read,rows,Output,sha
from ylm051.archive import select_archive,diversity

def main():
    p=argparse.ArgumentParser();p.add_argument('--inputs',required=True);p.add_argument('--baseline',required=True);p.add_argument('--out',required=True)
    p.add_argument('--modes',default='L,A,AB,ABC');p.add_argument('--datasets',default='exp01_t0,exp01_t1,exp02_t0,exp02_t1');a=p.parse_args()
    inputs=Path(a.inputs).resolve();baseline=Path(a.baseline).resolve();dest=Path(a.out).resolve();dest.mkdir(exist_ok=False,parents=True);o=Output(dest)
    results=[]
    for dataset in a.datasets.split(','):
        case,time=dataset.split('_')
        for mode in a.modes.split(','):
            source=baseline if mode=='L' else ROOT;run=dest/(dataset+'_'+mode)
            print('START',dataset,mode,flush=True)
            command=[sys.executable,'-m','ylm051','generate','--input',str(inputs/dataset/'input.json'),
                     '--profile',str(inputs/dataset/(mode+'.json')),'--out',str(run)]
            with (dest/(run.name+'.log')).open('w') as log:
                proc=subprocess.run(command,cwd=source,stdout=log,stderr=subprocess.STDOUT)
            result={'dataset':dataset,'mode':mode,'returncode':proc.returncode,'command':command,'code_root':str(source)}
            if (run/'run_manifest.json').exists():
                m=read(run/'run_manifest.json');result.update(processing_complete=m['processing_complete'],resources=m['resources'],error=m.get('error'))
                result['candidate_counts']={'singleton':0,'combined':0}
                if (run/'hypotheses.jsonl').exists():
                    for c in rows(run/'hypotheses.jsonl'):result['candidate_counts']['singleton' if c['is_singleton'] else 'combined']+=1
                if (run/'pair_pipeline_summary.json').exists():result['pair_metrics']=read(run/'pair_pipeline_summary.json')
                if (run/'candidate_diversity.json').exists():result['diversity']=read(run/'candidate_diversity.json')
                if mode=='AB' and proc.returncode==0:
                    archive=list(rows(run/'generated_archive.jsonl'));profile=read(inputs/dataset/'ABC.json')
                    same,selection=select_archive(archive,profile)
                    o.json(dataset+'_same_archive_selector.json',{'source_generated_archive_sha256':sha(run/'generated_archive.jsonl'),
                        'source_mode':'AB','selector_only':'diverse_v1','source_candidate_count':len(archive),'selected_ids':[c['candidate_id'] for c in same],
                        'selected_fragment_sets':[c['fragment_ids'] for c in same],'diversity':diversity(same,selection),
                        'note':'same generated archive; IDs keep AB profile hash; compare ABC by fragment sets'})
                if proc.returncode==0:
                    checked=subprocess.run([sys.executable,'-m','ylm051','verify','--run',str(run)],cwd=source,capture_output=True,text=True)
                    o.json(run.name+'_verify.json',{'returncode':checked.returncode,'stdout':checked.stdout,'stderr':checked.stderr})
                    result['verify_returncode']=checked.returncode
            results.append(result)
            o.json('comparison_summary.json',{'runs':results,'scope':'one independent process per requested dataset/mode; input time count and resolved budget scope define totals',
                                               'GT':'UNAVAILABLE','object_accuracy':'NOT_EVALUATED','registration':'NOT_RUN','graph_writes':0})
            print('DONE',dataset,mode,'rc',proc.returncode,'seconds',result.get('resources',{}).get('wall_seconds'),flush=True)
    return 0 if all(r['returncode']==0 and r.get('verify_returncode')==0 for r in results) else 2

if __name__=='__main__':sys.exit(main())
