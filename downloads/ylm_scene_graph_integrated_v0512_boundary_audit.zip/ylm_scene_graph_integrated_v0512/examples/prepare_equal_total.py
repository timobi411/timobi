"""Same total 5k pair checks / 5k expansions: old shared vs new 2.5k reserved/time."""
import argparse,copy,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ylm051.io import Output,read

def main():
    p=argparse.ArgumentParser();p.add_argument('--inputs',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    src=Path(a.inputs);dest=Path(a.out);dest.mkdir(exist_ok=False,parents=True);o=Output(dest)
    for case in ('exp01','exp02'):
        c=read(src/(case+'_t0')/'input.json');c['times'].update(read(src/(case+'_t1')/'input.json')['times'])
        legacy=read(src/(case+'_t0')/'L.json');new=read(src/(case+'_t0')/'ABC.json')
        for k in ('max_pair_checks','max_expanded_states','max_point_copies','max_regions','max_region_memberships'):
            new['budgets'][k]=legacy['budgets'][k]//2
        o.json(case+'_pair/input.json',c);o.json(case+'_pair/L.json',legacy);o.json(case+'_pair/ABC.json',new)
    o.json('scope.json',{'comparison':'same total count budgets; per-time reservation versus first-come shared',
        'max_pair_checks_total':5000,'max_expanded_states_total':5000,'legacy':'global shared 5000','new':'2500 reserved per time',
        'geometry':'unchanged','wall_rss_storage':'same run-global limits','workers':1})

if __name__=='__main__':main()
