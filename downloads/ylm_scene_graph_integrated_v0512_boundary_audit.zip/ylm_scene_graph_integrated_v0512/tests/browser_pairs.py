"""Actual Chromium UI checks via local HTTP; no network assets or policy overrides."""
import argparse,json
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from playwright.sync_api import sync_playwright

def main():
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--out',required=True);p.add_argument('--chromium',default='/usr/bin/chromium');a=p.parse_args()
    run=Path(a.run).resolve();dest=Path(a.out).resolve();dest.mkdir(exist_ok=False,parents=True)
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(run)))
    Thread(target=server.serve_forever,daemon=True).start();errors=[]
    try:
        with sync_playwright() as pw:
            browser=pw.chromium.launch(executable_path=a.chromium,headless=True,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
            page=browser.new_page(viewport={'width':1550,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)))
            page.goto(f'http://127.0.0.1:{server.server_port}/pair_viewer.html',wait_until='load')
            page.wait_for_function("document.querySelector('#pairs').options.length>0 && document.querySelector('#plot').data")
            page.locator('#pairQuery').fill('206,245')
            page.wait_for_function("shownPairs.length===1 && shownPairs[0].fragment_ids.join(',')==='206,245'")
            stage=page.locator('#states').inner_text();assert 'EVALUATED' in stage
            page.select_option('#direction','V_ONLY');page.select_option('#shared','false')
            page.wait_for_function('shownPairs.length===1')
            page.locator('#grid').check();page.select_option('#view','organized')
            page.wait_for_function("document.querySelector('#plot').data[0].type==='scattergl'")
            page.select_option('#view','3d')
            page.wait_for_function("document.querySelector('#plot').data.some(t=>t.name.startsWith('Core '))")
            page.select_option('#candidatePool','generated');page.locator('#candidateLayer').check()
            page.locator('#candidateLayer').uncheck()
            page.screenshot(path=str(dest/'pair_viewer.png'),full_page=True)
            page.select_option('#direction','H_ONLY');page.wait_for_function('shownPairs.length===0')
            page.select_option('#direction','V_ONLY');page.wait_for_function('shownPairs.length===1')
            assert not errors,errors
            (dest/'result.json').write_text(json.dumps({'status':'PASS','transport':'local HTTP','pair':'206,245','stages_text':stage,
                'checks':['pair exact search','direction filter V/H','shared Core filter','organized','3D Core boundary layer',
                          'generated/saved candidate pools','candidate layer','all stages','no JavaScript errors'],
                'javascript_errors':errors},ensure_ascii=False,indent=2)+'\n')
            browser.close()
    finally:server.shutdown();server.server_close()

if __name__=='__main__':main()
