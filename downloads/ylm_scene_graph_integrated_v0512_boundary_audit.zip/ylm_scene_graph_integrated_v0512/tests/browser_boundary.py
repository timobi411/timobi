"""Optional actual Chromium checks for the exp02 T1 regression output."""
import argparse,json
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
from threading import Thread
from playwright.sync_api import sync_playwright

def main():
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--out',required=True);p.add_argument('--chromium',default='/usr/bin/chromium');a=p.parse_args()
    root=Path(a.run).resolve();dest=Path(a.out);dest.mkdir(parents=True,exist_ok=False)
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(root)))
    Thread(target=server.serve_forever,daemon=True).start();errors=[];requests=[]
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path=a.chromium,headless=True,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
            page=browser.new_page(viewport={'width':1500,'height':1150});page.on('pageerror',lambda e:errors.append(str(e)))
            page.on('request',lambda r:requests.append(r.url))
            page.goto(f'http://127.0.0.1:{server.server_port}/boundary_audit.html',wait_until='load')
            page.wait_for_function("document.querySelector('#plotA').data && document.querySelector('#pairplot').data.length===9")
            assert 'A 83/83' in page.locator('#comparisonCounts').inner_text()
            assert 'B 85/85' in page.locator('#comparisonCounts').inner_text()
            page.select_option('#measurement','nearest')
            page.wait_for_function("document.querySelector('#pairplot').data.length===2")
            assert '2633,5510' in page.evaluate("document.querySelector('#pairplot').data[1].text[0]")
            page.select_option('#measurement','witness')
            assert 'legacy_all_links' in page.locator('#details').inner_text()
            page.evaluate("Plotly.relayout('plotA',{'scene.camera':{eye:{x:2,y:1,z:.8}}})")
            page.wait_for_function("document.querySelector('#plotB').layout.scene.camera.eye.x===2")
            for axis in ('xaxis','yaxis','zaxis'):
                assert page.evaluate(f"JSON.stringify(document.querySelector('#plotA').layout.scene.{axis}.range)===JSON.stringify(document.querySelector('#plotB').layout.scene.{axis}.range)")
            assert page.evaluate("document.querySelector('#plotB').data[0].marker.color.filter(c=>c==='#e5333d').length") == 2
            page.select_option('#measurement','contact');page.screenshot(path=str(dest/'boundary_viewer.png'),full_page=True)
            page.locator('#pair').fill('244,245');page.click('#show')
            page.wait_for_function("document.querySelector('#pairplot').data.length===2")
            assert not errors,errors
            assert all(r.startswith(f'http://127.0.0.1:{server.server_port}/') for r in requests)
            (dest/'result.json').write_text(json.dumps({'status':'PASS','transport':'local HTTP','external_requests':0,'javascript_errors':errors,
                'checks':['8 image contact lines','independent 3D nearest endpoints 2633/5510','witness and actual all-links decision',
                          'A83/B85 all points','shared axis bounds','linked camera','C244 two red points','244/245 one contact']},indent=2))
            browser.close()
    finally:server.shutdown();server.server_close()

if __name__=='__main__':main()
