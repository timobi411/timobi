import copy,itertools,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from ylm051.contacts import scan_image,image_order
from ylm051.policies import defaults
from ylm051.io import Output,Budget,read,rows
from ylm051.graph_v2 import build_graph,finish_diagnostics
from ylm051.features import snapshot_inputs,build_scene
from ylm051.config import load_input
from ylm051.pipeline import generate
from ylm051.search import search_scene
from ylm051.archive import select_archive,diversity
from examples.make_fixture import profile


class ContactTests(unittest.TestCase):
    def scan(self,labels,valid=None,settings=None):
        labels=np.asarray(labels,dtype=np.int32)
        scene=SimpleNamespace(labels=labels,valid=np.ones(labels.shape,bool) if valid is None else valid,time='t0')
        with tempfile.TemporaryDirectory() as d:
            b=Budget(profile()['budgets']);out=Output(Path(d),b)
            pairs,state=scan_image(scene,settings or defaults(),b,out)
            contacts=np.load(Path(d)/'image_contacts_t0.npz')['contacts']
            self.assertEqual(b.counts['pair_checks'],0)
            return pairs,state,contacts

    def test_horizontal_vertical_both_and_full_contact_counts(self):
        p,s,c=self.scan([[1,2],[2,1]])
        self.assertTrue(s['image_enumeration_complete']);self.assertEqual(len(c),4)
        self.assertEqual(p[(1,2)]['direction_class'],'BOTH')
        self.assertEqual(p[(1,2)]['horizontal_contact_count'],2);self.assertEqual(p[(1,2)]['vertical_contact_count'],2)

    def test_single_rows_columns_empty_and_no_wrap(self):
        for a,n in [([[1,2,3]],2),([[1],[2],[3]],2),([[-1,-1]],0),(np.zeros((0,0),int),0),([[1,-1],[2,-1]],1)]:
            with self.subTest(a=str(a)):
                p,s,c=self.scan(a);self.assertEqual(len(p),n);self.assertTrue(s['image_enumeration_complete'])
        p,s,c=self.scan([[1,2],[3,4]])
        self.assertNotIn((2,3),p)
        p,s,c=self.scan([[-1,-1]])
        self.assertIsNone(s['enumeration_rate']);self.assertEqual(s['rate_status'],'NOT_APPLICABLE')

    def test_invalid_and_negative_are_excluded(self):
        p,s,c=self.scan([[1,2],[-1,3]],np.array([[True,False],[True,True]]))
        self.assertEqual(len(p),0)

    def test_scan_limit_records_known_rows_unknown_denominator(self):
        s=defaults();s['max_image_pixels_scanned']=2
        p,status,c=self.scan([[1,2],[3,4]],settings=s)
        self.assertFalse(status['image_enumeration_complete']);self.assertEqual(status['processed_source_rows'],[0,1])
        self.assertEqual(status['unknown_source_rows'],[1,2]);self.assertIsNone(status['enumeration_rate'])

    def test_fair_order_covers_six_strata_and_tiles_before_repetition(self):
        inv={};i=0
        for d,shared in itertools.product(('H_ONLY','V_ONLY','BOTH'),(False,True)):
            for tile in ([0,0],[1,0],[0,0]):
                inv[(i,i+100)]={'direction_class':d,'shared_core':shared,'tile':tile};i+=1
        order=image_order(inv)
        self.assertEqual(len({(inv[p]['direction_class'],inv[p]['shared_core']) for p in order[:6]}),6)
        self.assertTrue(all(inv[p]['tile']==[1,0] for p in order[6:12]))
        self.assertEqual(order,image_order(dict(reversed(list(inv.items())))))


def scene_fixture(root,labels,xyz,p):
    labels=np.asarray(labels,np.int32);xyz=np.asarray(xyz,np.float32);valid=labels>=0
    src=root/'input';src.mkdir();o=Output(src);np.savez(src/'pixels.npz',xyz=xyz,valid=valid,labels=labels)
    ids,counts=np.unique(labels[valid],return_counts=True)
    o.json('clusters.json',{'clusters':[{'id':int(i),'point_count':int(n),'MODEL_INFERRED':0} for i,n in zip(ids,counts)]})
    o.json('input.json',{'schema':'ylm051.input.v1','run_id':'regression','case':'synthetic','window':'fixed11','boundary':'boundary_false',
                         'units':'m','dataset_kind':'SYNTHETIC','development_selection':'specified reachability test, not object GT',
                         'frame_status':'FRAME_UNVERIFIED','times':{'t0':{'pixels':'pixels.npz','clusters':'clusters.json'}}})
    o.json('profile.json',p);out=Output(root/'run',Budget(p['budgets']));out.root.mkdir()
    config,records=snapshot_inputs(load_input(src/'input.json'),out,out.budget)
    scene=build_scene(config,'t0',out.root,records,out,out.budget)
    return scene,out,src


class GraphTests(unittest.TestCase):
    def test_cross_core_horizontal_and_vertical_reach_attempt_without_halo(self):
        for vertical in (False,True):
            with self.subTest(vertical=vertical),tempfile.TemporaryDirectory() as d:
                p=profile();p['variant']='B1';p['geometry'].update(grid_origin_m=[0,0,0],cell_size_m=1.,halo_m=0.,spatial_radius_m=.05,max_added_gap_m=.2)
                lab=[[206],[245]] if vertical else [[206,245]]
                xyz=[[[.99,.5,.5]],[[1.145,.5,.5]]] if vertical else [[[.99,.5,.5],[1.145,.5,.5]]]
                scene,out,_=scene_fixture(Path(d),lab,xyz,p);g=build_graph(scene,p,out,out.budget)
                self.assertFalse(g.inventory[(206,245)]['shared_core'])
                cs,st=search_scene(scene,g,p,out,out.budget,'FRAME_UNVERIFIED')
                finish_diagnostics(g,cs,out,'t0')
                self.assertTrue(any(c['fragment_ids']==[206,245] for c in cs))
                self.assertGreater(g.inventory[(206,245)]['expansion_attempts'],0)
                self.assertGreater(g.inventory[(206,245)]['used_for_expansion'],0)
                self.assertTrue(all(c['identity_status']=='UNKNOWN' for c in cs))

    def test_deep_contact_reaches_attempt_but_gap_gate_stops(self):
        with tempfile.TemporaryDirectory() as d:
            p=profile();p['variant']='B1';p['geometry'].update(grid_origin_m=[0,0,0],cell_size_m=1.,halo_m=0.)
            scene,out,_=scene_fixture(Path(d),[[91,93]],[[[.1,0,0],[2.,0,0]]],p)
            g=build_graph(scene,p,out,out.budget);cs,st=search_scene(scene,g,p,out,out.budget,'FRAME_UNVERIFIED')
            self.assertGreater(g.inventory[(91,93)]['expansion_attempts'],0)
            self.assertEqual(g.inventory[(91,93)]['used_for_expansion'],0)
            self.assertEqual(len(cs),2)
            self.assertTrue(any(r.get('reason')=='MAX_ADDED_GAP' for r in rows(out.root/'region_crossing.jsonl')))

    def test_low_geometry_budget_preserves_complete_image_inventory(self):
        with tempfile.TemporaryDirectory() as d:
            p=profile();p['budgets']['max_pair_checks']=1
            scene,out,_=scene_fixture(Path(d),[[1,2,3,4]],[[[.1*i,0,0] for i in range(4)]],p)
            g=build_graph(scene,p,out,out.budget)
            self.assertTrue(g.status['image_scan']['image_enumeration_complete'])
            self.assertEqual(len(g.image_inventory),3);self.assertEqual(len(g.pairs),1)
            self.assertEqual(sum(g.inventory[k]['geometry_evaluation']=='NOT_EVALUATED' for k in g.image_inventory),2)

    def test_multicore_membership_uses_intersection_not_centroid(self):
        with tempfile.TemporaryDirectory() as d:
            p=profile();p['geometry'].update(grid_origin_m=[0,0,0],cell_size_m=1.,halo_m=0.)
            scene,out,_=scene_fixture(Path(d),[[1,1,2]],[[[.1,.2,.2],[1.1,.2,.2],[1.2,.2,.2]]],p)
            g=build_graph(scene,p,out,out.budget)
            self.assertTrue(g.inventory[(1,2)]['shared_core']);self.assertEqual(len(g.inventory[(1,2)]['core_cells']['1']),2)

    def test_incomplete_scan_is_partial_failure_and_b2_does_not_downgrade(self):
        for mode in ('scan','B2'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as d:
                p=profile()
                if mode=='scan':p['candidate_search']['max_image_pixels_scanned']=1
                else:p['variant']='B2'
                scene,out,src=scene_fixture(Path(d),[[1,2]],[[[0,0,0],[.1,0,0]]],p)
                result=generate(src/'input.json',src/'profile.json',Path(d)/'partial')
                self.assertFalse(result['processing_complete'])
                self.assertIn('IMAGE_PIXELS_SCAN_LIMIT' if mode=='scan' else 'B2 NOT_EVALUATED',result['error']['message'])

    def test_reserved_time_counts_are_order_independent(self):
        p=profile();p['budgets']['max_pair_checks']=2
        results=[]
        for times in (('t0','t1'),('t1','t0')):
            b=Budget(p['budgets'])
            for t in times:
                b.begin_time(t);b.take('pair_checks',2)
            results.append(b.time_counts)
            self.assertEqual(b.counts['pair_checks'],4)
        self.assertEqual(results[0],results[1])


class ArchiveTests(unittest.TestCase):
    def values(self):
        values=[]
        for region,seed,size in itertools.product(range(3),range(3),(3,8,18)):
            start=region*1000+seed*100+size
            values.append({'candidate_id':str((region,seed,size)),'fragment_ids':list(range(start,start+size)),
                           'rank_tuple':[region,seed,size],'seed_fragment_id':seed,
                           'origins':[{'region':[region,0,0],'seed_fragment_id':seed}]})
        return values

    def test_archive_permutation_region_seed_size_diversity(self):
        p=profile();p['budgets']['combined_per_time']=18
        v=self.values();a,records=select_archive(v,p);b,_=select_archive(list(reversed(v)),p)
        self.assertEqual([c['candidate_id'] for c in a],[c['candidate_id'] for c in b])
        report=diversity(a,records)
        self.assertEqual(report['unique_owner_regions'],3);self.assertGreaterEqual(report['unique_owner_seeds'],6)
        self.assertEqual(set(report['size_classes']),{'2-4','5-16','17+'})

    def test_near_duplicates_limited_but_shared_core_not_one_group(self):
        p=profile();p['candidate_search'].update(similarity_threshold=.8,similarity_group_limit=1)
        v=self.values()[:3]
        v[0]['fragment_ids']=[1,2,3,4,5,6];v[1]['fragment_ids']=[1,2,3,4,5,6,7];v[2]['fragment_ids']=[1,2,30,40,50]
        a,r=select_archive(v,p)
        self.assertEqual(len(a),2);self.assertTrue(any(x['state']=='PRUNED_DIVERSITY' for x in r))
        p['candidate_search']['relax_similarity_to_fill']=True
        self.assertEqual(len(select_archive(v,p)[0]),3)

if __name__=='__main__':unittest.main()
