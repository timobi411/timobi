import copy,json,tempfile,unittest,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from ylm051.boundary_audit import contact_arrays,summarize,minima,expansion_details,AuditRecorder
from ylm051.io import Output,Budget,read,rows,sha
from ylm051.archive import select_archive
from ylm051.pipeline import generate
from ylm051.audit_verify import audit_verify
from ylm051.selection_experiment import select_run,proxy_evaluate
from examples.make_fixture import profile,make

class ContactGeometryTests(unittest.TestCase):
    def arrays(self,pts,labels,valid=None):
        labels=np.array(labels,np.int32);xyz=np.array(pts,np.float32)
        return contact_arrays(xyz,np.ones(labels.shape,bool) if valid is None else valid,labels)

    def test_large_range_step_is_measurement_not_rejection(self):
        a=self.arrays([[[1,0,0],[2,0,0]]],[[1,2]])
        self.assertAlmostEqual(a['distance_m'][0],1);self.assertAlmostEqual(a['signed_delta_range_m'][0],1)
        self.assertNotIn('rejected',summarize(a,0,1))

    def test_lateral_separation_with_equal_range(self):
        a=self.arrays([[[1,0,0],[0,1,0]]],[[1,2]])
        self.assertAlmostEqual(a['distance_m'][0],2**.5);self.assertEqual(a['signed_delta_range_m'][0],0)

    def test_endpoint_order_normalized_by_id_after_image_reversal(self):
        a=self.arrays([[[1,0,0],[2,0,0]]],[[10,2]])
        b=self.arrays([[[2,0,0],[1,0,0]]],[[2,10]])
        np.testing.assert_equal(a['delta_xyz'],b['delta_xyz']);np.testing.assert_equal(a['signed_delta_range_m'],b['signed_delta_range_m'])
        self.assertEqual(a['signed_delta_range_m'][0],-1)

    def test_nonfinite_invalid_negative_empty_and_different_shapes(self):
        for shape in [(0,3),(3,0),(1,4),(4,1),(2,3)]:
            xyz=np.zeros((*shape,3));lab=np.full(shape,-1);v=np.ones(shape,bool)
            a=contact_arrays(xyz,v,lab);self.assertEqual(len(a['direction']),0);self.assertIsNone(summarize(a,0,0)['distance_min_p05_p50_p95_max_m'])
        a=self.arrays([[[1,0,0],[float('nan'),0,0],[2,0,0]]],[[1,2,3]])
        self.assertEqual(len(a['direction']),0)
        a=self.arrays([[[1,0,0],[2,0,0]]],[[1,2]],np.array([[True,False]]));self.assertEqual(len(a['direction']),0)

    def test_mixed_contacts_offsets_and_signed_counts(self):
        a=self.arrays([[[1,0,0],[2,0,0]],[[2,0,0],[1,0,0]]],[[1,2],[2,1]])
        s=summarize(a,0,4);self.assertEqual((s['horizontal_count'],s['vertical_count']),(2,2));self.assertEqual(s['distinct_endpoints'],4)
        self.assertEqual(s['signed_range_counts'],{'positive':4,'negative':0,'zero':0})

    def test_3d_nearest_and_image_contact_are_different_endpoints(self):
        a=self.arrays([[[1,0,0],[5,0,0],[1.01,0,0]]],[[1,1,2]])
        self.assertEqual(a['pixel_ids'].tolist(),[[1,2]])
        self.assertGreater(a['distance_m'][0],3)
        self.assertLess(np.linalg.norm(np.array([1,0,0])-np.array([1.01,0,0])),.02)

    def test_ties_and_legacy_all_links_shadow_difference(self):
        def p(ids,d,eligible):return {'fragment_ids':ids,'geometry':{'minimum_distance_m':d},'exploration_state':'ELIGIBLE_FOR_HYPOTHESIS' if eligible else 'SEARCH_GATE_EXCLUDED','routes':[{'route':'IMAGE_CONTACT_4'}]}
        pairs={(1,3):p([1,3],.1,False),(2,3):p([2,3],.3,True)}
        d=expansion_details([1,2],3,pairs,set(),.2)
        self.assertTrue(d['decision']['passed']);self.assertFalse(d['shadow_eligible_passed']);self.assertEqual(d['witness_pair'],[2,3]);self.assertFalse(d['witness_is_distance_minimizer'])
        tied=minima([p([2,3],.1,True),p([1,3],.1,True)])
        self.assertEqual(tied['equal_minimum_pairs'],[[1,3],[2,3]]);self.assertEqual(tied['representative_pair'],[1,3])

    def test_audit_storage_and_wall_limits_are_partial_and_separate(self):
        for kind in ('storage','wall'):
            with tempfile.TemporaryDirectory() as d:
                p=profile();p['budgets']['max_saved_bytes']=2048
                if kind=='wall':p['budgets']['wall_seconds']=0
                b=Budget(p['budgets']);a=AuditRecorder(Output(Path(d),b))
                self.assertFalse(a.write('events.jsonl',{'parent_fragment_ids':[1,2],'payload':'a'*5000}))
                self.assertFalse(a.status(True)['audit_complete']);self.assertTrue(a.stops)
                self.assertEqual(b.counts['expanded_states'],0);self.assertEqual(b.counts['pair_checks'],0)

class SelectionTests(unittest.TestCase):
    def candidates(self):
        return [{'candidate_id':str(i),'fragment_ids':sorted(set([i//4,i+20])), 'rank_tuple':[i],
                 'seed_fragment_id':i%3,'origins':[{'region':[i%2,0,0],'seed_fragment_id':i%3}]} for i in range(30)]

    def test_s0_trace_explains_unvisited_and_s1_is_deterministic(self):
        p=profile();p['budgets']['combined_per_time']=6;cs=self.candidates()
        for policy in ('S0','coverage_order_v1'):
            logs=[];chosen,_=select_archive(cs,p,audit_sink=logs.append,selection_policy=policy)
            revlogs=[];rev,_=select_archive(list(reversed(cs)),p,audit_sink=revlogs.append,selection_policy=policy)
            self.assertEqual(chosen,rev);self.assertEqual(logs,revlogs);self.assertEqual(len(chosen),6)
            self.assertTrue(any(not e['visited'] for e in logs));self.assertEqual(sum(e['accepted'] for e in logs),6)
            self.assertTrue(all(e['group_count_before']<p['candidate_search']['similarity_group_limit'] for e in logs if e['accepted']))

    def test_duplicate_visit_rejection_does_not_update_coverage(self):
        p=profile();p['budgets']['combined_per_time']=4;p['candidate_search']['similarity_group_limit']=1
        cs=self.candidates();cs[1]['fragment_ids']=cs[0]['fragment_ids'][:]
        logs=[];select_archive(cs,p,audit_sink=logs.append,selection_policy='coverage_order_v1')
        covered=set();byid={c['candidate_id']:c for c in cs}
        for e in logs:
            if not e['visited']:continue
            self.assertEqual(e['uncovered_fragments_before'],len(set(byid[e['candidate_id']]['fragment_ids'])-covered))
            if e['accepted']:covered.update(byid[e['candidate_id']]['fragment_ids'])

class IntegrationAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.root=Path(cls.temp.name)
        make(cls.root/'fixture');cls.run_dir=cls.root/'run'
        cls.result=generate(cls.root/'fixture/input.json',cls.root/'fixture/profiles/B3.json',cls.run_dir)

    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()

    def test_complete_audit_including_unarchived_parents_and_reuse(self):
        self.assertTrue(self.result['processing_complete'],self.result.get('error'))
        r=audit_verify(self.run_dir);self.assertTrue(r['audit_complete']);self.assertEqual(r['unavailable_parent_events'],0)
        for t,n in r['generated_event_count'].items():self.assertEqual(n,r['unique_generated_candidate_count'][t]+r['reused_candidate_event_count'][t])
        events=list(rows(self.run_dir/'expansion_events.jsonl'));saved={c['candidate_id'] for c in rows(self.run_dir/'hypotheses.jsonl')}
        self.assertTrue(any(e['parent_candidate_id'] not in saved for e in events))

    def test_proxy_is_posthoc_and_s0_matches_archive_order(self):
        before=sha(self.run_dir/'artifact_hashes.json');d=self.root/'selection';s=select_run(self.run_dir,d,'S0');self.assertTrue(s['complete'])
        original=[c['candidate_id'] for c in rows(self.run_dir/'hypotheses.jsonl') if not c['is_singleton']]
        self.assertEqual(original,[c['candidate_id'] for c in rows(d/'selected_candidates.jsonl')])
        config=read(self.run_dir/'input_contract.json');t=sorted(config['times'])[0]
        with np.load(self.run_dir/config['times'][t]['pixels']) as z:ids=np.flatnonzero(z['valid'].ravel()&(z['labels'].ravel()>=0))[:5]
        np.save(self.root/'proxy.npy',ids);r=proxy_evaluate(self.run_dir,None,self.root/'proxy.npy',t,self.root/'evaluation')
        self.assertEqual(sum(r['partition'].values()),len(ids));self.assertEqual(before,sha(self.run_dir/'artifact_hashes.json'))
        self.assertTrue(r['generation_unchanged'])

    def test_generator_and_selector_reject_proxy_arguments(self):
        for command in ('generate','select'):
            required=['--input',str(self.root/'fixture/input.json'),'--profile',str(self.root/'fixture/profiles/B3.json')] if command=='generate' else ['--run',str(self.run_dir)]
            p=subprocess.run([sys.executable,'-m','ylm051',command,*required,'--out',str(self.root/'forbidden'),'--proxy','hidden.npy'],capture_output=True)
            self.assertNotEqual(p.returncode,0)
            self.assertIn(b'unrecognized arguments',p.stderr)

    def test_changed_event_detected_without_trusting_artifact_hash(self):
        path=self.run_dir/'expansion_events.jsonl';original=path.read_bytes()
        try:
            events=list(rows(path));events[0]['all_links_minimum']['minimum_m']+=1
            path.write_text(''.join(json.dumps(e)+'\n' for e in events))
            with self.assertRaisesRegex(ValueError,'audit numeric mismatch'):audit_verify(self.run_dir,check_integrity=False)
        finally:path.write_bytes(original)

if __name__=='__main__':unittest.main()
