# v0.5.1.2 実装状況

対象仕様は `specification_v0512.md`（design-2）です。診断と互換経路を既定にし、比較経路は明示指定します。

| 章・要件 | 実装・確認方法 |
|---|---|
| 5 全接触幾何 | boundary_audit.contact_arrays。全端点・float64・ID正規化・符号・分位点・無接触null |
| 6 ゲート監査 | pair_gate_audit.jsonl。spatial/image/original、OR、独立した型付き端点 |
| 7 全拡張イベント | search_sceneの各追加評価を記録。未保存親の断片集合、全/eligible最小、witness、再訪、代表履歴 |
| 8 Viewer | boundary_audit.html。接触／3D最近傍／witness切替、A83/B85、C244赤、軸・視点共有 |
| 9 資源 | 監査件数は別カウンタ、wall/RSS/容量は元Budgetと共通。停止は完全性false・未記録数 |
| 10 検証器 | audit-verify。全接触再計算、端点・offset・符号・分位点、全親links、実距離・shadow・witness、選択ログ |
| 11 回帰試験 | 既存39件をそのまま保全し、新規14件。入力保護・GT分離・深さ上限等も継続 |
| 12 実データ互換 | 4ケースで凍結旧版を再実行し、旧同士／旧新の候補・順序・画素ID・探索カウンタを照合 |
| 15.1 選択履歴 | 実訪問順のquota/再配分、owner、類似群の直前件数、選択・見送り・未訪問を区別 |
| 15.2 S0/S1 | 同じ生成archive。S1のみowner内で未包含断片優先。採用時だけ包含更新、類似性の自動緩和なし |
| 16 E1～E4 | 元の資源上限・S0を固定。予算・Beam・サイズ上限の各倍増を別出力で全ケース実行 |
| 17 共通評価 | 全観測の生成／保存和集合、集中、点数・サイズ・接触range差、停止、hash、資源を記録 |
| 17 代理事後評価 | 専用proxy-evaluateのみが代理IDを受領。3分割・候補別内外・非劣位・画素重複を出力 |

実数値・成功／停止結果は `validation/REPORT_ja.md` と `comparison_summary.json` を参照してください。仕様の研究室報告値を実行結果として埋め込んでいません。

## 未受領・未実施

研究室の6診断フォルダ、proxy_pixel_ids.npy、proxy_reproduction.json、candidate_proxy_comparison.json、旧M2 PCDによる再現材料は未受領です。今回の330画素に対する249/183/66/81、候補別40/45等は再現評価していません。代理処理の実装は合成入力で検査し、全観測統計と区別します。

接触は遮蔽・物理接触・同一物体を証明しません。range原点のセンサ性も未確認です。新しい段差ゲート、eligible限定の実採否、ICP、Hungarian、永続ID、シーングラフ更新、exp08は今回実行しません。

## 互換性上の注意

候補生成器のprofileとrankを変えず、監査出力を別ファイルへ追加します。旧source_pixelsの意味の問題は型付き参照で補います。旧archive_selectionの最終分類を因果として読み替えず、selection_eventsで確認します。

元の7 schemaは保持し、追加3 schemaを `schemas/audit/` に格納します。既存39テストの期待値を変更しません。Python 3.10で検査し、ブラウザ操作は別のPlaywright試験です。

既存v0.5.1.1 ZIPと原本入力は上書きしません。旧コードと今回コードのSHA-256、入力・profile・生成集合・結果のhashを同梱記録します。互換候補が一致しても、監査追加による資源増を同じ実行時間と呼びません。
