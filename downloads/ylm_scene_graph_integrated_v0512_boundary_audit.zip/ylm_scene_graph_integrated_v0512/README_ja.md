# YLM-X001 v0.5.1.2 接触境界・候補拡張監査

design-2仕様に基づき、v0.5.1.1の探索を既定のまま維持して、接触の幾何、全拡張イベント、保存選択の実際の訪問履歴を追加しました。既定は互換経路E0/S0です。S1保存とE1～E4探索は明示的な別実験です。

物体認識精度を改善したとの判定ではありません。identity=UNKNOWN、registration=NOT_RUN、update=HELD、シーングラフ書込0を維持します。v0.4入力・構造マスク・ラベル・断片ID・元幾何ゲートを変更しません。rangeは座標原点からの距離であり、センサ原点との一致は未検証です。

## 結果を見る

ZIPを全体展開して `validation/index.html` を開いてください。各runの `boundary_audit.html` はデータ・Plotlyを埋め込んだ自己完結HTMLです。元の `index.html` と `pair_viewer.html` も残しています。

ペア欄に `206,245` を入力し、画像接触／3D最近傍／拡張witnessを切り替えます。線の端点ID、距離、符号付きrange差と、各追加のall/eligibleリンク・実判定・shadow判定を確認できます。3D最近傍[2633,5510]と画像接触8組は別の測定です。

A/B比較は同じ軸範囲・連動する視点を使います。exp02 T1では83点／85点を全表示し、差分C244の2点を赤くします。この表示上の既定選択は生成・保存ルールに使いません。

file://表示が制限される環境では、展開フォルダで `python3 -m http.server 8000 --bind 127.0.0.1` を起動し、`http://127.0.0.1:8000/validation/` を開いてください。今回のChromium操作試験はローカルHTTP経由です。

## 環境と導入

Ubuntu 22.04 / Python 3.10、数値1 thread・worker1。依存はNumPy 2.2.6、SciPy 1.14.1、Plotly 6.3.1です。生成・監査にROSとOpen3Dは不要です。Linuxのresourceを使うためWindowsではWSL2等を使用してください。HTML表示だけならPythonは不要です。

```bash
cd ylm_scene_graph_integrated_v0512
python3.10 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-dev.txt
python -m compileall -q ylm051 examples
python -m unittest discover -s tests -v
```

Ubuntuにはpython3.10-venv、JS構文検査にはNode.jsが必要です。Dockerは `docker build -t ylm0512 -f docs/Dockerfile .`、`docker run --rm -v "$PWD:/app" -w /app ylm0512 python3.10 -m unittest discover -s tests -v` で利用できます。管理プロキシの認証局が必要なら任意のca_bundle secretを使い、TLS検証を維持します。

## 生成 → 検証 → 表示

```bash
python examples/make_fixture.py --out outputs/fixture
python -m ylm051 generate --input outputs/fixture/input.json --profile outputs/fixture/profiles/B3.json --out outputs/run
python -m ylm051 verify --run outputs/run
python -m ylm051 audit-verify --run outputs/run
python -m ylm051 view --run outputs/run
```

その後 `outputs/run/boundary_audit.html` を開きます。verifyは既存hash・画素集合・状態を検証します。audit-verifyは全接触・全イベントを元入力から再構成し、選択ログも再実行して照合します。integrity、processing_complete、search_exhaustive、audit_complete、accuracyは独立です。部分監査・旧版の監査情報欠落は成功扱いしません。

```bash
python -m ylm051 audit-verify --run validation/real/exp02_t1
python -m ylm051 replay --run validation/real/exp02_t1 --out outputs/replay
python -m ylm051 audit-verify --run outputs/replay
```

毎回新しい出力先を指定します。原本が存在すればhashも照合し、原本がなくてもsnapshotだけで再生できます。bagの再読込は不要です。

## 互換性・測定・監査出力

input/profile schemaとCLI名ylm051を維持します。元profileをそのまま使用し、監査設定を候補IDへ混入しません。E0/S0の探索順・Beam・rank・保存順・IDを保持します。ただし診断の時間・容量も元の全体上限に含めるため、資源停止時は完全な互換結果とは扱いません。

全接触はvalid・XYZ有限・非負異ラベルの右／下4近傍からfloat64で再計算し、旧image_contactsの全端点と照合します。端点は断片ID昇順、差分は「大きい断片ID側−小さい断片ID側」です。画素の左右とは別です。

| 出力 | 内容 |
|---|---|
| contact_geometry_t0.npz / contact_geometry_t1.npz | 全接触の断片・画素ID、row/col、XYZ、方向、距離、range、符号付き差分 |
| contact_geometry_summary.jsonl | offset、接触数、端点数、分位点、符号数、別欄の3D最近傍 |
| pair_gate_audit.jsonl | spatial/image/original条件、演算子、閾値、OR結果、型付き端点参照 |
| expansion_events.jsonl | 親断片集合、全links／eligible links、実距離判定・witness・結果 |
| candidate_event_origins.jsonl | 代表addition_orderを作ったイベント |
| selection_events.jsonl | 訪問順、quota段階、owner、類似群の直前件数、採用／見送り／未訪問 |
| audit_status.json | 完全性、停止理由、出力済み／未記録件数、イベント数と一意候補数 |

NPZのfragment_ids/pixel_idsは[N,2]、row_colは[N,2,2]、xyzは[N,2,3]。directionは0=水平、1=垂直。offsetは半開区間[start,end)。接触なしはNO_DIRECT_CONTACT・[0,0]・count=0・分位点nullであり、0距離を意味しません。namespace・入力fingerprintをsummaryに、元ファイルhashをsource_hashesに保持します。

旧pair_evidenceのsource_pixelsは互換のため残します。旧IMAGE_DISTANCEにも3D最近傍端点が入るので、新しいtyped_referencesを正本とします。IMAGE_DISTANCEは画素距離の端点、GEOMETRY_DISTANCEは全断片3D最近傍です。targetへの複製や接触本数を独立した同一性支持として数えません。

実際の追加判定はlegacy_all_linksのままです。eligible限定の距離と合否はshadowであり棄却・減点・rankへ使いません。同値最小は絶対差1e-12m以内を全件記録し、表示代表はペアID昇順。実witnessは旧最短距離・ペアID順を保持します。照合幅1e-6mは計算再現用で、センサ精度・採用閾値ではありません。

候補IDは断片集合、event_idは生成経路です。GENERATED_HYPOTHESISには再訪も含まれます。生成イベント／一意生成候補／再訪イベント／保存一意候補を別々に集計します。親点群を複製せず、parent_fragment_idsで再構成します。

## 保存だけを比較するS0/S1

```bash
python -m ylm051 select --run validation/real/exp02_t1 --policy S0 --out outputs/S0
python -m ylm051 select --run validation/real/exp02_t1 --policy coverage_order_v1 --out outputs/S1
```

固定generated_archiveから再選択し、探索は再実行しません。S0は従来diverse_v1の集合・順序。S1はsize→region→seedの巡回枠、128件、類似性0.85・群上限2を維持し、owner内だけを「未包含断片数降順→旧rank→ID」へ変えます。採用時だけ包含集合を更新し、制約を自動緩和しません。S1は既定ではありません。

生成集合hash、profile、資源、全観測の生成／保存和集合、断片・タイル、集中、サイズ・点数・段差分布を出力します。旧archive_selectionのPRUNED_RANK等は最終分類です。未訪問の上限停止と訪問後の見送りの因果説明にはselection_eventsを使用してください。

## E1～E4の一因子実験

| profile | E0からの変更 |
|---|---|
| E0 | 元profileそのまま |
| E1 | max_expanded_states 5,000→10,000 |
| E2 | max_pair_checks 5,000→10,000 |
| E3 | beam_per_seed 4→8 |
| E4 | max_fragments 16→32、max_depth 15→31（サイズ上限の1因子） |

幾何・入力・S0保存と元wall/RSS/保存容量を固定します。S1との組合せは自動実施しません。別上限で止まった結果も記録し、良いケースだけを選別しません。profileをhashへ含むため、実験間は断片集合で比較します。

```bash
python examples/prepare_handoff.py --handoff /path/to/handoff --out outputs/inputs
python examples/run_boundary_experiments.py --inputs outputs/inputs --baseline /path/to/frozen_v0511 --baseline-results /path/to/v0511/validation/real --out outputs/comparison
```

まずexp02 T1を確認し、残り3ケースに同じ相対変更を適用します。exp02 T0は前回同様、未収録の旧研究室T0 profileの代わりに受領T1の数値設定で比較します。

## 代理領域の事後評価

研究室診断フォルダ、proxy_pixel_ids.npy、proxy_reproduction.json、candidate_proxy_comparison.jsonは今回未受領です。330画素・249/183/66/81等は研究室報告であり、今回再計算済みとは扱いません。旧M2 PCDによる代理抽出も未実施です。

```bash
python -m ylm051 proxy-evaluate --run validation/real/exp02_t1 --time t1 --proxy /path/to/proxy_pixel_ids.npy --out outputs/proxy_S0
python -m ylm051 proxy-evaluate --run validation/real/exp02_t1 --selection outputs/S1 --time t1 --proxy /path/to/proxy_pixel_ids.npy --out outputs/proxy_S1
```

代理IDは同時刻のH×WのC順flat index、一次元整数NPYです。有効ラベル付き観測以外を拒否します。由来・座標・閾値は代理再現JSON等で確認してください。CLIは代理の独立GT性を認証しません。生成器・選択器はproxy引数を受け取りません。

保存／生成のみ／未生成の3分割、候補別対象内外、非劣位集合、保存候補と非劣位候補間の画素重複を出します。対象外は誤結合と確定しません。元資源上限に達した重複出力はPARTIALです。代理情報追加で生成hashが変わらないことを合成試験で確認します。

## 検証・資源・納品

既存39件を変更せず、14件を追加した53件を検査します。全接触再照合、未保存親、再訪、一意数、S1順序不変性・類似性制約、容量／時間停止、proxy分離を含みます。実数値・資源・停止状態はvalidation/REPORT_ja.mdとcomparison_summary.jsonに記載します。

監査はpair/expanded/point-copyとは別カウンタですが、wall/RSS/保存容量は共通です。上限到達はaudit_complete=falseとし、出力済み範囲・未記録件数を残します。処理完了・監査完了は探索網羅・物体精度を意味しません。段差棄却・eligible限定距離判定は導入しません。

`python examples/verify_release.py` で納品全ファイルのhashを確認できます。元v0.5.1.1 ZIPはGitHubの既存ダウンロード先にそのまま保全し、hashをsource_inventory.jsonに記録します。本ZIPには旧版の検証データを重複同梱せず、旧ソースの凍結コピーをvendorへ格納します。
