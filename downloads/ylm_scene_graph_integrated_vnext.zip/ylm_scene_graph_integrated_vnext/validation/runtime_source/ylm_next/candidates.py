"""Non-destructive fragment unions; proximity proposes, boundary evidence gates."""
import itertools
import numpy as np
from scipy.spatial import cKDTree
from .core import *

def plane(p,c):
 if len(p)<3:return {'planar':False,'reason':'FEW_POINTS'}
 center=p.mean(0);_,_,v=np.linalg.svd(p-center,full_matrices=False);q=(p-center)@v.T;p95=float(np.quantile(abs(q[:,2]),.95));span=np.ptp(q,axis=0)
 return {'planar':len(p)>=c['planar_min_points'] and span[1]>=c['planar_min_span_m'] and p95<=c['planar_p95_m'],'normal':v[-1].tolist(),'center':center.tolist(),'p95_m':p95,'span_m':span.tolist()}

def boundary(a,la,lb,labels,c):
 h,w=labels.shape;ids=np.arange(h*w).reshape(h,w);r=a['range'].ravel();valid=a['valid'].ravel();mask=a['structure_mask'].ravel();flat=labels.ravel();rows=[];enough=False;strong=False
 pix=np.flatnonzero(np.isin(flat,[la,lb]));ys,xs=np.divmod(pix,w);margin=c['roi_margin_pixels']
 if not len(pix):return {'status':'UNRESOLVED_INSUFFICIENT_BOUNDARY_SUPPORT','directions':[]}
 roi=np.zeros_like(labels,bool);roi[max(0,int(ys.min())-margin):min(h,int(ys.max())+margin+1),max(0,int(xs.min())-margin):min(w,int(xs.max())+margin+1)]=True
 for direction,i,j in [('horizontal',ids[:,:-1].ravel(),ids[:,1:].ravel()),('vertical',ids[:-1].ravel(),ids[1:].ravel())]:
  inside=roi.ravel()[i]&roi.ravel()[j];ok=inside&valid[i]&valid[j]&~mask[i]&~mask[j]
  cross=ok&(((flat[i]==la)&(flat[j]==lb))|((flat[i]==lb)&(flat[j]==la)))
  internal=[ok&(flat[i]==x)&(flat[j]==x) for x in [la,lb]];p90=[float(np.quantile(abs(r[i[k]]-r[j[k]]),c['internal_quantile'])) if k.any() else None for k in internal]
  diff=abs(r[i[cross]]-r[j[cross]]);supported=len(diff)>=c['min_boundary_edges'] and all(int(k.sum())>=c['min_internal_edges'] for k in internal)
  sensitivity=[]
  for threshold in c['sensitivity_m']:
   cutoff=max([threshold]+[v for v in p90 if v is not None]);fraction=float(np.mean(diff>=cutoff)) if len(diff) else None
   sensitivity.append({'absolute_m':threshold,'effective_threshold_m':cutoff,'strong_fraction':fraction})
  cutoff=max([c['absolute_m']]+[v for v in p90 if v is not None]);fraction=float(np.mean(diff>=cutoff)) if len(diff) else None
  held=supported and fraction>=c['strong_fraction'];enough|=supported;strong|=held
  rows.append({'direction':direction,'boundary_edge_count':len(diff),'internal_counts':[int(k.sum()) for k in internal],'internal_p90_m':p90,'range_difference_m':diff.tolist(),'point_distance_m':np.linalg.norm(a['xyz'].reshape(-1,3)[i[cross]]-a['xyz'].reshape(-1,3)[j[cross]],axis=1).tolist(),'pixel_i':i[cross].tolist(),'pixel_j':j[cross].tolist(),'strong_fraction':fraction,'sufficient_support':supported,'held':held,'sensitivity':sensitivity,'missing_edges':int((inside&(~valid[i]|~valid[j])).sum()),'structure_edges':int((inside&(mask[i]|mask[j])).sum())})
 return {'status':'HELD_DEPTH_BOUNDARY' if strong else 'NO_STRONG_DEPTH_BOUNDARY' if enough else 'UNRESOLVED_INSUFFICIENT_BOUNDARY_SUPPORT','directions':rows,'missing_is_contact':False}

def generate(obs,fragments,labels,c,bc,manual,run_id,budget):
 a=obs['arrays'];xyz=a['xyz'].reshape(-1,3);oid=obs['metadata']['observation_id'];bylabel={f['label']:f for f in fragments};points={f['label']:xyz[f['pixel_ids']] for f in fragments};planes={k:plane(p,c) for k,p in points.items()};trees={k:cKDTree(p) for k,p in points.items()};active=[f for f in fragments if f['point_count']>=c['min_fragment_points']];proposals=[];graph={};maxradius=max(c['radius_m'],c['sensitivity_radius_m']);candidate_rows=[]
 centers=np.array([f['center'] for f in active]);radii=np.array([max(np.linalg.norm(points[f['label']]-f['center'],axis=1)) for f in active])
 center_tree=cKDTree(centers) if len(active) else None
 for ix,fa in enumerate(active):
  budget.check();la=fa['label']
  for jx in center_tree.query_ball_point(centers[ix],maxradius+radii[ix]+max(radii,default=0)):
   if jx<=ix:continue
   fb=active[jx];lb=fb['label']
   if np.linalg.norm(centers[ix]-centers[jx])>maxradius+radii[ix]+radii[jx]:continue
   da,_=trees[lb].query(points[la],workers=1);db,_=trees[la].query(points[lb],workers=1);minimum=float(da.min());support=[int((d<=c['radius_m']).sum()) for d in [da,db]];sensitivity=[int((d<=c['sensitivity_radius_m']).sum()) for d in [da,db]]
   if min(sensitivity)<c['min_support_each'] and min(support)<c['min_support_each']:continue
   pa,pb=planes[la],planes[lb];kind='MIXED_PLANAR_NONPLANAR' if pa['planar']!=pb['planar'] else 'NONPLANAR_COMPONENT_PROPOSAL';geo={}
   if pa['planar'] and pb['planar']:
    angle=float(np.degrees(np.arccos(np.clip(abs(np.dot(pa['normal'],pb['normal'])),0,1))));delta=np.array(pa['center'])-pb['center'];offset=max(abs(np.dot(delta,pa['normal'])),abs(np.dot(delta,pb['normal'])));merged=plane(np.concatenate([points[la],points[lb]]),c)
    coplanar=angle<=c['coplanar_angle_deg'] and offset<=c['coplanar_offset_m'] and merged['p95_m']<=c['merged_p95_m'];kind='COPLANAR_PROPOSAL' if coplanar else 'NONPARALLEL_OR_OFFSET_COMPONENT_PROPOSAL';geo={'normal_angle_deg':angle,'mutual_offset_m':offset,'merged_p95_m':merged['p95_m']}
   evidence=boundary(a,la,lb,labels,bc);inbase=min(support)>=c['min_support_each'];record={'labels':[la,lb],'fragment_keys':[fa['fragment_key'],fb['fragment_key']],'minimum_distance_m':minimum,'support_each':support,'radius_m':c['radius_m'],'in_base_radius':inbase,'sensitivity':{'radius_m':c['sensitivity_radius_m'],'support_each':sensitivity,'new_at_radius':not inbase},'route':kind,'geometry':geo,'boundary':evidence}
   proposals.append(record)
   if inbase:graph.setdefault(la,set()).add(lb);graph.setdefault(lb,set()).add(la)
 # Stable BFS over connected unions, bounded separately from singleton retention.
 edge_by={tuple(sorted(p['labels'])):p for p in proposals};groups=[(f['label'],) for f in fragments];composites=[];seen=set();front=sorted(tuple(sorted(p['labels'])) for p in proposals if p['in_base_radius']);truncated=False
 while front:
  budget.check();g=front.pop(0)
  if g in seen:continue
  seen.add(g)
  if len(composites)>=c['max_composites']:truncated=True;break
  composites.append(g)
  if len(g)<c['max_parts']:
   for x in sorted(set.union(*(graph.get(k,set()) for k in g))-set(g)):front.append(tuple(sorted(g+(x,))))
 groups+=composites
 def row(g,origin,provenance=None):
  fs=[bylabel[k] for k in g];ids=np.unique(np.concatenate([f['pixel_ids'] for f in fs])).astype(int);ev=[edge_by[tuple(sorted(pair))] for pair in itertools.combinations(g,2) if tuple(sorted(pair)) in edge_by];states=[p['boundary']['status'] for p in ev]
  state='SINGLETON' if len(g)==1 else 'HELD_DEPTH_BOUNDARY' if 'HELD_DEPTH_BOUNDARY' in states else 'UNRESOLVED_INSUFFICIENT_BOUNDARY_SUPPORT' if 'UNRESOLVED_INSUFFICIENT_BOUNDARY_SUPPORT' in states or not ev else 'PROPOSED_GEOMETRY_ONLY'
  key=f'{oid}:{run_id}:{origin}:'+digest([f['fragment_key'] for f in fs])[:16]
  return {'candidate_key':key,'observation_id':oid,'fragment_keys':[f['fragment_key'] for f in fs],'fragment_labels':list(g),'pixel_ids':ids.tolist(),'point_count':len(ids),'origin':origin,'manual_provenance':provenance,'generation_reason':'SINGLE_FRAGMENT' if len(g)==1 else [p['route'] for p in ev],'boundary_state':state,'boundary_proposal_indices':[proposals.index(p) for p in ev],'status':state,'obb':obb(xyz[ids]),'model_info':{'status':'UNKNOWN','semantic_class':'UNKNOWN'},'parts':{f['fragment_key']:f['pixel_ids'] for f in fs},'registration_eligible':len(ids)>=c['min_registration_points']}
 for g in groups:candidate_rows.append(row(g,'AUTO_SINGLE' if len(g)==1 else 'AUTO_COMPOSITE'))
 for m in manual:
  if m['observation_id']!=oid:continue
  require(all(m.get(k) for k in ['specified_by','specified_at','reason']),'Manual provenance required')
  g=tuple(sorted(set(m['labels'])));require(all(k in bylabel for k in g),'Manual fragment IDs do not exist in this run')
  candidate_rows.append(row(g,'MANUAL_COMPOSITE',{k:m[k] for k in ['specified_by','specified_at','reason']}))
 shared={f['fragment_key']:[r['candidate_key'] for r in candidate_rows if f['fragment_key'] in r['fragment_keys']] for f in fragments}
 return candidate_rows,{'proposals':proposals,'singleton_count':len(fragments),'composite_count':len(composites),'generation_complete':not truncated,'stop_reason':'MAX_COMPOSITES' if truncated else None,'additional_16cm_proposals':[p for p in proposals if p['sensitivity']['new_at_radius']],'shared_fragment_candidates':shared,'shared_pixel_rule':'exact pixel sets under observation_id; fragments partition pixels','manual_in_auto_metrics':False,'plane_features':planes}

def spatial_diagnostic(labels,audit):
 """Separate visualization partition from conservative complete-link coplanar groups."""
 labs=sorted(np.unique(labels[labels>=0]).tolist());groups=[{x} for x in labs]
 allowed={tuple(sorted(p['labels'])) for p in audit['proposals'] if p['in_base_radius'] and p['route']=='COPLANAR_PROPOSAL' and p['boundary']['status']=='NO_STRONG_DEPTH_BOUNDARY'}
 for pair in sorted(allowed):
  ga=next(g for g in groups if pair[0] in g);gb=next(g for g in groups if pair[1] in g)
  if ga is gb:continue
  if all(tuple(sorted((a,b))) in allowed for a in ga for b in gb):ga.update(gb);groups.remove(gb)
 result=labels.copy();lineage=[]
 for group in groups:
  target=min(group)
  for parent in sorted(group):
   ids=np.flatnonzero(labels.ravel()==parent);result.ravel()[ids]=target;lineage.append({'parent_label':parent,'proposal_label':target,'inherited_points':len(ids)})
 return result,{'status':'DISPLAY_PROPOSAL_ONLY_ORIGINAL_LABELS_UNCHANGED','method':'COMPLETE_LINK_COPLANAR_WITH_BOUNDARY_SUPPORT','lineage':lineage}
