"""Evidence records bind verification claims to exact observation/config values."""
import numpy as np
from .core import *

def decision_fingerprint(c):
 return digest({'gates':c['gates'],'registration':{k:v for k,v in c['registration'].items() if k not in ['max_pairs','per_source_reservation']},'assignment':{k:v for k,v in c['assignment'].items() if k!='max_nodes'},'gravity_axis':c['gravity']['axis']})

def check_claims(c,base):
 if c['frame']['status']=='FRAME_VERIFIED':
  r=read(base/c['frame']['evidence']);require(r.get('status')=='VERIFIED' and bool(r.get('method')),'Invalid frame evidence')
  for o in c['observations']:require(o['observation_id'] in r.get('transforms',{}) and np.allclose(matrix(r['transforms'][o['observation_id']]),matrix(o['observation_to_common'])),'Frame evidence does not match observation transform')
 if c['gravity']['status']=='VERIFIED':
  r=read(base/c['gravity']['evidence']);require(r.get('status')=='VERIFIED' and bool(r.get('method')) and np.allclose(r.get('axis'),c['gravity']['axis']),'Gravity verification evidence mismatch')
 if c['calibration']['status']=='VALIDATED':
  r=read(base/c['calibration']['record']);require(r.get('status')=='VALIDATED' and r.get('decision_fingerprint')==decision_fingerprint(c) and bool(r.get('independent_case_ids')) and c['case'] not in r['independent_case_ids'],'Calibration must match decision settings and separate cases')
