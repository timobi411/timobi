"""Non-destructive organized observation to registration proposal integration."""
__version__='0.7.0'
