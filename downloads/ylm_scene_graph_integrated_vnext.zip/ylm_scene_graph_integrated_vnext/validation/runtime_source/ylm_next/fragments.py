import numpy as np
from .core import *
from ylm_integrated_clustering_v04._vendor.organized_v01.clustering import components,cluster_organized

def cluster(obs,mask,c,run_id):
 a=obs['arrays'];eligible=a['valid']&~mask;e=obs['edges'];origin='SAVED_EDGE_REUSE'
 if e is None:
  trusted=a.get('measurement_confident',a['support_count']>=c['min_confidence_support']);current=a['valid']&(a['source_type']==1)&~mask
  fc={'acquisition':{'sensor_origin_xyz':[0,0,0]},'clustering':c}
  cl,_,_,_=cluster_organized(a['xyz_observation'],current,trusted,fc)
  _,e,_,_=cluster_organized(a['xyz_observation'],eligible,trusted,fc,cl,current);origin='FROZEN_V04_CONNECTION_RECOMPUTATION'
 else:
  old=obs['edge_config']['clustering']
  for k in ['neighborhood','beta_threshold_deg','max_edge_distance_m','boundary_jump_m','hold_boundary_points','prevent_temporal_bridges','min_confidence_support']:require(old[k]==c[k],'Saved-edge configuration differs: '+k)
 e={k:v.copy() for k,v in e.items()};i,j=e['pixel_i'],e['pixel_j'];valid=eligible.ravel()[i]&eligible.ravel()[j];reason=e['hold_reason'].astype(np.uint16)
 # Reconstruct geometric validity from primitive alpha/beta. Never re-gate on
 # pass_geometry, which some historical adapters used as an aggregate flag.
 primitive=np.isfinite(e['alpha_rad'])&np.isfinite(e['beta_rad'])&(e['alpha_rad']>=1e-8)&(e['alpha_rad']<np.pi/2)
 basic=valid&primitive&(e['beta_rad']>=np.radians(c['beta_threshold_deg']))&(e['distance_m']<=c['max_edge_distance_m'])&((reason&4)==0)&((reason&64)==0)
 base=valid&e['accepted'];relaxed=basic&(e['distance_m']<=c['local_distance_m'])&((reason&(8|32))!=0)
 local=base|relaxed;labels_base=components(eligible,i[base],j[base]);labels_local=components(eligible,i[local],j[local]);labels=labels_local if c['mode']=='LOCAL' else labels_base
 e.update(accepted_base=base,accepted_local=local,relaxed=relaxed&~base,base_component_i=labels_base.ravel()[i],base_component_j=labels_base.ravel()[j],local_component_i=labels_local.ravel()[i],local_component_j=labels_local.ravel()[j])
 oid=obs['metadata']['observation_id'];rows=[];parent=obs['parent_labels'] if obs['parent_labels'] is not None else labels_base
 for lab in np.unique(labels[labels>=0]):
  ids=np.flatnonzero(labels.ravel()==lab);pts=a['xyz'].reshape(-1,3)[ids];pl,pc=np.unique(parent.ravel()[ids],return_counts=True)
  rows.append({'fragment_key':f'{oid}:{run_id}:{c["mode"]}:{int(lab)}','observation_id':oid,'label':int(lab),'pixel_ids':ids.tolist(),'point_count':len(ids),'center':pts.mean(0).tolist(),'bounds':[pts.min(0).tolist(),pts.max(0).tolist()],'obb':obb(pts),'evaluation_eligible':len(ids)>=5,'display_eligible':True,'generation':origin,'parents':[{'label':int(x),'inherited_points':int(y)} for x,y in zip(pl,pc)],'semantic_class':'UNKNOWN'})
 lineage={'method':origin,'labels_are_run_local':True,'base_to_local':[],'parent_to_final':[],'relaxed_edges':np.flatnonzero(e['relaxed']).tolist(),'point_lineage':'labels.npz: original/base/local/final; same pixel_id'}
 for name,x,y in [('base_to_local',labels_base,labels_local),('parent_to_final',parent,labels)]:
  pairs,count=np.unique(np.column_stack([x[eligible],y[eligible]]),axis=0,return_counts=True)
  lineage[name]=[{'parent':int(p[0]),'child':int(p[1]),'inherited_points':int(n)} for p,n in zip(pairs,count)]
 return rows,{'original':parent,'base':labels_base,'local':labels_local,'final':labels},e,lineage
