from copy import deepcopy
from .core import require,matrix

def defaults():
 return {'schema':'ylm.next.config.v1','case':'unspecified','seed':42,'observations':[],
 'frame':{'status':'FRAME_UNVERIFIED','evidence':None},'gravity':{'status':'UNVERIFIED','axis':[0,0,1],'evidence':None},
 'wall':{'enabled':True,'voxel_m':.025,'distance_m':.02,'iterations':2000,'max_planes':30,'min_support':60,'max_normal_axis_dot':.258819,'merge_angle_deg':4.,'merge_distance_m':.06,'merged_min_support':150,'min_height_m':1.2,'min_width_m':1.2,'min_one_side_fraction':.97,'exclude_band_m':.08,'remove_band_m':.04,'support_radius_m':.18,'max_p95_m':.04},
 'clustering':{'mode':'LOCAL','local_distance_m':.04,'neighborhood':4,'beta_threshold_deg':10.,'max_edge_distance_m':.12,'boundary_jump_m':.25,'min_confidence_support':2,'hold_boundary_points':False,'prevent_temporal_bridges':True},
 'candidate':{'radius_m':.15,'min_support_each':3,'min_fragment_points':5,'max_parts':3,'max_composites':1000,'min_registration_points':30,'sensitivity_radius_m':.16,
 'planar_min_points':100,'planar_min_span_m':.08,'planar_p95_m':.025,'coplanar_angle_deg':15.,'coplanar_offset_m':.03,'merged_p95_m':.04},
 'boundary':{'absolute_m':.10,'sensitivity_m':[.08,.10,.12],'min_boundary_edges':5,'min_internal_edges':10,'internal_quantile':.9,'strong_fraction':.5,'roi_margin_pixels':5},
 'registration':{'route':'diagnostic_6dof','voxel_m':.02,'coarse_m':.35,'fine_m':.08,'iterations':80,'yaw_degrees':[-30,0,30],'max_points':1000000,'max_pairs':256,'per_source_reservation':1},
 'gates':{'obb_center':{'enabled':True,'threshold':1.5},'obb_size':{'enabled':False,'threshold':.45},'assignment_size':{'enabled':True,'threshold':[.2,.55]},'shape':{'enabled':True,'threshold':[.75,.03]},'pose':{'enabled':True,'threshold':5.},'movement':{'enabled':True,'threshold':1.2},'part_support':{'enabled':True,'threshold':.75},'legacy_validity':{'enabled':True,'threshold':'FROZEN_PROFILE'}},
 'assignment':{'utility':'minimum_coverage_minus_0.75','margin':None,'max_nodes':200000,'motion_threshold_m':.3,'use_yaw':False,'yaw_threshold_deg':5.},
 'calibration':{'status':'UNCALIBRATED','record':None},'manual_candidates':[],'object_models':[],
 'graph':{'path':None,'shape_policy':{'STATIC':'HISTORY_MODEL','MOVED':'CURRENT_OBSERVATION','UNKNOWN':'PRESERVE','HELD':'PRESERVE'}},
 'resources':{'wall_seconds':3600.,'rss_mib':4096.,'max_output_mib':1024.},'display':{'point_size':2,'opacity':1.,'obb_min_points':30,'arrow_basis':'ICP_REFERENCE_DISPLACEMENT'}}

def merge(a,b):
 for k,v in b.items():
  require(k in a,'Unknown configuration field: '+k)
  if isinstance(a[k],dict) and isinstance(v,dict):merge(a[k],v)
  else:a[k]=deepcopy(v)
 return a

def resolve(c):
 d=merge(defaults(),c)
 from pathlib import Path
 import json,jsonschema
 try:jsonschema.validate(d,json.loads((Path(__file__).parent/'schemas/config.json').read_text()))
 except jsonschema.ValidationError as exc:raise ValueError('Schema '+'.'.join(map(str,exc.absolute_path))+': '+exc.message) from exc
 require(d['schema']=='ylm.next.config.v1','Configuration version mismatch')
 require(len(d['observations'])==2,'Exactly two observations required')
 require(len({o['observation_id'] for o in d['observations']})==2,'Observation IDs must differ')
 require(d['frame']['status'] in ['FRAME_VERIFIED','FRAME_UNVERIFIED'],'Invalid frame status')
 import numpy as np
 require(len(d['gravity']['axis'])==3 and np.isfinite(d['gravity']['axis']).all() and np.linalg.norm(d['gravity']['axis'])>0,'Nonzero finite gravity/reference axis required')
 require(d['gravity']['status'] in ['VERIFIED','UNVERIFIED'],'Invalid gravity status')
 for label in ['frame','gravity']:
  if d[label]['status'] in ['FRAME_VERIFIED','VERIFIED']:require(bool(d[label]['evidence']),'Verification evidence required: '+label)
 require(d['clustering']['mode'] in ['BASE','LOCAL'],'Invalid clustering mode')
 require(type(d['clustering']['hold_boundary_points']) is bool,'boundary adapter requires boolean config, not string')
 require(d['registration']['route'] in ['frozen_B0','recovered_local_6dof','diagnostic_6dof','diagnostic_4dof'],'Unknown registration route')
 if d['registration']['route']=='diagnostic_4dof':require(d['gravity']['status']=='VERIFIED','diagnostic_4dof requires verified gravity')
 require(d['assignment']['utility'] in ['minimum_coverage_minus_0.75','legacy_score'],'Unknown utility')
 require(d['calibration']['status'] in ['UNCALIBRATED','SYNTHETIC_ONLY','VALIDATED'],'Invalid calibration')
 if d['calibration']['status']=='VALIDATED':require(bool(d['calibration']['record']),'Independent calibration record required')
 for g in d['gates'].values():require(type(g['enabled']) is bool,'Gate enabled must be boolean')
 for key in ['max_pairs','per_source_reservation','iterations','max_points']:require(type(d['registration'][key]) is int and d['registration'][key]>0,'Positive integer required: '+key)
 for key in ['wall_seconds','rss_mib','max_output_mib']:require(d['resources'][key]>0,'Positive resource limit required')
 require(1<=d['candidate']['max_parts']<=6 and d['candidate']['max_composites']>=0,'Invalid candidate budget')
 require(d['assignment']['margin'] is None or d['assignment']['margin']>=0,'Invalid ambiguity margin')
 return d
