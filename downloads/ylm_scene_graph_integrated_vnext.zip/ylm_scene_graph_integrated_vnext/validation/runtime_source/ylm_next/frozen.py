"""All B0 trial values are returned by the hash-verified original evaluate_pair."""
import importlib.util
from pathlib import Path
import numpy as np
from .core import *

def b0_trials(a,b,budget):
 import open3d as o3d
 from ylm06.legacy import B0_SHA
 import ylm06
 path=Path(ylm06.__file__).parent/'vendor/frozen/baseline_icp_B0.py';require(sha(path)==B0_SHA,'Frozen B0 source hash differs')
 spec=importlib.util.spec_from_file_location('frozen_b0_next',path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 clouds=[]
 for p in [a,b]:
  cloud=o3d.geometry.PointCloud();cloud.points=o3d.utility.Vector3dVector(p);clouds.append(cloud)
 aa,bb=[np.asarray(cloud.voxel_down_sample(mod.VOXEL).points) for cloud in clouds];raw=[];yaws=list(mod.YAW_CANDIDATES)
 for yaw in yaws:
  budget.check();mod.YAW_CANDIDATES=[yaw];r=mod.evaluate_pair(*clouds)
  if r is not None:raw.append({**r,'initial_yaw_deg':yaw,'initial_transform':mod.rotation_about_center(aa.mean(0),yaw).tolist()})
 mod.YAW_CANDIDATES=yaws
 legacy=max(raw,key=lambda h:h['score']) if raw else None
 return legacy,raw,{'source_before':len(a),'target_before':len(b),'source_after':len(aa),'target_after':len(bb),'voxel_m':mod.VOXEL,'source_sha256':B0_SHA,'method':'UNMODIFIED_EVALUATE_PAIR_SINGLE_INITIALIZER_AUDIT','constants':{k:getattr(mod,k) for k in ['COARSE_DISTANCE','FINE_DISTANCE','MAX_ITER','MIN_NORMAL_SCORE','MIN_PARTIAL_COVERAGE','MAX_PARTIAL_RMSE','MAX_ICP_MOVEMENT']}},aa,bb
