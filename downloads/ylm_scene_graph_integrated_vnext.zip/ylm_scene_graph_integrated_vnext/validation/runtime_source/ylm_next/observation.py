"""Versioned saved-v04 adapter; original row-major pixels are never renumbered."""
from pathlib import Path
import numpy as np
from .core import *

def input_paths(config,base):
 paths=[]
 for o in config['observations']:
  for k in ['observation','mask','edges','edge_config','labels','history','history_config']:
   if o.get(k):paths.append((base/Path(o[k])).resolve())
 for item in [config['frame'].get('evidence'),config['gravity'].get('evidence'),config['calibration'].get('record'),config['graph'].get('path')]:
  if item:paths.append((base/item).resolve())
 for m in config['object_models']:
  paths.append((base/m['path']).resolve())
 return sorted(set(paths))

def load_observation(o,base):
 a=load(base/o['observation']);require({'xyz','valid','source_type','support_count','source_time_ns'}<=a.keys(),'Saved v04 observation requires XYZ/valid/source_type/support_count/time')
 v=a['valid'];require(v.ndim==2 and v.dtype==bool,'valid must be bool HxW');h,w=v.shape
 require(a['xyz'].shape==(h,w,3) and np.isfinite(a['xyz'][v]).all(),'Finite XYZ required on valid pixels')
 for k in ['source_type','support_count','source_time_ns']:
  require(a[k].shape==(h,w) and np.issubdtype(a[k].dtype,np.integer),'Integer HxW required: '+k)
 require(np.all(a['support_count']>=0),'Negative support count')
 mask=load(base/o['mask'])['structure_mask'];require(mask.dtype==bool and mask.shape==v.shape,'structure_mask must be bool HxW')
 t=matrix(o.get('observation_to_common',np.eye(4)))
 raw=a['xyz'].copy();common=np.full_like(raw,np.nan,dtype=float);common[v]=transform(raw[v],t)
 ranges=a.get('range',np.linalg.norm(raw,axis=-1));require(ranges.shape==v.shape and np.isfinite(ranges[v]).all(),'Invalid range')
 a.update(pixel_id=np.arange(h*w,dtype=np.int64).reshape(h,w),range=ranges,xyz=common,xyz_observation=raw,valid=v.copy(),structure_mask=mask,observation_to_common=t)
 if 'missing_reason' not in a:a['missing_reason']=np.where(v,'OBSERVED','UNCLASSIFIED_INVALID')
 require(a['missing_reason'].shape==v.shape,'Missing reason must be HxW')
 edges=load(base/o['edges']) if o.get('edges') else None
 if edges is not None:
  require(o.get('edge_config'),'Saved edges require their exact configuration')
  for k in ['pixel_i','pixel_j','hold_reason','accepted','alpha_rad','beta_rad','distance_m']:require(k in edges,'Missing audited edge field: '+k)
  i,j=edges['pixel_i'],edges['pixel_j'];require(i.ndim==1 and i.shape==j.shape,'Invalid edge shape')
  for k in ['pixel_i','pixel_j','hold_reason']:require(np.issubdtype(edges[k].dtype,np.integer),'Integer edge field required')
  require(edges['accepted'].dtype==bool,'accepted must be boolean')
  require(np.all((i>=0)&(j>=0)&(i<h*w)&(j<h*w)),'Edge pixel out of bounds')
  require(all(x.shape==i.shape for x in edges.values()),'All audited edge arrays must align')
  known=v.ravel()[i]&v.ravel()[j]
  if 'endpoint_valid_i' in edges:known &= edges['endpoint_valid_i']&edges['endpoint_valid_j']
  require(not np.any(edges['accepted']&~known),'Accepted edge has invalid endpoint')
  require(np.allclose(np.linalg.norm(raw.reshape(-1,3)[i[known]]-raw.reshape(-1,3)[j[known]],axis=1),edges['distance_m'][known],atol=1e-5,equal_nan=False),'Saved edges belong to different XYZ')
 labels=load(base/o['labels'])['labels'] if o.get('labels') else None
 if labels is not None:require(labels.shape==v.shape and np.issubdtype(labels.dtype,np.integer),'Invalid parent labels')
 return {'metadata':o,'arrays':a,'edges':edges,'edge_config':read(base/o['edge_config']) if edges is not None else None,'parent_labels':labels}
