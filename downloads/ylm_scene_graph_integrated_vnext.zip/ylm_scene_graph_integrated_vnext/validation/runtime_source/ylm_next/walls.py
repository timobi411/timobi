"""Finite-support wall proposals, complete-link merging, measured OR masks."""
import numpy as np
from scipy.spatial import cKDTree
from .core import clean

def fit(points):
 c=points.mean(0);_,_,v=np.linalg.svd(points-c,full_matrices=False);n=v[-1]
 return c,n,float(np.quantile(abs((points-c)@n),.95)),v[:2].T

def finite_support_mask(points,support,center,normal,basis,band,radius):
 distances,_=cKDTree((support-center)@basis).query((points-center)@basis,workers=1)
 return (abs((points-center)@normal)<=band)&(distances<=radius)

def detect(a,c,gravity,seed,budget):
 original=a['structure_mask'];additional=np.zeros_like(original);cfg=c;records=[];pids=np.flatnonzero(a['valid']&~original);points=a['xyz'].reshape(-1,3)[pids]
 if not cfg['enabled'] or len(points)<cfg['min_support']:
  return additional,{'status':'DISABLED' if not cfg['enabled'] else 'INSUFFICIENT_POINTS','planes':[],'additional_removed':0}
 import open3d as o3d
 o3d.utility.random.seed(seed);cloud=o3d.geometry.PointCloud();cloud.points=o3d.utility.Vector3dVector(points);cloud=cloud.voxel_down_sample(cfg['voxel_m']);p=np.asarray(cloud.points);remaining=np.arange(len(p));planes=[]
 axis=np.asarray(gravity['axis'],float);axis/=np.linalg.norm(axis)
 for index in range(cfg['max_planes']):
  budget.check()
  if len(remaining)<cfg['min_support']:break
  cloud.points=o3d.utility.Vector3dVector(p[remaining]);_,support=cloud.segment_plane(cfg['distance_m'],3,cfg['iterations'],probability=.999999)
  support=np.asarray(support,int)
  if len(support)<cfg['min_support']:break
  ids=remaining[support];remaining=np.delete(remaining,support);center,n,res,basis=fit(p[ids]);vertical=abs(n@axis)<=cfg['max_normal_axis_dot']
  planes.append({'id':index,'ids':ids,'center':center,'normal':n,'p95':res,'vertical':vertical})
 groups=[]
 for plane in planes:
  if not plane['vertical']:continue
  chosen=None
  for group in groups:
   ok=all(np.degrees(np.arccos(np.clip(abs(plane['normal']@q['normal']),0,1)))<=cfg['merge_angle_deg'] and max(abs((plane['center']-q['center'])@q['normal']),abs((plane['center']-q['center'])@plane['normal']))<=cfg['merge_distance_m'] for q in group)
   merged=np.unique(np.concatenate([x['ids'] for x in group+[plane]]))
   if ok and fit(p[merged])[2]<=cfg['max_p95_m']:chosen=group;break
  if chosen is None:groups.append([plane])
  else:chosen.append(plane)
 for plane in planes:
  records.append(clean({'id':plane['id'],'support_voxel_indices':plane['ids'],'normal':plane['normal'],'center':plane['center'],'p95_m':plane['p95'],'vertical_candidate':plane['vertical'],'reason':'GROUP_EVALUATION' if plane['vertical'] else 'NORMAL_OUTSIDE_WALL_RANGE'}))
 groups_out=[];sum_counts=0
 for k,group in enumerate(groups):
  budget.check();ids=np.unique(np.concatenate([x['ids'] for x in group]));support=p[ids];center,n,res,basis=fit(support);height=float(np.ptp(support@axis));horizontal=np.cross(axis,n);horizontal/=max(np.linalg.norm(horizontal),1e-12);width=float(np.ptp(support@horizontal))
  signed=(points-center)@n;outside=abs(signed)>cfg['exclude_band_m'];one=max(int((signed[outside]>0).sum()),int((signed[outside]<0).sum()))/outside.sum() if outside.any() else None
  reasons=[]
  if len(ids)<cfg['merged_min_support']:reasons.append('INSUFFICIENT_SUPPORT')
  if height<cfg['min_height_m'] or width<cfg['min_width_m']:reasons.append('SMALL_EXTENT')
  if res>cfg['max_p95_m']:reasons.append('MERGED_RESIDUAL')
  if one is None or one<cfg['min_one_side_fraction']:reasons.append('ONE_SIDED_SUPPORT')
  within=finite_support_mask(points,support,center,n,basis,cfg['remove_band_m'],cfg['support_radius_m']);remove=within if not reasons else np.zeros(len(points),bool)
  additional.ravel()[pids[remove]]=True;sum_counts+=int(remove.sum())
  groups_out.append(clean({'id':k,'planes':[x['id'] for x in group],'support_points':support,'normal':n,'center':center,'p95_m':res,'height_m':height,'width_m':width,'one_side_fraction':one,'one_side_denominator':int(outside.sum()),'accepted':not reasons,'reasons':reasons,'removed_pixel_ids':pids[remove],'support_projection_radius_m':cfg['support_radius_m'],'normal_reference':'GRAVITY' if gravity['status']=='VERIFIED' else 'UNVERIFIED_SENSOR_AXIS'}))
 return additional,{'status':'COMPLETED_ZERO_REMOVAL' if not additional.any() else 'COMPLETED','planes':records,'groups':groups_out,'merge_method':'COMPLETE_LINK_WITH_MERGED_RESIDUAL','merged_p95_origin':'RECONSTRUCTED_COMPARISON_CONDITION','additional_removed':int(additional.sum()),'per_plane_sum':sum_counts,'union_removed':int((original|additional).sum()),'gravity_status':gravity['status'],'profile':cfg}
