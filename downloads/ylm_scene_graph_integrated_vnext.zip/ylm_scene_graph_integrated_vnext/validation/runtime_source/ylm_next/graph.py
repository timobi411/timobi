"""Reviewable proposals and explicit transactional apply/rollback; originals retained."""
import copy,fcntl,os,shutil,tempfile
from pathlib import Path
import numpy as np
from .core import *

def proposal(c,base,observations,candidates,pairs,assignment,run_id):
 old=read(base/c['graph']['path']) if c['graph'].get('path') else None;oldhash=sha(base/c['graph']['path']) if old is not None else None
 lookup={x['candidate_key']:x for x in candidates};records=[];operations=[];holds=[]
 if c['frame']['status']!='FRAME_VERIFIED':holds.append('FRAME_UNVERIFIED')
 if c['gravity']['status']!='VERIFIED':holds.append('GRAVITY_UNVERIFIED')
 if c['calibration']['status']!='VALIDATED':holds.append('PROFILE_UNCALIBRATED')
 if assignment['status']!='RESOLVED':holds.append('ASSIGNMENT_AMBIGUOUS_OR_INCOMPLETE')
 for p in pairs:
  selected=p['pair_id'] in assignment['selected'];state='UNKNOWN';diagnostic=None
  if selected and p.get('valid'):
   motion=p['motion'];moved=motion['estimated_center_movement_m']>=c['assignment']['motion_threshold_m'] or c['assignment']['use_yaw'] and abs(motion['yaw_deg'])>=c['assignment']['yaw_threshold_deg'];diagnostic='MOVED' if moved else 'STATIC'
   if not holds:state=diagnostic
  p['motion_status']=state;p['identity_status']='PENDING_EXPLICIT_REVIEW' if selected and not holds else 'HELD';records.append({'pair_id':p['pair_id'],'selected':selected,'state':state,'diagnostic_state':diagnostic,'rotation_deg':p.get('motion',{}).get('rotation_deg'),'manual_origin':p['manual_origin']})
  if selected:
   src=lookup[p['source_candidate_key']];mapping=observations[0]['metadata'].get('graph_node_map',{});node=mapping.get(src['candidate_key'],mapping.get(str(src['fragment_labels'][0])) if len(src['fragment_labels'])==1 else None)
   operations.append({'pair_id':p['pair_id'],'node_id':node,'state':state,'transform_source_to_target':p['transform_source_to_target'],'source_candidate_key':src['candidate_key'],'target_candidate_key':p['target_candidate_key'],'support_pixel_ids':lookup[p['target_candidate_key']]['pixel_ids'],'shape_policy':c['graph']['shape_policy'][state],'before_node':None,'after_node':None})
 if old is None:holds.append('NO_PERSISTENT_GRAPH')
 else:
  nodes=old.get('nodes',[]);nodes=list(nodes.values()) if isinstance(nodes,dict) else nodes;by={str(n.get('id',n.get('node_id'))):n for n in nodes}
  for op in operations:
   node=by.get(str(op['node_id']))
   if node is None:holds.append('PERSISTENT_NODE_MAPPING_MISSING');continue
   op['before_node']=node;new=copy.deepcopy(node);new['pose']= (matrix(op['transform_source_to_target'])@matrix(node.get('pose',np.eye(4)))).tolist();new['state']=op['state']
   if op['state']=='MOVED' and op['shape_policy']=='CURRENT_OBSERVATION':
    obs=observations[1]['arrays'];new['previous_shape']=copy.deepcopy(node.get('shape'));new['shape']={'points_common_m':obs['xyz'].reshape(-1,3)[op['support_pixel_ids']].tolist(),'source_candidate_key':op['target_candidate_key'],'run_id':run_id,'representation':'CURRENT_MEASURED_UNION'}
   new.setdefault('observations',[]).append({'run_id':run_id,'pair_id':op['pair_id'],'candidate_key':op['target_candidate_key'],'support_pixel_ids':op['support_pixel_ids'],'shape_policy':op['shape_policy']});op['after_node']=new
 return {'schema':'ylm.next.graph_proposal.v1','status':'PROPOSAL_ONLY','run_id':run_id,'base_graph_sha256':oldhash,'before_graph':old,'operations':operations,'states':records,'hold_reasons':sorted(set(holds)),'can_request_apply':not holds and bool(operations),'unmatched_status':'UNKNOWN_NOT_APPEARED_OR_DISAPPEARED','shape_policy':c['graph']['shape_policy'],'graph_modified':False,'independent_identity_accuracy':None}

def apply(run,review_path,store):
 from .pipeline import verify
 run=Path(run);verify(run);p=read(run/'graph_proposal.json');review=read(review_path)
 require(p['can_request_apply'],'Proposal held: '+','.join(p['hold_reasons']))
 require(review.get('proposal_sha256')==sha(run/'graph_proposal.json') and review.get('approved') is True and all(review.get(k) for k in ['reviewer','reviewed_at','reason']),'Explicit matching review required')
 require(set(review.get('confirmed_pairs',[]))=={x['pair_id'] for x in p['operations']},'Every operation needs identity review')
 store=Path(store);store.mkdir(parents=True,exist_ok=True)
 with (store/'lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX);head=read(store/'HEAD.json') if (store/'HEAD.json').exists() else None
  existing=store/p['run_id']
  if existing.exists():
   require(head is None or head['run_id']!=p['run_id'],'Run already applied')
   require(read(existing/'proposal.json')==p and read(existing/'review.json')==review,'Conflicting interrupted transaction')
   tx=read(existing/'transaction.json');require(sha(existing/'graph.json')==tx['graph_sha256'],'Interrupted graph changed')
   require(head is None or head['graph_sha256']==p['base_graph_sha256'],'Stale interrupted transaction')
   write(store/'HEAD.json',{'run_id':p['run_id'],'graph_sha256':tx['graph_sha256'],'previous':head,'status':'APPLIED'})
   return {'status':'APPLIED','path':str(existing/'graph.json'),'recovered':True}
  require(head is None or head['graph_sha256']==p['base_graph_sha256'],'Stale graph proposal')
  graph=copy.deepcopy(p['before_graph']);nodes=graph.get('nodes',[]);mapped={str(n.get('id',n.get('node_id'))):n for n in (nodes.values() if isinstance(nodes,dict) else nodes)}
  for op in p['operations']:
   n=mapped[str(op['node_id'])];require(n==op['before_node'],'Node precondition changed');n.clear();n.update(op['after_node']);n['identity_review']=review
  changed={str(x['node_id']) for x in p['operations']}
  for edge in graph.get('edges',[]):
   if str(edge.get('source')) in changed or str(edge.get('target')) in changed:
    edge['update_validity']='STALE_REQUIRES_RECOMPUTATION' if edge.get('kind') in ['spatial','geometric'] else 'PRESERVED_UNVERIFIED'
  temp=Path(tempfile.mkdtemp(prefix='.pending-',dir=store));write(temp/'before_graph.json',p['before_graph']);write(temp/'graph.json',graph);write(temp/'review.json',review);write(temp/'proposal.json',p);write(temp/'transaction.json',{'graph_sha256':sha(temp/'graph.json'),'base_graph_sha256':p['base_graph_sha256']})
  for f in temp.iterdir():
   with f.open('rb') as stream:os.fsync(stream.fileno())
  dest=store/p['run_id'];os.replace(temp,dest);write(store/'HEAD.json',{'run_id':p['run_id'],'graph_sha256':sha(dest/'graph.json'),'previous':head,'status':'APPLIED'})
 return {'status':'APPLIED','path':str(dest/'graph.json'),'original_preserved':True}

def rollback(store,run_id):
 store=Path(store)
 with (store/'lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX);head=read(store/'HEAD.json');require(head['run_id']==run_id,'Only current head can be rolled back')
  before=store/run_id/'before_graph.json';write(store/'HEAD.json',{'run_id':run_id+':rollback','graph_sha256':sha(before),'path':str(before),'previous':head,'status':'ROLLED_BACK'});return {'status':'ROLLED_BACK','path':str(before)}
