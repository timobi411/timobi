import os
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[name]='1'
import argparse,json
from pathlib import Path
from .core import *

def main():
 p=argparse.ArgumentParser(description='YLM organized-to-scene-graph diagnostic integration');sub=p.add_subparsers(dest='command',required=True)
 r=sub.add_parser('run');r.add_argument('--config',required=True);r.add_argument('--out',required=True);r.add_argument('--resume',action='store_true');r.add_argument('--additional-pairs',type=int)
 r=sub.add_parser('integrate-history');r.add_argument('--history',required=True);r.add_argument('--config',required=True);r.add_argument('--reference',type=int,required=True);r.add_argument('--out',required=True);r.add_argument('--rows',type=int,default=32)
 r=sub.add_parser('verify');r.add_argument('run')
 r=sub.add_parser('inspect');r.add_argument('--config',required=True)
 r=sub.add_parser('apply');r.add_argument('--run',required=True);r.add_argument('--review',required=True);r.add_argument('--store',required=True)
 r=sub.add_parser('rollback');r.add_argument('--store',required=True);r.add_argument('--run-id',required=True)
 a=p.parse_args()
 if a.command=='run':
  from .pipeline import run
  if a.additional_pairs is not None:require(a.additional_pairs>0,'Positive additional pair budget required')
  result=run(a.config,a.out,a.resume,a.additional_pairs);print(json.dumps(result,ensure_ascii=False,indent=2));return 0 if result['status']=='COMPLETE' else 2
 if a.command=='integrate-history':
  from .temporal import integrate_history
  result=integrate_history(a.history,a.config,a.reference,a.out,a.rows)
 elif a.command=='verify':
  from .pipeline import verify
  result=verify(a.run)
 elif a.command=='inspect':
  from .config import resolve
  from .observation import load_observation,input_paths
  c=resolve(read(a.config));base=Path(a.config).resolve().parent;observations=[load_observation(o,base) for o in c['observations']];result={'status':'INPUT_VALID','observations':[{'id':o['metadata']['observation_id'],'shape':o['arrays']['valid'].shape,'valid':int(o['arrays']['valid'].sum())} for o in observations],'input_hashes':{str(p):sha(p) for p in input_paths(c,base)}}
 elif a.command=='apply':
  from .graph import apply
  result=apply(a.run,a.review,a.store)
 else:
  from .graph import rollback
  result=rollback(a.store,a.run_id)
 print(json.dumps(result,ensure_ascii=False,indent=2));return 0
if __name__=='__main__':
 try:raise SystemExit(main())
 except (ValueError,OSError,KeyError) as e:print(json.dumps({'status':'ERROR','reason':str(e)},ensure_ascii=False));raise SystemExit(1)
