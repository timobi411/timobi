"""Explicit supplied furniture model evidence; never infer semantic labels."""
import numpy as np
from scipy.spatial import cKDTree
from .core import *

def assess(candidate,points,models,base):
 fits=[]
 for item in models:
  model=read(base/item['path']);require(all(k in model for k in ['model_id','version','extent_min_m','extent_max_m','parts','points','model_to_common','evaluation_distance_m']),'Model requires geometry, version, parts, verified placement and evaluation distance')
  raw=np.asarray(model['points'],float);require(raw.ndim==2 and raw.shape[1]==3 and len(raw)>0 and np.isfinite(raw).all(),'Invalid object model geometry');placed=transform(raw,matrix(model['model_to_common']));r=float(model['evaluation_distance_m']);require(r>0,'Invalid model evaluation distance');dist,_=cKDTree(placed).query(points,workers=1);inside=dist<=r;support=[]
  for part in model['parts']:
   ids=np.asarray(part['point_indices']);require(np.issubdtype(ids.dtype,np.integer) and np.all((ids>=0)&(ids<len(raw))),'Invalid model part indices');d,_=cKDTree(points).query(placed[ids],workers=1);support.append({'part_id':part['part_id'],'coverage':float(np.mean(d<=r)) if len(ids) else None,'point_count':len(ids)})
  ext=np.asarray(candidate['obb']['extent']);fits.append({'model_id':model['model_id'],'version':model['version'],'model_sha256':sha(base/item['path']),'dimension_pass':bool(np.all(ext>=model['extent_min_m']) and np.all(ext<=model['extent_max_m'])),'fit_residual_m':float(np.sqrt(np.mean(dist[inside]**2))) if inside.any() else None,'candidate_coverage':float(inside.mean()),'support_parts':support,'evaluation_distance_m':r,'relative_layout':'EVALUATED_IN_ONE_SUPPLIED_MODEL_POSE','pose_status':model.get('pose_status','UNVERIFIED'),'status':'ADDITIONAL_EVIDENCE_NOT_IDENTITY'})
 return {'status':'SUPPLIED_MODEL_EVIDENCE','fits':fits,'semantic_class':'UNKNOWN'}
