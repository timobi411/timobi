"""Explicit original-history entry point using the supplied frozen v04 rules."""
from pathlib import Path
from .core import *

def integrate_history(history,config,reference,out,rows=32):
 from ylm_integrated_clustering_v04._vendor.common_v02.temporal import integrate
 from ylm_integrated_clustering_v04._vendor.common_v02.audit import validate_provenance
 from ylm_integrated_clustering_v04._vendor.common_v02.io import validate_history
 a=load(history);c=read(config);c=c.get('front_end',c);require(0<=reference<len(a['valid']),'Reference sample outside history');require(rows>0,'Positive row block required');validate_history(a,c,rows)
 out=Path(out);out.mkdir(parents=True,exist_ok=False);before={str(Path(p).resolve()):sha(p) for p in [history,config]}
 stats,obs,legacy,modes,gates=integrate(a,reference,c,out,rows);validate_provenance(a,obs)
 npz(out/'missing_classification.npz',**{k:v for k,v in stats.items() if k.startswith('invalid_reason_')},missing_current=~a['valid'][reference],representative_valid=obs['valid'])
 write(out/'input_manifest.json',before);write(out/'resolved_config.json',c);write(out/'environment.json',environment());write(out/'run_manifest.json',{'stage':'FROZEN_V04_TEMPORAL','reference_sample':reference,'input_sha256':before,'source_hashes':sources(),'synthetic_points_created':0,'units':'m','status':'COMPLETE','temporal_gates':gates});require(all(sha(p)==h for p,h in before.items()),'History input mutated')
 return {'status':'COMPLETE','observation':str(out/'integrated_observation.npz'),'valid_pixels':int(obs['valid'].sum())}
