"""Two-best bounded set packing with unmatched option on both observations."""
from .core import *

def assign(pairs,candidates,c,complete,budget):
 lookup={x['candidate_key']:x for x in candidates};eligible=[];reasons={}
 for p in pairs:
  if not p.get('valid') or p.get('candidate_status')!='ELIGIBLE':reasons[p['pair_id']]='INVALID_OR_HELD'
  elif p.get('utility',0)<=0:reasons[p['pair_id']]='UNMATCHED_UTILITY_PREFERRED'
  else:eligible.append(p)
 eligible.sort(key=lambda p:(-p['utility'],p['pair_id']));eligible_keys=[p['pair_id'] for p in eligible]
 def tokens(p):
  tok=set()
  for key in ['source_candidate_key','target_candidate_key']:
   x=lookup[p[key]];oid=x['observation_id'];tok|={(oid,'f',f) for f in x['fragment_keys']}|{(oid,'p',i) for i in x['pixel_ids']}
  return tok
 sets=[tokens(p) for p in eligible];suffix=[0.]*(len(eligible)+1)
 for i in range(len(eligible)-1,-1,-1):suffix[i]=suffix[i+1]+eligible[i]['utility']
 best=[];nodes=0;stopped=False;stop_reason=None;stack=[(0,0.,[],set())]
 def record(score,chosen):
  ids=tuple(sorted(eligible[i]['pair_id'] for i in chosen))
  if not any(x[1]==ids for x in best):best.append((float(score),ids));best.sort(key=lambda x:(-x[0],x[1]));del best[2:]
 record(0.,[])
 while stack:
  i,score,chosen,used=stack.pop();nodes+=1
  if nodes>c['max_nodes']:stopped=True;stop_reason='ASSIGNMENT_NODE_LIMIT';break
  if nodes%128==0:
   try:budget.check()
   except Stop as e:stopped=True;stop_reason=str(e);break
  record(score,chosen)
  if i==len(eligible) or len(best)==2 and score+suffix[i]<best[1][0]-1e-12:continue
  stack.append((i+1,score,chosen,used))
  if not used&sets[i]:stack.append((i+1,score+eligible[i]['utility'],chosen+[i],used|sets[i]))
 top=best[0];second=best[1] if len(best)>1 else None;margin=top[0]-second[0] if second else None
 unresolved=not complete or stopped or c['margin'] is None or second is not None and margin<=c['margin']
 chosen=set(top[1]);used=set.union(*(sets[eligible_keys.index(k)] for k in chosen)) if chosen else set()
 for p in eligible:
  key=p['pair_id'];reasons[key]='SELECTED' if key in chosen else 'CONFLICT_REJECTED' if tokens(p)&used else 'UNMATCHED'
 return {'method':'BOUNDED_BRANCH_AND_BOUND_SET_PACKING_TOP2','constraints':['source_shared_pixels','source_shared_fragments','target_shared_pixels','target_shared_fragments'],'unmatched_utility':0.,'selected':list(top[1]),'utility':top[0],'second':{'selected':list(second[1]),'utility':second[0]} if second else None,'utility_gap':margin,'margin_threshold':c['margin'],'status':'AMBIGUOUS' if unresolved else 'RESOLVED','optimality_proven':not stopped,'search_nodes':nodes,'stop_reason':stop_reason,'requested_pair_evaluation_complete':complete,'pair_status':reasons,'automatic_identity_confirmed':False}
