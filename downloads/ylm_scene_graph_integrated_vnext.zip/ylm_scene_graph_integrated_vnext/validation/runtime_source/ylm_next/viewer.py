"""Offline interactive material views; one trace point per observation pixel."""
import json
from pathlib import Path
import numpy as np
from plotly.offline import get_plotlyjs
from .core import write,clean,digest

def color(key):return '#'+digest(key)[:6]
def render(out,observations,stages,pairs,assignment,c):
 payload={'observations':[],'candidates':{},'pairs':{},'assignment':assignment,'display':c['display'],'frame':c['frame']['status'],'gravity':c['gravity']['status']};palette={}
 for obs,stage in zip(observations,stages):
  a=obs['arrays'];ids=np.flatnonzero(a['valid']);oid=obs['metadata']['observation_id'];labels=stage['labels']['final'].ravel()[ids]
  payload['observations'].append({'id':oid,'pixel_ids':ids.tolist(),'points':a['xyz'].reshape(-1,3)[ids].tolist(),'source_type':a['source_type'].ravel()[ids].tolist(),'labels':labels.tolist(),'structure':a['structure_mask'].ravel()[ids].tolist(),'fragments':stage['fragments']})
  for lab in np.unique(labels):palette[oid+':'+str(lab)]=color(oid+':'+str(lab)) if lab>=0 else '#888888'
  for candidate in stage['candidates']:payload['candidates'][candidate['candidate_key']]=candidate
 for p in pairs:payload['pairs'][p['pair_id']]={k:v for k,v in p.items() if k!='hypotheses'}
 for p in pairs:palette[p['pair_id']]=color(p['pair_id'])
 payload['palette']=palette;write(out/'palette.json',palette)
 html='''<!doctype html><html lang="ja"><meta charset="utf-8"><title>YLM vNext 診断資料</title><style>body{font:14px sans-serif;margin:16px;background:#f8fafc}button,select{margin:5px;padding:6px}#plot{height:75vh}pre{max-height:22vh;overflow:auto} .hold{color:#a12424}</style><h2>YLM vNext — 観測・候補・登録・更新案</h2><p class="hold">座標: <span id="frame"></span> ／ 開発比較値。手動統合・曖昧対応は自動成功ではありません。</p><label>表示 <select id="view"><option value="both">観測位置の全体対応図</option><option value="t0">T0＋OBB</option><option value="t1">T1＋OBB</option><option value="registered">登録後重ね合わせ（選択sourceのみ変換）</option></select></label><label>候補案 <select id="plan"><option value="best">案1</option><option value="second">案2</option></select></label><label>枠 <select id="boxes"><option value="parts">元部品OBB</option><option value="composite">選択候補全体OBB</option><option value="none">なし</option></select></label><label>構造 <select id="structure"><option value="after">除去後</option><option value="before">除去前</option></select></label><label>黒線の根拠 <select id="arrows"><option value="icp">ICP基準中心の推定移動</option><option value="centers">観測中心間の対応線（移動量・軌跡ではない）</option><option value="none">なし</option></select></label><p>全点は観測ごとに1回・同じサイズと不透明度で描画。採用対応は同色、未対応は別色。T0枠＝実線、T1枠＝破線。灰色＝断片ラベル対象外（未認識・棚との結合を意味しません）。AABB代替はホバーに明記。</p><div id="plot"></div><pre id="audit"></pre><script>__PLOTLY__</script><script>const D=__DATA__;
const $=id=>document.getElementById(id),apply=(p,t)=>[0,1,2].map(i=>t[i][3]+p.reduce((v,x,j)=>v+t[i][j]*x,0));
$('frame').textContent=D.frame+' / 重力 '+D.gravity;
const all=D.observations.flatMap(o=>o.points);const ranges=[0,1,2].map(i=>{let v=all.map(p=>p[i]);let lo=Math.min(...v),hi=Math.max(...v);return [lo-.3,hi+.3]});
for(const p of Object.values(D.pairs)){if(!p.transform_source_to_target)continue;const a=D.candidates[p.source_candidate_key].obb.vertices;for(const x of a){const v=apply(x,p.transform_source_to_target);for(let i=0;i<3;i++){ranges[i][0]=Math.min(ranges[i][0],v[i]-.3);ranges[i][1]=Math.max(ranges[i][1],v[i]+.3)}}}
let camera={eye:{x:1.5,y:-1.5,z:1.1}};window.YLM_AUDIT={};
function selected(){return ($('plan').value==='best'?D.assignment.selected:(D.assignment.second?.selected||[])).map(k=>D.pairs[k])}
function draw(){const traces=[],sel=selected(),view=$('view').value,drawn=[];let transformed=0;
D.observations.forEach((o,index)=>{if(view==='t0'&&index===1||view==='t1'&&index===0)return;
 const assigned={},transforms={},candidateNames={};for(const cand of Object.values(D.candidates)){if(cand.observation_id!==o.id)continue;for(const id of cand.pixel_ids)(candidateNames[id]??=[]).push(cand.candidate_key)}
 for(const pair of sel){const key=index===0?pair.source_candidate_key:pair.target_candidate_key;const cand=D.candidates[key];for(const id of cand.pixel_ids){assigned[id]=pair.pair_id;if(index===0&&view==='registered')transforms[id]=pair.transform_source_to_target}}
 const points=[],colors=[],hover=[];o.points.forEach((p,k)=>{if($('structure').value==='after'&&o.structure[k])return;const id=o.pixel_ids[k];let q=p;if(transforms[id]){q=apply(p,transforms[id]);transformed++}points.push(q);colors.push(assigned[id]?D.palette[assigned[id]]:D.palette[o.id+':'+o.labels[k]]);hover.push([o.id,id,o.labels[k],o.source_type[k],(candidateNames[id]||[]).join('<br>'),assigned[id]?D.pairs[assigned[id]].identity_status:'UNMATCHED',...p].join(' | '));drawn.push(o.id+':'+id)});
 traces.push({type:'scatter3d',mode:'markers',x:points.map(p=>p[0]),y:points.map(p=>p[1]),z:points.map(p=>p[2]),marker:{size:D.display.point_size,opacity:D.display.opacity,color:colors},text:hover,hovertemplate:'%{text}<br>表示XYZ: %{x}, %{y}, %{z}<extra></extra>',name:o.id});
 let boxes=$('boxes').value==='parts'?o.fragments: $('boxes').value==='composite'?sel.map(p=>D.candidates[index===0?p.source_candidate_key:p.target_candidate_key]):[];
 for(const item of boxes){if(item.point_count<D.display.obb_min_points)continue;const ids=item.pixel_ids;const linked=sel.find(p=>D.candidates[index===0?p.source_candidate_key:p.target_candidate_key].fragment_keys.some(k=>(item.fragment_keys||[item.fragment_key]).includes(k)));const t=view==='registered'&&index===0&&linked?linked.transform_source_to_target:null;const vertices=item.obb.vertices.map(p=>t?apply(p,t):p),x=[],y=[],z=[];for(let i=0;i<8;i++)for(let j=i+1;j<8;j++){let bit=i^j;if([1,2,4].includes(bit)){x.push(vertices[i][0],vertices[j][0],null);y.push(vertices[i][1],vertices[j][1],null);z.push(vertices[i][2],vertices[j][2],null)}}
 traces.push({type:'scatter3d',mode:'lines',x,y,z,line:{color:linked?D.palette[linked.pair_id]:'#555',width:2,dash:index===0?'solid':'dash'},text:(item.origin||'FRAGMENT')+' '+item.obb.method+' '+(item.candidate_key||item.fragment_key),hovertemplate:'%{text}<extra></extra>',showlegend:false})}
});
if($('arrows').value!=='none'&&view==='both')for(const p of sel){const a=D.candidates[p.source_candidate_key].obb.center,b=$('arrows').value==='icp'?apply(a,p.transform_source_to_target):D.candidates[p.target_candidate_key].obb.center;const d=b.map((x,i)=>x-a[i]);traces.push({type:'scatter3d',mode:'lines',x:[a[0],b[0]],y:[a[1],b[1]],z:[a[2],b[2]],line:{color:'black',width:5},name:$('arrows').selectedOptions[0].text,showlegend:false});if(Math.hypot(...d)>1e-8)traces.push({type:'cone',x:[b[0]],y:[b[1]],z:[b[2]],u:[d[0]],v:[d[1]],w:[d[2]],anchor:'tip',sizemode:'absolute',sizeref:.08,colorscale:[[0,'black'],[1,'black']],showscale:false,showlegend:false})}
window.YLM_AUDIT={drawn:drawn.length,unique:new Set(drawn).size,transformed,selected:sel.map(p=>p.pair_id),manual:sel.filter(p=>p.manual_origin).length,frame:D.frame};
$('audit').textContent=JSON.stringify({display:window.YLM_AUDIT,assignment:D.assignment.status,utility_gap:D.assignment.utility_gap,selected:sel.map(p=>({pair_id:p.pair_id,manual:p.manual_origin,motion:p.motion,valid:p.valid,gates:p.gates}))},null,2);
Plotly.react('plot',traces,{uirevision:'shared',scene:{xaxis:{range:ranges[0],title:'X [m]'},yaxis:{range:ranges[1],title:'Y [m]'},zaxis:{range:ranges[2],title:'Z [m]'},aspectmode:'data',camera},margin:{l:0,r:0,t:20,b:0}},{responsive:true,displaylogo:false});}
for(const id of ['view','plan','boxes','structure','arrows'])$(id).onchange=draw;draw();$('plot').on('plotly_relayout',ev=>{if(ev['scene.camera'])camera=ev['scene.camera']});
</script></html>'''
 html=html.replace('__PLOTLY__',get_plotlyjs()).replace('__DATA__',json.dumps(clean(payload),ensure_ascii=False,allow_nan=False).replace('</','<\\/'))
 (Path(out)/'index.html').write_text(html)
