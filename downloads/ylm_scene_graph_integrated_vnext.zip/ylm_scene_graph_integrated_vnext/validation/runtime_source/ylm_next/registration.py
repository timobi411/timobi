import numpy as np
from scipy.spatial import cKDTree
from .core import *
from ylm06.registration import icp,preprocess,initializations

def support(a,b,t,r):
 if not len(a) or not len(b):return {'fitness':None,'rmse_m':None,'source_coverage':None,'target_coverage':None,'correspondences':0,'reason':'EMPTY_INPUT'}
 moved=transform(a,t);ds,si=cKDTree(b).query(moved,workers=1);dt,ti=cKDTree(moved).query(b,workers=1);ok=ds<=r;count=int(ok.sum())
 return {'fitness':count/len(a),'rmse_m':float(np.sqrt(np.mean(ds[ok]**2))) if count else None,'source_coverage':count/len(a),'target_coverage':float(np.mean(dt<=r)),'correspondences':count,'unique_target_correspondences':int(len(np.unique(si[ok]))),'evaluation_distance_m':r,'reason':None if count else 'NO_CORRESPONDENCE'}

def component_support(source,target,sa,ta,t,r):
 records={'source':[],'target':[]};all_a=sa[source['pixel_ids']];all_b=ta[target['pixel_ids']]
 for side,cand,xyz,other,tt in [('source',source,sa,all_b,t),('target',target,ta,all_a,np.linalg.inv(t))]:
  used=[]
  for key,ids in cand['parts'].items():
   moved=transform(xyz[ids],tt);dist,idx=cKDTree(other).query(moved,workers=1);ok=dist<=r;matches=set(idx[ok].tolist());overlap=sum(len(matches&old) for old in used);used.append(matches)
   records[side].append({'fragment_key':key,'points':len(ids),'supported_points':int(ok.sum()),'coverage':float(ok.mean()),'unique_opposite_points':len(matches),'opposite_indices':sorted(matches),'overlap_with_previous_parts':overlap,'one_to_one_part_identity_proven':False})
 return records

def evidence(source,target,m,t,parts,c,gravity,legacy_valid=None):
 sa,ta=source['obb'],target['obb'];extent=[float(np.linalg.norm(x['extent'])) for x in [sa,ta]];diag=min(extent)/max(extent) if max(extent)>0 else 0.;nr=min(source['point_count'],target['point_count'])/max(source['point_count'],target['point_count']);center=float(np.linalg.norm(np.array(sa['center'])-ta['center']));ref=np.asarray(sa['center']);dis=transform(ref[None],t)[0]-ref;axis=np.asarray(gravity['axis'],float);axis/=np.linalg.norm(axis);tilt=float(np.degrees(np.arccos(np.clip(axis@t[:3,:3]@axis,-1,1))));yaw=float(np.degrees(np.arctan2(t[1,0],t[0,0])));cov=min(m['source_coverage'],m['target_coverage']);partmin=min(x['coverage'] for side in parts.values() for x in side)
 values={'obb_center':center,'obb_size':diag,'assignment_size':[nr,diag],'shape':[cov,m['rmse_m']],'pose':tilt,'movement':float(np.linalg.norm(dis)),'part_support':partmin,'legacy_validity':legacy_valid}
 gates={}
 for name,g in c['gates'].items():
  v=values[name];th=g['threshold']
  if name in ['obb_center','pose','movement']:passed=v<=th
  elif name in ['obb_size','part_support']:passed=v>=th
  elif name=='assignment_size':passed=all(x>=y for x,y in zip(v,th))
  elif name=='shape':passed=v[0]>=th[0] and v[1] is not None and v[1]<=th[1]
  else:passed=legacy_valid
  gates[name]={'enabled':g['enabled'] and not(name=='legacy_validity' and legacy_valid is None),'pass':passed,'value':v,'threshold':th,'reason':'LEGACY_ROUTE_ONLY' if name=='legacy_validity' and legacy_valid is None else 'PASS' if passed else 'INSUFFICIENT_PART_SUPPORT' if name=='part_support' else 'FAILED_COMPARISON','calibration':'DEVELOPMENT_COMPARISON','axis_reference':'VERIFIED_GRAVITY' if gravity['status']=='VERIFIED' else 'UNVERIFIED_SENSOR_AXIS'}
 return gates,{'estimated_center_displacement_m':dis.tolist(),'estimated_center_movement_m':float(np.linalg.norm(dis)),'observed_center_difference_m':(np.asarray(ta['center'])-sa['center']).tolist(),'yaw_deg':yaw,'rotation_deg':float(np.degrees(np.arccos(np.clip((np.trace(t[:3,:3])-1)/2,-1,1)))),'axis_tilt_deg':tilt,'tilt_reference':'GRAVITY' if gravity['status']=='VERIFIED' else 'SENSOR_Z_AXIS_NOT_VERIFIED_GRAVITY'}

def register(source,target,sa,ta,c,budget):
 a=sa[source['pixel_ids']];b=ta[target['pixel_ids']];route=c['registration']['route'];pid='pair:'+digest([source['candidate_key'],target['candidate_key'],route])[:24]
 result={'pair_id':pid,'source_candidate_key':source['candidate_key'],'target_candidate_key':target['candidate_key'],'route':route,'evaluation_status':'INVALID_INPUT','valid':False,'transform_source_to_target':None,'identity_status':'HELD','motion_status':'UNKNOWN','hypotheses':[],'reason':None,'manual_origin':any(x['origin']=='MANUAL_COMPOSITE' for x in [source,target])}
 if not np.isfinite(a).all() or not np.isfinite(b).all():return {**result,'reason':'NONFINITE_INPUT'}
 if min(len(a),len(b))<3:return {**result,'evaluation_status':'DEGENERATE','reason':'FEWER_THAN_THREE_POINTS'}
 if min(np.linalg.matrix_rank(a-a.mean(0)),np.linalg.matrix_rank(b-b.mean(0)))<2:return {**result,'evaluation_status':'DEGENERATE','reason':'COLLINEAR_OR_COINCIDENT'}
 s={**c['registration'],'dof':'4DOF' if route=='diagnostic_4dof' else '6DOF','extra_rotations':[],'convergence_m':1e-7};legacy=None
 if route.startswith('diagnostic'):
  aa,_=preprocess(a,s);bb,_=preprocess(b,s);basis=np.eye(3)
  if min(len(aa),len(bb))<3:return {**result,'evaluation_status':'DEGENERATE','reason':'VOXEL_REDUCED_BELOW_THREE'}
  if route=='diagnostic_4dof':
   z=np.asarray(c['gravity']['axis'],float);z/=np.linalg.norm(z);x=np.cross([1,0,0] if abs(z[0])<.9 else [0,1,0],z);x/=np.linalg.norm(x);basis=np.column_stack([x,np.cross(z,x),z])
  ar,br=aa@basis,bb@basis;raw=[]
  for name,initial in initializations(ar,br,s):
   budget.check();t,steps,reason=icp(ar,br,initial,s,budget);tt=np.eye(4);tt[:3,:3]=basis@t[:3,:3]@basis.T;tt[:3,3]=basis@t[:3,3];ii=np.eye(4);ii[:3,:3]=basis@initial[:3,:3]@basis.T;ii[:3,3]=basis@initial[:3,3]
   raw.append({'initialization':name,'initial_transform':ii.tolist(),'transformation':tt.tolist(),'termination':reason,'iterations':steps})
  pre={'source_before':len(a),'target_before':len(b),'source_after':len(aa),'target_after':len(bb),'voxel_m':s['voxel_m'],'method':'DETERMINISTIC_FIRST_POINT_PER_VOXEL'}
 elif route=='recovered_local_6dof':
  from ylm06.compatibility import local_icp
  legacy,raw,pre=local_icp(a,b);pre.update(source_before=len(a),target_before=len(b))
  import open3d as o3d
  processed=[]
  for cloud_points in [a,b]:
   cloud=o3d.geometry.PointCloud();cloud.points=o3d.utility.Vector3dVector(cloud_points);processed.append(np.asarray(cloud.voxel_down_sample(pre.get('voxel_m',.01)).points))
  aa,bb=processed
  pre.update(source_after=len(aa),target_after=len(bb))
 else:
  from .frozen import b0_trials
  legacy,raw,pre,aa,bb=b0_trials(a,b,budget)
 fine=.08 if route in ['frozen_B0','recovered_local_6dof'] else s['fine_m'];trials=[]
 for n,h in enumerate(raw):
  budget.check();t=matrix(h['transformation']);m=support(aa,bb,t,fine);parts=component_support(source,target,sa,ta,t,fine);legacy_valid=None
  if route=='frozen_B0':legacy_valid=h['valid']
  elif route=='recovered_local_6dof':legacy_valid=bool(h['fitness']>0 and (h['score']>=.65 or max(h['t0_coverage'],h['t1_coverage'])>=.90 and h['rmse']<=.05) and h['icp_translation_m']<=1.2)
  g,motion=evidence(source,target,m,t,parts,c,c['gravity'],legacy_valid)
  numeric=m['correspondences']>=3 and m.get('unique_target_correspondences',0)>=3
  passed=numeric and all(v['pass'] for v in g.values() if v['enabled']);utility=min(m['source_coverage'],m['target_coverage'])-.75
  if c['assignment']['utility']=='legacy_score':
   require(route in ['frozen_B0','recovered_local_6dof'],'legacy_score requires compatibility route');utility=h.get('score',legacy['score'] if legacy else 0.)
  trials.append({'trial_id':pid+':'+str(n),'initial_transform':h['initial_transform'],'transform_source_to_target':t.tolist(),'initialization':h.get('initialization',h.get('start_yaw_deg',h.get('initial_yaw_deg'))),'metrics':m,'component_support':parts,'motion':motion,'gates':g,'pass':passed,'numeric_valid':numeric,'utility':float(utility),'score_formula_id':c['assignment']['utility'],'score_breakdown':{'minimum_coverage':min(m['source_coverage'],m['target_coverage']),'offset':.75} if c['assignment']['utility']=='minimum_coverage_minus_0.75' else {'legacy_score':utility},'legacy_trial':h if not route.startswith('diagnostic') else None})
 if not trials:return {**result,'evaluation_status':'DEGENERATE','reason':'NO_TRIALS'}
 pool=[h for h in trials if h['pass']] or trials;best=max(pool,key=lambda h:(h['utility'],-trials.index(h)));result.update(evaluation_status='EVALUATED' if best['metrics']['correspondences'] else 'NO_CORRESPONDENCE',valid=best['pass'],transform_source_to_target=best['transform_source_to_target'],selected_trial_id=best['trial_id'],selection_reason='PASSING_TRIALS_FIRST_THEN_UTILITY',hypotheses=trials,metrics=best['metrics'],gates=best['gates'],motion=best['motion'],component_support=best['component_support'],utility=best['utility'],score_formula_id=best['score_formula_id'],score_breakdown=best['score_breakdown'],preprocessing=pre,legacy_result=legacy,reason=None if best['pass'] else 'NO_PASSING_TRIAL')
 # Raw legacy winner remains unchanged alongside gated diagnostic winner.
 result['candidate_status']='ELIGIBLE' if best['pass'] else 'HELD'
 boundary_hold=any(x['boundary_state'] in ['HELD_DEPTH_BOUNDARY','UNRESOLVED_INSUFFICIENT_BOUNDARY_SUPPORT'] for x in [source,target])
 if boundary_hold:result.update(candidate_status='HELD',reason='COMPOSITE_BOUNDARY_UNRESOLVED')
 return result
