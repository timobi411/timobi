"""Auditable legacy gate factorial comparison, separate from graph adoption."""
import copy
import itertools
import json
from pathlib import Path
import shutil
import subprocess
import sys

import numpy as np

from .compatibility import gate_defaults, gate_evidence, local_icp, frozen_module, ROOT
from .util import read, write, sha, require

ASSIGNMENTS = {
    'current': 'pipeline_current/assign_changes_hungarian_gated.py',
    'frozen_B0': 'pipeline_phase2_downstream_frozen_20260929/baseline_assignment_B0.py',
}

WRAPPER = '''
import importlib.util,json,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('legacy_assignment',sys.argv[1])
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
if sys.argv[2]=='OFF':m.MIN_POINT_RATIO=0.;m.MIN_DIAG_RATIO=0.
Path('effective_settings.json').write_text(json.dumps({k:v for k,v in vars(m).items() if k.isupper() and isinstance(v,(int,float,str,list))},indent=2))
m.main()
'''


def resolve_cloud(root, row, side):
    original = Path(row['pcd'])
    candidates = [root / original] if not original.is_absolute() else [original]
    candidates += [root / (side + '_clouds') / original.name,
                   root / (side + '_clouds') / ('cloud_%04d.pcd' % int(row['merged_id']))]
    found = next((p.resolve() for p in candidates if p.is_file()), None)
    require(found is not None, 'Missing PCD; specify original exp folder or bundled legacy_inputs: ' + str(original))
    return found


def compare(inputs, output, pair_results=None, inject=None, obb_size=False, max_pairs=32):
    """Run both assignments at identical pair data over 2x2 gate settings.

    --pair-results replays a saved bank. --inject is explicitly manual diagnosis.
    Omitted pairs remain unassessed, not physically rejected.
    """
    import open3d as o3d
    root, out = Path(inputs).resolve(), Path(output).resolve()
    require(not out.exists(), 'Output must be new')
    require(type(max_pairs) is int and max_pairs > 0, 'Positive detailed pair limit required')
    out.mkdir(parents=True)
    snapshot = out / 'input_snapshot'
    snapshot.mkdir()
    metas, clouds, inventory = {}, {}, []
    for side in ('t0', 't1'):
        path = root / (side + '_merged_clusters.json')
        metas[side] = copy.deepcopy(read(path))
        inventory.append({'source': str(path), 'sha256': sha(path)})
        require(len({int(r['merged_id']) for r in metas[side]}) == len(metas[side]), 'Duplicate merged ID')
        for row in metas[side]:
            pcd = resolve_cloud(root, row, side)
            dest = snapshot / (side + '_M' + str(row['merged_id']) + '.pcd')
            shutil.copyfile(pcd, dest)
            points = np.asarray(o3d.io.read_point_cloud(str(dest)).points)
            points = points[np.isfinite(points).all(axis=1)]
            clouds[side, int(row['merged_id'])] = points
            inventory.append({'source': str(pcd), 'snapshot': str(dest.relative_to(out)), 'sha256': sha(dest)})
            row['pcd'] = str(dest)
        write(snapshot / (side + '_merged_clusters.json'), metas[side])
    # Preserve raw-presence/visibility inputs when supplied; absence is explicit.
    auxiliary = list(root.glob('*_occlusion_data.npz')) + [root / (side + '_temporal_median.pcd') for side in ('t0', 't1')]
    aux = []
    for p in auxiliary:
        if p.is_file():
            shutil.copyfile(p, snapshot / p.name)
            aux.append(p.name)
            inventory.append({'source': str(p), 'snapshot': 'input_snapshot/' + p.name, 'sha256': sha(p)})
    plan = list(itertools.product(metas['t0'], metas['t1']))
    gates = gate_defaults()
    gates['obb_size_gate'] = obb_size
    records, hypotheses = [], []
    if pair_results:
        records = copy.deepcopy(read(pair_results))
        require(isinstance(records, list), 'Saved pair results must be a list')
        inventory.append({'source': str(Path(pair_results).resolve()), 'sha256': sha(pair_results)})
    else:
        details = 0
        for a, b in plan:
            aid, bid = int(a['merged_id']), int(b['merged_id'])
            pre = gate_evidence(a, b, None, gates)
            if any(k in pre['rejected_by'] for k in ('obb_center', 'obb_size')):
                hypotheses.append({'t0_id': aid, 't1_id': bid, 'status': 'EXCLUDED_BY_PROFILE', 'gates': pre})
                continue
            if details >= max_pairs:
                hypotheses.append({'t0_id': aid, 't1_id': bid, 'status': 'NOT_EVALUATED_BUDGET'})
                continue
            result, hs, preprocessing = local_icp(clouds['t0', aid], clouds['t1', bid])
            details += 1
            hypotheses.append({'t0_id': aid, 't1_id': bid, 'status': 'EVALUATED' if result else 'INVALID_INPUT',
                               'hypotheses': hs, 'preprocessing': preprocessing, 'gates': pre})
            if result:
                result.update(t0_id=aid, t1_id=bid)
                records.append(result)
    if inject:
        injection = read(inject)
        require(set(injection) >= {'t0_id', 't1_id', 'result'}, 'Injection needs explicit IDs and result')
        row = copy.deepcopy(injection['result'])
        row.update(t0_id=injection['t0_id'], t1_id=injection['t1_id'])
        require(all(k in row for k in ('score','fitness','rmse','t0_coverage','t1_coverage','icp_translation_m','yaw_deg')), 'Incomplete manual pair')
        records = [r for r in records if (r['t0_id'], r['t1_id']) != (row['t0_id'], row['t1_id'])] + [row]
        inventory.append({'source': str(Path(inject).resolve()), 'sha256': sha(inject)})
    require(len({(r['t0_id'], r['t1_id']) for r in records}) == len(records), 'Duplicate pair records')
    write(out / 'pair_bank.json', records)
    write(out / 'registration_audit.json', hypotheses)
    write(out / 'input_inventory.json', inventory)
    lookup0 = {int(r['merged_id']): r for r in metas['t0']}
    lookup1 = {int(r['merged_id']): r for r in metas['t1']}
    runner = frozen_module('pipeline_current/run_scene_graph_pipeline.py', 'recovered_runner')
    summaries = []
    for version, size, shape in itertools.product(ASSIGNMENTS, (True, False), (True, False)):
        name = version + '_size_' + ('on' if size else 'off') + '_shape_' + ('on' if shape else 'off')
        folder = out / name
        folder.mkdir()
        for side in ('t0', 't1'):
            shutil.copyfile(snapshot / (side + '_merged_clusters.json'), folder / (side + '_merged_clusters.json'))
        for n in aux:
            shutil.copyfile(snapshot / n, folder / n)
        profile = dict(gates, assignment_size_gate=size, shape_gate=shape)
        bank = copy.deepcopy(records)
        # Saved pair banks can contain pairs excluded by the OBB gate; log and filter
        # them explicitly instead of silently bypassing candidate enumeration.
        excluded = []
        if pair_results:
            filtered = []
            for r in bank:
                evidence = gate_evidence(lookup0[r['t0_id']], lookup1[r['t1_id']], None, profile)
                if any(k in evidence['rejected_by'] for k in ('obb_center', 'obb_size')):
                    excluded.append({'t0_id': r['t0_id'], 't1_id': r['t1_id'], 'gates': evidence})
                else:
                    filtered.append(r)
            bank = filtered
        write(folder / 'candidate_exclusions.json', excluded)
        write(folder / 'gate_evidence.json', [dict(t0_id=r['t0_id'], t1_id=r['t1_id'],
            evidence=gate_evidence(lookup0[r['t0_id']], lookup1[r['t1_id']], r, profile)) for r in bank])
        write(folder / 'partial_icp_results.json', bank)
        if shape:
            # This mutates only the new trial copy, exactly as the historical runner.
            import contextlib
            with (folder / 'shape_gate.log').open('w') as log, contextlib.redirect_stdout(log):
                runner.apply_moved_shape_gate(folder, profile['moved_translation_m'],
                    profile['min_bidirectional_coverage'], profile['max_shape_rmse_m'])
        shutil.copyfile(folder / 'partial_icp_results.json', folder / 'partial_icp_results_fixed_repro.json')
        script = ROOT / ASSIGNMENTS[version]
        frozen_module(ASSIGNMENTS[version], 'verified_assignment_source')
        missing_aux = [side + '*_occlusion_data.npz' for side in ('t0','t1') if not list(folder.glob(side + '*_occlusion_data.npz'))] if version == 'frozen_B0' else []
        with (folder / 'assignment.log').open('w') as log:
            try:
                if missing_aux:
                    log.write('BLOCKED_MISSING_INPUT: ' + ', '.join(missing_aux))
                    code = 'BLOCKED_MISSING_INPUT'
                else:
                    process = subprocess.run([sys.executable, '-c', WRAPPER, str(script), 'ON' if size else 'OFF'],
                                             cwd=folder, stdout=log, stderr=subprocess.STDOUT, timeout=300)
                    code = process.returncode
            except subprocess.TimeoutExpired:
                code = 'TIMEOUT'
        result_name = 'hungarian_assignment_results.json' if version == 'current' else 'hungarian_assignment_fixed_repro.json'
        assignment = read(folder / result_name) if code == 0 else {}
        summary = {'trial': name, 'status': 'COMPLETED' if code == 0 else ('BLOCKED_MISSING_INPUT' if missing_aux else 'FAILED'), 'returncode': code,
            'missing_inputs': missing_aux, 'gate_profile': profile, 'base_pair_bank_sha256': sha(out / 'pair_bank.json'),
            'effective_assignment_input_sha256': sha(folder / 'partial_icp_results.json'),
            'matched': assignment.get('matched', []), 'output': str((folder / result_name).relative_to(out)),
            'source_sha256': sha(script), 'graph_modified': False}
        summaries.append(summary)
        write(folder / 'trial_summary.json', summary)
    complete = not any(r.get('status') == 'NOT_EVALUATED_BUDGET' for r in hypotheses)
    result = {'version': '0.6.1', 'scope': 'LEGACY_DIAGNOSTIC_FACTORIAL_COMPARISON',
        'solver': 'RECOVERED_LOCAL_6DOF' if not pair_results else 'SAVED_PAIR_BANK_REPLAY',
        'manual_pair_injection': bool(inject), 'inputs': str(root), 'auxiliary_inputs_copied': aux,
        'raw_visibility_inputs_missing': [n for n in ('t0_temporal_median.pcd','t1_temporal_median.pcd') if n not in aux],
        'pair_evaluation_complete': complete if not pair_results else None,
        'all_trials_completed': all(s['status'] == 'COMPLETED' for s in summaries),
        'trials': summaries, 'identity_accuracy': 'NOT_EVALUATED', 'graph_modified': False,
        'originals_modified': False, 'physical_identity_confirmed': False}
    write(out / 'comparison.json', result)
    from .compat_viewer import render
    render(out, result, metas, clouds)
    return {'out': str(out), 'all_trials_completed': result['all_trials_completed'],
            'completed_trials': sum(s['status'] == 'COMPLETED' for s in summaries),
            'blocked_trials': sum(s['status'] == 'BLOCKED_MISSING_INPUT' for s in summaries),
            'partial': not result['all_trials_completed'] or (not pair_results and not complete),
            'graph_modified': False}
