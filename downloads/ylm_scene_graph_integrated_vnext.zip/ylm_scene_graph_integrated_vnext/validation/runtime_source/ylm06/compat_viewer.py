"""Self-contained comparison of original observed positions and ICP overlays."""
import json
from pathlib import Path
import numpy as np
from plotly.offline import get_plotlyjs


def render(out, result, metas, clouds):
    payload = {'comparison': result, 'clouds': {side + ':' + str(mid): pts.tolist()
        for (side, mid), pts in clouds.items()}}
    data = json.dumps(payload, ensure_ascii=False, allow_nan=False).replace('<', '\\u003c')
    page = '''<!doctype html><meta charset="utf-8"><title>旧ICP互換・ゲート比較</title>
<style>body{font:15px sans-serif;margin:20px}#plot{height:75vh}select{max-width:90%;margin:6px}pre{white-space:pre-wrap}</style>
<h2>旧ICP互換・ゲート比較</h2><p>T0＝青／T1＝赤。旧方式の moved は診断結果です。同一物体の正解確認・実グラフ更新は行っていません。</p>
<label>比較条件<select id="trial"></select></label><label>表示<select id="pair"></select></label>
<label><input id="align" type="checkbox">ICP変換後のT0を紫で重ねる</label>
<div id="plot"></div><pre id="detail"></pre><script>__PLOTLY__</script><script>
const d=__DATA__,ts=document.getElementById('trial'),ps=document.getElementById('pair'),al=document.getElementById('align');
d.comparison.trials.forEach((t,i)=>ts.add(new Option(t.trial,i)));
function trace(p,name,color,opacity=1){return {type:'scatter3d',mode:'markers',x:p.map(x=>x[0]),y:p.map(x=>x[1]),z:p.map(x=>x[2]),name,marker:{size:3,color,opacity}}}
function select(){ps.replaceChildren();ps.add(new Option('全体：旧割当の全対応','all'));const t=d.comparison.trials[ts.value];t.matched.forEach((r,i)=>ps.add(new Option('M'+r.t0_id+' → M'+r.t1_id+' : '+r.state,i)));draw()}
function draw(){const t=d.comparison.trials[ts.value],rows=ps.value==='all'?t.matched:[t.matched[Number(ps.value)]],tr=[];
if(ps.value==='all'){for(const side of ['t0','t1']){let pts=[];for(const [key,p]of Object.entries(d.clouds))if(key.startsWith(side+':'))pts.push(...p);tr.push(trace(pts,side+' 全体',side==='t0'?'blue':'red',.16))}}
const bank=d.bank||[];for(const r of rows){if(!r)continue;let a=d.clouds['t0:'+r.t0_id],b=d.clouds['t1:'+r.t1_id];tr.push(trace(a,'T0 M'+r.t0_id,'blue'),trace(b,'T1 M'+r.t1_id,'red'));let raw=bank.find(x=>x.t0_id===r.t0_id&&x.t1_id===r.t1_id);if(al.checked&&raw&&raw.transformation){let T=raw.transformation,p=a.map(x=>T.slice(0,3).map(row=>row[0]*x[0]+row[1]*x[1]+row[2]*x[2]+row[3]));tr.push(trace(p,'ICP後 T0 M'+r.t0_id,'purple'))}}
Plotly.react('plot',tr,{scene:{aspectmode:'data',uirevision:'same-camera'},uirevision:'same-camera',margin:{t:10,b:10,l:0,r:0}});document.getElementById('detail').textContent=JSON.stringify({trial:t.trial,gate_profile:t.gate_profile,matched:rows,identity_accuracy:'NOT_EVALUATED',graph_modified:false},null,2)}ts.onchange=select;ps.onchange=draw;al.onchange=draw;select();
</script>'''
    from .util import read
    payload['bank'] = read(Path(out) / 'pair_bank.json')
    data = json.dumps(payload, ensure_ascii=False, allow_nan=False).replace('<', '\\u003c')
    (Path(out) / 'index.html').write_text(page.replace('__PLOTLY__', get_plotlyjs()).replace('__DATA__', data), encoding='utf-8')
