"""Create a separate compatibility config; original assets remain hashed/read-only."""
import copy
from pathlib import Path
from .util import read, write, require, sha
from .compatibility import gate_defaults


def prepare(source, output):
    source, output = Path(source).resolve(), Path(output).resolve()
    require(source != output and not output.exists(), 'Use a new output config path')
    c = copy.deepcopy(read(source))
    # Only config asset references are relocated. Embedded upstream contracts remain
    # relative to their own manifest directories, as enforced by contracts.load().
    def relocate(value):
        if isinstance(value, dict):
            for key, child in value.items():
                if key in ('path', 'graph_path') and isinstance(child, str):
                    value[key] = str((source.parent / child).resolve())
                else:
                    relocate(child)
        elif isinstance(value, list):
            for child in value: relocate(child)
    relocate(c)
    c['allowed_roots'] = list(dict.fromkeys([str(source.parent)] +
        [str((source.parent / r).resolve()) for r in c.get('allowed_roots', [])]))
    c['run_id'] += ':legacy-local6-compat'
    c['profiles']['solver'].update(mode='LEGACY_LOCAL_6DOF_COMPAT', dof='6DOF', voxel_m=.01,
        coarse_m=.35, fine_m=.08, iterations=150, yaw_degrees=[-30,-20,-10,0,10,20,30], extra_rotations=[])
    c['resources']['initializations'] = max(7, c['resources']['initializations'])
    c['compatibility'] = gate_defaults()
    write(output, c)
    return {'config': str(output), 'source_config_sha256': sha(source),
        'original_config_modified': False, 'asset_references': 'absolute; original files required',
        'default_gates': c['compatibility'], 'graph_modified': False}
