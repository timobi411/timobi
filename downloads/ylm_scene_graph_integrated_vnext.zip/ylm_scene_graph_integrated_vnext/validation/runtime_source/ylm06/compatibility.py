"""Recovered exp02 local ICP and explicit legacy gate contracts.

Compatibility decisions are regression evidence, never persistent identity evidence.
"""
import importlib.util
import json
import math
from pathlib import Path
import time

import numpy as np

from .util import require, sha, read, write, transformed

ROOT = Path(__file__).parent / 'vendor' / 'recovered'
LOCAL = 'exp02/test_m1_m1_local_icp.py'


def frozen_module(relative, name):
    path = ROOT / relative
    expected = read(ROOT / 'source_hashes.json')[relative]
    require(sha(path) == expected, 'Recovered source hash mismatch: ' + relative)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def gate_defaults():
    return {'obb_size_gate': False, 'assignment_size_gate': True, 'shape_gate': True,
            'max_obb_center_distance_m': 1.50, 'min_obb_diag_ratio': 0.45,
            'min_assignment_point_ratio': 0.20, 'min_assignment_diag_ratio': 0.55,
            'moved_translation_m': 0.30, 'min_bidirectional_coverage': 0.75,
            'max_shape_rmse_m': 0.030, 'min_match_score': 0.65,
            'min_partial_coverage': 0.90, 'max_partial_rmse_m': 0.05,
            'max_icp_movement_m': 1.20}


def validate_gates(profile):
    require(set(profile) == set(gate_defaults()), 'All legacy gate fields must be explicit')
    for key, value in profile.items():
        if key.endswith('_gate'):
            require(type(value) is bool, 'Gate switch must be boolean: ' + key)
        else:
            require(type(value) in (int, float) and math.isfinite(value) and value >= 0,
                    'Invalid legacy gate threshold: ' + key)
    for key in ('min_obb_diag_ratio', 'min_assignment_point_ratio',
                'min_assignment_diag_ratio', 'min_bidirectional_coverage', 'min_partial_coverage'):
        require(profile[key] <= 1, 'Invalid fraction: ' + key)
    return profile


def metadata(points):
    """Open3D OBB for new candidates; never relabel it historical metadata."""
    import open3d as o3d
    p = np.asarray(points, float)
    cloud = o3d.geometry.PointCloud()
    cloud.points = o3d.utility.Vector3dVector(p)
    try:
        box = cloud.get_oriented_bounding_box()
        center, extent = np.asarray(box.center), np.asarray(box.extent)
        basis = 'OPEN3D_OBB_RECOMPUTED_FROM_CURRENT_INPUT'
    except RuntimeError:
        center = (p.min(0) + p.max(0)) / 2
        extent = np.ptp(p, axis=0)
        basis = 'DEGENERATE_AABB_FALLBACK_DIAGNOSTIC'
    return {'center': center.tolist(), 'extent': extent.tolist(), 'points': len(p), 'basis': basis}


def gate_evidence(source, target, result, profile):
    validate_gates(profile)
    d0, d1 = [float(np.linalg.norm(m['extent'])) for m in (source, target)]
    diag = min(d0, d1) / max(d0, d1) if min(d0, d1) > 1e-9 else 0.
    n0, n1 = [int(m['points']) for m in (source, target)]
    ratio = min(n0, n1) / max(n0, n1) if min(n0, n1) > 0 else 0.
    center = float(np.linalg.norm(np.asarray(target['center']) - source['center']))
    stages = {
        'obb_center': {'enabled': True, 'pass': center <= profile['max_obb_center_distance_m'],
                       'value': center, 'maximum': profile['max_obb_center_distance_m']},
        'obb_size': {'enabled': profile['obb_size_gate'], 'pass': diag >= profile['min_obb_diag_ratio'],
                     'value': diag, 'minimum': profile['min_obb_diag_ratio']},
        'assignment_size': {'enabled': profile['assignment_size_gate'],
                            'pass': ratio >= profile['min_assignment_point_ratio'] and diag >= profile['min_assignment_diag_ratio'],
                            'point_ratio': ratio, 'diag_ratio': diag,
                            'minimum_point_ratio': profile['min_assignment_point_ratio'],
                            'minimum_diag_ratio': profile['min_assignment_diag_ratio']},
    }
    if result is not None:
        movement = result['icp_translation_m']
        cov = min(result['t0_coverage'], result['t1_coverage'])
        stages['moved_shape'] = {'enabled': profile['shape_gate'] and movement >= profile['moved_translation_m'],
                                 'pass': cov >= profile['min_bidirectional_coverage'] and result['rmse'] <= profile['max_shape_rmse_m'],
                                 'min_coverage': cov, 'rmse_m': result['rmse'],
                                 'minimum_coverage': profile['min_bidirectional_coverage'],
                                 'maximum_rmse_m': profile['max_shape_rmse_m']}
        stages['legacy_icp_validity'] = {'enabled': True, 'pass': bool(result['fitness'] > 0 and
            (result['score'] >= profile['min_match_score'] or
             max(result['t0_coverage'], result['t1_coverage']) >= profile['min_partial_coverage'] and
             result['rmse'] <= profile['max_partial_rmse_m']) and movement <= profile['max_icp_movement_m']),
            'meaning': 'legacy score/partial-match and movement criteria; not physical identity'}
    rejected = [key for key, stage in stages.items() if stage['enabled'] and not stage['pass']]
    return {'stages': stages, 'rejected_by': rejected, 'pass': not rejected,
            'geometry_metadata': {'source': source, 'target': target}, 'profile': profile}


def local_icp(source, target):
    """Same Open3D calls/order/criteria/scoring as recovered local main()."""
    import open3d as o3d
    m = frozen_module(LOCAL, 'recovered_local_icp')
    arrays = [np.asarray(x, dtype=float) for x in (source, target)]
    require(all(p.ndim == 2 and p.shape[1] == 3 and np.isfinite(p).all() for p in arrays), 'Invalid compatibility points')
    clouds = []
    for p in arrays:
        cloud = o3d.geometry.PointCloud()
        cloud.points = o3d.utility.Vector3dVector(p)
        clouds.append(cloud.voxel_down_sample(m.VOXEL))
    a, b = clouds
    p0, p1 = np.asarray(a.points), np.asarray(b.points)
    if min(len(p0), len(p1)) < 3:
        return None, [], {'source': len(p0), 'target': len(p1)}
    c0 = p0.mean(axis=0)
    criteria = o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=m.MAX_ITER)
    hypotheses = []
    for yaw in m.YAW_CANDIDATES:
        start = time.monotonic()
        initial = m.rotation_about_center(c0, yaw)
        coarse = o3d.pipelines.registration.registration_icp(
            a, b, m.COARSE_DISTANCE, initial,
            o3d.pipelines.registration.TransformationEstimationPointToPoint(), criteria)
        fine = o3d.pipelines.registration.registration_icp(
            a, b, m.FINE_DISTANCE, coarse.transformation,
            o3d.pipelines.registration.TransformationEstimationPointToPoint(), criteria)
        cova, covb = m.coverage(a, b, fine.transformation, m.FINE_DISTANCE)
        score = .45 * max(cova, covb) + .25 * fine.fitness + .30 * max(0., 1. - fine.inlier_rmse / m.FINE_DISTANCE)
        movement = float(np.linalg.norm(m.transform_center(c0, fine.transformation) - c0))
        hypotheses.append({'start_yaw_deg': yaw, 'score': float(score), 'fitness': float(fine.fitness),
            'rmse': float(fine.inlier_rmse), 't0_coverage': cova, 't1_coverage': covb,
            'partial_coverage': max(cova, covb), 'icp_translation_m': movement,
            'yaw_deg': float(m.yaw_from_transform(fine.transformation)),
            'transformation': fine.transformation.tolist(), 'initial_transform': initial.tolist(),
            'elapsed_seconds': time.monotonic() - start})
    # Strict greater-than reproduces old initial-yaw tie order.
    best = max(hypotheses, key=lambda h: h['score']).copy()
    best.update(normal_match=best['score'] >= .65,
                partial_match=best['partial_coverage'] >= .90 and best['rmse'] <= .05 and best['fitness'] > 0,
                movement_ok=best['icp_translation_m'] <= 1.20)
    best['valid'] = (best['normal_match'] or best['partial_match']) and best['movement_ok']
    best['numerically_supported'] = best['fitness'] > 0
    return best, hypotheses, {'source': len(p0), 'target': len(p1), 'voxel_m': m.VOXEL,
                              'basis': 'OPEN3D_VOXEL_CENTROIDS_NO_EXTRA_SUBSAMPLING_NO_HOLDOUT',
                              'open3d_version': o3d.__version__, 'source_sha256': sha(ROOT / LOCAL)}


def register_compat(source, target, context, gates=None, budget=None):
    """Isolated worker; old valid/moved never bypass integrated identity contracts."""
    import os
    import subprocess
    import sys
    import tempfile
    from .util import BudgetStop
    gates = validate_gates(gates or gate_defaults())
    if context['initialization_limit'] < 7:
        raise BudgetStop('Recovered local ICP requires all 7 initializations')
    with tempfile.TemporaryDirectory(prefix='ylm-local6-') as directory:
        root = Path(directory)
        np.save(root / 'source.npy', source, allow_pickle=False)
        np.save(root / 'target.npy', target, allow_pickle=False)
        write(root / 'gates.json', gates)
        timeout = max(.01, budget.config['wall_seconds'] - budget.stats()['wall_seconds']) if budget else 1800
        process = subprocess.Popen([sys.executable, '-m', 'ylm06.compatibility', '--worker', str(root)],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            env=dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1'))
        start = time.monotonic()
        try:
            while True:
                try:
                    stdout, stderr = process.communicate(timeout=.1)
                    break
                except subprocess.TimeoutExpired:
                    if time.monotonic() - start > timeout:
                        raise BudgetStop('Recovered local ICP wall budget')
                    if budget:
                        budget.check()
                        try:
                            rss = next(float(line.split()[1]) / 1024 for line in
                                (Path('/proc') / str(process.pid) / 'status').read_text().splitlines()
                                if line.startswith('VmRSS:'))
                            if rss >= budget.config['rss_mib']:
                                raise BudgetStop('Recovered local ICP RSS budget')
                        except (FileNotFoundError, StopIteration):
                            pass
            require(process.returncode == 0, 'Recovered local ICP subprocess failed: ' + stderr[-1800:])
            response = read(root / 'result.json')
        except BaseException:
            process.kill()
            process.communicate()
            raise
    legacy = response['best']
    hypotheses = response['hypotheses']
    for i, h in enumerate(hypotheses):
        h['hypothesis_id'] = context['pair_id'] + ':local6:' + str(i)
        h['pose_adoption'] = 'HELD_COMPATIBILITY_ONLY'
    result = {'evaluation_status': 'EVALUATED', 'identity_status': 'UNRESOLVED',
        'motion_status': 'UNKNOWN_MOTION', 'observation_status': 'UNKNOWN',
        'integration_validity': 'NOT_EVALUATED', 'initialization_complete': True,
        'selected_hypothesis_id': None, 'frame_status': context['frame_status'],
        'legacy_result': legacy, 'legacy_valid': None if legacy is None else legacy['valid'],
        'legacy_score': None if legacy is None else legacy['score'],
        'transformation': None if legacy is None else legacy['transformation'],
        'reasons': ['RECOVERED_LOCAL_6DOF_COMPATIBILITY_DIAGNOSTIC_ONLY'],
        'compatibility_gates': response['gates'], 'compatibility_preprocessing': response['preprocessing'],
        'input_maps': {'source_indices': list(range(len(source))), 'target_indices': list(range(len(target)))}}
    if legacy is None:
        result['evaluation_status'] = 'EXCLUDED_BY_PROFILE' if response['preprocessing'].get('basis') == 'EXCLUDED_BEFORE_ICP' else 'INVALID_INPUT'
        result['reasons'] += ['LEGACY_GATE:' + stage for stage in response['gates']['rejected_by']]
    if legacy:
        gate = response['gates']
        legacy_eligible = legacy['valid'] and legacy['numerically_supported'] and gate['pass']
        result['legacy_gate_eligible'] = legacy_eligible
        result['legacy_motion_status'] = ('MOVED' if legacy['icp_translation_m'] >= gates['moved_translation_m'] else 'STATIC') if legacy_eligible else 'HELD'
        result['selected_hypothesis_id'] = next(h['hypothesis_id'] for h in hypotheses if h['start_yaw_deg'] == legacy['start_yaw_deg'])
        reference = np.asarray(context['reference_point'])
        delta = transformed(reference[None], legacy['transformation'])[0] - reference
        result['model_reference_displacement_m'] = delta.tolist()
        result['displacement_m'] = float(np.linalg.norm(delta))
        result['metric_definitions'] = {'legacy_movement': 'voxelized source mean displacement',
                                        'displacement_m': 'declared model reference displacement'}
        result['reasons'] += ['LEGACY_GATE:' + stage for stage in gate['rejected_by']]
    return result, hypotheses


def worker(root):
    root = Path(root)
    a, b = [np.load(root / (key + '.npy'), allow_pickle=False) for key in ('source', 'target')]
    profile = read(root / 'gates.json')
    if min(len(a), len(b)) < 3:
        write(root / 'result.json', {'best': None, 'hypotheses': [], 'preprocessing': {'basis': 'INSUFFICIENT_POINTS'}, 'gates': {'rejected_by': ['INSUFFICIENT_POINTS'], 'pass': False}})
        return
    source, target = metadata(a), metadata(b)
    pre = gate_evidence(source, target, None, profile)
    if any(k in pre['rejected_by'] for k in ('obb_center', 'obb_size')):
        best, hypotheses, preprocessing = None, [], {'basis': 'EXCLUDED_BEFORE_ICP'}
    else:
        best, hypotheses, preprocessing = local_icp(a, b)
    write(root / 'result.json', {'best': best, 'hypotheses': hypotheses,
        'preprocessing': preprocessing, 'gates': gate_evidence(source, target, best, profile)})


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--worker', required=True)
    worker(parser.parse_args().worker)
