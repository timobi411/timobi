from pathlib import Path
import os,json,hashlib,time
import numpy as np
from . import SCHEMA
from ._vendor.occlusion_v01.common import clean,sha_array

def read(p):return json.loads(Path(p).read_text(encoding='utf8'),parse_constant=lambda s:(_ for _ in ()).throw(ValueError('Nonfinite JSON '+s)))
def write(p,obj):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.partial');tmp.write_text(json.dumps(clean(obj),ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n',encoding='utf8');os.replace(tmp,p)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def object_sha(x):return hashlib.sha256(json.dumps(clean(x),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def files_hashes(p):
 p=Path(p);return {str(q.resolve()):sha(q) for q in ([p] if p.is_file() else sorted(q for q in p.rglob('*') if q.is_file()))}
def npz(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def save_npz(p,**a):
 if any(np.asarray(v).dtype.hasobject for v in a.values()):raise ValueError('Object dtype prohibited')
 p=Path(p);tmp=p.with_name(p.name+'.partial')
 with tmp.open('wb') as f:np.savez_compressed(f,**a)
 os.replace(tmp,p)
def utc():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def directory_bytes(root):
 seen=set();total=0
 for p in Path(root).rglob('*'):
  if not p.is_file():continue
  st=p.stat();key=(st.st_dev,st.st_ino)
  if key not in seen:total+=st.st_size;seen.add(key)
 return total
def resolve(p,base):return (Path(base)/Path(p).expanduser()).resolve() if not Path(p).expanduser().is_absolute() else Path(p).expanduser().resolve()
def check_private_imports():
 import sys
 root=Path(__file__).resolve().parent
 wrong={k:str(v.__file__) for k,v in sys.modules.items() if k.startswith('ylm_integrated_clustering_v04.') and getattr(v,'__file__',None) and not Path(v.__file__).resolve().is_relative_to(root)}
 if wrong:raise ImportError('Mixed private module origins: '+str(wrong))
 return {'private_root':str(root),'mixed_private_modules':wrong,'bare_legacy_modules_ignored':[k for k in ('ylm_common','ylm_fragment','ylm_organized','ylm_occlusion') if k in sys.modules]}
