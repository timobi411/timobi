"""Single message traversal per bag, bounded spooling, shared immutable acquisition."""
import shutil
from .util import *
from ._vendor.common_v02.io import allocate,finish_store,open_store,unpack_history,validate_history,raw_frame
from ._vendor.organized_v01.input import bag_messages,metadata

def input_location(case):
 p=Path(case['input']['path']);kind=case['input']['kind']
 if not p.exists():raise FileNotFoundError(p)
 if kind=='v02_case':
  m=read(p/'input_manifest.json');history=next((p/x for x in ('raw_history','source_history','fixed11/history','all/history') if (p/x/'manifest.json').exists()),None)
  if history is None:raise ValueError('No saved history in '+str(p))
  hm=read(history/'manifest.json');complete=bool(m.get('complete_acquisition',False)) if history.name=='raw_history' else bool(hm.get('complete_acquisition',False))
  return history,complete
 if kind=='organized_v01':return p/'history.npz',False
 return p,kind=='bag' or bool(case['input'].get('complete_acquisition',False))
def signature(case):
 c=case['front_end'];return object_sha({k:c[k] for k in ('topic','storage_id','acquisition','validity','intensity','snr')})
def registry(c):
 items={};locations={};bindings={}
 for case in c['cases']:
  p,complete=input_location(case);loc=str(p.resolve());sig=signature(case)
  if loc in locations and locations[loc]!=sig:raise ValueError('Same input has incompatible decoding settings: '+loc)
  locations[loc]=sig;key=object_sha({'path':loc,'decoding':sig})[:16]
  if key in items and items[key]['complete_acquisition']!=complete:raise ValueError('Conflicting acquisition completeness')
  items.setdefault(key,{'input_id':key,'path':loc,'kind':'bag' if case['input']['kind']=='bag' else 'history','complete_acquisition':complete,'decoding_signature':sig,'front_end':case['front_end'],'cases':[]})['cases'].append(case['name']);bindings[case['name']]=key
 return items,bindings

def stream_bag(path,c,folder,resources,message_source=None):
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=False);spool=folder/'spool';spool.mkdir();budget=int(resources['disk_budget_gib']*1024**3)
 frames=[];chunks=[];buffer=[];nbytes=0;schema=None;imeta=None;before=files_hashes(path)
 def flush():
  nonlocal buffer
  if not buffer:return
  chunk=spool/str(len(chunks));chunk.mkdir()
  for k in buffer[0]:np.save(chunk/(k+'.npy'),np.stack([x[k] for x in buffer]),allow_pickle=False)
  chunks.append((chunk,len(buffer)));buffer=[]
 source=message_source if message_source is not None else bag_messages
 for i,stamp,msg in source(path,c):
  if i!=len(frames):raise ValueError('Nonsequential message index')
  if len(frames)>=resources['max_frames']:raise MemoryError('max_frames exceeded')
  m=metadata(msg,stamp,i,c);a,im=raw_frame(msg,c);now={k:(v.shape,v.dtype.str) for k,v in a.items()}
  if schema is None:schema=now;imeta=im
  if now!=schema or im!=imeta:raise ValueError('Raw PointField schema changed')
  if frames:
   if any(m[k]!=frames[0][k] for k in ('layout_id','frame_id','acquisition_setting_id')):raise ValueError('Acquisition layout/frame/settings changed')
   if any(m[k]<=frames[-1][k] for k in ('bag_time_ns','header_time_ns')):raise ValueError('Nonincreasing acquisition time')
  frame_bytes=sum(v.nbytes for v in a.values());nbytes+=frame_bytes
  if frame_bytes*(resources['spool_frames']+2)>resources['max_working_mb']*1024**2/2:raise MemoryError('Spool working set exceeds budget')
  if 2*nbytes>budget:raise MemoryError('Spooling/history disk budget exceeded')
  frames.append(m);buffer.append(a)
  if len(buffer)>=resources['spool_frames']:flush()
 flush()
 if not frames:raise ValueError('No target PointCloud2 messages')
 f=len(frames);h,w=frames[0]['height'],frames[0]['width'];arrays={}
 for k,(shape,dtype) in schema.items():
  arrays[k]=allocate(folder,k,(f,)+shape,dtype);pos=0
  for chunk,n in chunks:
   part=np.load(chunk/(k+'.npy'),mmap_mode='r',allow_pickle=False);arrays[k][pos:pos+n]=part;pos+=n
  arrays[k].flush()
 vals={'frame_index':np.arange(f,dtype=np.int64),'bag_time_ns':np.array([m['bag_time_ns'] for m in frames],np.int64),'header_time_ns':np.array([m['header_time_ns'] for m in frames],np.int64),'frame_id':np.array([m['frame_id'] for m in frames]),'layout_id':np.array([m['layout_id'] for m in frames]),'setting_id':np.array([m['acquisition_setting_id'] for m in frames]),'pixel_row':np.indices((h,w))[0],'pixel_column':np.indices((h,w))[1]}
 for k,v in vals.items():arrays[k]=allocate(folder,k,v.shape,v.dtype);arrays[k][...]=v
 shutil.rmtree(spool)
 if before!=files_hashes(path):raise ValueError('Bag bytes changed during extraction')
 write(folder/'frame_metadata.json',{'frames':frames,'layout_changed':False,'errors':[],'message_scan_count':1})
 meta=finish_store(folder,arrays,received_frame_count=f,complete_acquisition=True,intensity=imeta,source_hashes=before,message_scan_count=1,source_hash_file_sweeps=2)
 validate_history(arrays,c,resources['rows_per_chunk']);return arrays,meta

def acquire(job,out,resources):
 out=Path(out);out.mkdir(parents=True,exist_ok=False);p=Path(job['path']);c=job['front_end']
 if job['kind']=='bag':a,m=stream_bag(p,c,out/'history',resources)
 else:
  before=files_hashes(p);a=unpack_history(p,out/'history',int(resources['disk_budget_gib']*1024**3))
  if before!=files_hashes(p):raise ValueError('History source changed during import')
  m=finish_store(out/'history',a,source_hashes=before,complete_acquisition=job['complete_acquisition'],received_frame_count=len(a['frame_index']) if job['complete_acquisition'] else None,message_scan_count=0,source_hash_file_sweeps=2)
 report={'status':'READY','input_id':job['input_id'],'kind':job['kind'],'source_path':str(p),'cases':job['cases'],'schema':validate_history(a,c,resources['rows_per_chunk']),'source_hashes':m['source_hashes'],'complete_acquisition':m['complete_acquisition'],'received_frame_count':m['received_frame_count'],'message_scan_count':m['message_scan_count'],'source_hash_file_sweeps':2,'decoding_signature':job['decoding_signature'],'storage_bytes':directory_bytes(out),'raw_absence_not_reconstructed':True}
 write(out/'acquisition.json',report);return report
