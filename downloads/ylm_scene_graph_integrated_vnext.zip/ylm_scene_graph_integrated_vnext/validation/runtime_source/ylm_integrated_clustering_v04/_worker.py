import sys,traceback,threading,resource,time,os
from .util import *
from ._vendor.common_v02.runner import enforce_budget

def main():
 job=read(sys.argv[1]);out=Path(job['out']);report=Path(sys.argv[1]).with_suffix('.resources.json');stop=threading.Event();guard={}
 def sample():
  rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024
  rec={'peak_rss_mib':rss,'rss_source':'getrusage_self_ru_maxrss','guard':guard,'rss_poll_seconds':.2,'resource_failure':'RSS_LIMIT' if rss>job['resources']['max_working_mb'] else None}
  write(report,rec)
  if rec['resource_failure']:os._exit(75)
 def monitor():
  while not stop.wait(.2):sample()
 try:
  guard=enforce_budget(job['resources']['max_working_mb']);sample();thread=threading.Thread(target=monitor,daemon=True);thread.start();check_private_imports()
  if job['kind']=='ingest':
   from .ingest import acquire
   acquire(job['item'],out,job['resources'])
  elif job['kind']=='case':
   from .pipeline import process
   process(job['case'],job['config'],out,job['cache'])
  else:raise ValueError('Unknown internal job')
 except Exception as e:
  out.mkdir(parents=True,exist_ok=True);write(out/'failure.json',{'status':'FAILED_RESOURCE' if isinstance(e,(MemoryError,TimeoutError)) else 'FAILED_PROCESSING','error':type(e).__name__+': '+str(e),'traceback':traceback.format_exc()});traceback.print_exc();return 1
 finally:
  stop.set()
  if 'thread' in locals():thread.join(timeout=1)
  sample()
 return 0
if __name__=='__main__':raise SystemExit(main())
