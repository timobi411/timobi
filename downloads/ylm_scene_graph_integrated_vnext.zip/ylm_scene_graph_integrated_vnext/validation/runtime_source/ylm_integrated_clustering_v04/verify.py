"""Portable output integrity; external input coverage is separately reported."""
import gc,time,resource,zipfile
from .util import *
from ._vendor.fragment_v03.input import Input
from ._vendor.common_v02.io import open_store,validate_history
from ._vendor.common_v02.audit import validate_provenance,validate_source_modes

def verify(root,check_external=True):
 root=Path(root).resolve();m=read(root/'run_manifest.json');errors=[];external=[];checked=0;windows=set();npzs=0;jsons=0
 limits=m['resource_policy'];started=time.monotonic()
 def budget():
  if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024>limits['max_working_mb']:raise MemoryError('Verification RSS budget exceeded')
  if time.monotonic()-started>limits['max_case_seconds']:raise TimeoutError('Verification wall-time budget exceeded')
 def check(ok,message):
  if not ok:errors.append(message)
 for relative,digest in m.get('output_sha256',{}).items():
  p=(root/relative).resolve();check(p.is_relative_to(root) and p.is_file() and sha(p)==digest,'Output hash: '+relative);checked+=1
 check(sha(root/'config.json')==m['config_sha256'],'Config hash')
 for relative,digest in m['code_hashes'].items():check(sha(root/'code_snapshot'/relative)==digest,'Code snapshot '+relative)
 for p in root.rglob('*.json'):
  try:
   budget()
   if p.stat().st_size>limits['max_working_mb']*1024**2/4:raise MemoryError('JSON exceeds bounded verification size')
   read(p);jsons+=1
  except Exception as e:errors.append(str(p)+': '+str(e))
 for p in root.rglob('*.npz'):
  try:
   budget()
   with zipfile.ZipFile(p) as archive:
    if sum(v.file_size for v in archive.infolist())>limits['max_working_mb']*1024**2/2:raise MemoryError('NPZ decompressed verification size exceeds budget')
   with np.load(p,allow_pickle=False) as z:
    for key in z.files:check(not z[key].dtype.hasobject,'Object dtype '+str(p))
   npzs+=1
  except Exception as e:errors.append(str(p)+': '+str(e))
 bycase={}
 for item in m['conditions']:
  if item['status']!='COMPLETED_DIAGNOSTIC':continue
  p=root/item['output']
  try:
   budget()
   d=Input(p);contract=read(p/'stage_contract.json');tr=npz(p/'relations_v03/trial_pixel_correspondence.npz');fm=read(p/'relations_v03/run_manifest.json')
   check(d.label_hash==contract['label_sha256']==fm['label_sha256'],'Label contract '+str(p));check(d.lineage_valid,'Missing lineage')
   check(contract['immutable_window_manifest_sha256']==sha(d.input_run_manifest),'Window manifest changed')
   check(not np.any((tr['original_labels']<0)&(tr['trial_labels']>=0)),'Invented trial pixels')
   for k,v in d.a.items():check(np.array_equal(v,tr[k],equal_nan=True),'Measured correspondence changed '+k)
   check(np.array_equal(tr['labels'],tr['original_labels']),'Original labels changed')
   if fm['effective_mode']=='diagnostic_only':check(np.array_equal(tr['trial_labels'],tr['original_labels']),'Diagnostic-only trial labels changed')
   for rel,hsh in contract['source_hashes'].items():check(sha(p/rel)==hsh,'Stage contract source '+rel)
   if p.parent not in windows:
    windows.add(p.parent);a=d.history;validate_history(a,d.config);validate_provenance(a,npz(p.parent/'integrated_observation.npz'));validate_source_modes(a,d.modes['sample_mode'],npz(p.parent/'pixel_statistics.npz'),d.config)
    b,bm=open_store(p.parent/'measured');check(not b['target_valid'][d.reference].any(),'B reference included');wm=read(p.parent/'run_manifest.json');check(wm['reference_frame_index']==int(a['frame_index'][d.reference]),'Window reference mismatch');del b
   bycase.setdefault(item['case'],[]).append(item);del d,tr;gc.collect()
  except Exception as e:errors.append(str(p)+': '+type(e).__name__+': '+str(e))
 for name,items in bycase.items():
  check(len({(v['reference_frame_index'],v['reference_time_ns']) for v in items})==1,'Cross-window reference '+name)
  for window in {v['window'] for v in items}:check(len({v['B_classification_sha256'] for v in items if v['window']==window})==1,'Boundary-only B mismatch '+name+'/'+window)
 for key,acq in m['inputs'].items():
  if acq['status']!='READY':continue
  check(acq['message_scan_count']==(1 if acq['kind']=='bag' else 0),'Bag decoded more than once '+key)
  for p,digest in acq['source_hashes'].items():
   status='NOT_CHECKED_OFFLINE' if not check_external else 'MISSING_EXTERNAL_SOURCE' if not Path(p).exists() else 'MATCH' if sha(p)==digest else 'MISMATCH';external.append({'path':p,'status':status,'expected_sha256':digest})
   if status=='MISMATCH':errors.append('External source changed '+p)
 reg=read(root/'input_registry.json');check(len({x['path'] for x in reg['inputs'].values()})==len(reg['inputs']),'Duplicate acquisition entries')
 check(m['completed_conditions']==sum(x['status']=='COMPLETED_DIAGNOSTIC' for x in m['conditions']),'Completion denominator mismatch')
 r={'schema_version':SCHEMA,'status':'PASS' if not errors else 'FAIL','errors':errors,'json_files':jsons,'npz_files':npzs,'output_hashes_checked':checked,'external_source_checks':external,'external_sources_all_checked_and_matched':bool(external) and all(x['status']=='MATCH' for x in external),'completed_conditions':m['completed_conditions'],'expected_conditions':m['expected_conditions'],'processing_complete':m['completed_conditions']==m['expected_conditions'],'integrity_is_separate_from_completion_and_accuracy':True,'accuracy':None,'object_identity':'UNKNOWN'}
 write(root/'verification.json',r);return r
