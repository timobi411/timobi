from copy import deepcopy
import re
from .util import *
from ._vendor.organized_v01.config import load_config,validate as validate_front
from ._vendor.fragment_v03.common import default_config as fragment_default,validate_config as validate_fragment,effective_mode
from ._vendor.occlusion_v01.config import read as diagnostic_default

def default_config():
 return {'schema_version':SCHEMA,'cases':[],'windows':['fixed11','all'],'boundary_values':[True,False],
  'resources':{'max_working_mb':2048,'disk_budget_gib':20,'rows_per_chunk':8,'max_case_seconds':3600,'max_ingest_seconds':1800,'max_frames':10000,'spool_frames':8},
  'front_end':None,'occlusion':diagnostic_default(),'fragment':fragment_default(),
  'execution':{'continue_on_error':True,'workers':1,'verify_at_end':True},'display':{'max_points':30000},
  'scope':{'icp':False,'persistent_object_ids':False,'motion_classification':False,'scene_graph_update':False}}
def merge(dst,src,path=''):
 for k,v in src.items():
  if k not in dst:raise ValueError('Unknown setting '+path+k)
  if isinstance(dst[k],dict) and isinstance(v,dict):merge(dst[k],v,path+k+'.')
  else:dst[k]=v
 return dst
def load(path,base=None):
 c=merge(default_config(),read(path))
 if c['schema_version']!=SCHEMA:raise ValueError('Expected v0.4 configuration')
 names=[x['name'] for x in c['cases']]
 if not names or len(set(names))!=len(names) or any(not re.fullmatch('[A-Za-z0-9_-]+',n) for n in names):raise ValueError('Unique safe case names required')
 if not c['windows'] or len(set(c['windows']))!=len(c['windows']) or not set(c['windows'])<={'fixed11','all'}:raise ValueError('Invalid windows')
 c['windows']=[w for w in ('fixed11','all') if w in c['windows']]
 if not c['boundary_values'] or any(type(v)!=bool for v in c['boundary_values']) or len(set(c['boundary_values']))!=len(c['boundary_values']):raise ValueError('Distinct boolean boundaries required')
 if any(v is not False for v in c['scope'].values()):raise ValueError('ICP/identity/motion/scene graph update out of scope')
 if c['execution']['workers']!=1:raise ValueError('Sequential workers required')
 for k,v in c['resources'].items():
  if not isinstance(v,(int,float)) or isinstance(v,bool) or not np.isfinite(v) or v<=0:raise ValueError('Positive resource limit '+k)
 if c['resources']['max_working_mb']<256:raise ValueError('Minimum 256 MiB budget')
 for k in ('rows_per_chunk','max_frames','spool_frames'):
  if type(c['resources'][k])!=int:raise ValueError('Integer resource '+k)
 if not 1<=c['resources']['rows_per_chunk']<=256:raise ValueError('Chunk rows 1..256')
 if type(c['display']['max_points'])!=int or not 1<=c['display']['max_points']<=200000:raise ValueError('Display max_points 1..200000')
 c['fragment']['resources']['max_working_mb']=c['resources']['max_working_mb'];c['fragment']['resources']['max_condition_seconds']=c['resources']['max_case_seconds']
 validate_fragment(c['fragment']);c['fragment']['effective_mode'],c['fragment']['forced_mode_reasons']=effective_mode(c['fragment'])
 anchor=Path(base).expanduser().resolve() if base else Path(path).resolve().parent
 for item in c['cases']:
  spec=item['input'];kind=spec['kind'];spec['path']=str(resolve(spec['path'],anchor));p=Path(spec['path'])
  if kind not in ('bag','history','organized_v01','v02_case'):raise ValueError('Unknown input kind '+kind)
  for k in ('baseline_dir','structure_metadata','annotations_dir','config'):
   if item.get(k):item[k]=str(resolve(item[k],anchor))
  cp=item.get('config')
  if cp:front=load_config(cp)
  elif c['front_end'] is not None:front=deepcopy(c['front_end']);validate_front(front)
  elif kind=='v02_case':cp=p/'original_config.json';front=load_config(cp)
  elif kind=='organized_v01':cp=p/'config.json';front=load_config(cp)
  elif item.get('baseline_dir'):cp=Path(item['baseline_dir'])/'config.json';front=load_config(cp)
  else:raise ValueError('Provide front_end or per-case config for bag/history')
  front['intensity'].update(invalid_values=[],saturation_value=None,definition='Raw uncalibrated amplitude; zero retained; not an adoption feature')
  front['projection'].update(npz=None,verified=False,free_space_model_verified=False)
  front['evaluation']['dataset_role']=item.get('dataset_role','development');front['memory']['max_working_mb']=c['resources']['max_working_mb']
  for section,key in (('structure','mask_npz'),('evaluation','instance_labels_npz')):
   if front[section][key]:front[section][key]=str(resolve(front[section][key],anchor))
  validate_front(front);item['front_end']=front;item['front_config_source']=str(cp) if cp else 'inline'
 return c

def import_plan(plan_path,out,base=None):
 if Path(out).exists():raise FileExistsError(out)
 from ._vendor.common_v02.audit import relocate,resolve_source
 p=read(plan_path);c=default_config();anchor=Path(plan_path).resolve().parent
 for old in p['cases']:
  source=resolve_source(old,anchor,base);item={'name':old['name'],'dataset_role':old.get('dataset_role','development')};bag=relocate(old['bag'],base,anchor) if old.get('bag') else None
  if bag is None and source and (source/'run_manifest.json').exists():
   m=read(source/'run_manifest.json')
   if m.get('input_kind')=='bag':bag=relocate(m['input'],base,source)
  if bag and bag.exists():item['input']={'kind':'bag','path':str(bag)}
  elif old.get('history'):item['input']={'kind':'history','path':str(relocate(old['history'],base,anchor)),'complete_acquisition':bool(old.get('history_is_complete_acquisition',False))}
  elif source:item['input']={'kind':'organized_v01','path':str(source)}
  else:raise ValueError('Unresolved input '+old['name'])
  if source:item['baseline_dir']=str(source)
  for k in ('config','structure_metadata'):
   if old.get(k):item[k]=str(relocate(old[k],base,anchor))
  for k in ('reference_frame_index','fixed_frame_indices','expected_source_hashes'):
   if k in old:item[k]=old[k]
  c['cases'].append(item)
 for k in ('windows','boundary_values'):
  if k in p:c[k]=p[k]
 for k in ('rows_per_chunk','max_working_mb','disk_budget_gib'):
  if k in p:c['resources'][k]=p[k]
 if p.get('unresolved_cases'):raise ValueError('Resolve old plan cases first')
 write(out,c);return c
