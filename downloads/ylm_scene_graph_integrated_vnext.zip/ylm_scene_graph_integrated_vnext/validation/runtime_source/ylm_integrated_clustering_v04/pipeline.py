"""Native staged orchestration: immutable window contract and validated backend adapter."""
from copy import deepcopy
import gc,time
from .util import *
from ._vendor.common_v02.io import open_store,select_history,validate_history
from ._vendor.common_v02.audit import validate_provenance,validate_source_modes,source_audit
from ._vendor.common_v02.temporal import integrate
from ._vendor.common_v02.structure import evaluate_structure
from ._vendor.common_v02.relations import measured_diagnostic
from ._vendor.common_v02.runner import run_condition as front_condition
from ._vendor.common_v02.edges import compare_edges,partition_comparison
from ._vendor.occlusion_v01.config import resolve as resolve_diagnostic
from ._vendor.fragment_v03.input import Input
from ._vendor.fragment_v03.runner import run_condition as fragment_condition

def baseline(case,dest):
 kind=case['input']['kind'];p=Path(case['input']['path']);source=None;canonical=None;hashes={};audit={}
 if kind=='v02_case':source=p/'fixed11' if (p/'fixed11').exists() else p/'all'
 elif kind=='organized_v01':source=p
 elif case.get('baseline_dir'):source=Path(case['baseline_dir'])
 if source:
  files=['structure_mask.npz','structure_metadata.json','integrated_observation.npz','pixel_statistics.npz','sample_surface_modes.npz','surface_modes.npz']
  hashes={str((source/f).resolve()):sha(source/f) for f in files if (source/f).exists()};canonical=npz(source/'integrated_observation.npz')
  if kind=='v02_case':sa,_=open_store(source/'history');sm,_=open_store(source/'surface_mode_samples');modes=sm['sample_mode']
  else:
   sa=npz(source/'history.npz');modes=npz(source/'sample_surface_modes.npz')['sample_mode'];audit=source_audit(source,case['front_end'],expected=case.get('expected_source_hashes'));hashes.update({str((source/k).resolve()):v for k,v in audit['source_hashes'].items()})
  audit['mode_check']=validate_source_modes(sa,modes,npz(source/'pixel_statistics.npz'),case['front_end']);audit['point_provenance']=validate_provenance(sa,canonical)
  audit['reference_frame_index']=int(sa['frame_index'][int(sa['reference_sample_index'])]);audit['fixed_frame_indices']=sa['frame_index'].tolist()
 write(dest/'input_audit.json',{**audit,'source_hashes':hashes,'source_directory':str(source) if source else None})
 return source,canonical,audit,hashes

def adapter(path,case,window,boundary,resources):
 d=Input(path,max_mb=resources['max_working_mb']);inspection=d.summary()
 if not d.lineage_valid:raise ValueError('Measured sample lineage is mandatory')
 integ=npz(Path(path).parent/'integrated_observation.npz');validate_provenance(d.history,integ);valid=d.a['valid']
 for k in ('xyz','source_type','source_sample_index','source_frame_index','source_time_ns','source_header_time_ns'):
  if not np.array_equal(d.a[k][valid],integ[k][valid],equal_nan=True):raise ValueError('Stage contract mismatch: '+k)
 entry={'case':case,'window':window,'boundary':boundary,'path':str(Path(path).resolve()),'status':'READY',**inspection}
 contract={'schema_version':SCHEMA,'status':'PASS','label_sha256':d.label_hash,'coordinate_frame':d.frame_name,'sensor_origin_xyz':d.origin,'reference_frame_index':inspection['reference_frame_index'],'reference_time_ns':inspection['reference_time_ns'],'selected_frame_indices':d.history['frame_index'],'measured_lineage':True,'model_generated_points':0,'source_hashes':inspection['source_hashes'],'immutable_window_manifest_sha256':sha(d.input_run_manifest),'object_identity':'UNKNOWN','input_shape':d.shape,'raw_intensity_dtype':d.raw_dtype}
 write(Path(path)/'stage_contract.json',contract);return d,entry,contract

def saved_comparison(source,window,boundary,result,integ):
 old=source/window/boundary
 if not old.exists():return {'status':'NOT_AVAILABLE'}
 corr=npz(old/'pixel_correspondence.npz');oe=npz(old/'edges.npz');summary=read(old/'evaluation.json');comp=partition_comparison(corr['labels'],result['labels'])
 eq=comp['merge_count']==comp['split_count']==comp['old_only_labeled_pixels']==comp['new_only_labeled_pixels']==0
 same=all(np.array_equal(oe[k],result['edges'][k],equal_nan=True) for k in oe);xyz=np.array_equal(npz(old.parent/'integrated_observation.npz')['xyz'],integ['xyz'],equal_nan=True);b=summary['B_classification_sha256']==result['summary']['B_classification_sha256']
 return {'status':'PASS' if eq and same and xyz and b else 'DIFFERENCES','partition_equal':eq,'all_edge_arrays_equal':same,'integrated_xyz_equal':xyz,'B_content_identical':b,'pixel_partition_comparison':comp,'label_numbers_required_equal':False}

def process(case,c,out,cache):
 begin=time.monotonic();dest=Path(out);dest.mkdir(parents=True,exist_ok=False);cache=Path(cache);a,hm=open_store(cache/'history');acq=read(cache/'acquisition.json');front=deepcopy(case['front_end']);res=c['resources']
 source,canonical,audit,hashes=baseline(case,dest);f,h,w=a['valid'].shape;ref_frame=case.get('reference_frame_index',audit.get('reference_frame_index'))
 if ref_frame is None:ref_frame=int(a['frame_index'][int(a.get('reference_sample_index',f//2))])
 matches=np.flatnonzero(a['frame_index']==ref_frame)
 if len(matches)!=1:raise ValueError('Reference frame missing or duplicated')
 ref=int(matches[0]);fixed=case.get('fixed_frame_indices',audit.get('fixed_frame_indices'))
 if fixed is None:
  if ref<5 or ref+5>=f:raise ValueError('Eleven-frame baseline unavailable')
  fixed=a['frame_index'][ref-5:ref+6].tolist()
 index={int(v):i for i,v in enumerate(a['frame_index'])}
 if len(fixed)!=11 or len(set(fixed))!=11 or any(v not in index for v in fixed):raise ValueError('Exactly eleven existing baseline frames required')
 fixedids=[index[v] for v in fixed]
 if fixedids!=sorted(fixedids) or ref not in fixedids:raise ValueError('Invalid fixed frame order/reference')
 if source:
  sa=open_store(source/'history')[0] if case['input']['kind']=='v02_case' else npz(source/'history.npz')
  for j,fi in enumerate(sa['frame_index']):
   if int(fi) not in index:raise ValueError('Saved baseline frame absent from acquisition')
   k=index[int(fi)]
   if any(not np.array_equal(a[key][k],sa[key][j],equal_nan=True) for key in ('xyz','valid','bag_time_ns','header_time_ns')):raise ValueError('Saved baseline/acquisition mismatch')
  del sa
 write(dest/'input_manifest.json',{'schema_version':SCHEMA,'input_id':acq['input_id'],'cache':str(cache),'source_directory':str(source) if source else None,'raw_source':acq['source_path'],'raw_input_hashes':acq['source_hashes'],'reference_frame_index':ref_frame,'reference_time_ns':int(a['bag_time_ns'][ref]),'fixed_frame_indices':fixed,'received_frame_count':acq['received_frame_count'],'complete_acquisition':acq['complete_acquisition'],'source_schema':acq['schema'],'single_acquisition_shared':True})
 write(dest/'original_config.json',front);conditions=[];windows={};comparisons=[]
 for window in c['windows']:
  if window=='all' and not acq['complete_acquisition']:
   for bv in c['boundary_values']:conditions.append({'case':case['name'],'window':window,'boundary':'boundary_'+str(bv).lower(),'status':'NOT_RUN_MISSING_COMPLETE_HISTORY','reason':'Selected history cannot be relabeled as all received frames'})
   continue
  ids=fixedids if window=='fixed11' else list(range(f));wd=dest/window;wd.mkdir();aw,rw=select_history(a,ids,wd/'history',ref_frame)
  hmeta=read(wd/'history/manifest.json');hmeta.update(received_frame_count=acq['received_frame_count'],input_id=acq['input_id'],complete_acquisition=window=='all',intensity_field_name=front['intensity']['field'],intensity_raw_dtype=acq['schema']['raw_intensity_dtype']);write(wd/'history/manifest.json',hmeta);validate_history(aw,front,res['rows_per_chunk'])
  estimate=len(ids)*res['rows_per_chunk']*w*400+h*w*1600+128*1024**2
  if estimate>res['max_working_mb']*1024**2:raise MemoryError('Temporal working estimate exceeds budget; lower rows_per_chunk')
  print(case['name']+'/'+window+': history -> temporal -> structure',flush=True)
  stats,integ,legacy,modes,gates=integrate(aw,rw,front,wd,res['rows_per_chunk']);validate_provenance(aw,integ)
  if source is None and not case.get('structure_metadata') and front['structure']['mode']!='none':
   from ._vendor.organized_v01.clustering import load_frozen,structure_mask
   basis=dest/'structure_basis';basis.mkdir()
   if window!='fixed11':
    ba,br=select_history(a,fixedids,basis/'history',ref_frame);_,bi,bl,_,_=integrate(ba,br,front,basis,res['rows_per_chunk'])
   else:bi,bl=integ,legacy
   mod=load_frozen(front['legacy']['backend']) if front['structure']['mode']=='legacy_planes' else None;mask,meta=structure_mask(bl,bi,front,mod)
   save_npz(basis/'structure_mask.npz',structure_mask=mask);write(basis/'structure_metadata.json',meta);save_npz(basis/'integrated_observation.npz',**bi);source=basis;canonical=bi
  structure,sinfo=evaluate_structure(source,integ,canonical,front,Path(case['structure_metadata']) if case.get('structure_metadata') else None)
  save_npz(wd/'structure_mask.npz',**structure);write(wd/'structure_metadata.json',sinfo)
  diag=deepcopy(c['occlusion']);diag['evaluation']['dataset_role']=front['evaluation']['dataset_role'];measured,rays,bs=measured_diagnostic(aw,rw,stats,modes,front,resolve_diagnostic(diag,front),wd,res['rows_per_chunk'])
  write(wd/'run_manifest.json',{'schema_version':SCHEMA,'stage':'immutable_frontend_window','input_id':acq['input_id'],'coordinate_frame':str(aw['frame_id'][0]),'reference_frame_index':ref_frame,'reference_time_ns':int(aw['bag_time_ns'][rw]),'selected_frames':aw['frame_index'],'config_sha256':object_sha(front),'history_manifest_sha256':sha(wd/'history/manifest.json'),'integrated_observation_sha256':sha(wd/'integrated_observation.npz'),'structure_mask_sha256':sha(wd/'structure_mask.npz')})
  wr={}
  for bv in c['boundary_values']:
   boundary='boundary_'+str(bv).lower();cd=wd/boundary;cd.mkdir();bc=deepcopy(front);bc['clustering']['hold_boundary_points']=bv
   print(case['name']+'/'+window+'/'+boundary+': edges -> relations -> trial gates',flush=True)
   result=front_condition(aw,rw,stats,integ,modes,structure,bc,diag,measured,rays,cd)
   if case['input']['kind']=='v02_case':write(cd/'baseline_comparison.json',saved_comparison(Path(case['input']['path']),window,boundary,result,integ))
   d,entry,contract=adapter(cd,case['name'],window,boundary,res);ann=Path(case['annotations_dir'])/f"{case['name']}__{window}__{boundary}.json" if case.get('annotations_dir') else None
   fr=fragment_condition(entry,cd/'relations_v03',deepcopy(c['fragment']),ann if ann and ann.exists() else None,input_object=d)
   from .viewer import condition_view
   condition_view(cd,d,entry,c['display']['max_points'])
   item={'case':case['name'],'window':window,'boundary':boundary,'status':'COMPLETED_DIAGNOSTIC','output':str(cd.relative_to(dest.parent.parent)),'selected_frames':len(ids),'received_frames':acq['received_frame_count'],'reference_frame_index':ref_frame,'reference_time_ns':contract['reference_time_ns'],'B_classification_sha256':result['summary']['B_classification_sha256'],'valid_pixels':entry['valid_pixels'],'fragment_count':fr['fragment_count'],'candidate_count':fr['candidate_count'],'trial_group_count':fr['trial_group_count'],'effective_mode':fr['effective_mode'],'search_truncated':fr['search_truncated'],'history_support_omitted':fr['history_support_omitted'],'object_identity':'UNKNOWN','temporal_adoption_allowed':gates.get('temporal_adoption_allowed')}
   conditions.append(item);write(cd/'integrated_evaluation.json',item);wr[boundary]={k:result[k] for k in ('labels','edges','current_edges','summary')};del d,result,entry;gc.collect()
  if len(wr)==2:
   cp=wd/'boundary_comparison';cp.mkdir();x,y=wr['boundary_true'],wr['boundary_false']
   cmp={'kind':'boundary_only','window':window,'same_history':True,'same_xyz':True,'same_structure_mask':True,'B_content_identical':x['summary']['B_classification_sha256']==y['summary']['B_classification_sha256'],'C_edges':compare_edges(x['edges'],y['edges'],cp,'C'),'current_edges':compare_edges(x['current_edges'],y['current_edges'],cp,'current'),'clusters':partition_comparison(x['labels'],y['labels']),'false_merge_rate':None,'object_identity':'UNKNOWN'};write(cp/'comparison.json',cmp);comparisons.append(cmp)
  windows[window]={'runs':wr,'mask':structure['structure_mask'],'ref':ref_frame}
 if len(windows)==2:
  x,y=windows['fixed11'],windows['all']
  for b in x['runs'].keys()&y['runs'].keys():
   cp=dest/'window_comparison'/b;cp.mkdir(parents=True);cmp={'kind':'window_only','boundary':b,'reference_unchanged':x['ref']==y['ref'],'clustering_config_unchanged':True,'recovery_thresholds_unchanged':True,'B_count_change_expected':True,'structure_mask_differences':int((x['mask']!=y['mask']).sum()),'C_edges':compare_edges(x['runs'][b]['edges'],y['runs'][b]['edges'],cp,'C'),'clusters':partition_comparison(x['runs'][b]['labels'],y['runs'][b]['labels'])};write(cp/'comparison.json',cmp);comparisons.append(cmp)
 if any(not Path(p).exists() or sha(p)!=v for p,v in hashes.items()):raise ValueError('Saved baseline modified')
 report={'schema_version':SCHEMA,'case':case['name'],'status':'COMPLETED_DIAGNOSTIC','conditions':conditions,'comparisons':comparisons,'seconds':time.monotonic()-begin,'saved_input_hashes':hashes,'saved_inputs_unchanged':True,'automatic_object_merges':0,'accuracy':None,'false_merge_rate':None,'dataset_role':case.get('dataset_role','development')}
 write(dest/'evaluation.json',report);return report
