"""Deterministic conservative hypothesis search. Not a multicut solver."""
from collections import defaultdict,Counter
from itertools import combinations
import numpy as np
from .common import *

def conservative_groups(relations,eligible_field='test_eligible',reverse=False):
    lookup={tuple(sorted(r['fragments'])):r for r in relations}
    edges=[r for r in relations if r['H_SURFACE_CONTINUATION'].get(eligible_field)]
    def score(r):return tuple(r['H_SURFACE_CONTINUATION']['score_ordinal'])
    edges=sorted(edges,key=lambda r:(score(r),tuple(r['fragments'])),reverse=not reverse)
    incident=defaultdict(list)
    for r in edges:
        for v in r['fragments']:incident[v].append(r)
    tied=set();competitions=[]
    for v,rs in incident.items():
        if len(rs)>1:
            best=max(score(r) for r in rs);top=[r for r in rs if score(r)==best]
            if len(top)>1:
                tied.update(r['candidate_id'] for r in top)
                competitions.append({'fragment':v,'candidates':[r['candidate_id'] for r in top],'reason':'COMPETING_PARENT','tie':True})
    groups=[];decisions=[];used=set()
    for r in edges:
        members=set(r['fragments']);reason=[]
        if r['candidate_id'] in tied:reason.append('COMPETING_PARENT')
        if r.get('third_fragments') or r.get('chains'):reason.append('THIRD_FRAGMENT_INTERPOSED')
        # Check all adjacent prospective relations including a two-hop negative triangle BEFORE forming even a pair.
        for x in sorted(members):
            for link in incident[x]:
                other=set(link['fragments'])-members
                for y in other:
                    for z in members-{x}:
                        cross=lookup.get(tuple(sorted((y,z))))
                        if cross and cross['edge_state']=='NEGATIVE_HYPOTHESIS':reason.append('GROUP_CONFLICT')
        if members&used:reason.append('COMPETING_PARENT')
        if not reason:
            # Growth requires explicit positive support to every member; unknown nonedges stay unknown and do not become negatives.
            changed=True
            while changed:
                changed=False
                possible=sorted({v for a in members for e in incident[a] for v in e['fragments']}-members-used)
                for v in possible:
                    links=[lookup.get(tuple(sorted((v,a)))) for a in sorted(members)]
                    if all(e and e['H_SURFACE_CONTINUATION'].get(eligible_field) and e['candidate_id'] not in tied
                           and e['edge_state']!='NEGATIVE_HYPOTHESIS' and not e.get('third_fragments') and not e.get('chains') for e in links):
                        members.add(v);changed=True;break
            groups.append(sorted(members));used|=members
        decisions.append({'candidate_id':r['candidate_id'],'members_considered':sorted(members),
                          'accepted':not reason,'reasons':sorted(set(reason))})
    return sorted(groups),decisions,competitions

def geometry(d,members):
    pix=np.flatnonzero(d.valid.ravel()&np.isin(d.labels.ravel(),members));p=d.xyz[pix];center=p.mean(axis=0)
    if len(p)>=3:
        _,_,vh=np.linalg.svd(p-center,full_matrices=False);axes=vh.T
    else:axes=np.eye(3)
    q=(p-center)@axes;low=q.min(axis=0);high=q.max(axis=0)
    return {'measured_union_point_count':len(pix),'unique_pixel_count':len(pix),'measured_pixel_sha256':array_sha(pix),
            'centroid':center,'obb_axes':axes,'obb_center':center+axes@((high+low)/2),'obb_extent':high-low,
            'geometry_source':'deduplicated valid measured pixel union','pose_update':False}

def group(d,evidence,config):
    rel=evidence['relations'];mode=evidence['effective_mode'];trial=d.labels.copy();hypotheses=[]
    for r in rel:
        if r['H_SURFACE_CONTINUATION']['geometry_supported'] or r['H_OBJECT_PART']['state']=='PART_ASSOCIATION_CANDIDATE':
            hypotheses.append({'group_hypothesis_id':len(hypotheses),'members':r['fragments'],'relations':[r['candidate_id']],
                'state':'RELATION_ONLY','object_identity':'UNKNOWN','reasons':['IDENTITY_UNRESOLVED'],
                'hypothesis_kind':'H_SURFACE_CONTINUATION' if r['H_SURFACE_CONTINUATION']['geometry_supported'] else 'H_OBJECT_PART',
                'geometry':geometry(d,r['fragments'])})
    accepted,decisions,competition=conservative_groups(rel)
    reversed_groups,_,_=conservative_groups(rel,reverse=True)
    sensitive=accepted!=reversed_groups
    if sensitive:accepted=[]
    if mode!='trial_grouping':accepted=[]
    for members in accepted:
        for lab in members:trial[d.labels==lab]=min(members)
        hypotheses.append({'group_hypothesis_id':len(hypotheses),'members':members,'state':'TRIAL_GROUP','object_identity':'UNKNOWN',
            'relations':[r['candidate_id'] for r in rel if set(r['fragments'])<=set(members)],'geometry':geometry(d,members)})
    for h in hypotheses:
        h['competing_group_ids']=[x['group_hypothesis_id'] for x in hypotheses if x is not h and set(h['members'])&set(x['members'])]
        h['negative_relation_ids']=[r['candidate_id'] for r in rel if set(r['fragments'])<=set(h['members']) and r['edge_state']=='NEGATIVE_HYPOTHESIS']
    return {'schema_version':SCHEMA,'groups':hypotheses,'trial_group_count':len(accepted),'decisions':decisions,
            'competitions':competition,'order_sensitivity':sensitive,'ordering':'score ordinal then sorted original IDs; ties held',
            'stop_condition':'finite candidate list exhausted; clique growth requires every pair explicitly supported',
            'solver':'conservative deterministic heuristic, no optimality claim','unknown_nonedge_semantics':'UNKNOWN, never negative',
            'hard_cannot_links':[]},trial

def control_labels(d,relations,field):
    """Unconstrained graph merging ONLY for B1/B2/B3 diagnostic ablations."""
    parent={v:v for v in d.counts}
    def root(v):
        while parent[v]!=v:v=parent[v]
        return v
    for r in relations:
        use=True if field=='distance' else r['H_SURFACE_CONTINUATION'][field]
        if use:
            a,b=map(root,r['fragments']);parent[max(a,b)]=min(a,b)
    out=d.labels.copy()
    for v in parent:out[d.labels==v]=root(v)
    return out
