"""inspect → diagnose → verify → compare → export, with isolated failure records."""
from pathlib import Path
import os,time,resource,platform,shutil,zipfile,copy
import numpy as np
from .common import *
from .input import Input,AlignmentError
from .candidates import discover
from .models import Models,inventory
from .evidence import HistoryEvidence,evaluate
from .grouping import group,control_labels,conservative_groups
from .evaluation import metrics
from .viewer import condition_view,comparison

def inspect(root,out,cases=None):
    root=Path(root).expanduser().resolve();out=Path(out)
    if out.exists():raise FileExistsError(out)
    names=cases or ['exp01_t0','exp01_t1','exp02_t0','exp02_t1']
    if cases is None and (root/'cases').exists():names=sorted(set(names)|{p.name for p in (root/'cases').iterdir() if p.is_dir()})
    entries=[]
    for case in names:
        if '/' in case or case in ('.','..'):raise ValueError('Unsafe case name')
        for win in ('fixed11','all'):
            for b in ('boundary_true','boundary_false'):
                path=root/'cases'/case/win/b;entry={'case':case,'window':win,'boundary':b,'path':str(path),'status':'MISSING_INPUT'}
                if path.exists():
                    try:
                        d=Input(path);entry.update(d.summary());entry['status']='READY'
                    except Exception as e:entry.update(status='FAILED_INPUT_ALIGNMENT',error=type(e).__name__+': '+str(e))
                entries.append(entry)
    # Across windows of one bag the reference and declared coordinate system must match.
    for name in names:
        group=[e for e in entries if e['case']==name and e['status']=='READY']
        reference=next((e for e in group if e['window']=='fixed11'),group[0] if group else None)
        if reference:
            for e in group:
                for key in ('reference_frame_index','reference_time_ns','coordinate_frame','sensor_origin_xyz'):
                    a,b=e.get(key),reference.get(key)
                    if a is not None and b is not None and not np.array_equal(a,b):
                        e.update(status='FAILED_INPUT_ALIGNMENT',error='Cross-window '+key+' mismatch');break
    manifest={'schema_version':SCHEMA,'source_root':str(root),'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        'baseline_manifest_sha256':sha(root/'run_manifest.json') if (root/'run_manifest.json').exists() else None,
        'conditions':entries,'expected_condition_count':len(entries)}
    write_json(out,manifest);return manifest

def resource_check(c,start):
    rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024
    if rss>c['resources']['max_working_mb']:raise MemoryError(f'Peak RSS {rss:.1f} MiB exceeds budget')
    if time.monotonic()-start>c['resources']['max_condition_seconds']:raise TimeoutError('Condition time budget exhausted')

def run_condition(entry,out,c,annotation=None,input_object=None):
    out=Path(out);out.mkdir(parents=True,exist_ok=False);start=time.monotonic();d=input_object if input_object is not None else Input(entry['path'],entry,c['resources']['max_working_mb'])
    write_json(out/'input_manifest.json',{'condition':entry,'inspection':d.summary()});write_json(out/'baseline_config.json',d.config)
    write_json(out/'config.json',c);graph=discover(d,c);resource_check(c,start)
    # Candidate keys carry source condition/window and exact labels. No fixture IDs enter processing.
    source_run_hash=sha(d.input_run_manifest)
    for x in graph['candidates']:
        for route,v in x['routes'].items():v['candidate_key']=f"{source_run_hash}/{entry['case']}/{entry['window']}/{entry['boundary']}/{d.label_hash}/"+v['candidate_key']
    write_json(out/'candidate_graph.json',graph);inv=inventory(d,graph);write_json(out/'fragment_inventory.json',inv)
    models=Models(d,c);hist=HistoryEvidence(d,c,out/'history_support');ev=evaluate(d,graph,models,hist,c);resource_check(c,start)
    for frag in inv['fragments']:
        frag['local_model_ids']=[m['model_id'] for m in models.records if m['fragment']==frag['fragment_id']]
    write_json(out/'fragment_inventory.json',inv)
    write_json(out/'local_shape_models.json',{'schema_version':SCHEMA,'models':models.records,'configuration':c['local_models']})
    write_json(out/'relation_evidence.json',ev);groups,trial=group(d,ev,c);write_json(out/'group_hypotheses.json',groups)
    save_npz(out/'trial_pixel_correspondence.npz',**d.a,original_labels=d.labels,trial_labels=trial)
    rel=ev['relations'];distance_rel=[r for r,g in zip(rel,graph['candidates']) if any(e['distance_m']<=graph['search']['search_radius_m'] for e in g['endpoints'])]
    ablations={'B0':d.labels,'B1':control_labels(d,distance_rel,'distance'),
        'B2':control_labels(d,rel,'geometry_supported'),'B3':control_labels(d,rel,'history_consistent')}
    accepted,_,_=conservative_groups(rel,'history_consistent');b4=d.labels.copy()
    for members in accepted:
        for lab in members:b4[d.labels==lab]=min(members)
    ablations['B4']=b4;save_npz(out/'diagnostic_ablations.npz',**ablations)
    # Evaluation is downstream only: never passed to discovery/models/evidence/group.
    truth=read_json(annotation) if annotation else None
    evaluated={k:metrics(d,graph,v,truth) for k,v in ablations.items()}
    current=copy.copy(d);current.valid=d.valid&(d.a['source_type']==1)
    current.counts={int(l):int(n) for l,n in zip(*np.unique(d.labels[current.valid],return_counts=True))}
    current_metrics={k:metrics(current,graph,v,truth) for k,v in ablations.items()}
    evaluation={'schema_version':SCHEMA,'status':'COMPLETED_DIAGNOSTIC','all_valid_pixels':int(d.valid.sum()),
        'current_only_pixels':int((d.valid&(d.a['source_type']==1)).sum()),'history_pixels':int((d.valid&(d.a['source_type']==2)).sum()),
        'temporal_adoption_allowed':d.gates.get('temporal_adoption_allowed') if d.gates else None,
        'trial':metrics(d,graph,trial,truth),'ablations':evaluated,'ablation_semantics':{
        'B0':'original v0.2 labels','B1':'distance-only connected components DIAGNOSTIC CONTROL',
        'B2':'bidirectional plane geometry only','B3':'geometry plus measured history','B4':'B3 plus conservative group conflict checks'},
        'same_candidate_set':True,'ablation_outputs_are_not_trial_labels':True,
        'candidate_search_effect':{route:{'pairs':sum(route in x['routes'] for x in graph['candidates'])} for route in c['candidate_search']['candidate_routes']},
        'current_only_comparison':{'semantics':'same original fragment labels restricted to CURRENT_MEASURED pixels; no new clustering',
            'fragment_count':len(np.unique(d.labels[d.valid&(d.a['source_type']==1)])), 'ablations':current_metrics,
            'all_valid_fragment_count':len(d.counts)},'annotation_used_for_inference':False,'annotation_sha256':sha(annotation) if annotation else None,
        'unmeasured_points_generated':0,'raw_intensity_dtype':d.raw_dtype}
    write_json(out/'evaluation.json',evaluation);condition_view(d,graph,ev,trial,out/'comparison.html');resource_check(c,start)
    unchanged=all(sha(p)==h for p,h in d.files.items())
    if not unchanged:raise AlignmentError('Baseline changed during diagnosis')
    status={'schema_version':SCHEMA,'status':'COMPLETED_DIAGNOSTIC','source_condition':entry,'source_hashes':d.files,
        'baseline_unchanged':unchanged,'label_sha256':d.label_hash,'effective_mode':ev['effective_mode'],
        'fragment_count':len(d.counts),'candidate_count':len(graph['candidates']),'trial_group_count':groups['trial_group_count'],
        'search_truncated':graph['search_truncated'],'history_support_omitted':hist.truncated,
        'output_sha256':{str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file()},
        'elapsed_s':time.monotonic()-start,'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
        'availability':d.availability,'errors':[]}
    write_json(out/'run_manifest.json',status)
    (out/'checkpoint.txt').write_text('YLM-X001 v0.3 診断完了\n元v0.2不変。物体同一性UNKNOWN。未校正の試験採用は0。\n再実行は新しい出力ディレクトリで行う。設定はconfig.json、入力はinput_manifest.json。\n',encoding='utf8')
    return status

def diagnose(manifest_path,output,config_path=None,annotations_dir=None):
    inp=read_json(manifest_path);root=Path(output).resolve();root.mkdir(parents=True,exist_ok=False)
    config=validate_config(read_json(config_path) if config_path else default_config());write_json(root/'config.json',config);write_json(root/'input_manifest.json',inp)
    src=Path(__file__).parent;snapshot=root/'code_snapshot';shutil.copytree(src,snapshot,ignore=shutil.ignore_patterns('__pycache__'))
    status={'schema_version':SCHEMA,'version':VERSION,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        'conditions':[],'input_manifest_sha256':sha(manifest_path),'config_sha256':sha(root/'config.json'),
        'code_hashes':{str(p.relative_to(snapshot)):sha(p) for p in sorted(snapshot.rglob('*.py'))},
        'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':__import__('scipy').__version__},
        'status':'RUNNING','baseline_unchanged':True}
    for entry in inp['conditions']:
        item={k:entry[k] for k in ('case','window','boundary')};relative=f"cases/{entry['case']}/{entry['window']}/{entry['boundary']}";item['output']=relative
        if entry['status']!='READY':item.update(status=entry['status'],error=entry.get('error'))
        else:
            try:
                p=Path(annotations_dir)/f"{entry['case']}__{entry['window']}__{entry['boundary']}.json" if annotations_dir else None
                report=run_condition(entry,root/relative,config,p if p and p.exists() else None)
                item.update({k:report[k] for k in ('status','fragment_count','candidate_count','trial_group_count','search_truncated','elapsed_s','peak_rss_mib')})
            except Exception as e:
                item.update(status='FAILED_INPUT_ALIGNMENT' if isinstance(e,AlignmentError) else 'FAILED_RESOURCE' if isinstance(e,(MemoryError,TimeoutError)) else 'FAILED_PROCESSING',error=type(e).__name__+': '+str(e))
                folder=root/relative;folder.mkdir(parents=True,exist_ok=True);write_json(folder/'failure.json',item)
                (folder/'checkpoint.txt').write_text(item['status']+'\n'+item['error']+'\nUse a new output directory when rerunning.\n')
        status['conditions'].append(item);write_json(root/'run_manifest.json',status)
        print('/'.join(str(item[k]) for k in ('case','window','boundary')),item['status'],flush=True)
    status['baseline_unchanged']=None if any(x['status'].startswith('FAILED') for x in status['conditions']) else bool(any(x['status']=='COMPLETED_DIAGNOSTIC' for x in status['conditions']))
    complete=sum(x['status']=='COMPLETED_DIAGNOSTIC' for x in status['conditions']);status.update(status='COMPLETED_ALL' if complete==len(inp['conditions']) else 'COMPLETED_PARTIAL',completed_conditions=complete,expected_conditions=len(inp['conditions']))
    write_json(root/'run_manifest.json',status);compare(root)
    (root/'checkpoint.txt').write_text(f"YLM-X001 v{VERSION}\n完了 {complete}/{len(inp['conditions'])} 条件。欠損・失敗一覧はrun_manifest.json。\nverify → compare → export の順。元v0.2は保存先と分離。新しい出力先で再実行。\n")
    return status

def compare(root):
    root=Path(root);manifest=read_json(root/'run_manifest.json');conditions=[];bycase={}
    for c in manifest['conditions']:
        if c['status']=='COMPLETED_DIAGNOSTIC':
            a=npz(root/c['output']/'trial_pixel_correspondence.npz');v=a['valid']&(a['original_labels']>=0)
            bycase.setdefault(c['case'],[]).append((c['output'],v));conditions.append({'condition':c, 'evaluation':read_json(root/c['output']/'evaluation.json')})
        else:conditions.append({'condition':c,'evaluation':None})
    common={}
    for name,items in bycase.items():
        shapes={v.shape for _,v in items}
        common[name]={'conditions':[k for k,v in items],'common_valid_pixels':int(np.logical_and.reduce([v for _,v in items]).sum()) if len(shapes)==1 else None,
            'all_valid_pixels_per_condition':{k:int(v.sum()) for k,v in items},'note':'same bag pixel indices; not cross-bag registration'}
    write_json(root/'evaluation.json',{'schema_version':SCHEMA,'conditions':conditions,'common_pixels':common,'development_evaluation':True})
    comparison(root,manifest);return {'html':str(root/'comparison.html')}

def verify(root,check_sources=True):
    root=Path(root);manifest=read_json(root/'run_manifest.json');errors=[];count=0;npz_count=0
    required=('fragment_inventory.json','candidate_graph.json','local_shape_models.json','relation_evidence.json','group_hypotheses.json','trial_pixel_correspondence.npz','evaluation.json','comparison.html','checkpoint.txt')
    for p in root.rglob('*.json'):
        try:read_json(p);count+=1
        except Exception as e:errors.append(str(p)+': '+str(e))
    for p in root.rglob('*.npz'):
        try:npz(p);npz_count+=1
        except Exception as e:errors.append(str(p)+': '+str(e))
    checked_sources={}
    for c in manifest['conditions']:
        if c['status']!='COMPLETED_DIAGNOSTIC':continue
        folder=root/c['output']
        for f in required:
            if not (folder/f).exists():errors.append(str(folder/f)+' missing')
        try:
            m=read_json(folder/'run_manifest.json');a=npz(folder/'trial_pixel_correspondence.npz')
            for relpath,digest in m.get('output_sha256',{}).items():
                if not (folder/relpath).exists() or sha(folder/relpath)!=digest:errors.append('Output changed: '+str(folder/relpath))
            if array_sha(a['original_labels'])!=m['label_sha256']:errors.append(str(folder)+' original labels modified')
            if not np.array_equal(a['labels'],a['original_labels']):errors.append(str(folder)+' labels field changed')
            if m['effective_mode']=='diagnostic_only' and not np.array_equal(a['trial_labels'],a['original_labels']):errors.append(str(folder)+' diagnostic labels changed')
            if np.any((a['original_labels']<0)&(a['trial_labels']>=0)):errors.append('Invented trial pixels')
            if check_sources:
                for p,h in m['source_hashes'].items():
                    if p not in checked_sources:checked_sources[p]=sha(p) if Path(p).exists() else None
                    if checked_sources[p]!=h:errors.append('Source missing or changed: '+p)
                original=npz(Path(m['source_condition']['path'])/'pixel_correspondence.npz')
                for k,v in original.items():
                    if not np.array_equal(v,a[k],equal_nan=True):errors.append('Source correspondence changed '+k)
        except Exception as e:errors.append(str(folder)+': '+str(e))
    for p,h in manifest['code_hashes'].items():
        if sha(root/'code_snapshot'/p)!=h:errors.append('Code snapshot changed '+p)
    if sha(root/'config.json')!=manifest['config_sha256']:errors.append('Config changed')
    report={'schema_version':SCHEMA,'status':'PASS' if not errors else 'FAIL','errors':errors,'json_files':count,'npz_files':npz_count,
        'source_recheck':check_sources,'source_files_checked':len(checked_sources),'completed_conditions':manifest['completed_conditions'],
        'expected_conditions':manifest['expected_conditions'],'completion_is_separate_from_integrity':True}
    write_json(root/'verification.json',report);return report

def export(root,output,include_pcd=False):
    root=Path(root);output=Path(output)
    if output.exists():raise FileExistsError(output)
    result=verify(root,check_sources=False)
    if result['status']!='PASS':raise ValueError('Cannot export failed verification')
    if include_pcd:
        for c in read_json(root/'run_manifest.json')['conditions']:
            if c['status']!='COMPLETED_DIAGNOSTIC':continue
            folder=root/c['output'];a=npz(folder/'trial_pixel_correspondence.npz');groups=read_json(folder/'group_hypotheses.json')['groups']
            target=folder/'trial_measured_pcd'
            if target.exists():raise FileExistsError(target)
            target.mkdir()
            for g in groups:
                if g['state']!='TRIAL_GROUP':continue
                valid=a['valid']&np.isin(a['original_labels'],g['members']);pix=np.flatnonzero(valid);xyz=a['xyz'].reshape(-1,3)[pix]
                header=f'# measured pixel union only\nVERSION .7\nFIELDS x y z pixel_id\nSIZE 4 4 4 4\nTYPE F F F I\nCOUNT 1 1 1 1\nWIDTH {len(pix)}\nHEIGHT 1\nVIEWPOINT 0 0 0 1 0 0 0\nPOINTS {len(pix)}\nDATA ascii\n'
                with (target/f"group_{g['group_hypothesis_id']}.pcd").open('w') as f:
                    f.write(header)
                    for p,i in zip(xyz,pix):f.write(' '.join(map(str,p))+f' {i}\n')
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,6) as z:
        for p in sorted(root.rglob('*')):
            if p.is_file() and p.resolve()!=output.resolve():z.write(p,root.name+'/'+str(p.relative_to(root)))
    return {'path':str(output),'sha256':sha(output)}
