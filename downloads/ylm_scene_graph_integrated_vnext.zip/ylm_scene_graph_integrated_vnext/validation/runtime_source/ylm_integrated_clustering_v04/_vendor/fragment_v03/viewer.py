"""Self-contained canvas viewer, no network/CDN dependencies."""
from pathlib import Path
import json,html
import numpy as np
from .common import *

def condition_view(d,graph,evidence,trial,out):
    pix=np.flatnonzero(d.valid);p=d.xyz[pix];labs=d.labels.ravel()[pix];tr=trial.ravel()[pix]
    records=[]
    for c,r in zip(graph['candidates'],evidence['relations']):
        records.append({'id':c['candidate_id'],'fragments':c['fragments'],'routes':list(c['routes']),
            'endpoints':[e['pixels'] for e in c['endpoints']], 'third':c['third_fragments'],
            'surface':r['H_SURFACE_CONTINUATION']['state'],'part':r['H_OBJECT_PART']['state'],
            'reasons':r['H_SURFACE_CONTINUATION']['reasons'],'part_reasons':r['H_OBJECT_PART']['reasons'],'edge':r['edge_state'],
            'hypothesized':[{'pixels':x['target_pixel_ids'],'ranges':clean(x.get('projection_range_m')),'valid':clean(x.get('projection_valid'))}
                for x in r['measured']['history'] if x['status']=='AVAILABLE']})
    data={'xyz':np.round(p,5),'pixels':pix,'labels':labs,'trial':tr,'source':d.a['source_type'].ravel()[pix],
          'h':d.h,'w':d.w,'candidates':records,'mode':evidence['effective_mode'],'gate':d.gates,
          'floor_mask':np.flatnonzero(d.structure['structure_mask']) if d.structure else [],
          'rays':np.round(d.rays['unit_ray'].reshape(-1,3),8) if d.rays else None,'origin':d.origin,
          'availability':d.availability,'truncated':graph['search_truncated']}
    payload=json.dumps(clean(data),ensure_ascii=False,separators=(',',':'),allow_nan=False).replace('<','\\u003c')
    template='''<!doctype html><html lang="ja"><meta charset="utf-8"><title>YLM-X001 comparison</title>
<style>body{font:14px system-ui;background:#101820;color:#e9f0f4;margin:20px}select,input,button{font:inherit;margin:5px;background:#263844;color:white;border:1px solid #607582;padding:6px}.views{display:grid;grid-template-columns:repeat(2,minmax(320px,1fr));gap:12px}canvas{width:100%;background:#081016}section{border:1px solid #435762;padding:10px}pre{white-space:pre-wrap;overflow-wrap:anywhere}label{display:inline-block} .note{color:#f4ce75}#details{max-height:350px;overflow:auto}</style>
<h1>YLM-X001 / 観測断片と関係仮説</h1><p class="note">物体同一性 UNKNOWN。推定面は診断表示専用。ドラッグで3D回転。</p><p id="status"></p>
<select id="labelMode"><option value="labels">元ラベル</option><option value="trial">試験ラベル</option><option value="source">現在/履歴来歴</option></select>
<label><input type="checkbox" id="measured" checked>実測</label><label><input type="checkbox" id="candidate" checked>候補線</label><label><input type="checkbox" id="foreground" checked>第三断片</label><label><input type="checkbox" id="floor">構造除去マスク</label><label><input type="checkbox" id="hypothesized">推定投影</label><label><input type="checkbox" id="current">現在実測のみ</label>
<input id="query" placeholder="断片IDまたは理由を検索"><select id="relation"></select><div class="views">
<section>organized画素<canvas id="image" width="640" height="460"></canvas></section><section>3D<canvas id="space" width="640" height="460"></canvas></section>
<section>XY<canvas id="xy" width="640" height="460"></canvas></section><section>XZ<canvas id="xz" width="640" height="460"></canvas></section><section>YZ<canvas id="yz" width="640" height="460"></canvas></section>
<section>候補の状態・保留理由<pre id="details"></pre><p>床マスクはorganized上に表示。床の3D位置は対応実測がない場合UNAVAILABLE。透視投影の図ではなく同じ実測座標の平行投影。</p></section></div>
<script>const D=PAYLOAD;const $=id=>document.getElementById(id);const lookup=new Map(D.pixels.map((p,i)=>[p,i]));let yaw=.7,pitch=.35,drag=null;
function color(n){return n<0?'#55636c':`hsl(${(n*137.508)%360} 75% 64%)`}
function selected(){return D.candidates.find(c=>c.id===Number($('relation').value))}
function options(){let q=$('query').value.toLowerCase();$('relation').replaceChildren();let blank=document.createElement('option');blank.value=-1;blank.textContent='候補を選択';$('relation').append(blank);for(let c of D.candidates){if(q&&!JSON.stringify(c).toLowerCase().includes(q))continue;let o=document.createElement('option');o.value=c.id;o.textContent=`${c.id}: ${c.fragments.join(' ↔ ')} ${c.routes.join('/')}`;$('relation').append(o)}draw()}
function project(p,key){let [x,y,z]=p;if(key==='xy')return[x,y];if(key==='xz')return[x,z];if(key==='yz')return[y,z];let u=x*Math.cos(yaw)-z*Math.sin(yaw),v=x*Math.sin(yaw)+z*Math.cos(yaw);return[u,y*Math.cos(pitch)-v*Math.sin(pitch)]}
function draw(){let chosen=selected(),third=new Set(chosen?chosen.third:[]),lab=D[$('labelMode').value],current=$('current').checked;let eligible=D.pixels.map((_,i)=>i).filter(i=>!current||D.source[i]===1);
$('status').textContent=`${D.mode}; fragments ${new Set(D.labels).size}; measured pixels ${D.pixels.length}; search truncated ${D.truncated}; temporal adoption ${D.gate?D.gate.temporal_adoption_allowed:'UNAVAILABLE'}`;
$('details').textContent=JSON.stringify(chosen?{...chosen,hypothesized:`${chosen.hypothesized.length} projection records`}:D.availability,null,2);
for(let key of ['image','space','xy','xz','yz']){let cv=$(key),ctx=cv.getContext('2d');ctx.clearRect(0,0,cv.width,cv.height);let pts=key==='image'?D.pixels.map(p=>[p%D.w,Math.floor(p/D.w)]):D.xyz.map(p=>project(p,key));let xs=pts.map(p=>p[0]),ys=pts.map(p=>p[1]);let loX=key==='image'?0:Math.min(...xs),hiX=key==='image'?D.w:Math.max(...xs),loY=key==='image'?0:Math.min(...ys),hiY=key==='image'?D.h:Math.max(...ys);let scale=Math.min((cv.width-24)/Math.max(hiX-loX,.001),(cv.height-24)/Math.max(hiY-loY,.001));let screen=p=>[12+(p[0]-loX)*scale,key==='image'?12+(p[1]-loY)*scale:cv.height-12-(p[1]-loY)*scale];
if(key==='image'&&$('floor').checked){ctx.fillStyle='#888';for(let p of D.floor_mask){let [x,y]=screen([p%D.w,Math.floor(p/D.w)]);ctx.fillRect(x,y,2,2)}}
if($('measured').checked)for(let i of eligible){let [x,y]=screen(pts[i]);ctx.fillStyle=$('foreground').checked&&third.has(D.labels[i])?'#ff5b5b':color(lab[i]);ctx.fillRect(x,y,key==='image'?2:2,key==='image'?2:2)}
if(chosen&&$('candidate').checked){ctx.strokeStyle='#fff';ctx.lineWidth=1;for(let pair of chosen.endpoints){if(!pair.every(p=>lookup.has(p)))continue;let a=screen(pts[lookup.get(pair[0])]),b=screen(pts[lookup.get(pair[1])]);ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke()}}
if(chosen&&$('hypothesized').checked&&D.rays){ctx.strokeStyle='#ffd04c';for(let h of chosen.hypothesized)for(let i=0;i<h.pixels.length;i++){if(!h.valid[i])continue;let p=h.pixels[i],r=h.ranges[i],xyz=D.rays[p].map((v,j)=>D.origin[j]+v*r);let xy=key==='image'?[p%D.w,Math.floor(p/D.w)]:project(xyz,key);let[x,y]=screen(xy);ctx.beginPath();ctx.moveTo(x-3,y-3);ctx.lineTo(x+3,y+3);ctx.moveTo(x-3,y+3);ctx.lineTo(x+3,y-3);ctx.stroke()}}}}
for(let id of ['labelMode','measured','candidate','foreground','floor','hypothesized','current','relation'])$(id).addEventListener('change',draw);$('query').addEventListener('input',options);$('space').addEventListener('pointerdown',e=>{drag=[e.clientX,e.clientY];$('space').setPointerCapture(e.pointerId)});$('space').addEventListener('pointermove',e=>{if(!drag)return;yaw+=(e.clientX-drag[0])*.01;pitch+=(e.clientY-drag[1])*.01;drag=[e.clientX,e.clientY];draw()});$('space').addEventListener('pointerup',()=>drag=null);options();</script></html>'''
    Path(out).write_text(template.replace('PAYLOAD',payload),encoding='utf8')

def comparison(root,manifest):
    root=Path(root);rows=[]
    for c in manifest['conditions']:
        link=f'<a href="{html.escape(c["output"]+"/comparison.html")}">開く</a>' if c['status']=='COMPLETED_DIAGNOSTIC' else ''
        rows.append('<tr>'+''.join('<td>'+html.escape(str(c.get(k,'')))+'</td>' for k in ('case','window','boundary','status','fragment_count','candidate_count','trial_group_count'))+'<td>'+link+'</td></tr>')
    page='<!doctype html><html lang="ja"><meta charset="utf-8"><title>YLM-X001 全条件比較</title><style>body{font:15px system-ui;margin:30px}table{border-collapse:collapse}td,th{padding:9px;border:1px solid #bbb}.note{color:#8b4300}</style><h1>YLM-X001 全条件比較</h1><p class="note">未実行・入力失敗を完了件数に含めません。exp01/02は開発評価。物体同一性 UNKNOWN。</p><p>各画面は実測と推定を分離。全窓の統合保留と履歴診断の可否は別表示。</p><table><tr>'+''.join('<th>'+x+'</th>' for x in ('case','window','boundary','status','fragments','candidates','trial groups','表示'))+'</tr>'+''.join(rows)+'</table><p><a href="evaluation.json">共通画素・全画素・各条件比較JSON</a></p></html>'
    (root/'comparison.html').write_text(page,encoding='utf8')
