"""Bounded discovery only. No proposal route implies an object identity."""
from collections import Counter,defaultdict
import numpy as np
from scipy.spatial import cKDTree
from .common import *

def discover(d,config):
    budget=Budget(config);s=dict(config['candidate_search']);base=d.config['relations']
    if s['search_radius_m'] is None:s['search_radius_m']=base['max_endpoint_distance_m']
    if s['image_gap_limit_px'] is None:s['image_gap_limit_px']=base['max_gap_pixels']
    if int(s['image_gap_limit_px'])!=s['image_gap_limit_px']:raise ValueError('Integer image gap required')
    labels=d.labels.ravel();valid=d.valid.ravel();rows,cols=np.divmod(np.arange(d.n),d.w)
    candidates={};cuts=Counter();route_counts=Counter();routes=set(s['candidate_routes'])
    def add(i,j,route,gap=(),edge=None,path=None):
        a,b=int(labels[i]),int(labels[j])
        if a<0 or b<0 or a==b or not valid[i] or not valid[j]:return
        if a>b:a,b=b,a;i,j=j,i;gap=list(reversed(gap));path=list(reversed(path)) if path else path
        key=(a,b);route_counts[route]+=1
        if sum(route_counts.values())%1000==0:budget.check()
        if key not in candidates:
            if len(candidates)>=s['candidate_limit']:cuts['candidate_proposals_discarded']+=1;return
            candidates[key]={'fragments':[a,b],'routes':{},'endpoints':[], 'direct_held_edges':[], 'chains':[],'_seen':set(),'endpoint_proposals':0}
        c=candidates[key];c['routes'].setdefault(route,{'proposal_count':0,'candidate_key':f'{a}:{b}:{route}'})['proposal_count']+=1
        if edge is not None:c['direct_held_edges'].append(edge)
        if path is not None:
            c['chains'].append(path);return
        c['endpoint_proposals']+=1
        ek=(int(i),int(j))
        if ek in c['_seen']:return
        c['_seen'].add(ek)
        # Prefer new contact cells before duplicate samples; all held edges are retained separately.
        patch=[int(rows[i]//s['patch_grid_px']),int(cols[i]//s['patch_grid_px']),int(rows[j]//s['patch_grid_px']),int(cols[j]//s['patch_grid_px'])]
        rec={'pixels':[int(i),int(j)],'route':route,'distance_m':float(np.linalg.norm(d.xyz[i]-d.xyz[j])),
             'patch_key':patch,'gap_pixels':[int(x) for x in gap]}
        if len(c['endpoints'])<s['endpoint_samples_per_pair']:c['endpoints'].append(rec)
        elif patch not in [v['patch_key'] for v in c['endpoints']]:
            counts=Counter(tuple(v['patch_key']) for v in c['endpoints'])
            replace=next((k for k in reversed(range(len(c['endpoints']))) if counts[tuple(c['endpoints'][k]['patch_key'])]>1),None)
            if replace is not None:c['endpoints'][replace]=rec
            cuts['endpoint_samples_discarded']+=1
        else:cuts['endpoint_samples_discarded']+=1
    if 'DIRECT_HELD' in routes and d.edges is not None:
        e=d.edges;i=e['pixel_i'];j=e['pixel_j'];near=(abs(rows[i]-rows[j])+abs(cols[i]-cols[j]))==1
        use=~e['accepted']&near&valid[i]&valid[j]&(labels[i]!=labels[j])
        fields=[k for k in e if k not in ('pixel_i','pixel_j')]
        for ix in np.flatnonzero(use):add(int(i[ix]),int(j[ix]),'DIRECT_HELD',edge={'edge_index':int(ix),'pixels':[int(i[ix]),int(j[ix])],**{k:e[k][ix] for k in fields}})
    if 'IMAGE_GAP' in routes:
        grid=np.arange(d.n).reshape(d.shape)
        for dy,dx in ((0,1),(1,0),(1,1),(1,-1)):
            for step in range(2,int(s['image_gap_limit_px'])+2):
                yy,xx=np.indices(d.shape);ey=yy+dy*step;ex=xx+dx*step
                m=(ey>=0)&(ey<d.h)&(ex>=0)&(ex<d.w)
                i=grid[m];j=ey[m]*d.w+ex[m]
                use=valid[i]&valid[j]&(labels[i]!=labels[j])&(np.linalg.norm(d.xyz[i]-d.xyz[j],axis=1)<=s['search_radius_m'])
                for a,b in zip(i[use],j[use]):add(int(a),int(b),'IMAGE_GAP',[int(a+(dy*d.w+dx)*k) for k in range(1,step)])
    boundary=np.zeros(d.shape,bool)
    for dy,dx in ((0,1),(1,0),(0,-1),(-1,0)):
        shifted=np.roll(d.labels,(dy,dx),(0,1));boundary|=shifted!=d.labels
    boundary[[0,-1],:]=True;boundary[:,[0,-1]]=True;boundary &= d.valid
    if 'SPATIAL_NEAR' in routes:
        pix=np.flatnonzero(boundary)
        if len(pix)>1:
            tree=cKDTree(d.xyz[pix]);k=min(s['spatial_knn_limit']+1,len(pix))
            dd,jj=tree.query(d.xyz[pix],k=k,distance_upper_bound=s['search_radius_m'])
            counts=tree.query_ball_point(d.xyz[pix],s['search_radius_m'],return_length=True)
            cuts['spatial_neighbor_occurrences_discarded']=int(np.maximum(counts-k,0).sum())
            for ix in range(len(pix)):
                for v,dist in zip(np.atleast_1d(jj[ix]),np.atleast_1d(dd[ix])):
                    if v<len(pix) and v!=ix and np.isfinite(dist):add(int(pix[ix]),int(pix[v]),'SPATIAL_NEAR')
    if 'CHAIN_REVIEW' in routes:
        graph=defaultdict(set);representative={}
        for a,b in candidates:
            graph[a].add(b);graph[b].add(a)
        for lab in d.counts:representative[lab]=int(np.flatnonzero(labels==lab)[0])
        paths=0;stopped=False
        for start in sorted(graph):
            stack=[(start,)]
            while stack:
                path=stack.pop();tail=path[-1]
                if len(path)>=3 and start<tail:
                    add(representative[start],representative[tail],'CHAIN_REVIEW',path=list(path));paths+=1
                    if paths>=s['chain_path_limit']:stopped=True;break
                if len(path)-1>=s['max_chain_length']:continue
                if len(path)>1 and d.counts[tail]>s['small_fragment_max_points']:continue
                for nxt in sorted(graph[tail],reverse=True):
                    if nxt not in path:stack.append(path+(nxt,))
            if stopped:break
        if stopped:cuts['chain_enumeration_stopped']=1
    mask=d.structure['structure_mask'].ravel() if d.structure else np.zeros(d.n,bool)
    records=[]
    for idx,(key,c) in enumerate(sorted(candidates.items())):
        unique_endpoint_count=len(c.pop('_seen'));c['unique_endpoint_count']=unique_endpoint_count;c['candidate_id']=idx;c['label_sha256']=d.label_hash
        c['patch_count']=len(set(tuple(x['patch_key']) for x in c['endpoints']))
        c['endpoints_retained']=len(c['endpoints']);c['endpoint_scope_truncated']=unique_endpoint_count>s['endpoint_samples_per_pair']
        third=set()
        for e in c['endpoints']:
            gap=e['gap_pixels'];e['gap_observations']=[{'pixel_id':p,'label':int(labels[p]),'valid':bool(valid[p]),
                'structure_masked':bool(mask[p]),'range_m':float(d.ranges[p]) if np.isfinite(d.ranges[p]) else None} for p in gap]
            third.update(int(labels[p]) for p in gap if labels[p]>=0 and labels[p] not in key)
        c['third_fragments']=sorted(third);records.append(c)
    return {'schema_version':SCHEMA,'candidates':records,'search':s,'route_proposal_counts':dict(route_counts),
            'truncation_counts':dict(cuts),'search_truncated':any(cuts.values()),
            'truncation_count_note':'occurrences, not unique pairs; chain stop is a flag because unexplored paths are unknown',
            'boundary_pixels':np.flatnonzero(boundary).tolist(),'missing_routes':['DIRECT_HELD'] if d.edges is None else [],
            'absence_semantics':'No candidate only within recorded search scope; not absence of occlusion or object relation'}
