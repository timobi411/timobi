"""Two hypotheses; history is correlated observation evidence, not an identity oracle."""
from collections import Counter
from pathlib import Path
import numpy as np
from .common import *
from .models import selected,plane_projection,angle

CLASSES={0:'UNKNOWN',1:'NEAR_HYPOTHESIS',2:'FOREGROUND_MAY_OCCLUDE',3:'DEPTH_CONTRADICTION_SOFT',4:'NO_RETURN_UNKNOWN',5:'PROJECTION_UNAVAILABLE'}

def classify(measured,valid,hypothesis,projectable,epsilon):
    measured=np.asarray(measured);valid=np.asarray(valid,bool);r=np.broadcast_to(hypothesis,measured.shape)
    ok=np.broadcast_to(projectable,measured.shape)&np.isfinite(r)&(r>0)
    out=np.full(measured.shape,5,np.uint8);out[ok&~valid]=4
    use=ok&valid&np.isfinite(measured)&(measured>0);delta=measured-r
    out[use&(abs(delta)<=epsilon+1e-12)]=1
    out[use&(delta < -epsilon-1e-12)]=2;out[use&(delta>epsilon+1e-12)]=3
    return out,np.where(use,delta,np.nan)

class HistoryEvidence:
    def __init__(self,d,config,output):
        self.d=d;self.config=config;self.output=Path(output);self.output.mkdir();self.cache={};self.rows=0;self.files=[];self.truncated=0
    def compare(self,model,pixels):
        pixels=sorted(set(int(p) for p in pixels));key=(model['model_id'],tuple(pixels))
        if key in self.cache:return self.cache[key]
        d=self.d;c=self.config;result={'model_id':model['model_id'],'target_pixel_ids':pixels,'status':'UNAVAILABLE',
            'includes_reference':None,'excludes_reference':None,'independent_of_fit':None,'support_files':[],
            'support_rows_omitted':0,'reference_sample_index':d.reference,'class_codes':CLASSES,
            'not_independent_trials':True,'free_space_confirmed':False,'object_identity':'UNKNOWN'}
        if d.history is None or d.rays is None or model['kind']!='PLANE' or not model['quality_pass'] or not pixels:
            self.cache[key]=result;return result
        a=d.history;f=a['valid'].shape[0];yy,xx=np.divmod(pixels,d.w)
        lm=c['local_models'];pred,proj,extrap=plane_projection(model,d.rays['unit_ray'][yy,xx],d.origin,lm['max_extrapolation_m'],lm['min_abs_ray_dot'])
        proj &= d.rays['ray_valid'][yy,xx]
        raw=a['range'][:,yy,xx];valid=a['valid'][:,yy,xx]
        cls,delta=classify(raw,valid,pred[None,:],proj[None,:],c['history']['epsilon_m'])
        sample=np.broadcast_to(np.arange(f)[:,None],cls.shape);pix=np.broadcast_to(np.asarray(pixels)[None,:],cls.shape)
        train={(p['sample_index'],p['pixel_id']) for p in selected(model)['provenance']}
        reuse=np.array([[(i,p) in train for p in pixels] for i in range(f)],bool)
        def stats(mask):
            return {'sample_pixel_denominator':int(mask.sum()),'unique_pixel_denominator':int(np.unique(pix[mask]).size),
                'counts':{name:{'sample_pixel':int(((cls==code)&mask).sum()),'unique_pixel':int(np.unique(pix[(cls==code)&mask]).size)} for code,name in CLASSES.items()},
                'near_distinct_frames':int(np.unique(sample[(cls==1)&mask]).size)}
        result.update(status='AVAILABLE',includes_reference=stats(np.ones(cls.shape,bool)),
            excludes_reference=stats(sample!=d.reference),independent_of_fit=stats((sample!=d.reference)&~reuse),
            fit_sample_reuse_count=int(reuse.sum()),projection_range_m=pred,projection_valid=proj,extrapolation_m=extrap,
            epsilon_m=c['history']['epsilon_m'],epsilon_status='UNCALIBRATED_DIAGNOSTIC',
            near_pixel_ids=np.unique(pix[(cls==1)&(sample!=d.reference)&~reuse]).tolist(),
            near_frame_indices=np.unique(a['frame_index'][sample[(cls==1)&(sample!=d.reference)&~reuse]]).tolist())
        n=cls.size;available=max(0,c['resources']['max_support_rows']-self.rows)
        keep=min(n,available);result['support_rows_omitted']=n-keep;self.truncated+=n-keep
        if keep:
            sn=sample.ravel()[:keep];pn=pix.ravel()[:keep];y,x=np.divmod(pn,d.w)
            raw_present=np.asarray(a.get('intensity_present',np.zeros((f,d.h,d.w),bool)))[sn,y,x] if d.raw_dtype else np.zeros(keep,bool)
            raw_intensity=a['intensity_raw'][sn,y,x] if d.raw_dtype else np.zeros(keep,np.uint16)
            arr={'model_id':np.full(keep,model['model_id'],np.int32),'pixel_id':pn,'sample_index':sn.astype(np.int32),
                'frame_index':a['frame_index'][sn],'time_ns':a['bag_time_ns'][sn],'range_m':raw.ravel()[:keep],
                'range_valid':valid.ravel()[:keep],'hypothesized_range_m':np.broadcast_to(pred,cls.shape).ravel()[:keep],
                'delta_m':delta.ravel()[:keep],'classification':cls.ravel()[:keep],
                'mode_id':d.modes['sample_mode'][sn,y,x] if d.modes else np.full(keep,-1,np.int32),
                'intensity_raw':raw_intensity,'intensity_raw_present':raw_present,'fit_sample_reused':reuse.ravel()[:keep],
                'is_reference':sn==d.reference,'current_history_origin':np.where(sn==d.reference,1,2).astype(np.uint8),
                'is_integrated_source_sample':sn==d.a.get('source_sample_index',np.full(d.shape,-1))[y,x]}
            name=f'support_{len(self.files):06d}.npz';save_npz(self.output/name,**arr);self.files.append(name);result['support_files']=[name];self.rows+=keep
        self.cache[key]=result;return result
    def finish(self):
        write_json(self.output/'manifest.json',{'schema_version':SCHEMA,'files':self.files,'row_count':self.rows,
            'omitted_row_occurrences':self.truncated,'raw_intensity_dtype':self.d.raw_dtype,
            'note':'Each row is model × sample × pixel; repeated model projections are not independent observations'})

def cross_check(left,right,d,config):
    c=config['local_models'];a,b=selected(left),selected(right)
    out={'model_ids':[left['model_id'],right['model_id']],'both_quality_pass':left['quality_pass'] and right['quality_pass'],
         'normal_angle_deg':None,'directions':[],'geometry_supported':False,'reasons':[],
         'convexity':'CONVEXITY_UNKNOWN','normal_sign':'UNKNOWN','fit_evaluation_overlap_pixels':[]}
    if a['kind']!='PLANE' or b['kind']!='PLANE' or not out['both_quality_pass']:
        out['reasons']=['MODEL_UNAVAILABLE'];return out
    out['normal_angle_deg']=angle(a['normal'],b['normal'])
    for src,tgt in ((left,right),(right,left)):
        p=selected(src);q=selected(tgt);ids=q['evaluation_point_ids']
        reused=sorted(set(p['point_ids'])&set(ids));out['fit_evaluation_overlap_pixels']+=reused
        ids=[x for x in ids if x not in set(reused)]
        if len(ids)<3:out['reasons'].append('INSUFFICIENT_DISTINCT_SUPPORT')
        if not ids:out['directions'].append({'evaluation_pixels':[],'residual_m':None,'extrapolation_m':None,'incidence_abs':None});continue
        pts=d.xyz[ids];normal=np.asarray(p['normal']);center=np.asarray(p['center']);res=abs((pts-center)@normal)
        basis=np.asarray(p['basis'])[:,1:];coords=(pts-center)@basis
        extrap=np.linalg.norm(np.maximum(np.maximum(np.asarray(p['support_bounds_min'])[1:]-coords,coords-np.asarray(p['support_bounds_max'])[1:]),0),axis=1)
        rays=pts-d.origin;rays/=np.linalg.norm(rays,axis=1)[:,None];inc=abs(rays@normal)
        out['directions'].append({'evaluation_pixels':ids,'residual_m':quant(res),'residual_max_m':float(res.max()),
            'extrapolation_m':quant(extrap),'extrapolation_max_m':float(extrap.max()),'incidence_abs':quant(inc),'incidence_min_abs':float(inc.min())})
        if (extrap>c['max_extrapolation_m']).any():out['reasons'].append('EXTRAPOLATION_UNSUPPORTED')
        if np.quantile(res,.9)>c['max_residual_p90_m']:out['reasons'].append('HYPOTHESIS_DEPTH_CONTRADICTION')
        if (inc<c['min_abs_ray_dot']).any():out['reasons'].append('MODEL_UNAVAILABLE')
    if out['normal_angle_deg']>c['max_scale_angle_deg']:out['reasons'].append('MULTI_SURFACE')
    out['reasons']=sorted(set(out['reasons']));out['geometry_supported']=not out['reasons'];return out

def evaluate(d,graph,models,history,c):
    result=[];budget=Budget(c);mode,mode_reasons=effective_mode(c)
    neighbors={}
    for cc in graph['candidates']:
        a,b=cc['fragments'];neighbors.setdefault(a,set()).add(b);neighbors.setdefault(b,set()).add(a)
    for cand in graph['candidates']:
        if cand['candidate_id']%100==0:budget.check()
        patches={}
        for e in cand['endpoints']:
            key=tuple(e['patch_key'])
            if key not in patches or e['distance_m']<patches[key]['distance_m']:patches[key]=e
        checks=[];hr=[];reasons=[];modelids=set();part_configurations=[]
        for e in patches.values():
            l,r=(models.get(p) for p in e['pixels']);modelids.update((l['model_id'],r['model_id']))
            check=cross_check(l,r,d,c);checks.append(check)
            lp,rp=selected(l),selected(r);junction={'pixels':e['pixels'],'model_ids':[l['model_id'],r['model_id']],
                'model_kinds':[l['kind'],r['kind']],'endpoint_distance_m':e['distance_m'],
                'unsigned_plane_angle_deg':check['normal_angle_deg'],'line_plane_angle_deg':None,'line_endpoint_to_other_anchor_m':None,
                'convexity':'CONVEXITY_UNKNOWN','contact_identity':'UNKNOWN'}
            for src,tgt,anchor in ((lp,rp,e['pixels'][1]),(rp,lp,e['pixels'][0])):
                if src['kind']=='LINE' and tgt['kind']=='PLANE':
                    direction=np.asarray(src['direction']);normal=np.asarray(tgt['normal'])
                    junction['line_plane_angle_deg']=90-angle(direction,normal)
                    ends=[np.asarray(src['center'])+direction*v for v in (src['support_bounds_min'][2],src['support_bounds_max'][2])]
                    junction['line_endpoint_to_other_anchor_m']=float(min(np.linalg.norm(v-d.xyz[anchor]) for v in ends))
            part_configurations.append(junction)
            targets=set(e['gap_pixels'])|set(selected(l)['evaluation_point_ids'])|set(selected(r)['evaluation_point_ids'])
            for m in (l,r):hr.append(history.compare(m,targets))
        if not checks:reasons.append('MODEL_UNAVAILABLE')
        for x in checks:reasons+=x['reasons']
        geometry=bool(checks) and all(x['geometry_supported'] for x in checks)
        available=[x for x in hr if x['status']=='AVAILABLE']
        contradictions=sum(x['excludes_reference']['counts']['DEPTH_CONTRADICTION_SOFT']['sample_pixel'] for x in available)
        near_pixels=set();near_frames=set();fg=0;near_occurrences=0
        for x in available:
            near_occurrences+=x['independent_of_fit']['counts']['NEAR_HYPOTHESIS']['sample_pixel']
            fg+=x['excludes_reference']['counts']['FOREGROUND_MAY_OCCLUDE']['sample_pixel']
            near_pixels.update(x['near_pixel_ids']);near_frames.update(x['near_frame_indices'])
        if not available:reasons.append('HISTORY_EVIDENCE_UNAVAILABLE')
        if len(near_pixels)<3:reasons.append('INSUFFICIENT_DISTINCT_SUPPORT')
        if contradictions:reasons.append('HYPOTHESIS_DEPTH_CONTRADICTION')
        if cand['third_fragments'] or cand['chains']:reasons.append('THIRD_FRAGMENT_INTERPOSED')
        if graph['search_truncated'] or any(x['support_rows_omitted'] for x in available):reasons.append('SEARCH_TRUNCATED')
        if not d.gates or not d.gates.get('temporal_adoption_allowed'):reasons.append('TEMPORAL_INTEGRATION_HELD')
        if not d.lineage_valid or d.modes is None:reasons.append('INPUT_ALIGNMENT_FAILURE')
        reasons+=mode_reasons
        if not d.config.get('acquisition',{}).get('xyz_sensor_frame_confirmed'):reasons.append('INPUT_ALIGNMENT_FAILURE')
        surface_state='SURFACE_CANDIDATE' if geometry else 'HOLD'
        if any('HYPOTHESIS_DEPTH_CONTRADICTION' in x['reasons'] for x in checks):surface_state='REJECTED_SURFACE_HYPOTHESIS'
        edge_state='POSITIVE_HYPOTHESIS' if geometry else 'HOLD'
        if contradictions or surface_state=='REJECTED_SURFACE_HYPOTHESIS':edge_state='NEGATIVE_HYPOTHESIS'
        history_ok=geometry and bool(available) and contradictions==0 and len(near_pixels)>=3 and bool(near_frames)
        eligible=False
        if mode=='trial_grouping':
            p=c['adoption_thresholds'];measure_ids=np.flatnonzero(np.isin(d.labels.ravel(),cand['fragments'])&d.valid.ravel())
            ages=abs(d.a['source_time_ns'].ravel()[measure_ids]-d.history['bag_time_ns'][d.reference])*1e-9 if d.history is not None else np.array([np.inf])
            numeric=all(x['normal_angle_deg'] is not None and x['normal_angle_deg']<=p['max_normal_angle_deg'] and all(
                y.get('residual_max_m',np.inf)<=p['max_cross_residual_m'] and y.get('extrapolation_max_m',np.inf)<=p['max_extrapolation_m'] for y in x['directions']) for x in checks)
            eligible=bool(history_ok and numeric and len(near_pixels)>=p['min_distinct_support_pixels'] and len(near_frames)>=p['min_nonreference_frames']
                and contradictions<=p['max_depth_contradictions'] and len(patches)>=p['min_patch_count']
                and set(cand['routes'])&set(p['eligible_routes']) and np.max(ages,initial=0)<=p['max_age_s']
                and not any(x in reasons for x in ('THIRD_FRAGMENT_INTERPOSED','SEARCH_TRUNCATED','TEMPORAL_INTEGRATION_HELD','INPUT_ALIGNMENT_FAILURE')))
            if eligible:edge_state='TEST_ELIGIBLE'
        direct=cand['direct_held_edges'];multi_contact=len({p for e in direct for p in e['pixels']})>=4
        part_reasons=['IDENTITY_UNRESOLVED','NORMAL_SIGN_UNKNOWN','OBJECT_PART_PROFILE_UNAVAILABLE']
        if cand['third_fragments']:part_reasons.append('THIRD_FRAGMENT_INTERPOSED')
        result.append({'candidate_id':cand['candidate_id'],'fragments':cand['fragments'],'routes':sorted(cand['routes']),
            'state':'RELATION_ONLY','edge_state':edge_state,'object_identity':'UNKNOWN','model_ids':sorted(modelids),
            'H_SURFACE_CONTINUATION':{'state':surface_state,'reasons':sorted(set(reasons+['IDENTITY_UNRESOLVED'])),
                'score_ordinal':[int(geometry),int(history_ok),len(patches),len(near_pixels)],'score_is_probability':False,
                'checks':checks,'geometry_supported':geometry,'history_consistent':history_ok,'test_eligible':eligible},
            'H_OBJECT_PART':{'state':'PART_ASSOCIATION_CANDIDATE' if multi_contact or geometry else 'HOLD',
                'reasons':part_reasons,'test_eligible':False,'multi_point_contact_band':multi_contact,
                'line_plane_junction_model_ids':[i for i in modelids if models.records[i]['kind']=='LINE'],
                'score_ordinal':[int(multi_contact),int(bool(cand['chains']))],'score_is_probability':False,
                'local_junction_configurations':part_configurations,
                'alternative_parents':{str(lab):sorted(neighbors.get(lab,set())-set(cand['fragments'])) for lab in cand['fragments']},
                'junction_interpretation':'Configuration candidate only; no trained object-part model'},
            'measured':{'near_distinct_pixels':len(near_pixels),'near_distinct_frames':len(near_frames),
                'near_sample_model_pixel_occurrences':near_occurrences,'foreground_sample_model_pixel_occurrences':fg,
                'depth_contradiction_sample_model_pixel_occurrences':contradictions,'history':hr},
            'hypothesized':{'model_ids':sorted(modelids),'measured_points_generated':0},
            'third_fragments':cand['third_fragments'],'chains':cand['chains'],
            'provenance':{'correspondence':'pixel_correspondence.npz','edge_source':getattr(d,'edge_path',None),
                'label_sha256':d.label_hash,'source_condition':str(d.path)}})
    history.finish()
    return {'schema_version':SCHEMA,'relations':result,'effective_mode':mode,'forced_mode_reasons':mode_reasons,
        'history_support_rows_omitted':history.truncated,'object_part_adoption_available':False}
