"""Annotations are read only here, after inference; object and part truth are separate."""
from collections import Counter
from itertools import combinations
import numpy as np
from .common import *

def ground_truth_conflict(pairs):
    parent={}
    def root(x):
        parent.setdefault(x,x)
        while parent[x]!=x:x=parent[x]
        return x
    for p in pairs:
        if p['truth']=='confirmed_same_object':
            a,b=map(root,p['fragments']);parent[a]=b
    return any(p['truth']=='confirmed_different_object' and root(p['fragments'][0])==root(p['fragments'][1]) for p in pairs)

def metrics(d,graph,labels,annotation=None):
    pairs=(annotation or {}).get('pairs',[]);available=set(d.counts);valid=[];excluded=[]
    for p in pairs:
        if len(p['fragments'])!=2 or p['fragments'][0]==p['fragments'][1] or p['truth'] not in ('confirmed_same_object','confirmed_different_object','unclear'):raise ValueError('Annotation pair schema')
        (valid if set(p['fragments'])<=available else excluded).append(p)
    known=[p for p in valid if p['truth']!='unclear'];conflict=ground_truth_conflict(known)
    candidates={tuple(sorted(x['fragments'])) for x in graph['candidates']}
    mapping={k:int(labels.ravel()[np.flatnonzero(d.labels.ravel()==k)[0]]) for k in d.counts}
    same=[p for p in known if p['truth']=='confirmed_same_object'];adopted=[p for p in known if mapping[p['fragments'][0]]==mapping[p['fragments'][1]]]
    correct=[p for p in adopted if p['truth']=='confirmed_same_object'];held=[p for p in known if p not in adopted]
    discovered=[p for p in same if tuple(sorted(p['fragments'])) in candidates]
    denom={'annotated_pairs':len(known),'confirmed_same_pairs':len(same),'annotated_adopted_pairs':len(adopted),
        'unclear_pairs':len(valid)-len(known),'excluded_missing_fragment_pairs':len(excluded),
        'all_possible_fragment_pairs':len(d.counts)*(len(d.counts)-1)//2,'candidate_pairs':len(candidates)}
    weights=lambda ps:sum(d.counts[p['fragments'][0]]+d.counts[p['fragments'][1]] for p in ps)
    def rate(a,b):return a/b if b and not conflict else None
    out={'status':'GT_CONFLICT' if conflict else 'PARTIALLY_ANNOTATED' if known else 'UNAVAILABLE',
        'denominators':denom,'candidate_recall':rate(len(discovered),len(same)),'precision':rate(len(correct),len(adopted)),
        'recall':rate(len(correct),len(same)),'hold_rate':rate(len(held),len(known)),
        'point_weighted_precision':rate(weights(correct),weights(adopted)),'point_weighted_recall':rate(weights(correct),weights(same)),
        'point_weight_definition':'sum of both original fragment sizes per annotated pair; pairs can overlap',
        'unannotated_candidate_pairs':sum(k not in {tuple(sorted(p['fragments'])) for p in known} for k in candidates),
        'group_point_metrics':None,'different_tabletop_merges':None,'floor_merges':None,
        'cannot_evaluate':['unseen backside/leg reconstruction','independent performance on development exp01/exp02']}
    instance=(annotation or {}).get('instance_id_by_pixel');parts=(annotation or {}).get('part_by_pixel')
    if instance is not None:
        gt=np.asarray(instance)
        if gt.shape!=d.shape:raise ValueError('GT pixel shape mismatch')
        labeled=d.valid&(gt>=0);impure=0;wrong=0;annotated=0;groups=0
        for lab in np.unique(labels[d.valid]):
            m=d.valid&(labels==lab)&(gt>=0);counts=np.unique(gt[m],return_counts=True)[1]
            if counts.size:
                groups+=1;annotated+=int(counts.sum());wrong+=int(counts.sum()-counts.max());impure+=len(counts)>1
        fragment_known=0;fragment_impurity=0;fragment_mixed=0
        for lab in np.unique(labels[d.valid]):
            member_objects=[]
            for frag in np.unique(d.labels[d.valid&(labels==lab)]):
                objects=np.unique(gt[d.valid&(d.labels==frag)&(gt>=0)])
                if len(objects)==1:member_objects.append(int(objects[0]))
                elif len(objects)>1:fragment_mixed+=1
            if member_objects:
                counts=np.unique(member_objects,return_counts=True)[1];fragment_known+=int(counts.sum());fragment_impurity+=int(counts.sum()-counts.max())
        out['group_point_metrics']={'known_single_instance_fragments':fragment_known,'mixed_original_fragments':fragment_mixed,
            'fragment_weighted_impurity_rate':rate(fragment_impurity,fragment_known),'known_points':annotated,'unknown_points':int((d.valid&(gt<0)).sum()),
            'annotated_groups':groups,'mixed_groups':impure,'minority_point_count':wrong,
            'impurity_rate':None if conflict else rate(wrong,annotated),'instance_unknown_value':-1}
        if parts is not None:
            part=np.asarray(parts)
            if part.shape!=d.shape:raise ValueError('Part GT shape mismatch')
            floors=0;tables=0
            for lab in np.unique(labels[d.valid]):
                m=d.valid&(labels==lab)&(gt>=0);objects=set(gt[m].tolist())
                floors+=len(objects)>1 and np.any(part[m]=='floor')
                tabletop_gt=set(gt[m&(part=='tabletop')].tolist());tables+=len(tabletop_gt)>1
            out['different_tabletop_merges']=None if conflict else int(tables);out['floor_merges']=None if conflict else int(floors)
    return out
