"""Local models are hypotheses of existing measured support, never new points."""
from collections import deque
import numpy as np
from scipy.spatial import cKDTree
from .common import *

def angle(a,b):return float(np.degrees(np.arccos(np.clip(abs(np.dot(a,b)),0,1))))

def fit(points,c):
    p=np.asarray(points,float);n=len(p)
    result={'kind':'UNKNOWN','center':p.mean(axis=0).tolist() if n else None,'normal':None,'direction':None,
            'eigenvalues':None,'residual_p50_m':None,'residual_p90_m':None,'span_m':None,'quality_pass':False,'reasons':[]}
    if n<3:result['reasons']=['MODEL_UNAVAILABLE','INSUFFICIENT_DISTINCT_SUPPORT'];return result
    center=p.mean(axis=0);ev,U=np.linalg.eigh((p-center).T@(p-center)/n);ev=np.maximum(ev,0)
    projected=(p-center)@U;span=np.ptp(projected,axis=0)
    result.update(eigenvalues=ev.tolist(),span_m=span.tolist(),basis=U.tolist(),support_bounds_min=projected.min(axis=0).tolist(),support_bounds_max=projected.max(axis=0).tolist())
    if ev[2]<=1e-16:result['reasons']=['MODEL_DEGENERATE'];return result
    if ev[1]/ev[2]<c['line_eigen_ratio']:
        result['kind']='LINE';result['direction']=U[:,2].tolist();res=np.linalg.norm(projected[:,:2],axis=1)
    elif ev[1]>1e-16 and ev[0]/ev[1]<=c['plane_eigen_ratio']:
        result['kind']='PLANE';result['normal']=U[:,0].tolist();res=abs(projected[:,0])
    else:
        result['reasons']=['MODEL_UNSTABLE','MULTI_SURFACE'];return result
    result['residual_p50_m'],result['residual_p90_m']=np.quantile(res,[.5,.9]).tolist()
    reasons=[]
    if n<c['min_points']:reasons.append('INSUFFICIENT_DISTINCT_SUPPORT')
    if result['kind']=='PLANE' and span[1]<c['min_minor_span_m']:reasons.append('MODEL_DEGENERATE')
    if result['kind']=='LINE' and span[2]<c['min_minor_span_m']:reasons.append('MODEL_DEGENERATE')
    if result['residual_p90_m']>c['max_residual_p90_m']:reasons.append('MODEL_UNSTABLE')
    result['quality_pass']=not reasons;result['reasons']=reasons;return result

class Models:
    def __init__(self,d,config):self.d=d;self.config=config;self.cache={};self.records=[]
    def get(self,pixel):
        if pixel in self.cache:return self.records[self.cache[pixel]]
        d=self.d;c=self.config['local_models'];y,x=divmod(pixel,d.w);label=int(d.labels[y,x]);scales=[]
        for radius in c['scales_px']:
            seen={pixel};todo=deque([pixel]);neighbors=[];crossings=0
            while todo:
                p=todo.popleft();neighbors.append(p)
                for q in d.adjacency[p]:
                    yy,xx=divmod(q,d.w)
                    if q in seen or max(abs(yy-y),abs(xx-x))>radius or int(d.labels[yy,xx])!=label:continue
                    if abs(d.ranges[p]-d.ranges[q])>d.config['temporal']['mode_gap_m']:crossings+=1;continue
                    seen.add(q);todo.append(q)
            neighbors=sorted(neighbors)
            # Pixel-local mode IDs have no cross-pixel semantic equivalence. Require one observed mode per pixel.
            multi=[]
            if d.modes is not None:
                for p in neighbors:
                    yy,xx=divmod(p,d.w);ids=d.modes['sample_mode'][:,yy,xx];ids=ids[ids>=0]
                    if len(np.unique(ids))>1:multi.append(p)
            support=[p for p in neighbors if p not in set(multi)]
            # Deterministic held-out pixels are not used in fitting; sides never share pixels.
            evaluation=support[::4] if len(support)>=8 else []
            train=[p for p in support if p not in set(evaluation)]
            model=fit(d.xyz[train],c);model.update(radius_px=radius,point_ids=train,evaluation_point_ids=evaluation,
                excluded_multi_mode_pixels=multi,range_discontinuities_excluded=crossings,distinct_pixels=len(train),
                provenance=d.provenance(train),normal_sign='UNKNOWN',convexity='CONVEXITY_UNKNOWN',
                normalization='unit vectors; normal sign deliberately unoriented')
            if d.modes is None:model['reasons'].append('MODE_UNAVAILABLE');model['quality_pass']=False
            if d.edges is None:model['reasons'].append('CONNECTIVITY_UNAVAILABLE');model['quality_pass']=False
            if multi:model['reasons'].append('MULTI_SURFACE');model['quality_pass']=False
            if len(train)>1:model['point_spacing_m']=quant(cKDTree(d.xyz[train]).query(d.xyz[train],k=2)[0][:,1])
            else:model['point_spacing_m']=None
            model['distinct_samples']=len({p['sample_index'] for p in model['provenance'] if p['sample_index']>=0})
            model['distinct_frames']=len({p['frame_index'] for p in model['provenance'] if p['frame_index'] is not None})
            model['within_fit_holdout_residual_m']=None
            if model['kind']=='PLANE' and evaluation:
                model['within_fit_holdout_residual_m']=quant(abs((d.xyz[evaluation]-model['center'])@np.asarray(model['normal'])))
            scales.append(model)
        last=scales[-1];changes=[]
        for a,b in zip(scales,scales[1:]):
            key='normal' if a['kind']==b['kind']=='PLANE' else 'direction' if a['kind']==b['kind']=='LINE' else None
            changes.append(angle(a[key],b[key]) if key else None)
        stable=bool(changes) and all(v is not None and v<=c['max_scale_angle_deg'] for v in changes)
        if not stable:last['quality_pass']=False;last['reasons'].append('MODEL_UNSTABLE')
        result={'model_id':len(self.records),'anchor_pixel':int(pixel),'fragment':label,'scales':scales,
                'selected_scale_index':len(scales)-1,'scale_angles_deg':changes,'scale_stable':stable,
                'quality_pass':last['quality_pass'],'kind':last['kind'],'reasons':sorted(set(last['reasons']))}
        self.cache[pixel]=len(self.records);self.records.append(result);return result

def selected(m):return m['scales'][m['selected_scale_index']]

def plane_projection(m,rays,origin,max_extrap,min_dot):
    """Infinite-plane intersection followed by finite training-footprint domain gate."""
    p=selected(m);u=np.asarray(rays);n=np.asarray(p['normal']);center=np.asarray(p['center'])
    den=u@n;distance=np.divide(np.dot(center-origin,n),den,out=np.full(len(u),np.nan),where=abs(den)>=min_dot)
    pts=origin+distance[:,None]*u
    basis=np.asarray(p['basis'])[:,1:];coords=(pts-center)@basis
    # Conservative centered bounding box: at most observed span/2, not an unbounded plane.
    low=np.asarray(p['support_bounds_min'])[1:];high=np.asarray(p['support_bounds_max'])[1:]
    extrap=np.linalg.norm(np.maximum(np.maximum(low-coords,coords-high),0),axis=1)
    good=np.isfinite(distance)&(distance>0)&(abs(den)>=min_dot)&(extrap<=max_extrap)
    return distance,good,extrap

def floor_context(d,pixels):
    meta=d.structure_meta;planes=(meta or {}).get('planes');out={'status':'UNAVAILABLE','reason':'FLOOR_CONTEXT_UNKNOWN',
        'absolute_distance_m':None,'signed_height_m':None,'finite_footprint_inside':None,'finite_footprint_outside':None,
        'model_id':None,'model_residual_m':None,'normal_orientation':None,'per_model':[],
        'retained_point_count':len(pixels),'removed_original_fragment_count':None,
        'removal_count_reason':'Removed pixels have no surviving fragment membership; no invented assignment'}
    floor=[(i,e) for i,e in enumerate(planes or []) if e.get('role')=='floor']
    for i,e in floor:
        model=np.asarray(e['plane']['model'],float);norm=np.linalg.norm(model[:3])
        if not np.isfinite(norm) or norm<=0:continue
        model=model/norm;support=np.asarray(e['plane']['points'],float)
        if support.ndim!=2 or len(support)<3:continue
        center=support.mean(axis=0);n=model[:3];_,_,vh=np.linalg.svd(support-center,full_matrices=False);basis=vh[:2].T
        uv=(support-center)@basis;query=(d.xyz[pixels]-center)@basis;margin=e.get('footprint_margin_m',0)
        inside=((query>=uv.min(axis=0)-margin)&(query<=uv.max(axis=0)+margin)).all(axis=1)
        height=d.xyz[pixels]@n+model[3];sensor_side=float(d.origin@n+model[3]);oriented=abs(sensor_side)>1e-8
        signed=height*(1 if sensor_side>0 else -1) if oriented else None
        out['per_model'].append({'model_id':i,'absolute_distance_m':quant(abs(height)),'signed_height_m':quant(signed) if oriented else None,
            'finite_footprint_inside':int(inside.sum()),'finite_footprint_outside':int((~inside).sum()),
            'model_residual_m':quant(abs(support@n+model[3])),'normalized_coefficients':model,
            'normal_orientation':'toward declared sensor origin' if oriented else 'UNKNOWN',
            'orientation_evidence':{'sensor_origin_xyz':d.origin,'signed_sensor_distance_m':sensor_side},
            'height_scope':'signed plane distance, not gravity height or leg identity'})
    if len(out['per_model'])==1:
        r=out['per_model'][0];out.update(r);out['status']='AVAILABLE' if not r['finite_footprint_outside'] else 'PARTIAL_OUTSIDE_FOOTPRINT'
        out['reason']=None if out['status']=='AVAILABLE' else 'FLOOR_CONTEXT_UNKNOWN'
    elif len(out['per_model'])>1:out['status']='AMBIGUOUS_MULTIPLE_FLOORS'
    return out

def inventory(d,graph):
    b=set(graph['boundary_pixels']);records=[]
    for lab,n in sorted(d.counts.items()):
        pix=np.flatnonzero(d.valid.ravel()&(d.labels.ravel()==lab));p=d.xyz[pix]
        records.append({'fragment_id':lab,'point_count':n,'boundary_pixel_count':sum(int(v) in b for v in pix),
            'pixel_ids':pix,'current_pixels':int((d.a['source_type'].ravel()[pix]==1).sum()),
            'history_pixels':int((d.a['source_type'].ravel()[pix]==2).sum()),
            'source_time_ns':{'min':int(d.a['source_time_ns'].ravel()[pix].min()),'max':int(d.a['source_time_ns'].ravel()[pix].max())},
            'center_measured':p.mean(axis=0),'extent_axis_aligned_m':np.ptp(p,axis=0),'floor':floor_context(d,pix),
            'object_identity':'UNKNOWN'})
    return {'schema_version':SCHEMA,'fragments':records,'floor_masked_pixels_all':int(d.structure['structure_mask'].sum()) if d.structure else None}
