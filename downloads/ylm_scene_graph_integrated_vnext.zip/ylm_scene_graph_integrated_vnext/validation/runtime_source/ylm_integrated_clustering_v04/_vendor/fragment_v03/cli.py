import argparse,json
from .runner import inspect,diagnose,verify,compare,export
from .common import clean

def main():
    p=argparse.ArgumentParser(description='YLM-X001 v0.3 conservative postprocessing')
    sub=p.add_subparsers(dest='command',required=True)
    q=sub.add_parser('inspect-input');q.add_argument('--root',required=True);q.add_argument('--out',required=True);q.add_argument('--cases',nargs='+')
    q=sub.add_parser('diagnose-all');q.add_argument('--manifest',required=True);q.add_argument('--out',required=True);q.add_argument('--config');q.add_argument('--annotations-dir')
    q=sub.add_parser('verify');q.add_argument('--results',required=True);q.add_argument('--offline',action='store_true',help='Skip original source recheck, explicitly recorded')
    q=sub.add_parser('compare');q.add_argument('--results',required=True)
    q=sub.add_parser('export');q.add_argument('--results',required=True);q.add_argument('--out',required=True);q.add_argument('--pcd',action='store_true')
    a=p.parse_args()
    if a.command=='inspect-input':r=inspect(a.root,a.out,a.cases)
    elif a.command=='diagnose-all':r=diagnose(a.manifest,a.out,a.config,a.annotations_dir)
    elif a.command=='verify':
        r=verify(a.results,not a.offline);print(json.dumps(clean(r),ensure_ascii=False,indent=2));return 0 if r['status']=='PASS' else 1
    elif a.command=='compare':r=compare(a.results)
    else:r=export(a.results,a.out,a.pcd)
    print(json.dumps(clean(r),ensure_ascii=False,indent=2));return 0
