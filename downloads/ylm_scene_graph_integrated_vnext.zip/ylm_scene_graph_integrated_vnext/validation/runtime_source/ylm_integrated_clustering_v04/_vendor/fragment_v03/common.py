"""Serialization, immutable input digests and explicit experimental configuration."""
from pathlib import Path
import hashlib,json,math,os
import numpy as np
VERSION='0.3.0'
SCHEMA='ylm_x001_v03'

def clean(x):
    if isinstance(x,np.ndarray):return clean(x.tolist())
    if isinstance(x,np.generic):return clean(x.item())
    if isinstance(x,float) and not math.isfinite(x):return None
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple,set)):return [clean(v) for v in x]
    if isinstance(x,Path):return str(x)
    return x

def read_json(p):
    return json.loads(Path(p).read_text(encoding='utf8'),parse_constant=lambda x:(_ for _ in ()).throw(ValueError('Nonfinite JSON '+x)))

def write_json(p,a):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.partial')
    tmp.write_text(json.dumps(clean(a),ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n',encoding='utf8');os.replace(tmp,p)

def npz(p):
    with np.load(p,allow_pickle=False) as a:return {k:a[k] for k in a.files}

def save_npz(p,**a):
    if any(np.asarray(v).dtype.hasobject for v in a.values()):raise ValueError('Object array prohibited')
    with Path(p).with_suffix('.partial').open('wb') as f:np.savez_compressed(f,**a)
    os.replace(Path(p).with_suffix('.partial'),p)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()

def array_sha(a):
    a=np.ascontiguousarray(a);h=hashlib.sha256();h.update(str(a.dtype).encode());h.update(str(a.shape).encode());h.update(a.tobytes());return h.hexdigest()

def quant(a):
    a=np.asarray(a);a=a[np.isfinite(a)]
    return dict(zip(('p05','p50','p95'),np.quantile(a,[.05,.5,.95]).tolist())) if len(a) else None

def default_config():
    return {'schema_version':SCHEMA,'mode':'diagnostic_only','candidate_search':{
        'candidate_routes':['DIRECT_HELD','IMAGE_GAP','SPATIAL_NEAR','CHAIN_REVIEW'],
        'search_radius_m':None,'image_gap_limit_px':None,'candidate_limit':10000,
        'endpoint_samples_per_pair':64,'spatial_knn_limit':24,'max_chain_length':3,
        'chain_path_limit':20000,'small_fragment_max_points':49,'patch_grid_px':4},
        'local_models':{'types':['plane','line'],'scales_px':[2,4], 'min_points':6,
        'min_minor_span_m':.02,'max_residual_p90_m':.03,'plane_eigen_ratio':.25,
        'line_eigen_ratio':.02,'max_scale_angle_deg':25.,'min_abs_ray_dot':.1,
        'max_extrapolation_m':.05,'parameter_status':'legacy_diagnostic_unvalidated',
        'source':'v0.2 diagnostic gates; multiscale and line gates experimental'},
        'history':{'epsilon_m':.03,'epsilon_status':'legacy_uncalibrated_comparison','chunk_pixels':256},
        'resources':{'max_working_mb':2048,'max_condition_seconds':1800,'max_support_rows':2000000},
        'adoption_thresholds':None,'profile_locked':False,'profile_source':None,
        'profile_sha256':None,'automatic_trial_grouping':False,
        'visibility_model_verified':False,'intensity_used_for_adoption':False,'generate_unmeasured_points':False,
        'object_part_adoption_enabled':False}

def validate_config(c):
    for key in ('generate_unmeasured_points','intensity_used_for_adoption','object_part_adoption_enabled'):
        if c.get(key) is not False:raise ValueError(key+' must remain false in v0.3')
    if c['mode'] not in ('diagnostic_only','trial_grouping'):raise ValueError('Unknown mode')
    s=c['candidate_search']
    for k in ('candidate_limit','endpoint_samples_per_pair','spatial_knn_limit','max_chain_length','chain_path_limit','patch_grid_px'):
        if not isinstance(s[k],int) or s[k]<1:raise ValueError('Positive integer required: '+k)
    if s['max_chain_length']>5:raise ValueError('Max chain length supported is 5')
    for k in ('search_radius_m','image_gap_limit_px'):
        if s[k] is not None and s[k]<=0:raise ValueError('Invalid search bound '+k)
    if c['history']['epsilon_m']<=0:raise ValueError('epsilon must be positive')
    return c

def effective_mode(c):
    p=c.get('adoption_thresholds')
    needed=('max_cross_residual_m','max_normal_angle_deg','max_extrapolation_m','min_distinct_support_pixels',
            'min_nonreference_frames','max_depth_contradictions','eligible_routes','max_age_s','min_patch_count')
    if c['mode']!='trial_grouping':return 'diagnostic_only',['THRESHOLDS_NOT_CALIBRATED'] if p is None else []
    good=isinstance(p,dict) and all(p.get(k) is not None for k in needed)
    if good:
        raw=json.dumps(p,sort_keys=True,separators=(',',':')).encode()
        good=(c['profile_locked'] and c['profile_source'] and c['profile_sha256']==hashlib.sha256(raw).hexdigest()
              and c['automatic_trial_grouping'] and p.get('calibrated') is True and p.get('evaluation_record'))
        good=good and all(isinstance(p[k],(int,float)) and np.isfinite(p[k]) and p[k]>=0 for k in needed if k!='eligible_routes')
        good=good and p['min_distinct_support_pixels']>=3 and p['min_nonreference_frames']>=1 and p['min_patch_count']>=1
        good=good and bool(p['eligible_routes']) and set(p['eligible_routes'])<=set(c['candidate_search']['candidate_routes'])
    return ('trial_grouping',[]) if good else ('diagnostic_only',['THRESHOLDS_NOT_CALIBRATED'])

class Budget:
    def __init__(self,c):
        import time
        self.start=time.monotonic();self.c=c['resources']
    def check(self):
        import time,resource
        if time.monotonic()-self.start>self.c['max_condition_seconds']:raise TimeoutError('Processing time budget exceeded')
        if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024>self.c['max_working_mb']:raise MemoryError('Working memory budget exceeded')
