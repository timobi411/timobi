"""Read-only v0.2 adapter. A malformed optional input fails; absence stays unavailable."""
from pathlib import Path
import numpy as np
from .common import *

class AlignmentError(ValueError):pass

class Input:
    def __init__(self,path,expected=None,max_mb=2048):
        self.max_mb=max_mb;self.path=Path(path).resolve();self.window=self.path.parent;self.files={};self.availability={}
        self.input_run_manifest=next((p/'run_manifest.json' for p in (self.path,*self.path.parents) if (p/'run_manifest.json').exists()),None)
        if self.input_run_manifest is None:raise AlignmentError('Required input run manifest missing')
        self.json(self.input_run_manifest,True)
        self.a=self.load(self.path/'pixel_correspondence.npz',True)
        self.config=self.json(self.path/'config.json',True)
        self.labels=self.a['labels'];self.shape=self.labels.shape
        if len(self.shape)!=2:raise AlignmentError('labels must be organized H,W')
        self.h,self.w=self.shape;self.n=self.labels.size
        for k in ('valid','source_type','source_time_ns','pixel_row','pixel_column'):
            if k not in self.a or self.a[k].shape!=self.shape:raise AlignmentError('Required correspondence field '+k)
        if self.a['xyz'].shape!=self.shape+(3,) or self.a['valid'].dtype!=bool or self.labels.dtype.kind not in 'iu':raise AlignmentError('XYZ/valid/labels schema')
        for k in ('source_type','source_time_ns','pixel_row','pixel_column'):
            if self.a[k].dtype.kind not in 'iu':raise AlignmentError('Integer correspondence required '+k)
        self.valid=self.a['valid'] & (self.labels>=0);self.xyz=self.a['xyz'].reshape(-1,3)
        for k,grid in zip(('pixel_row','pixel_column'),np.indices(self.shape)):
            if not np.array_equal(self.a[k],grid):raise AlignmentError('Pixel coordinate mismatch')
        if np.any((self.labels>=0)&~self.a['valid']):raise AlignmentError('Labeled invalid measurement')
        self.origin=np.asarray(self.config.get('acquisition',{}).get('sensor_origin_xyz'),float)
        if self.origin.shape!=(3,) or not np.isfinite(self.origin).all():raise AlignmentError('Sensor origin unavailable')
        v=self.valid.ravel();rng=np.linalg.norm(self.xyz-self.origin,axis=1)
        if not np.isfinite(self.xyz[v]).all() or (rng[v]<=0).any():raise AlignmentError('Zero/nonfinite valid XYZ')
        self.ranges=rng;self.label_hash=array_sha(self.labels)
        if expected and expected.get('label_sha256')!=self.label_hash:raise AlignmentError('Manifest label hash mismatch')
        old=self.json(self.path/'fragment_relations.json')
        if old and old.get('label_sha256') and old['label_sha256']!=self.label_hash:raise AlignmentError('v0.2 relation label hash mismatch')
        self.old_relations=old
        self.history,self.history_meta=self.store(self.window/'history')
        self.modes,self.modes_meta=self.store(self.window/'surface_mode_samples')
        self.surface_modes=self.load(self.window/'surface_modes.npz')
        self.rays=self.load(self.window/'ray_mapping.npz')
        self.structure=self.load(self.window/'structure_mask.npz')
        self.structure_meta=self.json(self.window/'structure_metadata.json')
        self.gates=self.json(self.window/'temporal_gates.json')
        self.point_states=self.load(self.path/'point_states.npz')
        self.edges=None
        for name in ('edges.npz','C_edges.npz'):
            if (self.path/name).exists():self.edges=self.load(self.path/name);self.edge_path=name;break
        self.reference=None;self.lineage_valid=False;self.raw_dtype=None;self.frame_name=None
        if self.history is not None:self.validate_history()
        self.validate_optional()
        self.adjacency=[[] for _ in range(self.n)]
        if self.edges is not None:
            e=self.edges
            for k in ('pixel_i','pixel_j','accepted','hold_reason'):
                if k not in e:raise AlignmentError('Edge schema missing '+k)
            i,j=e['pixel_i'],e['pixel_j']
            if i.shape!=j.shape or np.any(i<0) or np.any(j<0) or np.any(i>=self.n) or np.any(j>=self.n):raise AlignmentError('Edge endpoints')
            if 'final_component_i' in e and not np.array_equal(e['final_component_i'],self.labels.ravel()[i]):raise AlignmentError('Edge labels mismatch')
            for x,y in zip(i[e['accepted']],j[e['accepted']]):
                if self.labels.ravel()[x]!=self.labels.ravel()[y]:raise AlignmentError('Accepted edge crosses labels')
                self.adjacency[x].append(int(y));self.adjacency[y].append(int(x))
        self.counts={int(k):int(n) for k,n in zip(*np.unique(self.labels[self.valid],return_counts=True))}
        self.availability.update(history=self.history is not None,raw_intensity=self.raw_dtype is not None,
            edges=self.edges is not None,modes=self.modes is not None,rays=self.rays is not None,
            floor_models=bool(self.structure_meta and self.structure_meta.get('planes')),lineage_valid=self.lineage_valid)
        if expected:
            for p,digest in expected.get('source_hashes',{}).items():
                q=self.path/p
                if not q.exists() or sha(q)!=digest:raise AlignmentError('Source hash mismatch '+p)
        estimate=sum(a.nbytes for a in self.a.values())+self.n*256
        if estimate>max_mb*1024**2:raise MemoryError('Input working-set estimate exceeds configured limit')
    def mark(self,p):self.files[str(p.resolve())]=sha(p)
    def json(self,p,required=False):
        if not p.exists():
            if required:raise AlignmentError('Missing '+str(p))
            return None
        self.mark(p);return read_json(p)
    def load(self,p,required=False):
        if not p.exists():
            if required:raise AlignmentError('Missing '+str(p))
            return None
        import zipfile
        with zipfile.ZipFile(p) as archive:
            if sum(v.file_size for v in archive.infolist())>self.max_mb*1024**2/2:raise MemoryError('NPZ decompressed size exceeds bounded working budget')
        self.mark(p);return npz(p)
    def store(self,p):
        meta=self.json(p/'manifest.json')
        if meta is None:return None,None
        result={}
        for k,v in meta['arrays'].items():
            q=(p/v['file']).resolve()
            if not q.is_relative_to(p.resolve()):raise AlignmentError('Unsafe history path')
            self.mark(q)
            if self.files[str(q)]!=v['sha256']:raise AlignmentError('History hash '+k)
            a=np.load(q,mmap_mode='r',allow_pickle=False)
            if list(a.shape)!=v['shape'] or a.dtype.str!=v['dtype']:raise AlignmentError('History dtype/shape '+k)
            result[k]=a
        return result,meta
    def validate_history(self):
        a=self.history
        if 'valid' not in a or a['valid'].ndim!=3:raise AlignmentError('Explicit history frame axis required')
        f,h,w=a['valid'].shape
        if (h,w)!=self.shape:raise AlignmentError('History grid mismatch')
        for k in ('range','invalid_reason'):
            if k not in a or a[k].shape!=(f,h,w):raise AlignmentError('History shape '+k)
        if a['xyz'].shape!=(f,h,w,3) or a['valid'].dtype!=bool:raise AlignmentError('History xyz/valid schema')
        for k in ('frame_index','bag_time_ns','header_time_ns','layout_id','frame_id','setting_id'):
            if k not in a or a[k].shape!=(f,):raise AlignmentError('History metadata '+k)
        for k in ('frame_index','bag_time_ns','header_time_ns'):
            if a[k].dtype.kind not in 'iu' or np.any(np.diff(a[k])<=0):raise AlignmentError('Nonincreasing integer frame/time '+k)
        for k in ('layout_id','frame_id','setting_id'):
            if len(np.unique(a[k]))!=1:raise AlignmentError('Changing '+k)
        self.frame_name=str(a['frame_id'][0]);self.reference=int(a['reference_sample_index'])
        if not 0<=self.reference<f:raise AlignmentError('Reference index invalid')
        if self.history_meta.get('reference_frame_index',int(a['frame_index'][self.reference]))!=int(a['frame_index'][self.reference]):raise AlignmentError('Reference frame mismatch')
        for y in range(0,h,8):
            sl=np.s_[:,y:y+8];v=a['valid'][sl];r=a['range'][sl]
            actual=np.linalg.norm(a['xyz'][sl].astype(float)-self.origin,axis=-1)
            if not np.isfinite(actual[v]).all() or (r[v]<=0).any() or not np.allclose(actual[v],r[v],atol=1e-5,rtol=0):raise AlignmentError('History range/XYZ')
        if 'intensity_raw' in a:
            raw=a['intensity_raw'];self.raw_dtype=raw.dtype.str
            if raw.shape!=(f,h,w) or raw.dtype.kind not in 'iu':raise AlignmentError('Original integer intensity required')
            for y in range(0,h,8):
                if 'intensity' in a and not np.array_equal(raw[:,y:y+8].astype(float),a['intensity'][:,y:y+8],equal_nan=True):raise AlignmentError('Raw intensity changed')
        required=('source_sample_index','source_frame_index')
        if all(k in self.a for k in required):
            pix=np.flatnonzero(self.valid);sample=self.a['source_sample_index'].ravel()[pix]
            if (sample<0).any() or (sample>=f).any():raise AlignmentError('Source sample out of bounds')
            yy,xx=np.divmod(pix,w)
            if not a['valid'][sample,yy,xx].all():raise AlignmentError('Source measurement invalid')
            if not np.array_equal(self.xyz[pix],a['xyz'][sample,yy,xx],equal_nan=True):raise AlignmentError('Measured lineage XYZ changed')
            for k,field in (('source_time_ns','bag_time_ns'),('source_frame_index','frame_index')):
                if not np.array_equal(self.a[k].ravel()[pix],a[field][sample]):raise AlignmentError('Source '+k+' mismatch')
            self.lineage_valid=True
            if not np.isin(self.a['source_type'][self.valid],[1,2]).all():raise AlignmentError('Unknown measured source type')
            if np.any((self.a['source_type'].ravel()[pix]==1)&(sample!=self.reference)):raise AlignmentError('CURRENT origin is not reference sample')
        if self.modes is not None:
            if self.modes['sample_mode'].shape!=(f,h,w):raise AlignmentError('Mode frame/shape mismatch')
            if self.modes_meta.get('frame_indices')!=a['frame_index'].tolist():raise AlignmentError('Mode frame indices mismatch')
            if self.modes_meta.get('reference_sample_index',self.reference)!=self.reference:raise AlignmentError('Mode reference mismatch')
            if self.lineage_valid and (self.modes['sample_mode'][sample,yy,xx]<0).any():raise AlignmentError('Measured source has no valid mode')
            if self.surface_modes is not None:
                table=self.surface_modes;offset=table['support_offsets'];n=len(table['pixel_id'])
                if len(offset)!=n+1 or offset[0]!=0 or offset[-1]!=len(table['support_sample_index']) or np.any(np.diff(offset)<0):raise AlignmentError('Ragged mode offsets mismatch')
                if not np.array_equal(np.diff(offset),table['support_count']):raise AlignmentError('Mode support count mismatch')
                for first in range(0,n,512):
                    last=min(first+512,n);row=np.repeat(np.arange(first,last),np.diff(offset[first:last+1]));sl=slice(int(offset[first]),int(offset[last]))
                    ss=table['support_sample_index'][sl];pp=table['pixel_id'][row];ry,rx=np.divmod(pp,w)
                    if np.any(ss<0) or np.any(ss>=f) or np.any(pp<0) or np.any(pp>=h*w):raise AlignmentError('Mode support index invalid')
                    if not np.array_equal(self.modes['sample_mode'][ss,ry,rx],table['mode_id'][row]):raise AlignmentError('Surface mode/support mismatch')
                    if not np.array_equal(table['support_frame_index'][sl],a['frame_index'][ss]) or not np.array_equal(table['support_time_ns'][sl],a['bag_time_ns'][ss]):raise AlignmentError('Mode support time/frame mismatch')
    def validate_optional(self):
        for data,fields in ((self.rays,('ray_valid','ray_available')),(self.structure,('structure_mask',))):
            if data is not None:
                for k in fields:
                    if data[k].shape!=self.shape:raise AlignmentError('Optional grid mismatch '+k)
        if self.structure is not None and np.any(self.valid & self.structure['structure_mask']):raise AlignmentError('Structure masked pixel labeled')
        if self.rays is not None:
            u=self.rays['unit_ray'];v=self.rays['ray_valid']
            if u.shape!=self.shape+(3,) or not np.allclose(np.linalg.norm(u[v],axis=-1),1,atol=1e-6):raise AlignmentError('Invalid unit rays')
    def provenance(self,pixels):
        out=[]
        for pix in pixels:
            y,x=divmod(int(pix),self.w);s=int(self.a.get('source_sample_index',np.full(self.shape,-1))[y,x])
            r={'pixel_id':int(pix),'sample_index':s,'frame_index':int(self.a['source_frame_index'][y,x]) if 'source_frame_index' in self.a else None,
               'time_ns':int(self.a['source_time_ns'][y,x]),'source_type':int(self.a['source_type'][y,x]),
               'mode':int(self.modes['sample_mode'][s,y,x]) if self.modes is not None and s>=0 else None,
               'range_m':float(self.ranges[pix]),'intensity_raw':int(self.history['intensity_raw'][s,y,x]) if self.history is not None and self.raw_dtype and s>=0 else None}
            out.append(r)
        return out
    def summary(self):
        return {'label_sha256':self.label_hash,'shape':self.shape,'fragment_count':len(self.counts),'valid_pixels':int(self.valid.sum()),
                'availability':self.availability,'raw_dtype':self.raw_dtype,'coordinate_frame':self.frame_name,'sensor_origin_xyz':self.origin,
                'units':'metres as declared by v0.2 configuration','reference_sample_index':self.reference,
                'selected_frame_count':len(self.history['frame_index']) if self.history is not None else None,
                'received_frame_count':(self.history_meta or {}).get('received_frame_count'),
                'reference_frame_index':int(self.history['frame_index'][self.reference]) if self.history is not None else None,
                'reference_time_ns':int(self.history['bag_time_ns'][self.reference]) if self.history is not None else None,
                'selected_time_span_s':float(self.history['bag_time_ns'][-1]-self.history['bag_time_ns'][0])*1e-9 if self.history is not None else None,
                'temporal_gate':self.gates,'source_hashes':{str(Path(k).relative_to(self.path)) if Path(k).is_relative_to(self.path) else __import__('os').path.relpath(k,self.path):v for k,v in self.files.items()}}
