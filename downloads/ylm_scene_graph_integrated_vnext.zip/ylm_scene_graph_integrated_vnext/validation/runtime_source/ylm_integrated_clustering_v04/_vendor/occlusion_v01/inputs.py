from pathlib import Path
import json,zipfile
import numpy as np
from .common import sha_array,sha_file,clean
from . import frozen_relations_v01

FILES=['config.json','history.npz','pixel_statistics.npz','integrated_observation.npz',
       'sample_surface_modes.npz','surface_hypotheses.json','structure_mask.npz',
       'C/pixel_correspondence.npz','C_edges.npz','fragment_relations.json','missingness.npz']


def read_json(path):
    with open(path,encoding='utf-8') as f:
        return json.load(f,parse_constant=lambda s:(_ for _ in ()).throw(ValueError('Non-finite JSON: '+s)))


def npz_bytes(path):
    total=0
    with zipfile.ZipFile(path) as z:
        for info in z.infolist():
            if not info.filename.endswith('.npy'):continue
            total+=info.file_size
    return total


def read_npz(path):
    with np.load(path,allow_pickle=False) as z:return {k:z[k] for k in z.files}


def assert_pixel_grid(data,h,w,label):
    rows,cols=np.indices((h,w))
    for k,v in [('pixel_row',rows),('pixel_column',cols)]:
        if k not in data or not np.array_equal(data[k],v):raise ValueError(f'{label}: missing/changed original {k}')


def assert_shapes(d,shapes,label):
    for k,shape in shapes.items():
        if k not in d or d[k].shape!=shape:raise ValueError(f'{label}.{k}: expected {shape}')


def bool_array(a,label):
    if a.dtype!=np.bool_:raise ValueError(label+' must be bool, not inferred from arbitrary values')


def recursive_equal(a,b,atol):
    if isinstance(a,np.generic):a=a.item()
    if isinstance(b,np.generic):b=b.item()
    if isinstance(a,np.ndarray):a=a.tolist()
    if isinstance(b,np.ndarray):b=b.tolist()
    if isinstance(a,dict) and isinstance(b,dict):
        return set(a)==set(b) and all((bool(np.allclose(a[k],b[k],rtol=0,atol=atol)) or bool(np.allclose(a[k],-np.asarray(b[k]),rtol=0,atol=atol))) if k=='normal' and a[k] is not None and b[k] is not None else recursive_equal(a[k],b[k],atol) for k in a)
    if isinstance(a,(list,tuple)) and isinstance(b,(list,tuple)):
        return len(a)==len(b) and all(recursive_equal(x,y,atol) for x,y in zip(a,b))
    if isinstance(a,float) or isinstance(b,float):
        if a is None or b is None:return (a is None or not np.isfinite(a)) and (b is None or not np.isfinite(b))
        return bool(np.isclose(a,b,rtol=0,atol=atol,equal_nan=True))
    return a==b


def audit_relations(old,regenerated,corr,atol):
    reasons=[];rs=old['relations'];new=regenerated['relations'];labels=corr['labels'];h,w=labels.shape
    if len(rs)!=len(new):reasons.append('candidate_count_changed')
    for idx,row in enumerate(rs):
        ends=np.asarray(row['endpoint_pixels'])
        if ends.shape!=(2,2) or ((ends<0)|(ends>=np.array([h,w]))).any():
            reasons.append(f'{idx}:invalid_endpoint');continue
        actual=sorted(int(labels[y,x]) for y,x in ends)
        if actual!=row['fragment_ids'] or min(actual)<0:reasons.append(f'{idx}:endpoint_label_mismatch')
    mismatch=[]
    for idx,(x,y) in enumerate(zip(rs,new)):
        if not recursive_equal(x,clean(y),atol):mismatch.append(idx)
    if mismatch:reasons.append('regenerated_record_mismatch')
    for k in ('candidate_limit','overflow_endpoint_pairs','complete_within_configured_search','search_scope','label_mutation_count'):
        if old.get(k)!=regenerated.get(k):reasons.append(k+'_mismatch')
    return {'passed':not reasons,'reasons':reasons,'mismatch_record_indices':mismatch,
            'stored_count':len(rs),'regenerated_count':len(new),
            'recomputed_with_frozen_relation_source':True,'comparison_atol':atol}


def load_case(root,diagnostic_config,regenerate=False):
    root=Path(root).resolve()
    for name in FILES:
        if not (root/name).is_file():raise ValueError('Missing required input: '+str(root/name))
    files=[root/name for name in FILES]
    # All archives are bounded before decompression. Budget includes working copies and viewer.
    base_bytes=sum(npz_bytes(p) for p in files if p.suffix=='.npz')
    estimate=base_bytes*10+256*1024**2
    if estimate>diagnostic_config['validation']['max_working_mb']*1024**2:
        raise MemoryError('Input exceeds conservative memory estimate; choose a smaller finite history window or increase an explicitly reviewed budget')
    hashes={str(p.relative_to(root)):sha_file(p) for p in files}
    source=read_json(root/'config.json')
    data={'history':read_npz(root/'history.npz'),'statistics':read_npz(root/'pixel_statistics.npz'),
          'integrated':read_npz(root/'integrated_observation.npz'),
          'modes':read_npz(root/'sample_surface_modes.npz'),
          'structure':read_npz(root/'structure_mask.npz'),
          'corr':read_npz(root/'C/pixel_correspondence.npz')}
    hst=data['history'];xyz=hst.get('xyz')
    if xyz is None or xyz.ndim!=4 or xyz.shape[-1]!=3:raise ValueError('Framewise xyz[F,H,W,3] required')
    f,h,w,_=xyz.shape
    if f<2 or h<=1 or w<1:raise ValueError('At least 2 organized frames required')
    shape=(f,h,w)
    assert_shapes(hst,{'range':shape,'valid':shape,'invalid_reason':shape,'frame_index':(f,),
                       'bag_time_ns':(f,),'header_time_ns':(f,),'frame_id':(f,),'setting_id':(f,),
                       'layout_id':(f,),'reference_sample_index':()},'history')
    ref=int(hst['reference_sample_index'])
    if not 0<=ref<f:raise ValueError('Invalid reference sample index')
    bool_array(hst['valid'],'history.valid')
    for key in ('frame_index','bag_time_ns','header_time_ns'):
        if hst[key].dtype.kind not in 'iu':raise ValueError(key+' must be integer')
    if (np.diff(hst['frame_index'])<=0).any():raise ValueError('Frame indices must preserve unique acquisition order')
    for key in ('frame_id','setting_id','layout_id'):
        if len(np.unique(hst[key]))!=1:raise ValueError(key+' changed: same-pixel projection cannot be applied')
    origin=np.asarray(source['acquisition']['sensor_origin_xyz'],float)
    if origin.shape!=(3,) or not np.isfinite(origin).all():raise ValueError('Invalid sensor origin')
    geom=np.linalg.norm(xyz.astype(float)-origin,axis=-1)
    hv=hst['valid']
    if not np.isfinite(xyz[hv]).all() or not np.isfinite(hst['range'][hv]).all() or (hst['range'][hv]<=0).any():raise ValueError('Source valid mask marks invalid geometry')
    if not np.allclose(geom[hv],hst['range'][hv],rtol=0,atol=diagnostic_config['validation']['range_xyz_atol_m']):raise ValueError('range/XYZ/origin/unit mismatch')
    for name in ('history','statistics','integrated','modes','structure','corr'):assert_pixel_grid(data[name],h,w,name)
    stats=data['statistics'];modes=data['modes'];corr=data['corr'];integ=data['integrated']
    assert_shapes(stats,{k:(h,w) for k in ('valid_count','mode_count','range_mad','max_ray_deviation_deg')},'statistics')
    assert_shapes(modes,{'sample_mode':shape,'frame_index':(f,)},'modes')
    if not np.array_equal(modes['frame_index'],hst['frame_index']):raise ValueError('Mode/history frame mismatch')
    sm=modes['sample_mode']
    if sm.dtype.kind not in 'iu' or not np.array_equal(sm>=0,hv):raise ValueError('Mode IDs/valid samples mismatch')
    if not np.array_equal(stats['valid_count'],hv.sum(axis=0)):raise ValueError('Stored valid_count mismatch')
    actual_mode_count=np.zeros((h,w),np.int16)
    for mode_id in np.unique(sm[sm>=0]):
        actual_mode_count+=np.any(sm==mode_id,axis=0)
        if not (mode_id<stats['mode_count'][np.any(sm==mode_id,axis=0)]).all():raise ValueError('Mode count/index mismatch')
    if not np.array_equal(actual_mode_count,stats['mode_count']):raise ValueError('Mode support/count mismatch')
    assert_shapes(corr,{'xyz':(h,w,3),'valid':(h,w),'labels':(h,w),'source_type':(h,w),'source_time_ns':(h,w)},'C')
    bool_array(corr['valid'],'C.valid')
    cv=corr['valid'];labels=corr['labels']
    if labels.dtype.kind not in 'iu' or ((labels>=0)&~cv).any():raise ValueError('Cluster labels do not match their valid mask')
    if not np.array_equal(corr['xyz'][cv],integ['xyz'][cv]):raise ValueError('C points and integrated samples differ')
    if not np.array_equal(corr['source_type'][cv],integ['source_type'][cv]) or not np.array_equal(corr['source_time_ns'][cv],integ['source_time_ns'][cv]):raise ValueError('C source provenance mismatch')
    assert_shapes(integ,{'source_sample_index':(h,w),'source_frame_index':(h,w),'source_time_ns':(h,w),'source_type':(h,w),'valid':(h,w)},'integrated')
    iv=integ['valid'];yy,xx=np.where(iv);ss=integ['source_sample_index'][iv]
    if ((ss<0)|(ss>=f)).any() or not hst['valid'][ss,yy,xx].all():raise ValueError('Integrated point source is not valid observed sample')
    if not np.array_equal(integ['xyz'][iv],hst['xyz'][ss,yy,xx]):raise ValueError('Integrated point not equal to actual source sample')
    if not np.array_equal(integ['source_frame_index'][iv],hst['frame_index'][ss]) or not np.array_equal(integ['source_time_ns'][iv],hst['bag_time_ns'][ss]):raise ValueError('Integrated sample time/frame mismatch')
    if (integ['source_type']==3).any():raise ValueError('MODEL_INFERRED input cannot be treated as measured geometry')
    assert_shapes(data['structure'],{'structure_mask':(h,w)},'structure')
    if (cv & data['structure']['structure_mask']).any():raise ValueError('C valid points include structure-masked pixels')
    old=read_json(root/'fragment_relations.json')
    regen=frozen_relations_v01.fragment_relations(corr['xyz'],labels,hst['range'][ref],hv[ref],stats,source)
    audit=audit_relations(old,regen,corr,diagnostic_config['validation']['recomputed_relation_atol'])
    if not audit['passed'] and not regenerate:raise ValueError('Relation/label provenance mismatch. Regenerate relations for these labels with --regenerate-relations; old IDs cannot be reused: '+str(audit['reasons'][:5]))
    data.update(root=root,source_config=source,files=files,input_hashes=hashes,reference=ref,
                origin=origin,source_relations=clean(regen) if regenerate else old,
                audit=audit,relations_regenerated=regenerate,
                label_sha256=sha_array(labels),geometry_sha256=sha_array(corr['xyz']),
                memory_estimate_bytes=estimate)
    return data
