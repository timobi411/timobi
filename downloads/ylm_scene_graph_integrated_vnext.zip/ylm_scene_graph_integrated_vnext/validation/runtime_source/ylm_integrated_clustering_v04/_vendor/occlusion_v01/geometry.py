import numpy as np
from scipy.spatial import ConvexHull,QhullError

RAY_HOLD={'NO_DIRECTION':1,'INSUFFICIENT_OBSERVATIONS':2,'DIRECTION_CHANGE':4,'GLOBAL_ASSUMPTION':8}
PLANE_HOLD={'NO_RAY':1,'PLANE_QUALITY':2,'PARALLEL':4,'NONPOSITIVE_OR_RANGE':8,'EXTRAPOLATION':16,'GLOBAL_ASSUMPTION':32}


def ray_geometry(data,c):
    hist=data['history'];ref=data['reference'];origin=data['origin'];v=hist['valid'];xyz=hist['xyz'].astype(float)-origin
    f,h,w=v.shape;norm=np.linalg.norm(xyz,axis=-1)
    rays=np.divide(xyz,norm[...,None],out=np.zeros_like(xyz),where=v[...,None])
    ages=np.abs(hist['bag_time_ns']-hist['bag_time_ns'][ref]).astype(float)
    rank=np.where(v,ages[:,None,None],np.inf);anchor=np.argmin(rank,axis=0)
    yy,xx=np.indices((h,w));ray=rays[anchor,yy,xx];count=v.sum(axis=0);anyv=count>0
    dot=np.clip((rays*ray[None]).sum(axis=-1),-1,1)
    maxdev=np.max(np.where(v,np.degrees(np.arccos(dot)),0),axis=0)
    maxdev[~anyv]=np.nan
    source=data['source_config'];reasons=[]
    checks=[(bool(str(hist['frame_id'][0]).strip()),'empty frame_id'),
            (source['scene']['static_confirmed'],'static acquisition not confirmed'),
            (not source['scene']['known_motion'],'known sensor/object motion'),
            (bool(source['scene']['acquisition_record'].strip()),'static record absent'),
            (source['acquisition']['pixel_correspondence_confirmed'],'pixel correspondence unverified'),
            (source['acquisition']['xyz_sensor_frame_confirmed'],'coordinate/origin unverified'),
            (bool(source['acquisition']['settings_evidence'].strip()),'fixed settings record absent'),
            (source['validity']['reviewed'],'driver validity unverified'),
            (bool(source['validity']['driver_definition'].strip()),'driver validity evidence absent'),
            (np.all(hist['bag_time_ns']>0) and np.all(np.diff(hist['bag_time_ns'])>0),'bag time invalid or nonmonotonic')]
    for ok,reason in checks:
        if not ok:reasons.append(reason)
    hold=np.zeros((h,w),np.uint8);hold[~anyv]|=RAY_HOLD['NO_DIRECTION']
    hold[count<c['ray_mapping']['minimum_observations']]|=RAY_HOLD['INSUFFICIENT_OBSERVATIONS']
    hold[maxdev>c['ray_mapping']['max_deviation_deg']]|=RAY_HOLD['DIRECTION_CHANGE']
    if reasons:hold|=RAY_HOLD['GLOBAL_ASSUMPTION']
    ray[~anyv]=np.nan
    return {'unit_ray':ray,'ray_valid':hold==0,'ray_available':anyv,'ray_hold_reason':hold,
            'anchor_sample_index':np.where(anyv,anchor,-1),'observation_count':count,
            'max_deviation_deg':maxdev,'global_gate_passed':not reasons,'global_hold_reasons':reasons,
            'direction_source':'exact normalized observed XYZ of nearest-time valid sample; no neighboring-pixel interpolation',
            'current_missing_ray_source':'other observed frames only, gated by repeated-ray stability',
            'intrinsic_calibration_available':False}


def fit_local_plane(xyz,labels,valid,endpoint,c):
    h,w=labels.shape;y,x=map(int,endpoint);radius=c['plane']['radius_pixels'];label=int(labels[y,x])
    y0,y1=max(0,y-radius),min(h,y+radius+1);x0,x1=max(0,x-radius),min(w,x+radius+1)
    yy,xx=np.indices((y1-y0,x1-x0));yy+=y0;xx+=x0
    keep=(labels[yy,xx]==label)&valid[yy,xx]&np.isfinite(xyz[yy,xx]).all(axis=-1)
    sy,sx=yy[keep],xx[keep];pts=xyz[sy,sx].astype(float)
    result={'label':label,'endpoint_pixel':[y,x],'support_pixels':np.column_stack([sy,sx]).tolist(),
            'support_count':len(pts),'accepted_for_projection':False,'hold_reasons':[],
            'normal':None,'center':None,'rms_m':None,'eigenvalues':None,'tangent_span_m':None,
            'minor_major_eigenvalue_ratio':None,'normal_minor_eigenvalue_ratio':None,
            'degenerate':None,'basis':None,'support_hull_uv':None}
    if len(pts)<3:
        result['hold_reasons'].append('fewer_than_three_points');result['degenerate']=True;return result
    center=pts.mean(axis=0);cov=(pts-center).T@(pts-center)/len(pts);val,vec=np.linalg.eigh(cov)
    val=np.maximum(val,0);normal=vec[:,0];basis=vec[:,[2,1]];uv=(pts-center)@basis
    spread=np.ptp(uv,axis=0);rms=float(np.sqrt(val[0]));ratio=float(val[1]/val[2]) if val[2]>1e-16 else 0.
    thickness=float(val[0]/val[1]) if val[1]>1e-16 else None
    degenerate=val[1]<=1e-14 or ratio<c['plane']['min_minor_major_eigenvalue_ratio']
    result.update(center=center,normal=normal,basis=basis,rms_m=rms,eigenvalues=val,
                  tangent_span_m=spread,minor_major_eigenvalue_ratio=ratio,
                  normal_minor_eigenvalue_ratio=thickness,degenerate=degenerate)
    reasons=result['hold_reasons']
    if len(pts)<c['plane']['min_points']:reasons.append('insufficient_plane_support')
    if degenerate:reasons.append('line_or_point_degeneracy')
    if spread[1]<c['plane']['min_minor_span_m']:reasons.append('insufficient_minor_spread')
    if rms>c['plane']['max_rms_m']:reasons.append('high_plane_residual')
    if thickness is None or thickness>c['plane']['max_normal_minor_eigenvalue_ratio']:reasons.append('not_reliably_planar')
    try:
        hull=ConvexHull(uv)
        result['support_hull_uv']=uv[hull.vertices]
    except QhullError:
        reasons.append('support_hull_degenerate')
    result['accepted_for_projection']=not reasons
    return result


def polygon_distance(q,poly):
    q=np.asarray(q);poly=np.asarray(poly);end=np.roll(poly,-1,axis=0);edge=end-poly
    diff=q[:,None,:]-poly[None]
    cross=edge[None,:,0]*diff[:,:,1]-edge[None,:,1]*diff[:,:,0]
    inside=(cross>=-1e-10).all(axis=1)|(cross<=1e-10).all(axis=1)
    t=np.sum(diff*edge[None],axis=-1)/np.maximum(np.sum(edge*edge,axis=-1),1e-30)
    near=poly[None]+np.clip(t,0,1)[...,None]*edge[None]
    dist=np.linalg.norm(q[:,None]-near,axis=-1).min(axis=1);dist[inside]=0
    return dist


def project_plane(plane,rays,ray_valid,origin,c,range_bounds,global_gate=True):
    rays=np.asarray(rays);n=len(rays);hold=np.zeros(n,np.uint8);raw=np.full(n,np.nan)
    denom=np.full(n,np.nan);extra=np.full(n,np.nan);rough_uncertainty=np.full(n,np.nan)
    hold[~ray_valid]|=PLANE_HOLD['NO_RAY']
    if not global_gate:hold|=PLANE_HOLD['GLOBAL_ASSUMPTION']
    if plane['normal'] is None or plane['center'] is None:
        hold|=PLANE_HOLD['PLANE_QUALITY']
    else:
        normal=np.asarray(plane['normal']);center=np.asarray(plane['center'])
        denom=rays@normal;parallel=~np.isfinite(denom)|(np.abs(denom)<c['plane']['min_abs_normal_dot_ray'])
        hold[parallel]|=PLANE_HOLD['PARALLEL']
        np.divide(np.dot(center-origin,normal),denom,out=raw,where=~parallel)
        invalid=~np.isfinite(raw)|(raw<=0)|(raw<range_bounds[0])|(raw>range_bounds[1])
        hold[invalid]|=PLANE_HOLD['NONPOSITIVE_OR_RANGE']
        if not plane['accepted_for_projection']:hold|=PLANE_HOLD['PLANE_QUALITY']
        if plane['support_hull_uv'] is not None:
            good=np.isfinite(raw)&np.isfinite(rays).all(axis=1)
            points=origin[None]+rays[good]*raw[good,None]
            uv=(points-center)@np.asarray(plane['basis'])
            extra[good]=polygon_distance(uv,plane['support_hull_uv'])
            hold[~np.isfinite(extra)|(extra>c['plane']['max_extrapolation_m'])]|=PLANE_HOLD['EXTRAPOLATION']
        else:hold|=PLANE_HOLD['EXTRAPOLATION']
        good=np.isfinite(denom)&(np.abs(denom)>0)
        rough_uncertainty[good]=plane['rms_m']/np.abs(denom[good])
    accepted=hold==0
    return {'range_m':np.where(accepted,raw,np.nan),'raw_intersection_range_m':raw,
            'projection_valid':accepted,'hold_reason':hold,'abs_normal_dot_ray':np.abs(denom),
            'extrapolation_distance_m':extra,'residual_over_incidence_m':rough_uncertainty,
            'uncertainty_is_calibrated':False}
