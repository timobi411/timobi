import numpy as np
from .common import CLASS,compare_distance,counts_rates,flags


def diagnose_measured(data,c,rays):
    hist=data['history'];ref=data['reference'];valid=hist['valid'];f,h,w=valid.shape
    target_valid=valid.copy();target_valid[ref]=False
    target=np.where(target_valid,hist['range'],np.nan)
    current=np.where(valid[ref],hist['range'][ref],np.nan)
    projection_valid=target_valid & rays['ray_valid'][None]
    cls,delta,compared=compare_distance(target,current,valid[ref],projection_valid,
        c['distance_tolerance']['resolved_epsilon_m'],target_valid=target_valid)
    mode=np.where(target_valid,data['modes']['sample_mode'],-1)
    obs_per_pixel=target_valid.sum(axis=0)
    perclass=np.stack([(cls==i).sum(axis=0) for i in range(len(CLASS))]).astype(np.int16)
    # Index zero counts deliberately are not part of any target evidence denominator.
    perclass[0]=0
    summary=counts_rates(cls,target_valid)
    summary.update(unit='historical measured sample / pixel compared with one reference sample',
                   reference_sample_index=ref,reference_frame_index=int(hist['frame_index'][ref]),
                   current_valid_pixels=int(valid[ref].sum()),
                   target_observed_pixels=int((obs_per_pixel>0).sum()),
                   no_historical_target_pixels=int((obs_per_pixel==0).sum()),
                   foreground_candidate_unique_pixels=int(np.any(cls==CLASS['foreground_occlusion_candidate'],axis=0).sum()),
                   behind_candidate_unique_pixels=int(np.any(cls==CLASS['behind_target_measurement_candidate'],axis=0).sum()),
                   unresolved_projection_unique_pixels=int(np.any(cls==CLASS['projection_unknown'],axis=0).sum()),
                   reference_self_comparisons=0,
                   epsilon_m=c['distance_tolerance']['resolved_epsilon_m'],
                   epsilon_verified=c['distance_tolerance']['verified'],
                   interpretation='diagnostic_provisional' if not c['distance_tolerance']['verified'] else 'distance_tolerance_verified; object identity still unknown',
                   object_count=None,accuracy=None,**flags())
    arrays={'target_range_m':target,'current_range_m':current,'range_difference_m':delta,
            'target_valid':target_valid,'current_valid':valid[ref],'projection_valid':projection_valid,
            'comparison_valid':compared,'classification':cls,'target_mode_id':mode,
            'target_sample_indices':np.arange(f,dtype=np.int32),'source_frame_index':hist['frame_index'],
            'source_bag_time_ns':hist['bag_time_ns'],'source_header_time_ns':hist['header_time_ns'],
            'reference_sample_index':np.array(ref),'reference_time_ns':hist['bag_time_ns'][ref],
            'current_fragment_label_at_pixel':data['corr']['labels'],
            'target_object_label_known':np.zeros((h,w),bool),
            'projection_hold_reason':np.where(target_valid,rays['ray_hold_reason'][None],0).astype(np.uint8),
            'target_observation_count':obs_per_pixel,'class_observation_count':perclass,
            'history_time_change_candidate':data['statistics'].get('time_change_candidate',np.zeros((h,w),bool)),
            'history_range_mad_m':data['statistics']['range_mad'],
            'pixel_row':np.indices((h,w))[0],'pixel_column':np.indices((h,w))[1]}
    return arrays,summary


def surface_records(data,measured):
    hist=data['history'];modes=data['modes']['sample_mode'];f,h,w=modes.shape;ref=data['reference']
    mc=data['statistics']['mode_count'];ranges=hist['range'];cls=measured['classification']
    for y,x in np.argwhere(mc>0):
        for mode in range(int(mc[y,x])):
            all_samples=np.flatnonzero((modes[:,y,x]==mode)&hist['valid'][:,y,x])
            samples=all_samples[all_samples!=ref]
            rv=ranges[all_samples,y,x];median=float(np.median(rv))
            yield {'surface_id':f'p{int(y*w+x)}_m{mode}','pixel':[int(y),int(x)],
                   'target_surface_type':'measured','mode_id':mode,'total_mode_support_count':len(all_samples),
                   'target_sample_indices':samples.tolist(),'target_frame_indices':hist['frame_index'][samples].tolist(),
                   'target_times_ns':hist['bag_time_ns'][samples].tolist(),
                   'all_support_sample_indices':all_samples.tolist(),
                   'range_statistics_not_generated_geometry':{'median_m':median,'mad_m':float(np.median(abs(rv-median))),
                     'min_m':float(rv.min()),'max_m':float(rv.max())},
                   'class_counts':{name:int((cls[samples,y,x]==code).sum()) for name,code in CLASS.items() if code},
                   'one_sample_only':len(all_samples)==1,
                   'stored_time_change_candidate':bool(data['statistics'].get('time_change_candidate',np.zeros((h,w),bool))[y,x]),
                   'stored_range_mad_m':float(data['statistics']['range_mad'][y,x]),
                   'current_fragment_label_at_pixel':int(data['corr']['labels'][y,x]),
                   'target_fragment_identity':None,'target_is_endpoint_object_confirmed':False,
                   'all_observations_retained_no_mode_selected':True,**flags()}
