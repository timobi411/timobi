import argparse,re,sys,json
from pathlib import Path
from .config import read
from .runner import new_output,run


def main(argv=None):
    parser=argparse.ArgumentParser(description='YLM occlusion diagnostic: read-only A/B/C; no automatic merging')
    sub=parser.add_subparsers(dest='command',required=True)
    cmd=sub.add_parser('init-config');cmd.add_argument('--out',required=True)
    cmd=sub.add_parser('run');cmd.add_argument('--case',nargs=2,action='append',required=True,metavar=('NAME','RUN_DIRECTORY'))
    cmd.add_argument('--config');cmd.add_argument('--out',required=True)
    cmd.add_argument('--regenerate-relations',action='store_true',help='Regenerate candidates for input labels; write separate output, never replace originals')
    cmd.add_argument('--no-viewer',action='store_true')
    args=parser.parse_args(argv)
    try:
        if args.command=='init-config':
            with Path(args.out).open('x',encoding='utf-8') as f:json.dump(read(),f,ensure_ascii=False,indent=2)
            return 0
        c=read(args.config)
        if args.no_viewer:c['outputs']['write_viewer']=False
        names=[x[0] for x in args.case]
        if len(set(names))!=len(names) or any(not re.fullmatch(r'[A-Za-z0-9_-]+',x) for x in names):raise ValueError('Case names must be unique path-safe labels; names never affect geometric decisions')
        out=new_output(args.out,[p for _,p in args.case]);run(args.case,c,out,args.regenerate_relations)
        return 0
    except (ValueError,RuntimeError,FileExistsError,FileNotFoundError,MemoryError,KeyError) as e:
        print('ERROR: '+str(e),file=sys.stderr);return 2


if __name__=='__main__':raise SystemExit(main())
