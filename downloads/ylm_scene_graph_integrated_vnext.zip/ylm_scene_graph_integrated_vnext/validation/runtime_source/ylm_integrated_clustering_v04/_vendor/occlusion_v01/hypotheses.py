from collections import Counter
import numpy as np
from .common import CLASS,compare_distance,counts_rates,evidence_class,flags,A_CLASSES
from .geometry import fit_local_plane,project_plane


def stage_a_records(data):
    output=[];counts=Counter();cross=Counter()
    for i,r in enumerate(data['source_relations']['relations']):
        fg=r['foreground_support_count'];back=r['depth_order_contradiction_count'];nr=r['no_return_count']
        cls=evidence_class(fg,back,nr);plane='unknown' if r['local_surface_compatible'] is None else ('compatible' if r['local_surface_compatible'] else 'incompatible')
        gap=len(r['gap_pixels']);valid=gap-nr
        output.append({'candidate_id':i,'candidate_key':f'r{i:05d}','original_fragment_ids':r['fragment_ids'],
                       'endpoint_pixels':r['endpoint_pixels'],'gap_pixels':r['gap_pixels'],
                       'target_surface_type':'hypothesized','target_model':'legacy_endpoint_linear_range',
                       'evidence_class':cls,'local_surface_compatibility':plane,
                       'foreground_support_count':fg,'depth_order_contradiction_count':back,
                       'no_return_count':nr,'all_gap_pixels':gap,'valid_comparison_count':valid,
                       'foreground_support_rate_valid_comparisons':fg/valid if valid else None,
                       'no_return_rate_all_gaps':nr/gap if gap else None,
                       'legacy_support_fraction_all_gaps':r['occlusion_support_fraction'],
                       'legacy_depth_margin_m':data['source_config']['relations']['depth_margin_m'],
                       'label_sha256':data['label_sha256'],**flags()})
        counts[cls]+=1;cross[(cls,plane)]+=1
    summary={'counts':{name:counts[name] for name in A_CLASSES},'total_candidates':len(output),
             'surface_cross_counts':[{'evidence':a,'surface':b,'count':n} for (a,b),n in sorted(cross.items())],
             'candidate_limit':data['source_relations']['candidate_limit'],
             'overflow_endpoint_pairs':data['source_relations']['overflow_endpoint_pairs'],
             'search_scope':data['source_relations']['search_scope'],
             'complete_within_configured_search':data['source_relations']['complete_within_configured_search'],
             'label_sha256':data['label_sha256'],'relation_source_regenerated':data['relations_regenerated'],**flags()}
    return output,summary


def diagnose_hypotheses(data,c,rays,measured,stage_a):
    relations=data['source_relations']['relations'];n=len(relations);hist=data['history'];ref=data['reference'];corr=data['corr'];h,w=corr['labels'].shape
    offsets=np.r_[0,np.cumsum([len(r['gap_pixels']) for r in relations])].astype(np.int64);total=int(offsets[-1])
    pixels=np.concatenate([np.asarray(r['gap_pixels'],int).reshape(-1,2) for r in relations],axis=0) if total else np.empty((0,2),int)
    py,px=pixels.T;pf=py*w+px
    current=np.where(hist['valid'][ref,py,px],hist['range'][ref,py,px],np.nan)
    current_valid=hist['valid'][ref,py,px]
    target=np.full((3,total),np.nan);raw_target=target.copy();pvalid=np.zeros((3,total),bool)
    p_hold=np.zeros((3,total),np.uint8);extrap=np.full((2,total),np.nan);incidence=extrap.copy();residual_scale=extrap.copy()
    method_names=['endpoint_linear','left_local_plane','right_local_plane']
    plane_table=[];plane_cache={};plane_ids=np.full((n,2),-1,np.int32);records=[]
    eps=c['distance_tolerance']['resolved_epsilon_m'];source=data['source_config']
    bounds=(source['validity']['min_range_m'],source['validity']['max_range_m'])
    for idx,r in enumerate(relations):
        lo,hi=offsets[idx:idx+2];local_pixels=pixels[lo:hi];yy,xx=local_pixels.T
        target[0,lo:hi]=r['hypothetical_range_m'];raw_target[0,lo:hi]=r['hypothetical_range_m']
        pvalid[0,lo:hi]=rays['ray_valid'][yy,xx]
        p_hold[0,lo:hi]=rays['ray_hold_reason'][yy,xx]
        for side,endpoint in enumerate(r['endpoint_pixels']):
            key=tuple(endpoint)
            if key not in plane_cache:
                plane=fit_local_plane(corr['xyz'],corr['labels'],corr['valid'],endpoint,c)
                plane['plane_id']=len(plane_table)
                supp=np.asarray(plane['support_pixels'],int).reshape(-1,2)
                sy,sx=supp.T
                plane['support_source_sample_indices']=data['integrated']['source_sample_index'][sy,sx]
                plane['support_source_times_ns']=data['integrated']['source_time_ns'][sy,sx]
                plane['kind']='hypothesized_local_plane_fitted_to_measured_samples'
                plane_table.append(plane);plane_cache[key]=plane['plane_id']
            pid=plane_cache[key];plane_ids[idx,side]=pid;plane=plane_table[pid]
            prediction=project_plane(plane,rays['unit_ray'][yy,xx],rays['ray_valid'][yy,xx],data['origin'],c,bounds,rays['global_gate_passed'])
            target[side+1,lo:hi]=prediction['range_m'];raw_target[side+1,lo:hi]=prediction['raw_intersection_range_m']
            pvalid[side+1,lo:hi]=prediction['projection_valid'];p_hold[side+1,lo:hi]=prediction['hold_reason']
            extrap[side,lo:hi]=prediction['extrapolation_distance_m'];incidence[side,lo:hi]=prediction['abs_normal_dot_ray']
            residual_scale[side,lo:hi]=prediction['residual_over_incidence_m']
    classification,delta,comparison=compare_distance(target,current,current_valid,pvalid,eps,target_valid=np.ones_like(pvalid))
    both=pvalid[1]&pvalid[2]
    disagreement=np.full(total,np.nan);disagreement[both]=abs(target[1,both]-target[2,both])
    range_agree=both & (disagreement<=c['plane']['max_dual_disagreement_m'])
    class_agree=range_agree & (classification[1]==classification[2])
    joint=np.full(total,CLASS['projection_unknown'],np.uint8);joint[class_agree]=classification[1,class_agree]
    # Never average or select one of two conflicting inferred planes.
    for idx,r in enumerate(relations):
        lo,hi=offsets[idx:idx+2];yy,xx=pixels[lo:hi].T
        bcls=measured['classification'][:,yy,xx];bt=measured['target_valid'][:,yy,xx]
        bsummary=counts_rates(bcls,bt)
        bsummary.update(all_gap_pixels=hi-lo,
                        unique_gap_pixels_with_historical_target=int(bt.any(axis=0).sum()),
                        gap_pixels_without_historical_target=int((~bt.any(axis=0)).sum()),
                        unique_gap_pixels_with_foreground_candidate=int((bcls==CLASS['foreground_occlusion_candidate']).any(axis=0).sum()),
                        no_current_measurement_gap_pixels=int((~current_valid[lo:hi]).sum()),
                        target_to_endpoint_identity_known=False,
                        warning='Historical surfaces at a gap are not thereby identified as either endpoint object')
        cm={name:counts_rates(classification[k,lo:hi],np.ones(hi-lo,bool)) for k,name in enumerate(method_names)}
        holds=['object_identity_not_established','no_automatic_merge_in_this_version']
        if not both[lo:hi].all():holds.append('at_least_one_endpoint_plane_projection_unavailable')
        if (both[lo:hi]&~range_agree[lo:hi]).any():holds.append('endpoint_plane_range_predictions_disagree')
        if (range_agree[lo:hi]&~class_agree[lo:hi]).any():holds.append('endpoint_plane_relation_classes_disagree')
        if hi-lo==1:holds.append('single_gap_pixel_support_is_not_wide_surface_evidence')
        if not c['distance_tolerance']['verified']:holds.append('epsilon_is_provisional')
        records.append({'candidate_id':idx,'candidate_key':stage_a[idx]['candidate_key'],
                        'original_fragment_ids':r['fragment_ids'],'endpoint_pixels':r['endpoint_pixels'],
                        'gap_pixels':r['gap_pixels'],'npz_gap_offset':[int(lo),int(hi)],
                        'label_sha256':data['label_sha256'],'stage_A':stage_a[idx],
                        'stage_B_measured_gap':bsummary,'stage_C_methods':cm,
                        'plane_ids':plane_ids[idx].tolist(),
                        'dual_plane_comparison':{'both_projected_pixels':int(both[lo:hi].sum()),
                           'range_agreement_pixels':int(range_agree[lo:hi].sum()),
                           'same_class_and_range_agreement_pixels':int(class_agree[lo:hi].sum()),
                           'disagreement_threshold_m':c['plane']['max_dual_disagreement_m'],
                           'maximum_range_disagreement_m':float(np.nanmax(disagreement[lo:hi])) if both[lo:hi].any() else None,
                           'joint_relation':counts_rates(joint[lo:hi],np.ones(hi-lo,bool)),
                           'consensus_range_generated':False},
                        'target_surface_types':{'stage_B':'measured','stage_C':'hypothesized'},
                        'hold_reasons':holds,**flags()})
    summary={'methods':{name:counts_rates(classification[k],np.ones(total,bool)) for k,name in enumerate(method_names)},
             'all_relation_gap_occurrences':total,'unique_gap_pixels':len(np.unique(pf)),
             'gap_pixels_are_deduplicated_for_per_pixel_results_only':True,
             'plane_models':len(plane_table),'quality_passed_plane_models':sum(p['accepted_for_projection'] for p in plane_table),
             'both_endpoint_planes_projected_gap_occurrences':int(both.sum()),
             'dual_range_agreement_occurrences':int(range_agree.sum()),
             'dual_class_and_range_agreement_occurrences':int(class_agree.sum()),
             'dual_plane_range_disagreement_occurrences':int((both&~range_agree).sum()),
             'unique_plane_fit_hold_counts':dict(Counter(reason for p in plane_table for reason in p['hold_reasons'])),
             'epsilon_m':eps,'original_linear_A_margin_m':source['relations']['depth_margin_m'],
             'hypothesis_points_written_to_measured_history_or_PCD':0,'automatic_merges':0,
             'by_gap_size':{},**flags()}
    sizes=np.diff(offsets)
    for size in sorted(set(sizes.tolist())|set(c['evaluation']['minimum_gap_sizes'])):
        ids=np.flatnonzero(sizes==size);mask=np.isin(np.repeat(np.arange(n),sizes),ids)
        summary['by_gap_size'][str(size)]={'candidate_count':len(ids),
                  'methods':{name:counts_rates(classification[k,mask],np.ones(mask.sum(),bool)) for k,name in enumerate(method_names)}}
    arrays={'candidate_id':np.repeat(np.arange(n,dtype=np.int32),sizes),'candidate_offsets':offsets,
            'pixel_row':py,'pixel_column':px,'method_names':np.asarray(method_names),
            'target_range_m':target,'raw_intersection_range_m':raw_target,
            'current_range_m':current,'current_valid':current_valid,'projection_valid':pvalid,
            'comparison_valid':comparison,'range_difference_m':delta,'classification':classification,
            'projection_hold_reason':p_hold,'extrapolation_distance_m':extrap,
            'abs_normal_dot_ray':incidence,'residual_over_incidence_m':residual_scale,
            'plane_ids':plane_ids,'dual_prediction_difference_m':disagreement,
            'both_planes_projected':both,'dual_range_agreement':range_agree,
            'dual_classification_agreement':class_agree,'joint_classification':joint,
            'reference_sample_index':np.asarray(ref),'reference_frame_index':hist['frame_index'][ref],
            'reference_time_ns':hist['bag_time_ns'][ref]}
    return arrays,records,plane_table,summary
