import numpy as np


def local_plane(xyz, labels, row, col, radius):
    h,w=labels.shape; y0,y1=max(0,row-radius),min(h,row+radius+1); x0,x1=max(0,col-radius),min(w,col+radius+1)
    a=xyz[y0:y1,x0:x1][labels[y0:y1,x0:x1]==labels[row,col]]
    if len(a)<3:
        return None
    mean=a.mean(axis=0); _,s,vt=np.linalg.svd(a-mean,full_matrices=False)
    if len(s)<2 or s[1]<1e-6:
        return None
    residual=float(np.sqrt(np.mean(((a-mean)@vt[-1])**2)))
    return {'normal':vt[-1].tolist(),'center':mean.tolist(),'rms_m':residual,'points':len(a)}


def fragment_relations(xyz, labels, current_range, current_valid, stats, c):
    h,w=labels.shape; cfg=c['relations']; flat=labels.ravel(); pts=xyz.reshape(-1,3)
    grid=np.arange(h*w).reshape(h,w); selected={}; clipped=0
    for step in range(2,cfg['max_gap_pixels']+2):
        pairs=[]
        if step<w: pairs.append((grid[:,:-step].ravel(),grid[:,step:].ravel(),1))
        if step<h: pairs.append((grid[:-step].ravel(),grid[step:].ravel(),w))
        for ii,jj,stride in pairs:
            use=(flat[ii]>=0)&(flat[jj]>=0)&(flat[ii]!=flat[jj])
            ii,jj=ii[use],jj[use]
            dist=np.linalg.norm(pts[ii]-pts[jj],axis=1)
            use=dist<=cfg['max_endpoint_distance_m']; ii,jj,dist=ii[use],jj[use],dist[use]
            for i,j,d in zip(ii,jj,dist):
                inside=np.arange(i+stride,j,stride,dtype=int)
                if np.any((flat[inside]==flat[i])|(flat[inside]==flat[j])):
                    continue
                key=tuple(sorted((int(flat[i]),int(flat[j]))))
                if key not in selected and len(selected)>=cfg['max_candidates']:
                    clipped+=1; continue
                old=selected.get(key)
                if old is None or d<old[2]:
                    selected[key]=(int(i),int(j),float(d),inside)
    out=[]; rng=np.linalg.norm(pts-np.asarray(c['acquisition']['sensor_origin_xyz']),axis=1)
    cr=current_range.ravel(); cv=current_valid.ravel()
    for (a,b),(i,j,d,inside) in sorted(selected.items()):
        # This interpolation is only a *hypothesis for contradiction checking*;
        # no XYZ/range samples are created or exported from it.
        expected=np.linspace(rng[i],rng[j],len(inside)+2)[1:-1]
        valid=cv[inside]; observed=cr[inside]
        fg=valid & (observed<expected-cfg['depth_margin_m'])
        free=valid & (observed>expected+cfg['depth_margin_m'])
        free_checked=c['projection']['free_space_model_verified'] and c['acquisition']['xyz_sensor_frame_confirmed'] and c['validity']['reviewed']
        plane1=local_plane(xyz,labels,i//w,i%w,cfg['local_plane_radius_pixels'])
        plane2=local_plane(xyz,labels,j//w,j%w,cfg['local_plane_radius_pixels'])
        angle=None; compatible=None
        if plane1 is not None and plane2 is not None:
            angle=float(np.degrees(np.arccos(np.clip(abs(np.dot(plane1['normal'],plane2['normal'])),-1,1))))
            compatible=angle<=cfg['max_local_normal_angle_deg'] and max(plane1['rms_m'],plane2['rms_m'])<=cfg['max_local_plane_residual_m']
        reason=['v0.1 candidate only; fragment labels never merged']
        if fg.any(): reason.append('foreground measurements support possible occlusion of the endpoint-surface hypothesis')
        else: reason.append('no foreground evidence; no-return is not classified as occlusion')
        if free.any(): reason.append('free-space contradiction' if free_checked else 'depth-order contradiction candidate; free-space sensor model unverified')
        if compatible is not True: reason.append('local surface compatibility unknown or failed')
        out.append({'fragment_ids':[a,b],'endpoint_pixels':[[i//w,i%w],[j//w,j%w]],
                    'endpoint_distance_m':d,'endpoint_ranges_m':[rng[i],rng[j]],
                    'gap_pixels':np.column_stack(np.divmod(inside,w)).tolist(),
                    'observed_gap_ranges_m':observed,'gap_current_valid':valid,
                    'hypothetical_range_m':expected,'hypothetical_values_are_measurements':False,
                    'foreground_support_count':int(fg.sum()),'occlusion_support_fraction':float(fg.mean()),
                    'no_return_count':int((~valid).sum()),'depth_order_contradiction_count':int(free.sum()),
                    'free_space_model_verified':free_checked,
                    'free_space_contradiction_count':int(free.sum()) if free_checked else None,
                    'gap_history_valid_fraction':stats['valid_fraction'].ravel()[inside],
                    'gap_mode_counts':stats['mode_count'].ravel()[inside],
                    'local_planes':[plane1,plane2],'local_normal_angle_deg':angle,
                    'local_surface_compatible':compatible,
                    'accepted_merge':False,'decision':'HOLD','reasons':reason})
    return {'relations':out,'candidate_limit':cfg['max_candidates'],
            'overflow_endpoint_pairs':clipped,'complete_within_configured_search':clipped==0,
            'search_scope':'horizontal/vertical bounded gaps; not exhaustive object association',
            'label_mutation_count':0}
