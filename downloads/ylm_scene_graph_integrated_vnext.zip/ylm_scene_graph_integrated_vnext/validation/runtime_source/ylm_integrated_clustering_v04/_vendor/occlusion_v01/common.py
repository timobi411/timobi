from pathlib import Path
from collections import Counter
import hashlib,json,math,os,tempfile,zipfile
import numpy as np

CLASS = {'no_target_observation':0,'observed_consistent':1,'foreground_occlusion_candidate':2,
         'behind_target_measurement_candidate':3,'no_return_unknown':4,'projection_unknown':5,'out_of_view':6}
A_CLASSES = ['occlusion_candidate','depth_contradiction_candidate','mixed_evidence_hold',
             'no_return_without_foreground','insufficient_evidence']


def clean(x):
    if isinstance(x,np.ndarray):return clean(x.tolist())
    if isinstance(x,np.generic):return clean(x.item())
    if isinstance(x,float) and not math.isfinite(x):return None
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [clean(v) for v in x]
    if isinstance(x,Path):return str(x)
    return x


def json_write(path,obj,compact=False):
    Path(path).write_text(json.dumps(clean(obj),ensure_ascii=False,allow_nan=False,
                         indent=None if compact else 2,separators=(',',':') if compact else None)+'\n',encoding='utf-8')


def json_array_write(path,iterable):
    with Path(path).open('w',encoding='utf-8') as f:
        f.write('[\n');first=True
        for row in iterable:
            if not first:f.write(',\n')
            f.write(json.dumps(clean(row),ensure_ascii=False,allow_nan=False,separators=(',',':')))
            first=False
        f.write('\n]\n')


def npz_write(path,**arrays):
    """Publish only a closed, flushed, CRC-verified archive."""
    path=Path(path)
    fd,temp=tempfile.mkstemp(prefix=path.name+'.',suffix='.partial',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as stream:
            np.savez_compressed(stream,**arrays)
            stream.flush();os.fsync(stream.fileno())
        with zipfile.ZipFile(temp) as archive:
            bad=archive.testzip()
            if bad is not None:raise RuntimeError('NPZ CRC failure: '+bad)
        os.replace(temp,path)
    finally:
        if os.path.exists(temp):os.unlink(temp)


def sha_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()


def sha_array(a):
    a=np.ascontiguousarray(a);h=hashlib.sha256()
    h.update(str(a.dtype).encode());h.update(str(a.shape).encode());h.update(a.tobytes());return h.hexdigest()


def files_hashes(paths):return {str(Path(p).resolve()):sha_file(p) for p in sorted(paths)}


def compare_distance(target,current,current_valid,projection_valid,epsilon,target_valid=None,verified_out_of_view=None):
    target=np.asarray(target,float);current=np.broadcast_to(current,target.shape)
    current_valid=np.broadcast_to(np.asarray(current_valid,bool),target.shape)&np.isfinite(current)&(current>0)
    target_valid=np.isfinite(target)&(target>0) if target_valid is None else np.broadcast_to(np.asarray(target_valid,bool),target.shape)
    projection_valid=np.broadcast_to(np.asarray(projection_valid,bool),target.shape)&target_valid&np.isfinite(target)&(target>0)
    result=np.full(target.shape,CLASS['no_target_observation'],np.uint8)
    result[target_valid]=CLASS['projection_unknown']
    result[projection_valid & ~current_valid]=CLASS['no_return_unknown']
    valid=projection_valid & current_valid;delta=np.full(target.shape,np.nan)
    delta[valid]=current[valid]-target[valid]
    # A tiny roundoff tolerance only protects exact epsilon equality, not a sensor threshold change.
    tol=32*np.finfo(float).eps*np.maximum(1,np.maximum(np.abs(current),np.abs(target)))
    result[valid & (np.abs(delta)<=epsilon+tol)]=CLASS['observed_consistent']
    result[valid & (delta < -epsilon-tol)]=CLASS['foreground_occlusion_candidate']
    result[valid & (delta > epsilon+tol)]=CLASS['behind_target_measurement_candidate']
    if verified_out_of_view is not None:
        outside=np.broadcast_to(np.asarray(verified_out_of_view,bool),target.shape)&target_valid
        result[outside]=CLASS['out_of_view'];delta[outside]=np.nan
    return result,delta,valid


def counts_rates(classes,considered=None):
    cls=np.asarray(classes)
    selected=cls!=0 if considered is None else np.asarray(considered,bool)
    a=cls[selected];counts={name:int((a==code).sum()) for name,code in CLASS.items()}
    total=len(a);compared=sum(counts[x] for x in ('observed_consistent','foreground_occlusion_candidate','behind_target_measurement_candidate'))
    return {'counts':counts,'total_target_evaluations':total,'valid_comparison_count':compared,
            'foreground_support_rate_valid_comparisons':counts['foreground_occlusion_candidate']/compared if compared else None,
            'behind_rate_valid_comparisons':counts['behind_target_measurement_candidate']/compared if compared else None,
            'no_return_rate_all_targets':counts['no_return_unknown']/total if total else None,
            'projection_unknown_rate_all_targets':counts['projection_unknown']/total if total else None,
            'rate_denominators':{'support':'valid_comparison_count','no_return':'total_target_evaluations','projection_unknown':'total_target_evaluations'}}


def evidence_class(foreground,behind,no_return):
    if foreground and behind:return 'mixed_evidence_hold'
    if foreground:return 'occlusion_candidate'
    if behind:return 'depth_contradiction_candidate'
    if no_return:return 'no_return_without_foreground'
    return 'insufficient_evidence'


def flags():
    return {'object_identity_confirmed':False,'trial_merge_adopted':False,
            'free_space_confirmed':False,'disappearance_confirmed':False}
