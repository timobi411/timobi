from copy import deepcopy
import json,math

DEFAULT={
 'version':'0.1.0',
 'parameter_status':'experimental_fixed_before_exp02_diagnostic_run',
 'distance_tolerance':{'mode':'source_projection_depth_error','epsilon_m':None,
                       'verified':False,'verification_record':'',
                       'basis':'Carry source projection.depth_error_m unchanged; sensor accuracy not calibrated here.'},
 'ray_mapping':{'minimum_observations':2,'max_deviation_deg':None,
                'allow_neighbor_inferred_rays':False},
 'plane':{'radius_pixels':None,'min_points':6,'max_rms_m':None,
          'min_minor_span_m':0.02,'min_minor_major_eigenvalue_ratio':0.02,
          'max_normal_minor_eigenvalue_ratio':0.25,
          'min_abs_normal_dot_ray':0.10,'max_extrapolation_m':0.05,
          'max_dual_disagreement_m':0.03},
 'validation':{'range_xyz_atol_m':1e-5,'recomputed_relation_atol':1e-5,
               'recompute_legacy_relations':True,'max_working_mb':4096},
 'viewer':{'max_context_points':20000,'max_relation_lines':600,'display_rotation_deg':0},
 'evaluation':{'dataset_role':'development','minimum_gap_sizes':[1,2,3,4,5]},
 'outputs':{'write_surface_json':True,'write_viewer':True}
}


def merge(dst,src):
    for k,v in src.items():
        if k not in dst:raise ValueError('Unknown diagnostic config key: '+k)
        if isinstance(dst[k],dict):
            if not isinstance(v,dict):raise ValueError('Config object required: '+k)
            merge(dst[k],v)
        else:dst[k]=v


def read(path=None):
    c=deepcopy(DEFAULT)
    if path:
        with open(path) as f:merge(c,json.load(f))
    def finite(x):
        if isinstance(x,dict):
            for v in x.values():finite(v)
        elif isinstance(x,list):
            for v in x:finite(v)
        elif isinstance(x,float) and not math.isfinite(x):raise ValueError('NaN/Inf config')
    finite(c)
    if c['ray_mapping']['allow_neighbor_inferred_rays']:
        raise ValueError('Neighbor-inferred rays are deliberately not implemented in v0.1; no guessed projection')
    if c['distance_tolerance']['mode'] not in ('source_projection_depth_error','explicit'):
        raise ValueError('Invalid epsilon mode')
    if c['distance_tolerance']['verified'] and not c['distance_tolerance']['verification_record'].strip():
        raise ValueError('Verified epsilon needs a verification record')
    if not c['validation']['recompute_legacy_relations']:
        raise ValueError('Label/relation consistency regeneration is a required acceptance gate')
    if c['evaluation']['dataset_role'] not in ('development','held_out','synthetic'):raise ValueError('Invalid dataset role')
    for group,keys in [('ray_mapping',['minimum_observations']),('plane',['min_points']),('viewer',['max_context_points','max_relation_lines'])]:
        for k in keys:
            if not isinstance(c[group][k],int) or c[group][k]<1:raise ValueError(f'{group}.{k} must be positive integer')
    if c['ray_mapping']['minimum_observations']<2:raise ValueError('Ray stability cannot be established from one sample')
    if c['plane']['min_points']<3:raise ValueError('Plane min_points must be >=3')
    if c['viewer']['display_rotation_deg'] not in (0,180):raise ValueError('Display rotation 0/180 only')
    for k in ('min_minor_span_m','min_minor_major_eigenvalue_ratio','max_normal_minor_eigenvalue_ratio','min_abs_normal_dot_ray','max_extrapolation_m','max_dual_disagreement_m'):
        if c['plane'][k]<=0:raise ValueError('Plane thresholds must be positive')
    if c['validation']['max_working_mb']<=0:raise ValueError('Positive memory limit required')
    if any(not isinstance(x,int) or x<1 for x in c['evaluation']['minimum_gap_sizes']):raise ValueError('Gap sizes must be positive integers')
    return c


def resolve(c,source):
    r=deepcopy(c)
    eps=(source['projection']['depth_error_m'] if c['distance_tolerance']['mode']=='source_projection_depth_error' else c['distance_tolerance']['epsilon_m'])
    if eps is None or not math.isfinite(eps) or eps<=0:raise ValueError('Positive epsilon required')
    r['distance_tolerance']['resolved_epsilon_m']=float(eps)
    r['ray_mapping']['max_deviation_deg']=c['ray_mapping']['max_deviation_deg'] if c['ray_mapping']['max_deviation_deg'] is not None else source['temporal']['max_ray_deviation_deg']
    r['plane']['radius_pixels']=c['plane']['radius_pixels'] if c['plane']['radius_pixels'] is not None else source['relations']['local_plane_radius_pixels']
    r['plane']['max_rms_m']=c['plane']['max_rms_m'] if c['plane']['max_rms_m'] is not None else source['relations']['max_local_plane_residual_m']
    if not isinstance(r['plane']['radius_pixels'],int) or r['plane']['radius_pixels']<1:raise ValueError('Invalid plane radius')
    if not 0<r['ray_mapping']['max_deviation_deg']<90 or r['plane']['max_rms_m']<=0:raise ValueError('Invalid geometric tolerances')
    r['source_thresholds']={'projection_depth_error_m':source['projection']['depth_error_m'],
                            'relations_depth_margin_m':source['relations']['depth_margin_m'],
                            'source_projection_verified':source['projection']['verified'],
                            'source_free_space_model_verified':source['projection']['free_space_model_verified'],
                            'source_mode_gap_m':source['temporal']['mode_gap_m'],
                            'hold_boundary_points':source['clustering']['hold_boundary_points']}
    return r
