from pathlib import Path
import contextlib,os,platform,resource,shutil,time,traceback
import numpy as np
import scipy
from . import __version__
from .common import json_write,json_array_write,npz_write,sha_file,sha_array,CLASS,flags
from .config import resolve
from .inputs import load_case
from .geometry import ray_geometry,RAY_HOLD,PLANE_HOLD
from .measured import diagnose_measured,surface_records
from .hypotheses import stage_a_records,diagnose_hypotheses


def new_output(path,inputs):
    out=Path(path).resolve()
    for p in inputs:
        p=Path(p).resolve()
        if p==out or p in out.parents:raise ValueError('Output must not be inside an input run directory')
    out.mkdir(parents=True,exist_ok=False)
    return out


def memory_limit(config):
    stat=Path('/proc/self/statm')
    if not stat.exists():return {'rlimit_enforced':False,'reason':'/proc not available; input estimate still enforced'}
    base=int(stat.read_text().split()[0])*os.sysconf('SC_PAGE_SIZE');growth=int(config['validation']['max_working_mb']*1024**2)
    soft,hard=resource.getrlimit(resource.RLIMIT_AS);new=base+growth
    if soft!=resource.RLIM_INFINITY:new=min(new,soft)
    if hard!=resource.RLIM_INFINITY:new=min(new,hard)
    resource.setrlimit(resource.RLIMIT_AS,(new,hard))
    return {'rlimit_enforced':True,'address_space_limit_bytes':new,'initial_address_space_bytes':base,'additional_budget_bytes':growth}


def snapshot_code(out):
    root=Path(__file__).resolve().parent;dest=out/'code_snapshot';dest.mkdir()
    hashes={}
    for p in sorted(root.glob('*.py')):
        shutil.copyfile(p,dest/p.name);hashes[p.name]=sha_file(p)
    return hashes


def run_case(name,path,c,out,regenerate):
    begin=time.perf_counter();dest=out/'cases'/name;dest.mkdir(parents=True)
    print(name+': checking history and regenerating relation provenance',flush=True)
    data=load_case(path,c,regenerate);cfg=resolve(c,data['source_config'])
    json_write(dest/'source_config.json',data['source_config']);json_write(dest/'resolved_config.json',cfg)
    json_write(dest/'label_relation_audit.json',data['audit'])
    meta={'case_name':name,'source_directory':data['root'],'input_hashes':data['input_hashes'],
          'label_sha256':data['label_sha256'],'geometry_sha256':data['geometry_sha256'],
          'source_kind':'saved_organized_observations','source_input_origin_field_verification':'source config record; no original bag in this package',
          'shape':data['history']['valid'].shape,'reference_sample_index':data['reference'],
          'frame_indices':data['history']['frame_index'],'bag_times_ns':data['history']['bag_time_ns'],
          'header_times_ns':data['history']['header_time_ns'],
          'sensor_origin_xyz':data['origin'],'coordinate_frame_id':str(data['history']['frame_id'][0]),
          'range_units':'m; matches XYZ Euclidean distance within configured numerical tolerance',
          'scene_and_settings_assertions':{k:data['source_config'][k] for k in ('scene','acquisition','validity')},
          'source_label_setting_hold_boundary_points':data['source_config']['clustering']['hold_boundary_points'],
          'relations_regenerated_for_current_labels':regenerate,
          'automatic_merges':0,'cross_T0_T1_projection':False,**flags()}
    json_write(dest/'input_manifest.json',meta)
    stage_a,a_summary=stage_a_records(data);json_write(dest/'stage_A_evidence.json',{'summary':a_summary,'records':stage_a},compact=True)
    print(name+': measured-sample projection diagnostics',flush=True)
    rays=ray_geometry(data,cfg)
    npz_write(dest/'ray_mapping.npz',**{k:v for k,v in rays.items() if isinstance(v,np.ndarray)})
    measured,b_summary=diagnose_measured(data,cfg,rays)
    npz_write(dest/'measured_projection.npz',**measured)
    if c['outputs']['write_surface_json']:json_array_write(dest/'measured_surfaces.json',surface_records(data,measured))
    print(name+': all candidate local-plane hypotheses',flush=True)
    inferred,candidates,planes,c_summary=diagnose_hypotheses(data,cfg,rays,measured,stage_a)
    npz_write(dest/'hypothesized_projection.npz',**inferred)
    json_write(dest/'candidates.json',{'candidate_count':len(candidates),'label_sha256':data['label_sha256'],'records':candidates},compact=True)
    json_write(dest/'local_planes.json',{'planes':planes,'model_type':'hypothesized_not_measured'},compact=True)
    if regenerate:json_write(dest/'regenerated_fragment_relations.json',data['source_relations'],compact=True)
    invariants={'all_essential_source_file_hashes_unchanged':all(sha_file(data['root']/k)==v for k,v in data['input_hashes'].items()),
                'labels_hash_unchanged':sha_array(data['corr']['labels'])==data['label_sha256'],
                'measured_xyz_hash_unchanged':sha_array(data['corr']['xyz'])==data['geometry_sha256'],
                'legacy_missingness_not_written':True,'input_point_or_label_modifications':0,
                'inferred_points_written_to_measured_PCD_or_history':0,
                'object_identity_confirmations':0,'adopted_merges':0}
    if not all(invariants[k] for k in ('all_essential_source_file_hashes_unchanged','labels_hash_unchanged','measured_xyz_hash_unchanged')):raise RuntimeError('Source input changed during diagnosis')
    summary={'case':name,'A':a_summary,'B':b_summary,'C':c_summary,'invariants':invariants,
             'ray_mapping':{k:v for k,v in rays.items() if not isinstance(v,np.ndarray)},
             'ray_counts':{'valid':int(rays['ray_valid'].sum()),'available':int(rays['ray_available'].sum()),
                           'hold_bits':{k:int(((rays['ray_hold_reason']&v)!=0).sum()) for k,v in RAY_HOLD.items()}},
             'class_codes':CLASS,'ray_hold_bits':RAY_HOLD,'plane_hold_bits':PLANE_HOLD,
             'dataset_role':c['evaluation']['dataset_role'],'ground_truth_available':False,
             'accuracy_improvement':None,'false_merge_rate':None,
             'seconds':time.perf_counter()-begin,'peak_process_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
             'no_new_observations_generated':True,'interpretation':'diagnosis only; no object disappearance/free-space/identity confirmation'}
    json_write(dest/'summary.json',summary)
    payload=None
    if c['outputs']['write_viewer']:
        from .viewer import case_data
        payload=case_data(name,data,cfg,rays,measured,inferred,candidates,planes,summary)
    return summary,payload


def run(cases,c,out,regenerate=False):
    start=time.perf_counter();manifest={'version':__version__,'status':'started','case_order':[x[0] for x in cases],
                                      'code_sha256':snapshot_code(out),'python':platform.python_version(),
                                      'numpy':np.__version__,'scipy':scipy.__version__,'config':c,
                                      'memory_limit':memory_limit(c),'cross_case_geometry_combined':False}
    json_write(out/'run_manifest.json',manifest);json_write(out/'config.json',c)
    summaries={};payloads=[]
    try:
        for name,path in cases:
            summary,payload=run_case(name,path,c,out,regenerate)
            summaries[name]=summary
            if payload is not None:payloads.append(payload)
        result={'cases':summaries,'all_inputs_unchanged':all(x['invariants']['all_essential_source_file_hashes_unchanged'] for x in summaries.values()),
                'epsilon_calibrated':c['distance_tolerance']['verified'],'automatic_merges':0,
                'comparison_units':{'A':'fragment-pair candidates; legacy interpolated target','B':'other-frame measured target observations vs one reference','C':'candidate gap occurrences for each inferred model'},
                'units_are_not_interchangeable':True,'held_out_evaluation_status':'not_supplied' if c['evaluation']['dataset_role']!='held_out' else 'user-declared held-out run; independence not automatically verified'}
        if payloads:
            from .viewer import write_viewer
            write_viewer(out/'index.html',payloads,result,c)
        manifest.update(status='completed_diagnostic',total_seconds=time.perf_counter()-start,
                        peak_rss_mib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
                        all_inputs_unchanged=result['all_inputs_unchanged'])
        json_write(out/'evaluation.json',result);json_write(out/'run_manifest.json',manifest)
        print('Completed: '+str(out),flush=True)
        return result
    except Exception as e:
        manifest.update(status='failed',error=str(e),error_type=type(e).__name__)
        json_write(out/'run_manifest.json',manifest)
        json_write(out/'failure.json',{'error':str(e),'traceback':traceback.format_exc(),'partial_output_only':True,'existing_results_replaced':False})
        raise
