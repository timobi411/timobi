#!/usr/bin/env python3

import sys
import json
import shutil
from pathlib import Path
from collections import deque

import numpy as np
import open3d as o3d
import plotly.graph_objects as go
from plotly.subplots import make_subplots


# ============================================================
# 基本設定
# ============================================================

MAX_RANGE = 7.0

VOXEL_SIZE = 0.02

# 椅子の脚など小さい断片をmerge前に残す
MIN_CLUSTER_POINTS = 50

# ============================================================
# Adaptive local reclustering
# ============================================================

# 通常クラスタリング
CLUSTER_TOLERANCE = 0.06

# 巨大クラスタだけ局所的に再分割
LOCAL_RECLUSTER_TOLERANCE = 0.053

# 巨大クラスタ判定
LARGE_CLUSTER_MIN_POINTS = 3000
LARGE_CLUSTER_MIN_DIAGONAL = 2.0

# 中規模だが複数物体が接続している可能性があるクラスタ
MEDIUM_CLUSTER_MIN_POINTS = 500
MEDIUM_CLUSTER_MIN_DIAGONAL = 0.85
MEDIUM_RECLUSTER_TOLERANCE = 0.045


# ============================================================
# RANSAC平面探索
# ============================================================

PLANE_DISTANCE_THRESHOLD = 0.03

MAX_PLANE_CANDIDATES = 20

MIN_PLANE_INLIERS = 120

# X/Y/Z軸から約23度以内
AXIS_ALIGNMENT_THRESHOLD = 0.92


# ============================================================
# 床
# ============================================================

# XY方向の最低サイズ
FLOOR_MIN_LONG = 1.50
FLOOR_MIN_SHORT = 1.00

# シーン下端からこの範囲にある水平面
FLOOR_BOUNDARY_MARGIN = 0.45

# 床面の周囲何mまで削除するか
FLOOR_BAND = 0.04

# RANSACで取れた床面の外周を少し拡張
FLOOR_FOOTPRINT_MARGIN = 0.10

# 主床と同一平面とみなす床断片の条件
FLOOR_FRAGMENT_MAX_ANGLE_DEG = 10.0
FLOOR_FRAGMENT_MAX_DISTANCE = 0.08


# ============================================================
# 天井
# ============================================================

CEILING_MIN_LONG = 1.20
CEILING_MIN_SHORT = 0.80

CEILING_BOUNDARY_MARGIN = 0.45

CEILING_BAND = 0.04

CEILING_FOOTPRINT_MARGIN = 0.10

# 主天井と同一平面とみなす天井断片
CEILING_FRAGMENT_MAX_ANGLE_DEG = 10.0
CEILING_FRAGMENT_MAX_DISTANCE = 0.08


# ============================================================
# 壁
# ============================================================

# 壁の横幅・高さ
WALL_MIN_WIDTH = 1.00
WALL_MIN_HEIGHT = 1.00

# X/Y方向のシーン外周からこの距離以内
WALL_BOUNDARY_MARGIN = 0.40

# 壁の厚み・計測ばらつきを考慮
WALL_BAND = 0.06

WALL_FOOTPRINT_MARGIN = 0.15


# ============================================================
# 表示色
# ============================================================

COLORS = [
    "red",
    "cyan",
    "lime",
    "orange",
    "magenta",
    "yellow",
    "blue",
    "purple",
    "brown",
    "pink",
    "gold",
    "deepskyblue",
    "springgreen",
    "tomato",
    "violet",
    "darkcyan",
    "darkorange",
    "chartreuse",
    "hotpink",
    "royalblue",
]


# ============================================================
# PCD読み込み
# ============================================================

def load_cloud(path):

    pcd = o3d.io.read_point_cloud(
        str(path)
    )

    points = np.asarray(
        pcd.points
    )

    if len(points) == 0:
        raise RuntimeError(
            f"Point cloud is empty: {path}"
        )

    # NaN / Inf
    points = points[
        np.isfinite(points).all(axis=1)
    ]

    # 明らかな遠距離異常点
    ranges = np.linalg.norm(
        points,
        axis=1
    )

    mask = (
        (ranges >= 0.05)
        &
        (ranges <= MAX_RANGE)
    )

    points = points[
        mask
    ]

    result = (
        o3d.geometry.PointCloud()
    )

    result.points = (
        o3d.utility.Vector3dVector(
            points
        )
    )

    return result


# ============================================================
# 平面モデル正規化
# ============================================================

def normalize_plane(model):

    model = np.asarray(
        model,
        dtype=np.float64
    ).copy()

    norm = np.linalg.norm(
        model[:3]
    )

    if norm < 1e-12:
        return model

    return (
        model / norm
    )


# ============================================================
# 平面情報
# ============================================================

def make_plane_info(
    plane_id,
    model,
    plane_points
):

    model = normalize_plane(
        model
    )

    normal = model[:3]

    center = np.mean(
        plane_points,
        axis=0
    )

    extent = (
        plane_points.max(axis=0)
        -
        plane_points.min(axis=0)
    )

    abs_normal = np.abs(
        normal
    )

    dominant_axis = int(
        np.argmax(
            abs_normal
        )
    )

    alignment = float(
        abs_normal[
            dominant_axis
        ]
    )

    horizontal = (
        abs(normal[2])
        >=
        AXIS_ALIGNMENT_THRESHOLD
    )

    vertical = (
        dominant_axis in [0, 1]
        and
        alignment
        >=
        AXIS_ALIGNMENT_THRESHOLD
    )

    return {
        "id": int(
            plane_id
        ),

        "model":
            model,

        "normal":
            normal,

        "center":
            center,

        "extent":
            extent,

        "points":
            plane_points,

        "point_count":
            int(
                len(
                    plane_points
                )
            ),

        "dominant_axis":
            dominant_axis,

        "alignment":
            alignment,

        "horizontal":
            horizontal,

        "vertical":
            vertical,
    }


# ============================================================
# 平面候補を抽出
#
# 重要:
# ここでは何も構造物として削除しない。
#
# 棚板や机をRANSACが見つけても、
# 「候補」として見るだけ。
# ============================================================

def extract_plane_candidates(
    cloud
):

    # Fix Open3D RANSAC randomness for reproducibility.
    o3d.utility.random.seed(42)

    search_points = np.asarray(
        cloud.points
    ).copy()

    planes = []

    print()
    print("======================================")
    print("Plane Candidate Extraction")
    print("======================================")

    for plane_id in range(
        MAX_PLANE_CANDIDATES
    ):

        if (
            len(search_points)
            <
            MIN_PLANE_INLIERS
        ):
            break

        search_cloud = (
            o3d.geometry.PointCloud()
        )

        search_cloud.points = (
            o3d.utility.Vector3dVector(
                search_points
            )
        )

        model, inliers = (
            search_cloud.segment_plane(

                distance_threshold=
                    PLANE_DISTANCE_THRESHOLD,

                ransac_n=3,

                num_iterations=1500,
            )
        )

        inliers = np.asarray(
            inliers,
            dtype=np.int64
        )

        if (
            len(inliers)
            <
            MIN_PLANE_INLIERS
        ):
            break

        plane_points = (
            search_points[
                inliers
            ]
        )

        info = make_plane_info(
            plane_id,
            model,
            plane_points
        )

        planes.append(
            info
        )

        print()
        print(
            f"P{plane_id}"
        )

        print(
            " points     =",
            info[
                "point_count"
            ]
        )

        print(
            " normal     =",
            info[
                "normal"
            ]
        )

        print(
            " center     =",
            info[
                "center"
            ]
        )

        print(
            " extent     =",
            info[
                "extent"
            ]
        )

        print(
            " horizontal =",
            info[
                "horizontal"
            ]
        )

        print(
            " vertical   =",
            info[
                "vertical"
            ]
        )

        # 次のRANSACでは
        # 今見つけた平面候補だけ外す
        keep = np.ones(
            len(search_points),
            dtype=bool
        )

        keep[
            inliers
        ] = False

        search_points = (
            search_points[
                keep
            ]
        )

    print()
    print(
        "Plane candidates:",
        len(planes)
    )

    return planes


# ============================================================
# 床選択
# ============================================================

def select_floor(
    planes,
    low_bound
):

    candidates = []

    for p in planes:

        if not p[
            "horizontal"
        ]:
            continue

        x_size = float(
            p["extent"][0]
        )

        y_size = float(
            p["extent"][1]
        )

        dims = sorted(
            [
                x_size,
                y_size
            ],
            reverse=True
        )

        if (
            dims[0]
            <
            FLOOR_MIN_LONG
            or
            dims[1]
            <
            FLOOR_MIN_SHORT
        ):
            continue

        z = float(
            p["center"][2]
        )

        if (
            abs(
                z
                -
                low_bound[2]
            )
            >
            FLOOR_BOUNDARY_MARGIN
        ):
            continue

        candidates.append(
            p
        )

    if not candidates:
        return None

    # 最も低い大水平面
    candidates.sort(
        key=lambda p:
            p["center"][2]
    )

    return candidates[0]


# ============================================================
# 主床と同一面にある床断片を追加取得
# ============================================================

def select_floor_fragments(
    planes,
    floor
):

    if floor is None:
        return []

    floor_model = normalize_plane(
        floor["model"]
    )

    floor_normal = floor_model[:3]

    fragments = []

    for p in planes:

        if p["id"] == floor["id"]:
            continue

        if not p["horizontal"]:
            continue

        normal = normalize_plane(
            p["model"]
        )[:3]

        dot = abs(
            float(
                np.dot(
                    floor_normal,
                    normal
                )
            )
        )

        dot = np.clip(
            dot,
            -1.0,
            1.0
        )

        angle_deg = float(
            np.degrees(
                np.arccos(dot)
            )
        )

        # 候補平面中心から主床面までの距離
        center = np.asarray(
            p["center"]
        )

        floor_distance = abs(
            float(
                center @ floor_normal
                +
                floor_model[3]
            )
        )

        if (
            angle_deg
            <=
            FLOOR_FRAGMENT_MAX_ANGLE_DEG
            and
            floor_distance
            <=
            FLOOR_FRAGMENT_MAX_DISTANCE
        ):

            fragments.append(
                p
            )

            print(
                "Floor fragment:",
                f"P{p['id']}",
                f"angle={angle_deg:.2f} deg",
                f"distance={floor_distance:.4f} m"
            )

    return fragments


# ============================================================
# 天井選択
# ============================================================

def select_ceiling(
    planes,
    floor,
    high_bound
):

    candidates = []

    for p in planes:

        if not p[
            "horizontal"
        ]:
            continue

        if (
            floor is not None
            and
            p["id"]
            ==
            floor["id"]
        ):
            continue

        dims = sorted(
            [
                float(
                    p["extent"][0]
                ),
                float(
                    p["extent"][1]
                )
            ],
            reverse=True
        )

        if (
            dims[0]
            <
            CEILING_MIN_LONG
            or
            dims[1]
            <
            CEILING_MIN_SHORT
        ):
            continue

        z = float(
            p["center"][2]
        )

        if (
            abs(
                high_bound[2]
                -
                z
            )
            >
            CEILING_BOUNDARY_MARGIN
        ):
            continue

        candidates.append(
            p
        )

    if not candidates:
        return None

    # 最も高いもの
    candidates.sort(
        key=lambda p:
            p["center"][2],
        reverse=True
    )

    return candidates[0]


# ============================================================
# 外周壁
# ============================================================

def select_walls(
    planes,
    low_bound,
    high_bound
):

    walls = []

    for p in planes:

        if not p[
            "vertical"
        ]:
            continue

        axis = int(
            p[
                "dominant_axis"
            ]
        )

        # X法線壁なら
        # Y方向の長さ + Z高さを見る
        if axis == 0:

            width = float(
                p["extent"][1]
            )

        # Y法線壁なら
        # X方向の長さ + Z高さ
        else:

            width = float(
                p["extent"][0]
            )

        height = float(
            p["extent"][2]
        )

        if (
            width
            <
            WALL_MIN_WIDTH
            or
            height
            <
            WALL_MIN_HEIGHT
        ):
            continue

        position = float(
            p["center"][axis]
        )

        dist_low = abs(
            position
            -
            low_bound[axis]
        )

        dist_high = abs(
            high_bound[axis]
            -
            position
        )

        if (
            min(
                dist_low,
                dist_high
            )
            >
            WALL_BOUNDARY_MARGIN
        ):
            continue

        walls.append(
            p
        )

    return walls


# ============================================================
# RANSACで検出した有限平面の周辺を削除
#
# 無限平面全体を消さない。
# 実際に観測された平面領域の周囲だけ消す。
# ============================================================

def finite_plane_band_mask(
    all_points,
    plane,
    band,
    footprint_margin
):

    model = normalize_plane(
        plane[
            "model"
        ]
    )

    normal = model[:3]

    d = float(
        model[3]
    )

    plane_points = (
        plane[
            "points"
        ]
    )

    center = np.mean(
        plane_points,
        axis=0
    )

    # 平面上の基準点
    signed_distance = (
        center @ normal
        +
        d
    )

    origin = (
        center
        -
        signed_distance
        *
        normal
    )

    # ========================================================
    # 平面内のu/v軸
    # ========================================================

    if abs(
        normal[2]
    ) < 0.90:

        reference = np.array(
            [
                0.0,
                0.0,
                1.0
            ]
        )

    else:

        reference = np.array(
            [
                1.0,
                0.0,
                0.0
            ]
        )

    u = np.cross(
        normal,
        reference
    )

    if (
        np.linalg.norm(u)
        <
        1e-8
    ):

        reference = np.array(
            [
                0.0,
                1.0,
                0.0
            ]
        )

        u = np.cross(
            normal,
            reference
        )

    u /= np.linalg.norm(
        u
    )

    v = np.cross(
        normal,
        u
    )

    v /= np.linalg.norm(
        v
    )

    # ========================================================
    # 検出平面の実際の範囲
    # ========================================================

    plane_rel = (
        plane_points
        -
        origin
    )

    plane_u = (
        plane_rel
        @
        u
    )

    plane_v = (
        plane_rel
        @
        v
    )

    u_min = (
        plane_u.min()
        -
        footprint_margin
    )

    u_max = (
        plane_u.max()
        +
        footprint_margin
    )

    v_min = (
        plane_v.min()
        -
        footprint_margin
    )

    v_max = (
        plane_v.max()
        +
        footprint_margin
    )

    # ========================================================
    # 全点を判定
    # ========================================================

    rel = (
        all_points
        -
        origin
    )

    point_u = (
        rel @ u
    )

    point_v = (
        rel @ v
    )

    distance = np.abs(
        all_points
        @
        normal
        +
        d
    )

    inside = (
        (point_u >= u_min)
        &
        (point_u <= u_max)
        &
        (point_v >= v_min)
        &
        (point_v <= v_max)
    )

    return (
        inside
        &
        (
            distance
            <=
            band
        )
    )


# ============================================================
# 床・壁・天井だけ除去
# ============================================================


# ============================================================
# 主天井と同一面にある天井断片を追加取得
# ============================================================

def select_ceiling_fragments(
    planes,
    ceiling
):

    if ceiling is None:
        return []

    ceiling_model = normalize_plane(
        ceiling["model"]
    )

    ceiling_normal = ceiling_model[:3]

    fragments = []

    for p in planes:

        if p["id"] == ceiling["id"]:
            continue

        if not p["horizontal"]:
            continue

        normal = normalize_plane(
            p["model"]
        )[:3]

        dot = abs(
            float(
                np.dot(
                    ceiling_normal,
                    normal
                )
            )
        )

        dot = float(
            np.clip(
                dot,
                -1.0,
                1.0
            )
        )

        angle_deg = float(
            np.degrees(
                np.arccos(
                    dot
                )
            )
        )

        center = np.asarray(
            p["center"],
            dtype=np.float64
        )

        ceiling_distance = abs(
            float(
                center @ ceiling_normal
                +
                ceiling_model[3]
            )
        )

        if (
            angle_deg <= CEILING_FRAGMENT_MAX_ANGLE_DEG
            and
            ceiling_distance <= CEILING_FRAGMENT_MAX_DISTANCE
        ):

            fragments.append(
                p
            )

            print(
                "Ceiling fragment:",
                f"P{p['id']}",
                f"angle={angle_deg:.2f} deg",
                f"distance={ceiling_distance:.4f} m"
            )

    return fragments


def remove_room_structures(
    cloud
):

    points = np.asarray(
        cloud.points
    )

    # 少数外れ値の影響を抑える
    low_bound = np.percentile(
        points,
        1.0,
        axis=0
    )

    high_bound = np.percentile(
        points,
        99.0,
        axis=0
    )

    print()
    print("======================================")
    print("Scene Bounds")
    print("======================================")

    print(
        "low :",
        low_bound
    )

    print(
        "high:",
        high_bound
    )

    planes = (
        extract_plane_candidates(
            cloud
        )
    )

    floor = select_floor(
        planes,
        low_bound
    )

    floor_fragments = (
        select_floor_fragments(
            planes,
            floor
        )
    )

    ceiling = select_ceiling(
        planes,
        floor,
        high_bound
    )

    ceiling_fragments = (
        select_ceiling_fragments(
            planes,
            ceiling
        )
    )

    walls = select_walls(
        planes,
        low_bound,
        high_bound
    )

    print()
    print("======================================")
    print("Room Structure Classification")
    print("======================================")

    if floor is None:

        print(
            "Floor   : NONE"
        )

    else:

        print(
            "Floor   :",
            f"P{floor['id']}",
            "center=",
            floor["center"]
        )

    if ceiling is None:

        print(
            "Ceiling : NONE"
        )

    else:

        print(
            "Ceiling :",
            f"P{ceiling['id']}",
            "center=",
            ceiling["center"]
        )

    print(
        "Walls   :",
        [
            f"P{x['id']}"
            for x in walls
        ]
    )

    print()
    print(
        "IMPORTANT:"
    )

    print(
        "Desk / shelf / chair / stairs are NOT removed here."
    )

    # ========================================================
    # マスク
    # ========================================================

    floor_mask = np.zeros(
        len(points),
        dtype=bool
    )

    ceiling_mask = np.zeros(
        len(points),
        dtype=bool
    )

    wall_mask = np.zeros(
        len(points),
        dtype=bool
    )

    # floor
    if floor is not None:

        floor_mask |= (
            finite_plane_band_mask(
                points,
                floor,
                FLOOR_BAND,
                FLOOR_FOOTPRINT_MARGIN
            )
        )

    # 同一床面として検出された床断片も除去
    for floor_fragment in floor_fragments:

        floor_mask |= (
            finite_plane_band_mask(
                points,
                floor_fragment,
                FLOOR_BAND,
                FLOOR_FOOTPRINT_MARGIN
            )
        )

    # ceiling
    if ceiling is not None:

        ceiling_mask |= (
            finite_plane_band_mask(
                points,
                ceiling,
                CEILING_BAND,
                CEILING_FOOTPRINT_MARGIN
            )
        )

    # 同一天井面として検出された天井断片も除去
    for ceiling_fragment in ceiling_fragments:

        ceiling_mask |= (
            finite_plane_band_mask(
                points,
                ceiling_fragment,
                CEILING_BAND,
                CEILING_FOOTPRINT_MARGIN
            )
        )

    # walls
    for wall in walls:

        wall_mask |= (
            finite_plane_band_mask(
                points,
                wall,
                WALL_BAND,
                WALL_FOOTPRINT_MARGIN
            )
        )

    remove_mask = (
        floor_mask
        |
        ceiling_mask
        |
        wall_mask
    )

    remaining_points = (
        points[
            ~remove_mask
        ]
    )

    # ========================================================
    # PCD生成
    # ========================================================

    object_cloud = (
        o3d.geometry.PointCloud()
    )

    object_cloud.points = (
        o3d.utility.Vector3dVector(
            remaining_points
        )
    )

    floor_cloud = (
        o3d.geometry.PointCloud()
    )

    floor_cloud.points = (
        o3d.utility.Vector3dVector(
            points[
                floor_mask
            ]
        )
    )

    wall_cloud = (
        o3d.geometry.PointCloud()
    )

    wall_cloud.points = (
        o3d.utility.Vector3dVector(
            points[
                wall_mask
            ]
        )
    )

    ceiling_cloud = (
        o3d.geometry.PointCloud()
    )

    ceiling_cloud.points = (
        o3d.utility.Vector3dVector(
            points[
                ceiling_mask
            ]
        )
    )

    print()
    print("--------------------------------------")

    print(
        "Before       :",
        len(points)
    )

    print(
        "Floor removed:",
        int(
            floor_mask.sum()
        )
    )

    print(
        "Wall removed :",
        int(
            wall_mask.sum()
        )
    )

    print(
        "Ceiling rem. :",
        int(
            ceiling_mask.sum()
        )
    )

    print(
        "Total removed:",
        int(
            remove_mask.sum()
        )
    )

    print(
        "Remaining    :",
        len(
            remaining_points
        )
    )

    print("======================================")

    return (
        object_cloud,
        floor_cloud,
        wall_cloud,
        ceiling_cloud,
    )


# ============================================================
# Euclidean Clustering
# ============================================================


def measure_precluster_density(
    cloud,
    name
):

    import json

    points = np.asarray(
        cloud.points
    )

    result = {
        "name": name,
        "stage": "after_structure_removal_before_clustering",
        "voxel_size_m": float(VOXEL_SIZE),
        "points": int(len(points)),
    }

    if len(points) < 2:

        result.update({
            "valid_nn_points": 0,
            "nn_mean_m": None,
            "nn_median_m": None,
            "nn_p25_m": None,
            "nn_p75_m": None,
            "nn_p90_m": None,
        })

    else:

        distances = np.asarray(
            cloud.compute_nearest_neighbor_distance(),
            dtype=np.float64
        )

        distances = distances[
            np.isfinite(distances)
        ]

        # Duplicate/zero-distance points are not useful
        # for spacing estimation.
        distances = distances[
            distances > 0.0
        ]

        if len(distances) == 0:

            result.update({
                "valid_nn_points": 0,
                "nn_mean_m": None,
                "nn_median_m": None,
                "nn_p25_m": None,
                "nn_p75_m": None,
                "nn_p90_m": None,
            })

        else:

            result.update({
                "valid_nn_points":
                    int(len(distances)),

                "nn_mean_m":
                    float(
                        np.mean(distances)
                    ),

                "nn_median_m":
                    float(
                        np.median(distances)
                    ),

                "nn_p25_m":
                    float(
                        np.percentile(
                            distances,
                            25
                        )
                    ),

                "nn_p75_m":
                    float(
                        np.percentile(
                            distances,
                            75
                        )
                    ),

                "nn_p90_m":
                    float(
                        np.percentile(
                            distances,
                            90
                        )
                    ),
            })

    output = Path(
        f"{name}_precluster_density.json"
    )

    with open(
        output,
        "w"
    ) as f:

        json.dump(
            result,
            f,
            indent=2
        )

    print()
    print("======================================")
    print("Pre-cluster Point Density")
    print("======================================")
    print("Points    :", result["points"])
    print(
        "Valid NN  :",
        result["valid_nn_points"]
    )
    print(
        "NN median :",
        result["nn_median_m"]
    )
    print(
        "NN mean   :",
        result["nn_mean_m"]
    )
    print(
        "NN p25    :",
        result["nn_p25_m"]
    )
    print(
        "NN p75    :",
        result["nn_p75_m"]
    )
    print(
        "NN p90    :",
        result["nn_p90_m"]
    )
    print("JSON      :", output)
    print("======================================")

    return result


def euclidean_clustering(
    pcd,
    tolerance,
    min_points
):

    points = np.asarray(
        pcd.points
    )

    n = len(
        points
    )

    if n == 0:
        return []

    tree = (
        o3d.geometry.KDTreeFlann(
            pcd
        )
    )

    visited = np.zeros(
        n,
        dtype=bool
    )

    clusters = []

    for start in range(n):

        if visited[start]:
            continue

        visited[start] = True

        queue = deque(
            [start]
        )

        cluster = []

        while queue:

            current = (
                queue.popleft()
            )

            cluster.append(
                current
            )

            _, indices, _ = (
                tree.search_radius_vector_3d(
                    points[current],
                    tolerance
                )
            )

            for index in indices:

                if not visited[
                    index
                ]:

                    visited[
                        index
                    ] = True

                    queue.append(
                        index
                    )

        if (
            len(cluster)
            >=
            min_points
        ):

            clusters.append(
                np.asarray(
                    cluster,
                    dtype=np.int32
                )
            )

    clusters.sort(
        key=len,
        reverse=True
    )

    return clusters


# ============================================================
# OBB
# ============================================================


# ============================================================
# 巨大クラスタだけ局所再クラスタリング
# ============================================================

def adaptive_recluster(
    object_cloud,
    clusters
):

    all_points = np.asarray(
        object_cloud.points
    )

    final_clusters = []

    print()
    print("======================================")
    print("Adaptive Local Reclustering")
    print("======================================")

    for original_id, indices in enumerate(
        clusters
    ):

        pts = all_points[
            indices
        ]

        extent = (
            pts.max(axis=0)
            -
            pts.min(axis=0)
        )

        diagonal = float(
            np.linalg.norm(
                extent
            )
        )

        is_large = (
            len(indices)
            >=
            LARGE_CLUSTER_MIN_POINTS
            and
            diagonal
            >=
            LARGE_CLUSTER_MIN_DIAGONAL
        )

        is_medium_wide = (
            len(indices)
            >=
            MEDIUM_CLUSTER_MIN_POINTS
            and
            diagonal
            >=
            MEDIUM_CLUSTER_MIN_DIAGONAL
        )

        needs_recluster = (
            is_large
            or
            is_medium_wide
        )

        print()
        print(
            f"Global C{original_id}:",
            f"{len(indices)} pts",
            f"diag={diagonal:.3f} m",
            (
                "LARGE"
                if is_large
                else
                (
                    "MEDIUM-WIDE"
                    if is_medium_wide
                    else
                    "keep"
                )
            )
        )

        if not needs_recluster:

            final_clusters.append(
                indices
            )

            continue

        # ----------------------------------------------------
        # 巨大クラスタだけ別PointCloud化
        # ----------------------------------------------------

        local_cloud = (
            o3d.geometry.PointCloud()
        )

        local_cloud.points = (
            o3d.utility.Vector3dVector(
                pts
            )
        )

        # LARGEは従来条件を維持。
        # MEDIUM-WIDEだけ、近接した別物体を分離するため
        # より小さいtoleranceを使用する。
        if is_large:
            recluster_tolerance = (
                LOCAL_RECLUSTER_TOLERANCE
            )
        else:
            recluster_tolerance = (
                MEDIUM_RECLUSTER_TOLERANCE
            )

        print(
            " recluster tolerance:",
            recluster_tolerance
        )

        local_clusters = (
            euclidean_clustering(
                local_cloud,
                recluster_tolerance,
                MIN_CLUSTER_POINTS
            )
        )

        print(
            " local clusters:",
            len(local_clusters)
        )

        # 元object_cloudのindexへ戻す
        for local_id, local_indices in enumerate(
            local_clusters
        ):

            mapped_indices = (
                indices[
                    local_indices
                ]
            )

            local_pts = all_points[
                mapped_indices
            ]

            local_extent = (
                local_pts.max(axis=0)
                -
                local_pts.min(axis=0)
            )

            local_diag = float(
                np.linalg.norm(
                    local_extent
                )
            )

            print(
                f"   L{local_id}:",
                f"{len(mapped_indices)} pts",
                f"diag={local_diag:.3f} m"
            )

            final_clusters.append(
                mapped_indices
            )

    print()
    print(
        "Final clusters:",
        len(final_clusters)
    )

    return final_clusters


def compute_obb(
    pcd
):

    try:

        return (
            pcd
            .get_oriented_bounding_box(
                robust=True
            )
        )

    except Exception:

        return (
            pcd
            .get_axis_aligned_bounding_box()
            .get_oriented_bounding_box()
        )


def obb_lines(
    obb
):

    line_set = (
        o3d.geometry.LineSet
        .create_from_oriented_bounding_box(
            obb
        )
    )

    points = np.asarray(
        line_set.points
    )

    lines = np.asarray(
        line_set.lines
    )

    xs = []
    ys = []
    zs = []

    for a, b in lines:

        xs += [
            points[a, 0],
            points[b, 0],
            None
        ]

        ys += [
            points[a, 1],
            points[b, 1],
            None
        ]

        zs += [
            points[a, 2],
            points[b, 2],
            None
        ]

    return (
        xs,
        ys,
        zs
    )


# ============================================================
# 構造除去確認HTML
# ============================================================

def create_structure_check_html(
    name,
    object_cloud,
    floor_cloud,
    wall_cloud,
    ceiling_cloud
):

    fig = go.Figure()

    data = [
        (
            "Remaining objects",
            object_cloud,
            "green",
            0.80
        ),
        (
            "Removed floor",
            floor_cloud,
            "orange",
            0.75
        ),
        (
            "Removed wall",
            wall_cloud,
            "red",
            0.75
        ),
        (
            "Removed ceiling",
            ceiling_cloud,
            "blue",
            0.75
        ),
    ]

    for (
        label,
        cloud,
        color,
        opacity
    ) in data:

        points = np.asarray(
            cloud.points
        )

        if len(points) == 0:
            continue

        fig.add_trace(
            go.Scatter3d(

                x=points[:, 0],
                y=points[:, 1],
                z=points[:, 2],

                mode="markers",

                name=label,

                marker=dict(
                    size=1.5,
                    color=color,
                    opacity=opacity
                ),

                hoverinfo="skip"
            )
        )

    fig.update_layout(

        title=(
            f"{name.upper()} "
            "Room Structure Removal Check"
        ),

        scene=dict(

            xaxis_title="X [m]",
            yaxis_title="Y [m]",
            zaxis_title="Z [m]",

            aspectmode="data"
        ),

        width=1400,
        height=950,

        margin=dict(
            l=0,
            r=0,
            b=0,
            t=60
        )
    )

    path = (
        f"{name}_structure_check.html"
    )

    fig.write_html(
        path,
        include_plotlyjs=True
    )

    return path


# ============================================================
# main
# ============================================================

def main():

    if len(sys.argv) != 3:

        print(
            "Usage:"
        )

        print(
            " python3 cluster_obb_html.py "
            "<input.pcd> <name>"
        )

        sys.exit(1)

    input_path = Path(
        sys.argv[1]
    )

    name = sys.argv[2]

    output_dir = Path(
        f"{name}_clusters"
    )

    if output_dir.exists():

        shutil.rmtree(
            output_dir
        )

    output_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    # ========================================================
    # load
    # ========================================================

    cloud = load_cloud(
        input_path
    )

    print()
    print("======================================")
    print("Input")
    print("======================================")

    print(
        "File:",
        input_path
    )

    print(
        "Points:",
        len(
            cloud.points
        )
    )

    # ========================================================
    # voxel
    # ========================================================

    cloud = (
        cloud.voxel_down_sample(
            VOXEL_SIZE
        )
    )

    print(
        "Voxel:",
        VOXEL_SIZE
    )

    print(
        "Voxelized:",
        len(
            cloud.points
        )
    )

    o3d.io.write_point_cloud(
        f"{name}_voxel.pcd",
        cloud
    )

    # ========================================================
    # 床・壁・天井だけ除去
    # ========================================================

    (
        object_cloud,
        floor_cloud,
        wall_cloud,
        ceiling_cloud
    ) = remove_room_structures(
        cloud
    )

    o3d.io.write_point_cloud(
        f"{name}_structure_removed.pcd",
        object_cloud
    )

    o3d.io.write_point_cloud(
        f"{name}_removed_floor.pcd",
        floor_cloud
    )

    o3d.io.write_point_cloud(
        f"{name}_removed_wall.pcd",
        wall_cloud
    )

    o3d.io.write_point_cloud(
        f"{name}_removed_ceiling.pcd",
        ceiling_cloud
    )

    structure_html = (
        create_structure_check_html(
            name,
            object_cloud,
            floor_cloud,
            wall_cloud,
            ceiling_cloud
        )
    )

    # ========================================================
    # Pre-cluster density measurement
    # ========================================================

    measure_precluster_density(
        object_cloud,
        name
    )

    # ========================================================
    # clustering
    # ========================================================

    clusters = (
        euclidean_clustering(
            object_cloud,
            CLUSTER_TOLERANCE,
            MIN_CLUSTER_POINTS
        )
    )

    # ========================================================
    # 巨大クラスタのみ局所0.05 mで再クラスタリング
    # ========================================================

    clusters = (
        adaptive_recluster(
            object_cloud,
            clusters
        )
    )

    print()
    print("======================================")

    print(
        "Detected clusters:",
        len(
            clusters
        )
    )

    print("======================================")

    points = np.asarray(
        object_cloud.points
    )

    clustered_mask = np.zeros(
        len(points),
        dtype=bool
    )

    metadata = []

    fig = go.Figure()

    labels_x = []
    labels_y = []
    labels_z = []
    labels_text = []

    # ========================================================
    # clusters
    # ========================================================

    for (
        cluster_id,
        indices
    ) in enumerate(
        clusters
    ):

        clustered_mask[
            indices
        ] = True

        cluster_points = (
            points[
                indices
            ]
        )

        cluster_pcd = (
            o3d.geometry.PointCloud()
        )

        cluster_pcd.points = (
            o3d.utility.Vector3dVector(
                cluster_points
            )
        )

        obb = compute_obb(
            cluster_pcd
        )

        center = np.asarray(
            obb.center
        )

        extent = np.asarray(
            obb.extent
        )

        rotation = np.asarray(
            obb.R
        )

        cluster_path = (
            output_dir
            /
            f"cluster_{cluster_id:03d}.pcd"
        )

        o3d.io.write_point_cloud(
            str(
                cluster_path
            ),
            cluster_pcd
        )

        metadata.append(
            {
                "cluster_id":
                    int(
                        cluster_id
                    ),

                "points":
                    int(
                        len(
                            cluster_points
                        )
                    ),

                "center":
                    center.tolist(),

                "extent":
                    extent.tolist(),

                "rotation":
                    rotation.tolist(),

                "pcd":
                    str(
                        cluster_path
                    ),
            }
        )

        print()
        print(
            f"C{cluster_id}"
        )

        print(
            " points =",
            len(
                cluster_points
            )
        )

        print(
            " center =",
            center
        )

        print(
            " extent =",
            extent
        )

        color = (
            COLORS[
                cluster_id
                %
                len(
                    COLORS
                )
            ]
        )

        fig.add_trace(
            go.Scatter3d(

                x=cluster_points[:, 0],
                y=cluster_points[:, 1],
                z=cluster_points[:, 2],

                mode="markers",

                name=(
                    f"C{cluster_id} "
                    f"({len(cluster_points)} pts)"
                ),

                marker=dict(
                    size=2,
                    color=color,
                    opacity=0.85
                ),

                hoverinfo="skip"
            )
        )

        xs, ys, zs = (
            obb_lines(
                obb
            )
        )

        fig.add_trace(
            go.Scatter3d(

                x=xs,
                y=ys,
                z=zs,

                mode="lines",

                line=dict(
                    color="black",
                    width=5
                ),

                showlegend=False,

                hoverinfo="skip"
            )
        )

        labels_x.append(
            center[0]
        )

        labels_y.append(
            center[1]
        )

        labels_z.append(
            center[2]
        )

        labels_text.append(
            f"C{cluster_id}"
        )

    # ========================================================
    # 未クラスタ点
    # ========================================================

    noise = (
        points[
            ~clustered_mask
        ]
    )

    if len(noise) > 0:

        fig.add_trace(
            go.Scatter3d(

                x=noise[:, 0],
                y=noise[:, 1],
                z=noise[:, 2],

                mode="markers",

                name=(
                    "unclustered "
                    f"({len(noise)} pts)"
                ),

                marker=dict(
                    size=1,
                    color="lightgray",
                    opacity=0.18
                ),

                hoverinfo="skip"
            )
        )

    if labels_x:

        fig.add_trace(
            go.Scatter3d(

                x=labels_x,
                y=labels_y,
                z=labels_z,

                mode="text",

                text=labels_text,

                textfont=dict(
                    size=17,
                    color="black"
                ),

                showlegend=False,

                hoverinfo="skip"
            )
        )

    fig.update_layout(

        title=(
            f"{name.upper()} "
            "Floor/Wall/Ceiling Removal "
            "+ Clustering + OBB"
        ),

        scene=dict(

            xaxis_title="X [m]",
            yaxis_title="Y [m]",
            zaxis_title="Z [m]",

            aspectmode="data"
        ),

        width=1400,
        height=950,

        margin=dict(
            l=0,
            r=0,
            b=0,
            t=60
        )
    )

    html_path = (
        f"{name}_clusters_obb.html"
    )

    fig.write_html(
        html_path,
        include_plotlyjs=True
    )

    with open(
        f"{name}_clusters.json",
        "w"
    ) as f:

        json.dump(
            metadata,
            f,
            indent=2
        )

    print()
    print("======================================")
    print("Finished")
    print("======================================")

    print(
        "Structure check:",
        structure_html
    )

    print(
        "Remaining PCD:",
        f"{name}_structure_removed.pcd"
    )

    print(
        "Floor PCD:",
        f"{name}_removed_floor.pcd"
    )

    print(
        "Wall PCD:",
        f"{name}_removed_wall.pcd"
    )

    print(
        "Ceiling PCD:",
        f"{name}_removed_ceiling.pcd"
    )

    print(
        "Cluster HTML:",
        html_path
    )

    print(
        "Cluster JSON:",
        f"{name}_clusters.json"
    )

    print("======================================")


if __name__ == "__main__":
    main()
