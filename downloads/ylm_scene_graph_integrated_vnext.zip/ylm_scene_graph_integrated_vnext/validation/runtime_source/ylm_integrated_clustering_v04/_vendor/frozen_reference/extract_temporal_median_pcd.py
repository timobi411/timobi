#!/usr/bin/env python3

import sys
from pathlib import Path

import numpy as np

import rosbag2_py
from rclpy.serialization import deserialize_message
from sensor_msgs.msg import PointCloud2
from sensor_msgs_py import point_cloud2


TOPIC = "/lumotive_ros/pointcloud"

# 中央を含む奇数にする
NUM_FRAMES = 11

MIN_RANGE = 0.05
MAX_RANGE = 12.0

# 11フレーム中、最低何フレーム有効なら
# その画素を採用するか
MIN_VALID_FRAMES = 5


def open_reader(bag_dir):
    reader = rosbag2_py.SequentialReader()

    storage_options = rosbag2_py.StorageOptions(
        uri=str(bag_dir),
        storage_id="sqlite3",
    )

    converter_options = rosbag2_py.ConverterOptions(
        input_serialization_format="cdr",
        output_serialization_format="cdr",
    )

    reader.open(
        storage_options,
        converter_options
    )

    return reader


def read_all_cloud_messages(bag_dir):
    reader = open_reader(bag_dir)

    messages = []

    while reader.has_next():
        topic, data, timestamp = reader.read_next()

        if topic != TOPIC:
            continue

        msg = deserialize_message(
            data,
            PointCloud2
        )

        messages.append(
            (msg, timestamp)
        )

    return messages


def msg_to_xyz(msg):
    points = []

    # skip_nans=False が重要
    # organized配列の位置を維持する
    for p in point_cloud2.read_points(
        msg,
        field_names=("x", "y", "z"),
        skip_nans=False,
    ):
        points.append(
            [
                float(p[0]),
                float(p[1]),
                float(p[2]),
            ]
        )

    xyz = np.asarray(
        points,
        dtype=np.float32
    )

    expected = (
        msg.width *
        msg.height
    )

    if len(xyz) != expected:
        raise RuntimeError(
            f"Point count mismatch: "
            f"{len(xyz)} != {expected}"
        )

    xyz = xyz.reshape(
        msg.height,
        msg.width,
        3
    )

    return xyz


def build_temporal_representative(
    xyz_stack
):
    """
    xyz_stack:
        [F, H, W, 3]

    各pixelで、
    1. 各フレームのRangeを計算
    2. 有効Rangeの中央値を計算
    3. 中央値に最も近い「実測点」を代表XYZとして採用

    座標ごとのmedianではなく、
    実際に観測されたXYZを選ぶ。
    """

    ranges = np.linalg.norm(
        xyz_stack,
        axis=3
    )

    valid = (
        np.isfinite(xyz_stack).all(axis=3)
        &
        np.isfinite(ranges)
        &
        (ranges >= MIN_RANGE)
        &
        (ranges <= MAX_RANGE)
    )

    valid_count = valid.sum(
        axis=0
    )

    # invalidをNaNへ
    ranges_nan = np.where(
        valid,
        ranges,
        np.nan
    )

    with np.errstate(
        all="ignore"
    ):
        median_range = np.nanmedian(
            ranges_nan,
            axis=0
        )

    # 各フレームが中央値からどれだけ離れているか
    difference = np.abs(
        ranges -
        median_range[None, :, :]
    )

    difference[~valid] = np.inf

    # median rangeに最も近い実測フレーム
    best_frame = np.argmin(
        difference,
        axis=0
    )

    _, h, w, _ = (
        xyz_stack.shape
    )

    vv, uu = np.indices(
        (h, w)
    )

    representative_xyz = (
        xyz_stack[
            best_frame,
            vv,
            uu
        ]
    )

    representative_valid = (
        (valid_count >= MIN_VALID_FRAMES)
        &
        np.isfinite(median_range)
    )

    # 無効pixelはNaNにしてorganized形状を維持
    representative_xyz[
        ~representative_valid
    ] = np.nan

    representative_range = np.linalg.norm(
        representative_xyz,
        axis=2
    )

    representative_range[
        ~representative_valid
    ] = np.nan

    # Rangeの時間方向MADも保存
    with np.errstate(
        all="ignore"
    ):
        mad = np.nanmedian(
            np.abs(
                ranges_nan -
                median_range[None, :, :]
            ),
            axis=0
        )

    mad[
        ~representative_valid
    ] = np.nan

    return (
        representative_xyz,
        representative_range,
        representative_valid,
        valid_count,
        mad,
    )


def save_ascii_pcd(
    path,
    xyz,
    valid
):
    points = xyz[
        valid
    ]

    with open(
        path,
        "w"
    ) as f:
        f.write(
            "# .PCD v0.7 - Point Cloud Data file format\n"
        )
        f.write("VERSION 0.7\n")
        f.write("FIELDS x y z\n")
        f.write("SIZE 4 4 4\n")
        f.write("TYPE F F F\n")
        f.write("COUNT 1 1 1\n")
        f.write(
            f"WIDTH {len(points)}\n"
        )
        f.write("HEIGHT 1\n")
        f.write(
            "VIEWPOINT 0 0 0 1 0 0 0\n"
        )
        f.write(
            f"POINTS {len(points)}\n"
        )
        f.write("DATA ascii\n")

        for x, y, z in points:
            f.write(
                f"{x:.6f} "
                f"{y:.6f} "
                f"{z:.6f}\n"
            )


def main():
    if len(sys.argv) != 3:
        print(
            "Usage:\n"
            " python3 extract_temporal_median_pcd.py "
            "<bag_dir> <prefix>\n\n"
            "Example:\n"
            " python3 extract_temporal_median_pcd.py "
            "t0_bag t0"
        )
        sys.exit(1)

    bag_dir = Path(
        sys.argv[1]
    )

    prefix = sys.argv[2]

    messages = read_all_cloud_messages(
        bag_dir
    )

    total = len(messages)

    if total == 0:
        raise RuntimeError(
            f"No messages on {TOPIC}"
        )

    if total < NUM_FRAMES:
        raise RuntimeError(
            f"Need at least {NUM_FRAMES} frames, "
            f"but bag has {total}"
        )

    middle = total // 2
    half = NUM_FRAMES // 2

    start = (
        middle - half
    )

    end = (
        middle + half + 1
    )

    selected = messages[
        start:end
    ]

    print()
    print("======================================")
    print("Temporal Representative Extraction")
    print("======================================")

    print(
        "Bag:",
        bag_dir
    )

    print(
        "Total PointCloud2 frames:",
        total
    )

    print(
        "Selected frame indices:",
        list(
            range(
                start,
                end
            )
        )
    )

    print(
        "Number of selected frames:",
        len(selected)
    )

    first_msg = selected[0][0]

    print(
        "Organized size:",
        first_msg.width,
        "x",
        first_msg.height
    )

    xyz_frames = []

    for local_index, (
        msg,
        timestamp
    ) in enumerate(
        selected
    ):
        if (
            msg.width != first_msg.width
            or
            msg.height != first_msg.height
        ):
            raise RuntimeError(
                "PointCloud2 dimensions changed "
                "inside selected frames"
            )

        xyz = msg_to_xyz(
            msg
        )

        xyz_frames.append(
            xyz
        )

        valid_single = (
            np.isfinite(
                xyz
            ).all(axis=2)
        )

        print(
            f"Frame "
            f"{start + local_index}: "
            f"finite={int(valid_single.sum())}"
        )

    xyz_stack = np.stack(
        xyz_frames,
        axis=0
    )

    (
        representative_xyz,
        representative_range,
        representative_valid,
        valid_count,
        mad,
    ) = build_temporal_representative(
        xyz_stack
    )

    print()
    print("--------------------------------------")
    print(
        "Representative valid pixels:",
        int(
            representative_valid.sum()
        )
    )

    valid_mad = mad[
        np.isfinite(mad)
    ]

    if len(valid_mad) > 0:
        print(
            "Median temporal MAD:",
            float(
                np.median(
                    valid_mad
                )
            ),
            "m"
        )

        print(
            "95% temporal MAD:",
            float(
                np.percentile(
                    valid_mad,
                    95
                )
            ),
            "m"
        )

    # ========================================================
    # 保存
    # ========================================================

    pcd_path = Path(
        f"{prefix}_temporal_median.pcd"
    )

    npz_path = Path(
        f"{prefix}_temporal_median.npz"
    )

    save_ascii_pcd(
        pcd_path,
        representative_xyz,
        representative_valid
    )

    np.savez_compressed(
        npz_path,

        xyz=
            representative_xyz,

        range_image=
            representative_range,

        valid=
            representative_valid,

        valid_count=
            valid_count,

        temporal_mad=
            mad,

        frame_start=
            start,

        frame_end=
            end - 1,

        num_frames=
            NUM_FRAMES,
    )

    print()
    print("Saved PCD:")
    print(
        " ",
        pcd_path
    )

    print(
        "Saved organized NPZ:"
    )

    print(
        " ",
        npz_path
    )

    print("======================================")


if __name__ == "__main__":
    main()
