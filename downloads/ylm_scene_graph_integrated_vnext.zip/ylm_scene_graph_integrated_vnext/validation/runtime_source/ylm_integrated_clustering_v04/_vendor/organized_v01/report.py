import json
import numpy as np
from .util import clean
from .temporal import MISSING


def make_report(path, a, ref, stats, integrated, missing, variants, manifest, evaluation, relations, c):
    h,w=a['valid'].shape[1:]
    def values(x):
        x=np.asarray(x)
        return clean(np.round(x.astype(float),5).ravel())
    maps={'reference range (m)':values(np.where(a['valid'][ref],a['range'][ref],np.nan)),
          'valid fraction':values(stats['valid_fraction']), 'range MAD (m)':values(stats['range_mad']),
          'mode count':values(stats['mode_count']), 'missingness class':values(missing['classification']),
          'structure mask':values(missing['structure_mask']),
          'integrated range (m)':values(integrated['range']),
          'hold reason bits':values(integrated['hold_reason'])}
    if 'intensity_median' in stats: maps['intensity median']=values(stats['intensity_median'])
    views={}; stride=max(1,int(np.ceil(h*w/c['viewer']['max_3d_points'])))
    for name,v in variants.items():
        if v.get('status')!='ok': continue
        mask=v['valid'].ravel(); ids=np.flatnonzero(mask)[::stride]
        views[name]={'points':np.round(v['xyz'].reshape(-1,3)[ids],5).tolist(),
                     'pixels':ids.tolist(),'labels':v['labels'].ravel()[ids].tolist(),
                     'source':v['source'].ravel()[ids].tolist(),'counts':v['counts']}
        maps[name+' labels']=values(v['labels'])
    data=clean({'h':h,'w':w,'rotation':c['acquisition']['display_rotation_deg'],
                'maps':maps,'views':views,'manifest':manifest,'evaluation':evaluation,
                'missing_codes':MISSING,'relations':relations,
                'history':np.round(a['range'].reshape(len(a['range']),-1),5),
                'history_valid':a['valid'].reshape(len(a['range']),-1).astype(int),
                'frames':a['frame_index'],'bag_times_ns':[str(int(x)) for x in a['bag_time_ns']],
                'header_times_ns':[str(int(x)) for x in a['header_time_ns']],
                'ref':ref,'source_frame':integrated['source_frame_index'].ravel(),
                'source_type':integrated['source_type'].ravel(),
                'accepted':integrated['representative_accepted'].ravel().astype(int),
                'viewer_sampling_stride':stride})
    html=TEMPLATE.replace('__DATA__',json.dumps(data,ensure_ascii=False,allow_nan=False).replace('<','\\u003c'))
    path.write_text(html,encoding='utf-8')


TEMPLATE = r'''<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>YLM organized 観測レビュー</title><style>
:root{color-scheme:dark;font-family:system-ui,sans-serif;background:#101720;color:#dfebf6}body{margin:0 auto;max-width:1500px;padding:28px}h1{font-size:26px;margin:5px 0}h2{font-size:18px}p{line-height:1.65}section{background:#192431;border:1px solid #324153;border-radius:12px;padding:20px;margin-top:18px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.grid section{min-width:0}select,button{background:#0d1720;color:#eee;border:1px solid #52677d;padding:8px;border-radius:5px}canvas{width:100%;background:#090f18;display:block;margin-top:12px;border-radius:6px;touch-action:none}#heat{image-rendering:pixelated}#three{height:440px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px;max-height:430px;overflow:auto}a{color:#80d2f5}small{color:#afc1d2}.tag{background:#2d4c59;border-radius:8px;padding:5px 9px;display:inline-block}.cards{display:flex;gap:12px;flex-wrap:wrap}.card{padding:12px 20px;background:#243344;border-radius:8px}.card b{font-size:24px;display:block}table{border-collapse:collapse;width:100%;font-size:13px}td,th{text-align:left;border-bottom:1px solid #354457;padding:9px}.scroll{overflow:auto}#legend{font-size:12px;line-height:1.7}#point{max-height:250px}@media(max-width:900px){.grid{grid-template-columns:1fr}body{padding:12px}}</style>
<header><small>YLM-X001 · organized observation · v0.1</small><h1>観測・時間統合・断片クラスタの確認</h1><p id="verdict"></p><div class="cards" id="cards"></div></header>
<section><h2>比較 A / B / C / D</h2><p>同じ選択フレーム集合と構造マスクを使用。DはCのラベルを維持し、断片関係の候補のみ追加します。GTなしでは精度・誤結合数を確定しません。</p><div class="scroll"><table id="compare"></table></div></section>
<div class="grid"><section><h2>画素マップ</h2><select id="metric"></select><canvas id="heat"></canvas><p id="legend"></p><small>画素をクリックすると元のrow/columnと各フレームの観測履歴を表示します。黒は値なし。</small><pre id="point">画素を選択してください。</pre></section>
<section><h2>3D全体図</h2><select id="variant"></select> <select id="color"><option value="label">断片ID</option><option value="source">点の由来</option></select> <button id="reset">視点を戻す</button><canvas id="three"></canvas><p><small>ドラッグで回転、ホイールで拡大。表示のみ間引く場合があります。全点はNPZ/PCDに保存。由来表示：青=現在、橙=履歴。</small></p><p id="viewinfo"></p></section></div>
<section><h2>保留と関連候補</h2><p id="relation_count"></p><pre id="holds"></pre><details><summary>断片関係の証拠を開く</summary><pre id="rels"></pre></details></section>
<section><h2>監査用出力</h2><p><a href="run_manifest.json">manifest</a> · <a href="config.json">config</a> · <a href="frame_metadata.json">全フレームmetadata</a> · <a href="surface_hypotheses.json">面仮説</a> · <a href="fragment_relations.json">断片関係</a> · <a href="evaluation.json">評価</a> · <a href="clusters.json">クラスタ索引</a></p><details><summary>実行条件</summary><pre id="manifest"></pre></details></section>
<script>const D=__DATA__;const $=x=>document.getElementById(x);const pal=['#39b8da','#edaa50','#84c784','#b695e8','#e88183','#bce3dc','#d7b670'];
function rgb(s){return s.match(/\w\w/g).map(x=>parseInt(x,16))}function col(id){return id<0?'#444b54':pal[id%pal.length]}
$('verdict').textContent=D.manifest.gates.temporal_adoption_allowed?'単一面の時間統合を採用しました。静止の証明・性能保証ではありません。':'時間統合は保留です。現在実測点と観測履歴は保持しています。';
const counts=[['選択フレーム',D.frames.length],['画素',D.h*D.w],['時系列回収',D.evaluation.variants.C?.history_recovered_pixels_vs_current??0],['モデル推定点',0]];
for(const [k,v]of counts){let d=document.createElement('div');d.className='card';let b=document.createElement('b');b.textContent=v;d.append(b,document.createTextNode(k));$('cards').append(d)}
let head=document.createElement('tr');for(const s of ['条件','状態','点数','通常断片','小断片','未所属','GT purity']){let t=document.createElement('th');t.textContent=s;head.append(t)}$('compare').append(head);
for(const [k,v] of Object.entries(D.evaluation.variants)){let row=document.createElement('tr');for(const val of [k,v.status,v.counts?.points??'—',v.counts?.main_fragments??'—',v.counts?.small_fragments??'—',v.counts?.unassigned_points??'—',v.ground_truth?.purity??'未評価']){let t=document.createElement('td');t.textContent=val;row.append(t)}$('compare').append(row)}
for(const k of Object.keys(D.maps)){$('metric').add(new Option(k,k))}for(const k of Object.keys(D.views)){$('variant').add(new Option(k,k))}$('variant').value='C';
function heat(){const k=$('metric').value,v=D.maps[k],can=$('heat');can.width=D.w;can.height=D.h;const ctx=can.getContext('2d'),im=ctx.createImageData(D.w,D.h);let lo=Infinity,hi=-Infinity;for(const x of v)if(x!==null){lo=Math.min(lo,x);hi=Math.max(hi,x)}let categorical=k.endsWith('labels')||k==='missingness class';
for(let i=0;i<v.length;i++){let x=v[i],c=[4,8,15];if(x!==null){if(categorical)c=rgb(col(x).slice(1));else{let t=(x-lo)/(hi-lo||1);c=[Math.round(40+205*t),Math.round(190-90*t),Math.round(225-165*t)]}}const p=D.rotation===180?v.length-1-i:i;im.data.set([...c,255],p*4)}ctx.putImageData(im,0,0);$('legend').textContent=k==='missingness class'?Object.entries(D.missing_codes).map(([k,v])=>v+': '+k).join(' / '):'min '+(isFinite(lo)?lo:'—')+' / max '+(isFinite(hi)?hi:'—');}
$('metric').onchange=heat;heat();$('heat').onclick=e=>{const b=e.currentTarget.getBoundingClientRect();let x=Math.min(D.w-1,Math.floor((e.clientX-b.left)/b.width*D.w)),y=Math.min(D.h-1,Math.floor((e.clientY-b.top)/b.height*D.h));if(D.rotation===180){x=D.w-1-x;y=D.h-1-y}let p=y*D.w+x;
let history=D.frames.map((f,j)=>({frame:f,bag_time_ns:D.bag_times_ns[j],header_time_ns:D.header_times_ns[j],valid:!!D.history_valid[j][p],range_m:D.history_valid[j][p]?D.history[j][p]:null}));$('point').textContent=JSON.stringify({row:y,column:x,source_frame:D.source_frame[p],source_type:D.source_type[p],representative_accepted:!!D.accepted[p],map_value:D.maps[$('metric').value][p],history},null,2);};
let yaw=-.8,pitch=.35,zoom=1,drag=null;function draw(){const can=$('three'),ctx=can.getContext('2d');can.width=Math.max(300,Math.round(can.clientWidth));can.height=440;ctx.fillStyle='#090f18';ctx.fillRect(0,0,can.width,can.height);const v=D.views[$('variant').value];if(!v||!v.points.length)return;let cen=[0,0,0],lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];for(const p of v.points)for(let k=0;k<3;k++){lo[k]=Math.min(lo[k],p[k]);hi[k]=Math.max(hi[k],p[k])}cen=lo.map((x,k)=>(x+hi[k])/2);let span=Math.max(...hi.map((x,k)=>x-lo[k]),.1);let scale=Math.min(can.width,can.height)*.8/span*zoom;let dots=[];for(let k=0;k<v.points.length;k++){let [x,y,z]=v.points[k].map((x,j)=>x-cen[j]);let a=x*Math.cos(yaw)-y*Math.sin(yaw),b=x*Math.sin(yaw)+y*Math.cos(yaw),z2=z*Math.cos(pitch)-b*Math.sin(pitch);dots.push([can.width/2+a*scale,can.height/2-z2*scale,b*Math.cos(pitch)+z*Math.sin(pitch),k])}dots.sort((a,b)=>a[2]-b[2]);for(const [x,y,z,k]of dots){ctx.fillStyle=$('color').value==='source'?(v.source[k]===2?'#edaa50':'#39b8da'):col(v.labels[k]);ctx.fillRect(x-1,y-1,2.2,2.2)}$('viewinfo').textContent='表示 '+v.points.length+'点 / 出力 '+v.counts.points+'点';}
$('variant').onchange=draw;$('color').onchange=draw;$('reset').onclick=()=>{yaw=-.8;pitch=.35;zoom=1;draw()};$('three').onpointerdown=e=>{drag=[e.clientX,e.clientY];e.currentTarget.setPointerCapture(e.pointerId)};$('three').onpointerup=()=>drag=null;$('three').onpointermove=e=>{if(drag){yaw+=(e.clientX-drag[0])*.008;pitch+=(e.clientY-drag[1])*.008;drag=[e.clientX,e.clientY];draw()}};$('three').onwheel=e=>{e.preventDefault();zoom*=e.deltaY>0?.9:1.1;zoom=Math.max(.1,Math.min(20,zoom));draw()};window.onresize=draw;draw();
$('holds').textContent=JSON.stringify(D.manifest.gates,null,2);$('manifest').textContent=JSON.stringify(D.manifest,null,2);$('relation_count').textContent=D.relations.relations.length+'件の断片関連候補。強制結合は0件。';$('rels').textContent=JSON.stringify(D.relations,null,2);
</script></html>'''
