import warnings
import numpy as np
from .input import time_diagnostics

SOURCE = {'NONE': 0, 'CURRENT_MEASURED': 1, 'TEMPORAL_MEASURED': 2, 'MODEL_INFERRED': 3}
MISSING = {'CURRENT_MEASURED': 1, 'TEMPORALLY_SUPPORTED': 2, 'OCCLUSION_SUPPORTED': 3,
           'MULTI_SURFACE_HOLD': 4, 'NO_RETURN_UNKNOWN': 5, 'OUT_OF_VIEW': 6, 'STRUCTURE_MASKED': 7}
HOLD = {'NO_OBSERVATION': 1, 'INSUFFICIENT_SUPPORT': 2, 'MULTI_SURFACE': 4,
        'HIGH_MAD': 8, 'STALE': 16, 'TIME_CHANGE': 32, 'GLOBAL_GATE': 64, 'RAY_CHANGE': 128}


def quantiles(a):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning)
        q = np.nanquantile(a, [.05, .5, .95], axis=0)
        mad = np.nanmedian(np.abs(a-q[1]), axis=0)
    return q, mad


def analyze_history(a, ref, c):
    xyz, valid, r = a['xyz'], a['valid'], a['range']
    f,h,w = r.shape; n = h*w
    obs = np.where(valid, r, np.nan)
    q, mad = quantiles(obs)
    count = valid.sum(axis=0).astype(np.int32)
    anyv = count > 0
    first = np.argmax(valid, axis=0)
    last = f-1-np.argmax(valid[::-1], axis=0)
    rr,cc = np.indices((h,w))
    first_time = np.where(anyv, a['bag_time_ns'][first], -1)
    last_time = np.where(anyv, a['bag_time_ns'][last], -1)
    last_range = np.where(anyv, r[last,rr,cc], np.nan)
    streak = np.zeros((h,w), np.int32); max_streak = streak.copy()
    for k in range(f):
        if k and a['frame_index'][k] != a['frame_index'][k-1]+1:
            streak[:] = 0
        streak = np.where(valid[k], 0, streak+1)
        max_streak = np.maximum(streak, max_streak)
    through_ref = np.zeros((h,w), np.int32)
    for k in range(ref+1):
        if k and a['frame_index'][k] != a['frame_index'][k-1]+1:
            through_ref[:] = 0
        through_ref = np.where(valid[k], 0, through_ref+1)
    stats = dict(valid_count=count, received_frame_count=np.full((h,w),f,np.int32),
                 valid_fraction=count/f, first_valid_time_ns=first_time, last_valid_time_ns=last_time,
                 last_valid_range=last_range, trailing_missing_run=streak,
                 missing_run_at_reference=through_ref, max_missing_run=max_streak,
                 range_q05=q[0], range_median=q[1], range_q95=q[2], range_mad=mad,
                 statistic_valid=anyv, stability_sample_sufficient=count>=2,
                 pixel_row=rr, pixel_column=cc)
    if 'intensity' in a:
        iv = a['intensity_valid']; iq, imad = quantiles(np.where(iv,a['intensity'],np.nan))
        stats.update(intensity_q05=iq[0], intensity_median=iq[1], intensity_q95=iq[2],
                     intensity_mad=imad, intensity_count=iv.sum(axis=0),
                     intensity_statistic_valid=iv.any(axis=0),
                     intensity_distance_overlap_count=(iv & valid).sum(axis=0))
    # Mode hypotheses: split sorted real measurements by adjacent gaps. No averaging across modes.
    sorted_r = np.sort(np.where(valid, r, np.inf), axis=0)
    gap = c['temporal']['mode_gap_m'] + c['temporal']['mode_gap_per_m']*np.nan_to_num(q[1])
    with np.errstate(invalid='ignore'):
        split = (np.diff(sorted_r, axis=0)>gap) & np.isfinite(sorted_r[1:])
    mode_count = np.where(anyv,1+split.sum(axis=0),0).astype(np.int16)
    sample_mode = np.where(valid, 0, -1).astype(np.int16)
    hypotheses = []
    for p in np.flatnonzero(mode_count.ravel()>1):
        y,x = divmod(int(p),w)
        ids = np.flatnonzero(valid[:,y,x]); ids = ids[np.argsort(r[ids,y,x], kind='stable')]
        groups = np.split(ids, np.flatnonzero(np.diff(r[ids,y,x])>gap[y,x])+1)
        modes = []
        for label, group in enumerate(groups):
            vals = r[group,y,x]; med = np.median(vals)
            chosen = int(group[np.argmin(np.abs(vals-med))])
            sample_mode[group,y,x] = label
            modes.append({'mode': label, 'range_median_m': float(med),
                          'mad_m': float(np.median(np.abs(vals-med))),
                          'support_count': len(group), 'low_support': len(group)<c['temporal']['min_support_count'],
                          'sample_indices': group.tolist(),
                          'frame_indices': a['frame_index'][group].tolist(),
                          'bag_times_ns': a['bag_time_ns'][group].tolist(),
                          'representative_sample_index': chosen,
                          'representative_xyz': xyz[chosen,y,x].tolist(),
                          'discarded': False})
        seq = sample_mode[valid[:,y,x],y,x]
        hypotheses.append({'pixel': [y,x], 'modes': modes,
                           'time_order_mode_ids': seq.tolist(),
                           'switch_count': int((np.diff(seq)!=0).sum()),
                           'decision': 'MULTI_SURFACE_HOLD'})
    # Gradual movement may not create a gap, so also detect temporal monotone drift.
    first_range = np.where(anyv,r[first,rr,cc],np.nan)
    span = q[2]-q[0]
    drift = (count>=3) & (span>c['temporal']['drift_span_m']) & (np.abs(last_range-first_range)>.5*span)
    relxyz = xyz-np.asarray(c['acquisition']['sensor_origin_xyz'])
    rays = np.divide(relxyz,r[...,None],out=np.zeros_like(relxyz,dtype=float),where=valid[...,None])
    reference_ray = rays[first,rr,cc]
    cos = np.clip((rays*reference_ray[None]).sum(axis=-1),-1,1)
    deviations = np.where(valid, np.degrees(np.arccos(cos)), 0)
    ray_max = deviations.max(axis=0)
    ray_change = (count>=2) & (ray_max>c['temporal']['max_ray_deviation_deg'])
    dynamic = (mode_count>1) | drift | ray_change
    denom = int((count>=2).sum())
    dynamic_fraction = float((dynamic & (count>=2)).sum()/denom) if denom else 0.0
    reasons = []
    if not c['scene']['static_confirmed'] or not c['scene']['acquisition_record'].strip():
        reasons.append('static acquisition record not confirmed')
    if c['scene']['known_motion']:
        reasons.append('known sensor/object motion')
    if not c['acquisition']['pixel_correspondence_confirmed']:
        reasons.append('pixel correspondence not confirmed')
    if not c['acquisition']['xyz_sensor_frame_confirmed']:
        reasons.append('XYZ sensor frame / origin not confirmed')
    if c['acquisition']['setting_id']=='unknown' or not c['acquisition']['settings_evidence'].strip():
        reasons.append('FoV/acquisition settings not verified')
    if not c['validity']['reviewed'] or not c['validity']['driver_definition'].strip():
        reasons.append('driver validity definitions not verified')
    if dynamic_fraction>c['scene']['global_dynamic_fraction']:
        reasons.append('distance/ray history contradicts static assumption')
    delta = np.diff(a['bag_time_ns'])
    if (delta<=0).any() or (a['bag_time_ns']<=0).any():
        reasons.append('bag time missing/duplicate/reversed')
    if f < 2:
        reasons.append('fewer than two frames; temporal stability unknown')
    span_s = float((int(a['bag_time_ns'].max())-int(a['bag_time_ns'].min()))/1e9)
    if span_s > c['temporal']['max_window_span_s']:
        reasons.append('time window exceeds configured expiry')
    if any(not str(x).strip() for x in a['frame_id']):
        reasons.append('frame_id is empty')
    gate = not reasons
    # Closest actual sample to median; ties prefer reference/nearest timestamp, then order.
    diff = np.where(valid, np.abs(r-q[1]), np.inf)
    nearest = np.min(diff, axis=0)
    ages = np.abs(a['bag_time_ns']-a['bag_time_ns'][ref])/1e9
    candidates = (diff == nearest[None]) & valid
    costs = np.where(candidates, ages[:,None,None], np.inf)
    best = np.argmin(costs, axis=0)
    representative_age = ages[best]
    nearest_support_age = np.min(np.where(valid,ages[:,None,None],np.inf),axis=0)
    hold = np.zeros((h,w),np.uint16)
    hold[~anyv] |= HOLD['NO_OBSERVATION']
    enough = (count>=c['temporal']['min_support_count']) & (count/f>=c['temporal']['min_support_fraction']) & (count>=2)
    hold[~enough] |= HOLD['INSUFFICIENT_SUPPORT']
    hold[mode_count>1] |= HOLD['MULTI_SURFACE']
    hold[mad>c['temporal']['max_mad_m']] |= HOLD['HIGH_MAD']
    hold[representative_age>c['temporal']['freshness_limit_s']] |= HOLD['STALE']
    hold[drift] |= HOLD['TIME_CHANGE']; hold[ray_change] |= HOLD['RAY_CHANGE']
    if not gate:
        hold |= HOLD['GLOBAL_GATE']
    accepted = hold==0
    # Always retain actual reference measurements separately from representative adoption.
    outxyz = xyz[ref].copy(); outr = r[ref].copy(); ov = valid[ref].copy()
    source = np.where(ov,SOURCE['CURRENT_MEASURED'],SOURCE['NONE']).astype(np.uint8)
    src_idx = np.where(ov,ref,-1).astype(np.int32)
    outxyz[accepted] = xyz[best,rr,cc][accepted]
    outr[accepted] = r[best,rr,cc][accepted]; ov |= accepted
    src_idx[accepted] = best[accepted]
    source[accepted] = np.where(best[accepted]==ref,SOURCE['CURRENT_MEASURED'],SOURCE['TEMPORAL_MEASURED'])
    outxyz[~ov] = np.nan; outr[~ov] = np.nan
    safe_idx = np.maximum(src_idx,0)
    integrated = dict(xyz=outxyz, range=outr, valid=ov,
                      representative_accepted=accepted, mode_range_median=q[1],
                      representative_sample_index=np.where(accepted,best,-1),
                      source_type=source, source_sample_index=src_idx,
                      source_frame_index=np.where(ov,a['frame_index'][safe_idx],-1),
                      source_time_ns=np.where(ov,a['bag_time_ns'][safe_idx],-1),
                      source_header_time_ns=np.where(ov,a['header_time_ns'][safe_idx],-1),
                      support_count=count, hold_reason=hold,
                      source_time_valid=ov, pixel_row=rr,pixel_column=cc)
    stats.update(mode_count=mode_count, time_change_candidate=drift,
                 max_ray_deviation_deg=ray_max, ray_change_candidate=ray_change,
                 nearest_support_age_s=np.where(anyv,nearest_support_age,np.nan),
                 representative_age_s=np.where(anyv,representative_age,np.nan))
    # Exact legacy representative selection: range filters and earliest argmin tie from uploaded extractor.
    lr = np.linalg.norm(xyz,axis=-1)
    lv = np.isfinite(xyz).all(axis=-1) & (lr>=c['legacy']['min_range_m']) & (lr<=c['legacy']['max_range_m'])
    lq,_ = quantiles(np.where(lv,lr,np.nan))
    lb = np.argmin(np.where(lv,np.abs(lr-lq[1]),np.inf),axis=0)
    lm = (lv.sum(axis=0)>=c['legacy']['min_valid_frames']) & np.isfinite(lq[1])
    legacy = dict(xyz=xyz[lb,rr,cc].copy(), valid=lm, range=lr[lb,rr,cc],
                  source_sample_index=np.where(lm,lb,-1),
                  source_type=np.where(lm,np.where(lb==ref,1,2),0).astype(np.uint8),
                  source_time_ns=np.where(lm,a['bag_time_ns'][lb],-1))
    legacy['xyz'][~lm]=np.nan; legacy['range'][~lm]=np.nan
    return stats, integrated, legacy, sample_mode, hypotheses, {
        'temporal_adoption_allowed': gate, 'hold_reasons': reasons,
        'scene_static_assumption': c['scene'], 'dynamic_fraction': dynamic_fraction,
        'selected_window_span_s': span_s,
        'static_test_limitation': 'Passing gates is not proof of immobility; pose registration is not implemented',
        'header_time_used_for_freshness': False,
    }


def classify_missingness(a, ref, stats, integ, structure, c):
    current = a['valid'][ref]; h,w = current.shape
    cls = np.full((h,w),MISSING['NO_RETURN_UNKNOWN'],np.uint8)
    cls[current]=MISSING['CURRENT_MEASURED']
    recovered = ~current & integ['representative_accepted']
    cls[recovered]=MISSING['TEMPORALLY_SUPPORTED']
    multi = (stats['mode_count']>1)|stats['time_change_candidate']|stats['ray_change_candidate']
    cls[multi]=MISSING['MULTI_SURFACE_HOLD']
    occ=np.zeros((h,w),bool); out=np.zeros((h,w),bool)
    if c['projection']['npz']:
        with np.load(c['projection']['npz'],allow_pickle=False) as z:
            for k in ('known_surface_range','in_fov_mask','projection_valid'):
                if k not in z or z[k].shape!=(h,w):
                    raise ValueError(f'Projection {k}[H,W] required')
            known=z['known_surface_range']; pv=z['projection_valid'].astype(bool); infov=z['in_fov_mask'].astype(bool)
            occ=pv & infov & current & np.isfinite(known) & (known>a['range'][ref]+c['projection']['depth_error_m'])
            out=pv & ~infov & ~current
        # Classification relates to known target surface, while current_foreground remains available.
        cls[occ]=MISSING['OCCLUSION_SUPPORTED']; cls[out]=MISSING['OUT_OF_VIEW']
    cls[structure]=MISSING['STRUCTURE_MASKED']
    low=np.zeros((h,w),bool)
    threshold=c['intensity']['low_evidence_threshold']
    if threshold is not None and 'intensity_median' in stats:
        low=(stats['intensity_median']<threshold) & (stats['valid_fraction']<c['intensity']['low_valid_fraction']) & stats['intensity_statistic_valid']
    free=np.full((h,w),np.nan,np.float32)
    if c['projection']['free_space_model_verified'] and c['acquisition']['xyz_sensor_frame_confirmed'] and c['validity']['reviewed']:
        free[current]=np.maximum(0,a['range'][ref][current]-c['projection']['depth_error_m'])
    return dict(classification=cls,current_measured=current,temporally_supported=recovered,
                occlusion_supported=occ,out_of_view=out,structure_mask=structure,
                low_return_evidence=low,multi_surface_hold=multi,
                hold_reason=integ['hold_reason'],free_space_max_range=free,
                free_space_evidence_valid=np.isfinite(free),
                no_return_unknown=~current & ~recovered & ~occ & ~out & ~structure & ~multi)
