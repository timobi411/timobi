import numpy as np
from .util import summary


def instance_metrics(labels, gt, selected=None):
    if gt is None:
        return {'status':'not_evaluated_no_instance_ground_truth','purity':None,'coverage':None,
                'object_split_counts':None,'false_merge_clusters':None,'oversegmentation_excess':None}
    support=gt>=0
    if selected is not None: support &= selected
    assigned=support & (labels>=0)
    objects=[]; total=int(support.sum()); labeled=int(assigned.sum())
    pairs=np.column_stack([labels[assigned],gt[assigned]])
    if len(pairs):
        unique,counts=np.unique(pairs,axis=0,return_counts=True)
    else: unique=np.empty((0,2),int); counts=np.array([],int)
    mixed=[]; correct=0
    if len(unique):
        clusters,starts=np.unique(unique[:,0],return_index=True)
        ends=np.r_[starts[1:],len(unique)]
        for cid,start,end in zip(clusters,starts,ends):
            row=counts[start:end]; correct+=int(row.max())
            if end-start>1:
                mixed.append({'cluster':int(cid),'instances':unique[start:end,1].tolist(),'counts':row.tolist()})
    for obj in np.unique(gt[support]):
        allc=int((support & (gt==obj)).sum()); rows=unique[:,1]==obj
        cc=counts[rows]; ids=unique[rows,0]
        objects.append({'instance_id':int(obj),'annotated_pixels':allc,'assigned_pixels':int(cc.sum()),
                        'fragment_count':len(ids),'fragments':ids.tolist(),
                        'coverage':float(cc.sum()/allc),'largest_fragment_coverage':float(cc.max()/allc) if len(cc) else 0.0})
    return {'status':'evaluated_on_pixel_instance_labels','purity':correct/labeled if labeled else None,
            'coverage':labeled/total if total else None,'object_split_counts':objects,
            'false_merge_clusters':mixed,'false_merge_cluster_count':len(mixed),
            'oversegmentation_excess':sum(max(0,x['fragment_count']-1) for x in objects)}


def evaluate(variants, stats, missing, gt, c):
    data={}
    for name,v in variants.items():
        if v.get('status')!='ok':
            data[name]=v; continue
        lab=v['labels']; valid=v['valid']; current=variants['current_only']['valid']
        data[name]={'status':'ok','counts':v['counts'],
                    'history_recovered_pixels_vs_current':int((valid & ~current).sum()),
                    'current_pixels_not_in_variant':int((current & ~valid).sum()),
                    'MODEL_INFERRED_count':0,
                    'ground_truth':instance_metrics(lab,gt),
                    'strata':{},'seconds':v.get('seconds')}
        fields=[('range_m',v['range'],c['evaluation']['range_bins_m']),
                ('valid_fraction',stats['valid_fraction'],c['evaluation']['valid_fraction_bins']),
                ('occlusion_supported',missing['occlusion_supported'].astype(float),[-.5,.5,1.5])]
        if c['evaluation']['intensity_bins'] is not None and 'intensity_median' in stats:
            fields.append(('intensity',stats['intensity_median'],c['evaluation']['intensity_bins']))
        for field,values,bins in fields:
            bins=np.asarray(bins,float)
            if len(bins)<2 or (np.diff(bins)<=0).any():
                raise ValueError(f'{field} bin edges must increase')
            records=[]
            for low,high in zip(bins[:-1],bins[1:]):
                mask=(values>=low)&(values<high)
                records.append({'low_inclusive':low,'high_exclusive':high,
                                'valid_pixels':int((mask & valid).sum()),
                                'assigned_pixels':int((mask & (lab>=0)).sum()),
                                'ground_truth':instance_metrics(lab,gt,mask)})
            data[name]['strata'][field]=records
    return {'dataset_role':c['evaluation']['dataset_role'],'variants':data,
            'accuracy_claim':'none; synthetic/GT-free runs are diagnostic only' if gt is None else 'only supplied instance annotations; held-out status is user-declared',
            'observed_occlusion_rate':float(missing['occlusion_supported'].mean()) if c['projection']['npz'] else None,
            'true_occlusion_rate_stratification':'unavailable without known projected surfaces/annotations',
            'intensity_stratification':'configured' if c['evaluation']['intensity_bins'] is not None else 'not configured; no calibrated intensity bands invented',
            'D_labels_identical_to_C':True}
