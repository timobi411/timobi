"""Strict PointCloud2 codec; no dense reshape of compacted point lists."""
import hashlib
import json
import zipfile
from pathlib import Path
import numpy as np
from .util import write_json, summary

POINT_TYPES = {1: 'i1', 2: 'u1', 3: 'i2', 4: 'u2', 5: 'i4', 6: 'u4', 7: 'f4', 8: 'f8'}
INVALID_BITS = {'NONFINITE': 1, 'ZERO_XYZ': 2, 'RANGE_FILTER': 4,
                'DRIVER_SENTINEL': 8, 'STATUS': 16, 'SOURCE_INVALID': 32}


def field_schema(msg):
    return [{'name': f.name, 'datatype': int(f.datatype), 'offset': int(f.offset),
             'count': int(f.count)} for f in msg.fields]


def metadata(msg, bag_time_ns, index, c):
    schema = field_schema(msg)
    signature = {'height': int(msg.height), 'width': int(msg.width),
                 'point_step': int(msg.point_step), 'row_step': int(msg.row_step),
                 'is_bigendian': bool(msg.is_bigendian), 'fields': schema,
                 'frame_id': msg.header.frame_id}
    return dict(signature, frame_index=index, bag_time_ns=int(bag_time_ns),
                header_time_ns=int(msg.header.stamp.sec)*1000000000 + int(msg.header.stamp.nanosec),
                is_dense=bool(msg.is_dense), data_size_bytes=len(msg.data),
                row_padding_bytes=int(msg.row_step-msg.width*msg.point_step),
                layout_id=hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest(),
                acquisition_setting_id=c['acquisition']['setting_id'])


def decode_fields(msg):
    h, w, ps, rs = map(int, (msg.height, msg.width, msg.point_step, msg.row_step))
    if h <= 1 or w < 1:
        raise ValueError('Unorganized PointCloud2: height<=1. 元pixel ID付き再抽出が必要です。')
    if ps <= 0 or rs < ps*w or len(msg.data) < h*rs:
        raise ValueError('Malformed PointCloud2 row_step / point_step / data length')
    names, formats, offsets = [], [], []
    for f in msg.fields:
        if f.datatype not in POINT_TYPES or f.count < 1 or f.offset < 0 or f.name in names:
            raise ValueError('Invalid/duplicate PointField declaration')
        dt = np.dtype(('>' if msg.is_bigendian else '<') + POINT_TYPES[f.datatype])
        if f.offset + dt.itemsize*f.count > ps:
            raise ValueError('PointField extends beyond point_step')
        names.append(f.name); formats.append(dt if f.count == 1 else (dt, (f.count,))); offsets.append(f.offset)
    dtype = np.dtype({'names': names, 'formats': formats, 'offsets': offsets, 'itemsize': ps})
    raw = np.ndarray((h, w), dtype=dtype, buffer=memoryview(bytes(msg.data)), strides=(rs, ps))
    for name in ('x', 'y', 'z'):
        if name not in raw.dtype.names or raw[name].shape != (h, w):
            raise ValueError('Scalar x/y/z fields are mandatory')
    return raw


def validity(xyz, c, source_valid=None, status=None):
    r = np.linalg.norm(xyz - np.asarray(c['acquisition']['sensor_origin_xyz']), axis=-1)
    reason = np.zeros(r.shape, np.uint16)
    reason[~np.isfinite(xyz).all(axis=-1) | ~np.isfinite(r)] |= INVALID_BITS['NONFINITE']
    v = c['validity']
    if v['zero_xyz_invalid']:
        reason[(xyz == 0).all(axis=-1)] |= INVALID_BITS['ZERO_XYZ']
    reason[np.isfinite(r) & ((r < v['min_range_m']) | (r > v['max_range_m']))] |= INVALID_BITS['RANGE_FILTER']
    for sentinel in v['invalid_ranges_m']:
        reason[np.isclose(r, sentinel, rtol=0, atol=v['invalid_range_atol_m'])] |= INVALID_BITS['DRIVER_SENTINEL']
    if status is not None:
        reason[~np.isin(status, v['status_valid_values'])] |= INVALID_BITS['STATUS']
    if source_valid is not None:
        reason[~source_valid.astype(bool)] |= INVALID_BITS['SOURCE_INVALID']
    return r, reason == 0, reason


def extract_frame(msg, c):
    raw = decode_fields(msg)
    xyz = np.stack([raw[k] for k in ('x', 'y', 'z')], axis=-1)
    xyz = xyz.astype(np.float64 if xyz.dtype.itemsize > 4 or xyz.dtype.kind != 'f' else np.float32)
    status = None
    sf = c['validity']['status_field']
    if sf:
        if sf not in raw.dtype.names or raw[sf].shape != xyz.shape[:2]:
            raise ValueError('Configured status field absent/non-scalar')
        status = np.array(raw[sf])
    r, v, reason = validity(xyz, c, status=status)
    result = {'xyz': xyz, 'range': r, 'valid': v, 'invalid_reason': reason}
    if status is not None:
        result['status'] = status
    for group in ('intensity', 'snr'):
        name = c[group]['field']
        if name and name in raw.dtype.names:
            if raw[name].shape != v.shape:
                raise ValueError(f'{group} field is not scalar')
            a = np.array(raw[name], dtype=np.float32)
            result[group] = a
            good = np.isfinite(a)
            if group == 'intensity':
                good &= ~np.isin(a, c[group]['invalid_values'])
                if c[group]['saturation_value'] is not None:
                    good &= a < c[group]['saturation_value']
            result[group+'_valid'] = good
    return result


def bag_messages(path, c):
    try:
        import rosbag2_py
        from rclpy.serialization import deserialize_message
        from sensor_msgs.msg import PointCloud2
    except ImportError as e:
        raise RuntimeError('ROS2 Humble環境で source /opt/ros/humble/setup.bash を実行してください。NPZ demoはROSなしで動作します。') from e
    storage = c['storage_id']
    if storage == 'auto':
        p = Path(path)
        candidates = list(p.glob('*.db3')) if p.is_dir() else []
        mcap = list(p.glob('*.mcap')) if p.is_dir() else []
        if candidates and mcap:
            raise ValueError('Mixed storage: specify storage_id explicitly')
        storage = 'mcap' if mcap or p.suffix == '.mcap' else 'sqlite3'
    reader = rosbag2_py.SequentialReader()
    reader.open(rosbag2_py.StorageOptions(uri=str(path), storage_id=storage),
                rosbag2_py.ConverterOptions(input_serialization_format='cdr', output_serialization_format='cdr'))
    topics = {t.name: t.type for t in reader.get_all_topics_and_types()}
    if topics.get(c['topic']) != 'sensor_msgs/msg/PointCloud2':
        raise ValueError(f'PointCloud2 topic not found: {c["topic"]}; actual={topics}')
    idx = 0
    while reader.has_next():
        topic, data, stamp = reader.read_next()
        if topic != c['topic']:
            continue
        yield idx, int(stamp), deserialize_message(data, PointCloud2)
        idx += 1


def time_diagnostics(frames):
    problems = []
    for k in ('bag_time_ns', 'header_time_ns'):
        a = np.asarray([m[k] for m in frames], np.int64)
        problems.append({'field': k, 'zero_indices': np.flatnonzero(a == 0).tolist(),
                         'duplicate_adjacent_indices': (np.flatnonzero(np.diff(a) == 0)+1).tolist(),
                         'reversed_indices': (np.flatnonzero(np.diff(a) < 0)+1).tolist(),
                         'interval_ns': summary(np.diff(a))})
    return problems


def inspect_bag(path, c):
    frames, layouts, errors, samples = [], {}, [], []
    for i, stamp, msg in bag_messages(path, c):
        m = metadata(msg, stamp, i, c); frames.append(m)
        if m['layout_id'] not in layouts:
            layouts[m['layout_id']] = {'first_frame_index': i, 'schema': m}
            try:
                raw = decode_fields(msg)
                samples.append({'frame_index': i, 'field_numeric_summary': {
                    k: summary(raw[k]) for k in raw.dtype.names if raw[k].ndim == 2}})
            except ValueError as e:
                errors.append({'frame_index': i, 'error': str(e)})
        if len(msg.data) < msg.row_step*msg.height:
            errors.append({'frame_index': i, 'error': 'truncated PointCloud2 data'})
    if not frames:
        raise ValueError('No PointCloud2 messages')
    return {'schema_version': 'ylm_inspection_v1', 'input': str(Path(path).resolve()),
            'topic': c['topic'], 'frames': frames, 'received_frame_count': len(frames),
            'layouts': layouts, 'layout_changed': len(layouts) > 1,
            'time_diagnostics': time_diagnostics(frames), 'field_samples': samples,
            'errors': errors, 'fov_setting_verification': 'PointCloud2 does not encode FoV/driver settings; require acquisition record plus measured-ray stability checks',
            'communication_loss': 'not identifiable from PointCloud2 alone; denominator is received selected messages'}


def npz_inventory(path):
    keys = {}
    with zipfile.ZipFile(path) as z:
        for name in z.namelist():
            if not name.endswith('.npy'):
                continue
            with z.open(name) as f:
                version = np.lib.format.read_magic(f)
                if version == (1, 0):
                    shape, fortran, dtype = np.lib.format.read_array_header_1_0(f)
                elif version == (2, 0):
                    shape, fortran, dtype = np.lib.format.read_array_header_2_0(f)
                else:
                    raise ValueError('Unsupported NPY header version')
            if dtype.hasobject:
                raise ValueError('Object/pickle arrays are not accepted')
            keys[name[:-4]] = {'shape': list(shape), 'dtype': str(dtype)}
    old = 'xyz' in keys and len(keys['xyz']['shape']) == 3
    return {'input': str(Path(path).resolve()), 'arrays': keys,
            'legacy_aggregated_npz': old,
            'history_available': 'xyz' in keys and len(keys['xyz']['shape']) == 4,
            'action': '各frameのXYZ・時刻・強度は復元不可。元bagを再抽出してください。' if old else 'history schema is validated by run'}


def choose_frames(total, c):
    s = c['frame_selection']
    if s['mode'] == 'middle':
        if total < s['count']:
            raise ValueError(f'Need {s["count"]} received frames; got {total}')
        mid, half = total//2, s['count']//2
        idx = list(range(mid-half, mid+half+1))
    elif s['mode'] == 'all':
        idx = list(range(total))
    else:
        idx = s['indices']
        if not idx or idx != sorted(set(idx)) or min(idx) < 0 or max(idx) >= total:
            raise ValueError('indices must be unique, sorted, valid acquisition indices')
    if len(idx) > c['memory']['max_window_frames']:
        raise ValueError('Window exceeds max_window_frames: split acquisition into finite windows')
    ref = total//2 if s['reference_index'] is None else s['reference_index']
    if ref not in idx:
        ref = idx[len(idx)//2] if s['reference_index'] is None else ref
    if ref not in idx:
        raise ValueError('reference_index must belong to selected indices')
    return idx, idx.index(ref)


def memory_guard(f, h, w, c):
    # Conservative bound for raw history, masked/sorted float64 workspaces, edge arrays,
    # JSON surface evidence and viewer preparation. Process runs additionally have RLIMIT_AS.
    estimate = (f*h*w*320 + h*w*600 + 64*1024*1024)
    if estimate > c['memory']['max_working_mb']*1024**2:
        raise MemoryError(f'Estimated working allocation {estimate/1024**2:.1f} MiB exceeds config limit; select fewer frames or raise reviewed memory limit')
    return int(estimate)


def load_bag_history(path, c, inspection, output):
    idx, ref = choose_frames(inspection['received_frame_count'], c)
    selected = [inspection['frames'][i] for i in idx]
    if len({m['layout_id'] for m in selected}) != 1 or inspection['errors']:
        raise ValueError('Layout/frame_id changed or malformed input: history integration stopped; split a constant-setting interval and re-extract')
    h, w = selected[0]['height'], selected[0]['width']
    memory_guard(len(idx), h, w, c)
    if h <= 1:
        raise ValueError('Original pixel mapping missing; cannot reconstruct organized history')
    arrays = None
    seen = set()
    wanted = {v: j for j, v in enumerate(idx)}
    for i, stamp, msg in bag_messages(path, c):
        if i not in wanted:
            continue
        actual = metadata(msg, stamp, i, c)
        expected = selected[wanted[i]]
        if any(actual[k] != expected[k] for k in ('layout_id', 'bag_time_ns', 'header_time_ns', 'data_size_bytes')):
            raise ValueError('Input metadata changed between inspection and extraction')
        seen.add(i)
        a = extract_frame(msg, c)
        if arrays is None:
            arrays = {k: np.empty((len(idx),)+v.shape, v.dtype) for k,v in a.items()}
        if set(a) != set(arrays):
            raise ValueError('Optional fields changed across selected frames')
        for k,v in a.items():
            arrays[k][wanted[i]] = v
    if seen != set(idx):
        raise ValueError('Selected received frames missing on second bag pass')
    arrays.update(frame_index=np.array(idx, np.int64),
                  bag_time_ns=np.array([m['bag_time_ns'] for m in selected], np.int64),
                  header_time_ns=np.array([m['header_time_ns'] for m in selected], np.int64),
                  frame_id=np.array([m['frame_id'] for m in selected]),
                  setting_id=np.array([m['acquisition_setting_id'] for m in selected]),
                  layout_id=np.array([m['layout_id'] for m in selected]))
    return arrays, ref


def load_npz_history(path, c):
    inventory = npz_inventory(path)
    shape = inventory['arrays'].get('xyz', {}).get('shape', [])
    if len(shape) == 4:
        memory_guard(shape[0], shape[1], shape[2], c)
    with np.load(path, allow_pickle=False) as z:
        if len(shape) != 4 or shape[-1] != 3:
            raise ValueError('Framewise xyz[F,H,W,3] required. 既存temporal_median.npzから履歴を推測しません。元bagを再抽出してください。')
        total, h, w, _ = shape
        if h <= 1 or w < 1:
            raise ValueError('Organized H>1 and W>=1 required')
        idx, ref = choose_frames(total, c)
        memory_guard(len(idx), h, w, c)
        required = ['bag_time_ns', 'header_time_ns', 'frame_index', 'frame_id', 'setting_id', 'layout_id']
        for k in required:
            if k not in z or z[k].shape != (total,):
                raise ValueError(f'Missing history field/shape: {k}[F]')
        # Loading a compressed array temporarily needs its full size.
        memory_guard(total, h, w, c)
        a = {k: z[k][idx].copy() for k in ['xyz']+required}
        for k in ('valid', 'intensity', 'intensity_valid', 'status', 'snr', 'snr_valid'):
            if k in z:
                if z[k].shape != (total, h, w):
                    raise ValueError(f'Invalid {k} shape')
                a[k] = z[k][idx].copy()
                if k in ('valid','intensity_valid','snr_valid'):
                    if not np.isin(a[k],[False,True]).all():
                        raise ValueError(f'{k} must contain only boolean/0/1 values')
                    a[k] = a[k].astype(bool)
        for k in ('bag_time_ns', 'header_time_ns', 'frame_index'):
            if a[k].dtype.kind not in 'iu':
                raise ValueError(f'{k} must be integer; nanosecond timestamps cannot be float')
        if len(set(a['layout_id'].tolist())) != 1 or len(set(a['frame_id'].tolist())) != 1 or len(set(a['setting_id'].tolist())) != 1:
            raise ValueError('Layout / frame / settings changed in selected history')
        if (np.diff(a['frame_index']) <= 0).any():
            raise ValueError('Acquisition frame_index must be strictly increasing')
        if c['validity']['status_field'] and 'status' not in a:
            raise ValueError('Configured status field missing from history')
        r, v, reason = validity(a['xyz'], c, a.get('valid'), a.get('status') if c['validity']['status_field'] else None)
        a.update(range=r, valid=v, invalid_reason=reason)
        for group in ('intensity', 'snr'):
            if not c[group]['field']:
                a.pop(group, None); a.pop(group+'_valid', None)
            elif group in a:
                good = np.isfinite(a[group]) & a.get(group+'_valid', True)
                if group == 'intensity':
                    good &= ~np.isin(a[group], c[group]['invalid_values'])
                    if c[group]['saturation_value'] is not None:
                        good &= a[group] < c[group]['saturation_value']
                a[group+'_valid'] = good
    frames = [{'frame_index': int(a['frame_index'][j]), 'bag_time_ns': int(a['bag_time_ns'][j]),
               'header_time_ns': int(a['header_time_ns'][j]), 'frame_id': str(a['frame_id'][j]),
               'height': h, 'width': w, 'acquisition_setting_id': str(a['setting_id'][j]),
               'layout_id': str(a['layout_id'][j])} for j in range(len(idx))]
    return a, ref, {'frames': frames, 'source_total_frames': total,
                    'time_diagnostics': time_diagnostics(frames),
                    'warning': 'NPZ input is an explicit history contract, not verification of original PointField schema',
                    'arrays': npz_inventory(path)}
