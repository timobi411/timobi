from pathlib import Path
import hashlib
import json
import math
import numpy as np


def clean(value):
    if isinstance(value, np.ndarray):
        return clean(value.tolist())
    if isinstance(value, np.generic):
        return clean(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    return value


def write_json(path, value):
    Path(path).write_text(json.dumps(clean(value), ensure_ascii=False, indent=2,
                                    allow_nan=False) + '\n', encoding='utf-8')


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def input_hashes(path):
    p = Path(path).resolve()
    files = [p] if p.is_file() else sorted(q for q in p.rglob('*') if q.is_file())
    return [{'path': str(q), 'size': q.stat().st_size, 'sha256': sha256(q)} for q in files]


def new_output(path, inputs=()):
    p = Path(path).resolve()
    for src in inputs:
        s = Path(src).resolve()
        if p == s or (s.is_dir() and s in p.parents):
            raise ValueError('出力先を入力ディレクトリ内に作成できません。別の新規ディレクトリを指定してください。')
    p.mkdir(parents=True, exist_ok=False)
    return p


def save_pcd(path, xyz):
    a = np.asarray(xyz, dtype=np.float64).reshape(-1, 3)
    if not np.isfinite(a).all():
        raise ValueError('PCD contains non-finite coordinates')
    with open(path, 'w') as f:
        f.write('# .PCD v0.7\nVERSION 0.7\nFIELDS x y z\nSIZE 4 4 4\nTYPE F F F\nCOUNT 1 1 1\n')
        f.write(f'WIDTH {len(a)}\nHEIGHT 1\nVIEWPOINT 0 0 0 1 0 0 0\nPOINTS {len(a)}\nDATA ascii\n')
        np.savetxt(f, a, fmt='%.9g')


def summary(a):
    a = np.asarray(a); a = a[np.isfinite(a)]
    return {'count': len(a), 'q05_q50_q95': np.quantile(a, [.05, .5, .95]).tolist() if len(a) else None}
