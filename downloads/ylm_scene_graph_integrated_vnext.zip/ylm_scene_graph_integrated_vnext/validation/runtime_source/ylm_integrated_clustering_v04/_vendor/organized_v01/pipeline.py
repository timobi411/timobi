from pathlib import Path
import contextlib
import json
import importlib.metadata
import os
import platform
import resource
import sys
import time
import traceback
import numpy as np
from . import __version__
from .util import write_json, input_hashes, sha256, save_pcd, summary
from .input import inspect_bag, load_bag_history, load_npz_history, INVALID_BITS
from .temporal import analyze_history, classify_missingness, SOURCE, MISSING, HOLD
from .clustering import (load_frozen, structure_mask, cluster_organized, export_clusters,
                         frozen_cluster, EDGE_HOLD)
from .relations import fragment_relations
from .evaluation import evaluate
from .report import make_report


def apply_memory_limit(c):
    # Linux address-space growth limit protects against oversized windows/JSON output.
    # Includes the already-imported interpreter/NumPy/SciPy baseline, recorded below.
    pages=int(Path('/proc/self/statm').read_text().split()[0]) if Path('/proc/self/statm').exists() else None
    if pages is None:
        return {'enforced':False,'reason':'/proc unavailable; conservative allocation guard remains active'}
    base=pages*os.sysconf('SC_PAGE_SIZE'); growth=int(c['memory']['max_working_mb']*1024**2)
    soft,hard=resource.getrlimit(resource.RLIMIT_AS); requested=base+growth
    new=min(requested,hard) if hard!=resource.RLIM_INFINITY else requested
    if soft!=resource.RLIM_INFINITY: new=min(new,soft)
    resource.setrlimit(resource.RLIMIT_AS,(new,hard))
    return {'enforced':True,'rlimit_as_bytes':new,'baseline_virtual_bytes':base,'additional_address_space_limit_bytes':growth}


def source_hashes():
    root=Path(__file__).resolve().parent.parent
    return {str(p.relative_to(root)):sha256(p) for p in sorted(root.rglob('*.py')) if '__pycache__' not in p.parts}


def save_variant(out,name,v,c,metadata=None):
    summary_v=export_clusters(out/name,v['xyz'],v['valid'],v['labels'],v['source'],v['times'],
                              c['clustering']['min_cluster_points'],metadata)
    v['counts']=summary_v['counts'];v['status']='ok'
    return v


def run(input_path, kind, c, out):
    start=time.perf_counter()
    extra_inputs=[c['structure']['mask_npz'],c['projection']['npz'],c['evaluation']['instance_labels_npz']]
    manifest={'version':__version__,'status':'started','input_kind':kind,'input':str(Path(input_path).resolve()),
              'input_hashes':input_hashes(input_path),'auxiliary_input_hashes':[],
              'code_sha256':source_hashes(),'topic':c['topic'] if kind=='bag' else None,
              'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,
              'scene_static_assumption':c['scene'],'config_sha256':None,
              'downstream_ICP_assignment_scene_graph_modified':False,
              'point_source_codes':SOURCE,'missingness_codes':MISSING,'hold_reason_bits':HOLD,
              'invalid_reason_bits':INVALID_BITS,'edge_hold_bits':EDGE_HOLD,
              'ray_geometry_source':'measurement-derived XYZ normalization',
              'display_transform':{'rotation_deg':c['acquisition']['display_rotation_deg'],'data_reordered':False}}
    manifest['dependency_versions']={}
    for package in ('numpy','scipy','open3d','plotly'):
        try: manifest['dependency_versions'][package]=importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError: manifest['dependency_versions'][package]=None
    write_json(out/'run_manifest.json',manifest);write_json(out/'config.json',c)
    manifest['config_sha256']=sha256(out/'config.json')
    try:
        for p in extra_inputs:
            if p: manifest['auxiliary_input_hashes']+=input_hashes(p)
        manifest['memory_limit']=apply_memory_limit(c)
        if kind=='bag':
            inspection=inspect_bag(input_path,c);write_json(out/'input_inspection.json',inspection)
            write_json(out/'frame_metadata.json',inspection['frames'])
            a,ref=load_bag_history(input_path,c,inspection,out)
            total=inspection['received_frame_count']
        else:
            a,ref,inspection=load_npz_history(input_path,c)
            write_json(out/'input_inspection.json',inspection)
            write_json(out/'frame_metadata.json',inspection['frames'])
            total=inspection['source_total_frames']
        h,w=a['valid'].shape[1:];pixel_row,pixel_column=np.indices((h,w))
        np.savez_compressed(out/'history.npz',**a,pixel_row=pixel_row,pixel_column=pixel_column,
                            reference_sample_index=ref)
        manifest.update(selected_frame_indices=a['frame_index'],reference_frame_index=a['frame_index'][ref],
                        reference_sample_index=ref,source_received_frame_count=total,
                        selected_received_frame_count=len(a['frame_index']),
                        observation_rate_denominator='selected received frames, not estimated transmissions',
                        comparison_scope='same-window' if c['frame_selection']['mode']!='all' else 'full-acquisition; separate comparison from middle-window',
                        selected_bag_times_ns=a['bag_time_ns'],selected_header_times_ns=a['header_time_ns'],
                        available_history_fields=sorted(a), intensity_enabled='intensity' in a,
                        driver_validity_reviewed=c['validity']['reviewed'],
                        selected_shape=[len(a['frame_index']),h,w],
                        missing_run_basis='consecutive acquisition indices inside selected window; gaps reset runs')
        print(f'History: {len(a["frame_index"])} received frames, {h} x {w}',flush=True)
        stats,integ,legacy,sample_modes,hypotheses,gates=analyze_history(a,ref,c)
        manifest['gates']=gates
        np.savez_compressed(out/'pixel_statistics.npz',**stats)
        np.savez_compressed(out/'sample_surface_modes.npz',sample_mode=sample_modes,
                            frame_index=a['frame_index'],pixel_row=pixel_row,pixel_column=pixel_column)
        write_json(out/'surface_hypotheses.json',{'multi_surface_pixels':hypotheses,
                   'single_surface_trace':'sample_surface_modes.npz + history.npz; mode 0 for valid single-surface samples',
                   'unobserved_mode_count':0,'outlier_policy':'singletons retained as low-support hypotheses; not deleted'})
        np.savez_compressed(out/'integrated_observation.npz',**integ)
        np.savez_compressed(out/'legacy_temporal_observation.npz',**legacy)
        mod=None;baseline_reason=None
        try:
            mod=load_frozen(c['legacy']['backend'])
            if mod is None: baseline_reason='disabled explicitly in config'
        except ImportError as e:
            baseline_reason='Optional frozen backend dependencies unavailable: '+str(e)
            if c['structure']['mode']=='legacy_planes':
                raise RuntimeError(baseline_reason+'; structure mode requires them, no silent fallback') from e
        with open(out/'legacy_backend.log','w') as log,contextlib.redirect_stdout(log):
            structure,sinfo=structure_mask(legacy,integ,c,mod)
        np.savez_compressed(out/'structure_mask.npz',structure_mask=structure,pixel_row=pixel_row,pixel_column=pixel_column)
        write_json(out/'structure_metadata.json',sinfo)
        manifest['structure_mask_sha256']=sha256(out/'structure_mask.npz');manifest['structure_status']=sinfo['status']
        missing=classify_missingness(a,ref,stats,integ,structure,c)
        np.savez_compressed(out/'missingness.npz',**missing)
        maxrange=c['structure']['max_processing_range_m']
        conf=(stats['valid_count']>=c['clustering']['min_confidence_support']) & (stats['range_mad']<=c['temporal']['max_mad_m']) & (stats['mode_count']==1) & ~stats['time_change_candidate'] & ~stats['ray_change_candidate']
        variants={}; diagnostics={}
        current_valid=a['valid'][ref] & ~structure & (a['range'][ref]<=maxrange)
        cv={'xyz':np.where(a['valid'][ref][...,None],a['xyz'][ref],np.nan),
            'range':a['range'][ref], 'valid':current_valid,
            'source':np.where(current_valid,1,0).astype(np.uint8),
            'times':np.where(current_valid,a['bag_time_ns'][ref],-1)}
        t=time.perf_counter()
        labels,edges,boundary,bridges=cluster_organized(cv['xyz'],cv['valid'],conf,c)
        cv['labels']=labels
        variants['current_only']=save_variant(out,'current_only',cv,c,{'trust':'history confidence; points are current only'})
        cv['seconds']=time.perf_counter()-t
        np.savez_compressed(out/'current_edges.npz',**edges)
        for name,obs,trust in [('B',legacy,np.ones((h,w),bool)),('C',integ,conf)]:
            t=time.perf_counter();valid=obs['valid'] & ~structure & (obs['range']<=maxrange)
            labels,edges,boundary,bridges=cluster_organized(obs['xyz'],valid,trust,c,
                current_labels=cv['labels'] if name=='C' else None,current_valid=cv['valid'] if name=='C' else None)
            v={'xyz':obs['xyz'],'range':obs['range'],'valid':valid,'labels':labels,
               'source':obs['source_type'],'times':obs['source_time_ns']}
            variants[name]=save_variant(out,name,v,c,{'input':'legacy representative' if name=='B' else 'current + accepted single-surface representatives',
                                           'shared_structure_mask':'../structure_mask.npz'})
            v['seconds']=time.perf_counter()-t
            np.savez_compressed(out/(name+'_edges.npz'),**edges)
            write_json(out/(name+'_bridge_candidates.json'),bridges)
            diagnostics[name]={'edge_distance_m':summary(edges['distance_m']),
                               'alpha_deg':summary(np.degrees(edges['alpha_rad'])),
                               'beta_deg':summary(np.degrees(edges['beta_rad'])),
                               'boundary_pixels':int(boundary.sum()),'bridge_holds':len(bridges),
                               'edge_hold_counts':{k:int(((edges['hold_reason'] & bit)!=0).sum()) for k,bit in EDGE_HOLD.items()}}
            if name=='C':
                flying=boundary & ((stats['range_mad']>c['temporal']['max_mad_m']) | (stats['mode_count']>1))
                missing['flying_pixel_candidate']=flying
                missing['flying_pixel_cause_confirmed']=np.zeros((h,w),bool)
        np.savez_compressed(out/'missingness.npz',**missing)
        if mod is None:
            variants['A']={'status':'not_run','reason':baseline_reason}
            write_json(out/'A_status.json',variants['A'])
        else:
            t=time.perf_counter();valid=variants['B']['valid']
            with open(out/'legacy_backend.log','a') as log,contextlib.redirect_stdout(log):
                lab,trace,vxyz,vlab=frozen_cluster(legacy['xyz'],valid,c,mod)
            av={'xyz':legacy['xyz'],'range':legacy['range'],'valid':valid,'labels':lab,
                'source':legacy['source_type'],'times':legacy['source_time_ns']}
            variants['A']=save_variant(out,'A',av,c,{'method':'frozen '+c['legacy']['backend'],
                'comparison':'controlled shared pixel mask -> legacy voxel -> frozen clustering; not historical full-pipeline reproduction',
                'pcd_note':'fragment PCDs retain source samples; voxel input and labels separately saved'})
            np.savez_compressed(out/'A'/'voxel_trace.npz',**trace,voxel_xyz=vxyz,voxel_label=vlab)
            save_pcd(out/'A'/'voxel_input.pcd',vxyz);av['seconds']=time.perf_counter()-t
        print('Clustering complete; building relations and viewer',flush=True)
        t=time.perf_counter()
        vc=variants['C']
        rel=fragment_relations(vc['xyz'],vc['labels'],a['range'][ref],a['valid'][ref],stats,c)
        write_json(out/'fragment_relations.json',rel)
        vd=dict(vc);vd['seconds']=time.perf_counter()-t;variants['D']=vd
        # D is a zero-copy label reference, not a second clustering/merge run.
        write_json(out/'D.json',{'labels_reference':'C/pixel_correspondence.npz','clusters_reference':'C/clusters.json',
                               'relations':'fragment_relations.json','label_changes':0})
        gt=None
        if c['evaluation']['instance_labels_npz']:
            with np.load(c['evaluation']['instance_labels_npz'],allow_pickle=False) as z:
                if 'instance_id' not in z or z['instance_id'].shape!=(h,w) or z['instance_id'].dtype.kind not in 'iu':
                    raise ValueError('instance_id[H,W] integer labels required; -1 means unlabelled')
                gt=z['instance_id'].copy()
        evaluation=evaluate(variants,stats,missing,gt,c)
        evaluation.update(edge_diagnostics=diagnostics,
                          held_temporal_pixels=int((integ['hold_reason']!=0).sum()),
                          global_static_hold=not gates['temporal_adoption_allowed'],
                          structure_masked_pixels=int(structure.sum()),
                          point_filter_excluded_pixels={k:int((v['valid'] & (v['range']>maxrange)).sum()) for k,v in [('legacy',legacy),('integrated',integ)]},
                          known_input_corruption_holds=len(inspection.get('errors',[])),
                          baseline_A_limit='frozen clustering on controlled shared-mask inputs, not historical full pipeline',
                          fullbag_effect_separate=c['frame_selection']['mode']=='all')
        write_json(out/'clusters.json',{'variants':{k:{'status':v['status'],'path':('C' if k=='D' else k)+'/clusters.json' if v['status']=='ok' else None} for k,v in variants.items()},
                                      'ICP_invoked':False,'object_ID_or_coordinates_updated':False})
        calib={'status':'diagnostic, not sensor calibration','noise_by_range':[],
               'edge_diagnostics':diagnostics,'thresholds_auto_tuned':False}
        bins=c['evaluation']['range_bins_m']
        for low,high in zip(bins[:-1],bins[1:]):
            mask=(stats['range_median']>=low)&(stats['range_median']<high)&(stats['valid_count']>=2)&(stats['mode_count']==1)
            calib['noise_by_range'].append({'low_m':low,'high_m':high,'range_MAD_m':summary(stats['range_mad'][mask])})
        write_json(out/'calibration_diagnostics.json',calib)
        manifest['status']='completed_with_holds' if not gates['temporal_adoption_allowed'] else 'completed_experimental'
        manifest['baseline_A_status']=variants['A']['status']
        manifest['independent_real_data_validation']=False
        manifest['input_verified_after_run'] = input_hashes(input_path)==manifest['input_hashes']
        if not manifest['input_verified_after_run']:
            raise RuntimeError('Input changed during run; results cannot be claimed reproducible')
        evaluation['runtime_seconds_before_viewer']=time.perf_counter()-start
        evaluation['peak_rss_mib_before_viewer']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024
        make_report(out/'index.html',a,ref,stats,integ,missing,variants,manifest,evaluation,rel,c)
        evaluation['total_runtime_seconds']=time.perf_counter()-start
        evaluation['peak_rss_mib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024
        write_json(out/'evaluation.json',evaluation);write_json(out/'run_manifest.json',manifest)
        print(f'Output: {out}\nTemporal: {gates["temporal_adoption_allowed"]}\nViewer: {out/"index.html"}',flush=True)
        return manifest,evaluation
    except Exception as e:
        manifest.update(status='failed',error_type=type(e).__name__,error=str(e))
        write_json(out/'run_manifest.json',manifest)
        write_json(out/'failure.json',{'error':str(e),'type':type(e).__name__,'traceback':traceback.format_exc(),
                                     'partial_output_only':True,'input_modified_by_pipeline':False})
        raise
