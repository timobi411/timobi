from copy import deepcopy
import json

DEFAULT = {
    'version': '0.1.0',
    'parameter_status': 'experimental_unvalidated_on_YLM',
    'parameter_basis': 'legacy window/range retained for comparison; other numerical gates are conservative engineering starting values, not calibrated sensor constants',
    'topic': '/lumotive_ros/pointcloud',
    'storage_id': 'auto',
    'frame_selection': {'mode': 'middle', 'count': 11, 'indices': None, 'reference_index': None},
    'memory': {'max_working_mb': 2048, 'max_window_frames': 256},
    'acquisition': {
        'setting_id': 'unknown', 'settings_evidence': '',
        'pixel_correspondence_confirmed': False,
        'xyz_sensor_frame_confirmed': False,
        'sensor_origin_xyz': [0.0, 0.0, 0.0],
        'display_rotation_deg': 0,
    },
    'validity': {
        'reviewed': False, 'driver_definition': '',
        'min_range_m': 0.05, 'max_range_m': 12.0,
        'zero_xyz_invalid': True, 'invalid_ranges_m': [], 'invalid_range_atol_m': 1e-6,
        'status_field': None, 'status_valid_values': None, 'status_definition': '',
    },
    'intensity': {'field': None, 'definition': '', 'invalid_values': [],
                  'saturation_value': None, 'low_evidence_threshold': None,
                  'low_valid_fraction': 0.5},
    'snr': {'field': None, 'definition': ''},
    'scene': {'static_confirmed': False, 'acquisition_record': '',
              'known_motion': False, 'global_dynamic_fraction': 0.05},
    'temporal': {'min_support_count': 5, 'min_support_fraction': 0.45,
                 'freshness_limit_s': 1.0, 'max_window_span_s': 2.0,
                 'mode_gap_m': 0.08, 'mode_gap_per_m': 0.0,
                 'max_mad_m': 0.03, 'drift_span_m': 0.08,
                 'max_ray_deviation_deg': 0.5,
                 'time_basis': 'bag', 'window_direction': 'offline_symmetric'},
    'legacy': {'min_valid_frames': 5, 'min_range_m': 0.05, 'max_range_m': 12.0,
               'backend': 'fixed_B0'},
    'structure': {'mode': 'none', 'mask_npz': None,
                  'mask_basis': '', 'include_unobserved_pixel_mask': False,
                  'max_processing_range_m': 7.0},
    'clustering': {'neighborhood': 4, 'beta_threshold_deg': 10.0,
                   'max_edge_distance_m': 0.12, 'boundary_jump_m': 0.25,
                   'min_cluster_points': 50, 'min_confidence_support': 2,
                   'hold_boundary_points': True, 'prevent_temporal_bridges': True},
    'relations': {'max_gap_pixels': 5, 'max_endpoint_distance_m': 0.35,
                  'depth_margin_m': 0.10, 'local_plane_radius_pixels': 2,
                  'max_local_plane_residual_m': 0.03,
                  'max_local_normal_angle_deg': 25.0,
                  'max_candidates': 10000},
    'projection': {'npz': None, 'verified': False, 'evidence': '',
                   'depth_error_m': 0.03, 'free_space_model_verified': False},
    'evaluation': {'instance_labels_npz': None,
                   'dataset_role': 'development',
                   'range_bins_m': [0, 1, 2, 3, 4, 6, 12],
                   'valid_fraction_bins': [0, 0.25, 0.5, 0.75, 1.01],
                   'intensity_bins': None},
    'viewer': {'max_3d_points': 25000}
}


def merge(dst, src, trail=''):
    for key, value in src.items():
        if key not in dst:
            raise ValueError(f'Unknown config key: {trail}{key}')
        if isinstance(dst[key], dict):
            if not isinstance(value, dict):
                raise ValueError(f'Expected object: {trail}{key}')
            merge(dst[key], value, trail + key + '.')
        else:
            dst[key] = value
    return dst


def load_config(path=None):
    c = deepcopy(DEFAULT)
    if path:
        with open(path) as f:
            merge(c, json.load(f))
    validate(c)
    if path:
        from pathlib import Path
        base = Path(path).resolve().parent
        for section, key in [('structure','mask_npz'), ('projection','npz'), ('evaluation','instance_labels_npz')]:
            value = c[section][key]
            if value and not Path(value).is_absolute():
                c[section][key] = str((base/value).resolve())
    return c


def validate(c):
    import math
    def check_finite(x):
        if isinstance(x, dict):
            for v in x.values(): check_finite(v)
        elif isinstance(x, list):
            for v in x: check_finite(v)
        elif isinstance(x, float) and not math.isfinite(x):
            raise ValueError('Config cannot contain NaN/Inf')
    check_finite(c)
    if len(c['acquisition']['sensor_origin_xyz']) != 3:
        raise ValueError('sensor_origin_xyz must have 3 coordinates')
    if c['temporal']['mode_gap_per_m'] < 0:
        raise ValueError('mode_gap_per_m must be nonnegative')
    if c['validity']['min_range_m'] < 0 or c['validity']['max_range_m'] <= c['validity']['min_range_m']:
        raise ValueError('Invalid range limits')
    for section, key in [('temporal','min_support_count'),('memory','max_window_frames'),('relations','max_gap_pixels'),('relations','max_candidates'),('clustering','min_cluster_points'),('clustering','min_confidence_support'),('viewer','max_3d_points')]:
        if not isinstance(c[section][key],int) or c[section][key] <= 0:
            raise ValueError(f'{section}.{key} must be positive integer')
    if c['frame_selection']['mode'] not in ('middle', 'indices', 'all'):
        raise ValueError('frame_selection.mode: middle / indices / all')
    n = c['frame_selection']['count']
    if not isinstance(n, int) or n < 1 or n % 2 != 1:
        raise ValueError('middle count must be positive odd integer')
    if c['clustering']['neighborhood'] not in (4, 8):
        raise ValueError('Only 4/8 adjacency; no wraparound')
    if c['acquisition']['display_rotation_deg'] not in (0, 180):
        raise ValueError('Display rotation must be 0/180; arrays are never rotated')
    if c['legacy']['backend'] not in ('fixed_B0', 'adaptive_V2', 'disabled'):
        raise ValueError('Unknown frozen clustering backend')
    if c['structure']['mode'] not in ('none', 'pixel_mask', 'legacy_planes'):
        raise ValueError('Unknown structure mode')
    if c['temporal']['time_basis'] != 'bag' or c['temporal']['window_direction'] != 'offline_symmetric':
        raise ValueError('v0.1 supports bag-time offline symmetric windows only')
    for section, keys in {
        'temporal': ['min_support_count', 'freshness_limit_s', 'max_window_span_s', 'mode_gap_m', 'max_mad_m', 'drift_span_m', 'max_ray_deviation_deg'],
        'memory': ['max_working_mb', 'max_window_frames'],
        'clustering': ['max_edge_distance_m', 'boundary_jump_m', 'min_cluster_points', 'min_confidence_support'],
        'relations': ['max_gap_pixels', 'max_endpoint_distance_m', 'depth_margin_m', 'max_candidates'],
    }.items():
        for k in keys:
            if c[section][k] <= 0:
                raise ValueError(f'{section}.{k} must be positive')
    for x in [c['temporal']['min_support_fraction'], c['scene']['global_dynamic_fraction']]:
        if not 0 <= x <= 1:
            raise ValueError('Fractions must be in [0,1]')
    if not 0 < c['clustering']['beta_threshold_deg'] < 90:
        raise ValueError('beta threshold must be between 0 and 90 degrees')
    if c['evaluation']['dataset_role'] not in ('development', 'held_out', 'synthetic'):
        raise ValueError('Unknown dataset role')
    for group in ('intensity', 'snr'):
        if c[group]['field'] and not c[group]['definition'].strip():
            raise ValueError(f'{group}.definition is required before using this field')
    if c['validity']['status_field'] and (not c['validity']['status_definition'] or c['validity']['status_valid_values'] is None):
        raise ValueError('Define status meaning and valid values first')
    if c['structure']['mode'] == 'pixel_mask' and (not c['structure']['mask_npz'] or not c['structure']['mask_basis']):
        raise ValueError('pixel_mask requires mask_npz and mask_basis')
    if c['projection']['npz'] and (not c['projection']['verified'] or not c['projection']['evidence']):
        raise ValueError('Known projection requires verified=true and evidence')
