import argparse
import sys
from pathlib import Path
from .config import load_config
from .util import new_output,write_json,input_hashes
from .input import inspect_bag,npz_inventory
from .demo import create


def main(argv=None):
    p=argparse.ArgumentParser(description='YLM organized observation v0.1: frozen downstream, no overwrites')
    sub=p.add_subparsers(dest='command',required=True)
    q=sub.add_parser('init-config');q.add_argument('--out',required=True)
    q=sub.add_parser('make-demo');q.add_argument('--out',required=True)
    for command in ('inspect','run'):
        q=sub.add_parser(command);g=q.add_mutually_exclusive_group(required=True)
        g.add_argument('--bag');g.add_argument('--history-npz')
        q.add_argument('--config');q.add_argument('--out',required=True)
    args=p.parse_args(argv)
    try:
        if args.command=='init-config':
            path=Path(args.out)
            with path.open('x',encoding='utf-8') as f:
                import json
                json.dump(load_config(),f,ensure_ascii=False,indent=2)
            print(path.resolve());return 0
        if args.command=='make-demo':
            out=new_output(args.out);create(out);print(out);return 0
        c=load_config(args.config);source=args.bag or args.history_npz
        aux=[c['structure']['mask_npz'],c['projection']['npz'],c['evaluation']['instance_labels_npz']]
        out=new_output(args.out,[source]+[x for x in aux if x])
        if args.command=='inspect':
            try:
                result=inspect_bag(source,c) if args.bag else npz_inventory(source)
                result['input_hashes']=input_hashes(source);write_json(out/'inspection.json',result)
                if 'frames' in result:write_json(out/'frame_metadata.json',result['frames'])
                write_json(out/'config.json',c)
                print(f'Inspection: {out/"inspection.json"}')
                if args.bag:
                    print(f'Received frames: {result["received_frame_count"]}; layouts: {len(result["layouts"])}')
                    for x in result['layouts'].values():
                        m=x['schema'];print(m['height'],m['width'],m['fields'])
                else:print(result['action'])
                return 0
            except Exception as e:
                write_json(out/'failure.json',{'error':str(e),'status':'inspection_failed'})
                raise
        from .pipeline import run
        run(source,'bag' if args.bag else 'history_npz',c,out)
        return 0
    except (ValueError,RuntimeError,FileExistsError,FileNotFoundError,MemoryError) as e:
        print(f'ERROR: {e}',file=sys.stderr);return 2


if __name__=='__main__':
    raise SystemExit(main())
