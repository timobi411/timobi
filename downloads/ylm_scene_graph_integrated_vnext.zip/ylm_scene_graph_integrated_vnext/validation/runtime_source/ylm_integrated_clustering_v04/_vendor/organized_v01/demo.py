import numpy as np
from .config import load_config
from .util import write_json


def fixture():
    f,h,w=11,18,30
    yy,xx=np.indices((h,w)); rays=np.stack([np.ones((h,w)),(xx-14.5)*.02,(yy-8.5)*.02],axis=-1)
    rays/=np.linalg.norm(rays,axis=-1,keepdims=True)
    # Two adjacent but distinct panels; permanent no-return column separates them.
    ranges=np.where(xx<15,2.0,2.04)
    xyz=np.tile((rays*ranges[...,None])[None],(f,1,1,1)).astype(np.float32)
    valid=np.ones((f,h,w),bool);valid[:,:,15]=False;valid[:,0,0]=False
    valid[:,0,1]=False;valid[2,0,1]=True
    valid[5,6:10,5:10]=False
    xyz[6:,2:4,3:5]=rays[2:4,3:5]*3.0
    xyz[:,14,26]=rays[14,26]*np.linspace(2,2.25,f)[:,None]
    xyz[~valid]=np.nan
    intensity=np.ones((f,h,w),np.float32)*100;intensity[:,5:11,4:11]=4
    intensity[~valid]=np.nan
    time=np.arange(f,dtype=np.int64)*100000000+1791430000000000000
    data=dict(xyz=xyz,valid=valid,frame_index=np.arange(f,dtype=np.int64),
              bag_time_ns=time,header_time_ns=time-1000000,
              frame_id=np.full(f,'synthetic_sensor'),setting_id=np.full(f,'synthetic_fixed'),
              layout_id=np.full(f,'synthetic_layout'),intensity=intensity,intensity_valid=np.isfinite(intensity))
    gt=np.where(xx<15,0,1).astype(np.int32);gt[:,15]=-1;gt[0,0]=-1
    return data,gt


def config():
    c=load_config()
    c['acquisition'].update(setting_id='synthetic_fixed',settings_evidence='synthetic generator fixed rays',pixel_correspondence_confirmed=True,xyz_sensor_frame_confirmed=True)
    c['scene'].update(static_confirmed=True,acquisition_record='synthetic fixture; local switching pixels explicitly included')
    c['validity'].update(reviewed=True,driver_definition='synthetic: NaN is invalid; finite positive range is valid')
    c['intensity'].update(field='intensity',definition='synthetic arbitrary amplitude, not calibrated reflectivity',low_evidence_threshold=10)
    c['legacy']['backend']='disabled';c['evaluation']['dataset_role']='synthetic';c['clustering']['min_cluster_points']=10
    c['evaluation']['intensity_bins']=[0,10,200]
    return c


def create(folder):
    a,gt=fixture();c=config();c['evaluation']['instance_labels_npz']='instance_labels.npz'
    np.savez_compressed(folder/'synthetic_history.npz',**a)
    np.savez_compressed(folder/'instance_labels.npz',instance_id=gt)
    write_json(folder/'synthetic_config.json',c)
    write_json(folder/'fixture_description.json',{'real_YLM_data':False,'all_missing_pixel':[0,0],
        'single_observation_pixel':[0,1],'reference_missing_patch':'rows 6:10, cols 5:10',
        'multi_surface_patch':'rows 2:4, cols 3:5','permanent_no_return_column':15,
        'gradual_drift_pixel':[14,26],'instance_labels_used_only_in_evaluation':True})
