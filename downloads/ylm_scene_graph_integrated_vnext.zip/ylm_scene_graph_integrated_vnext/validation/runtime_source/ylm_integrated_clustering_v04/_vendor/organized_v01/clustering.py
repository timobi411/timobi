import importlib.util
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from .util import save_pcd, write_json

EDGE_HOLD = {'ANGLE':1,'DISTANCE':2,'BOUNDARY':4,'LOW_CONFIDENCE':8,'GEOMETRY':16,'TEMPORAL_BRIDGE':32}


def components(mask, i, j):
    h,w=mask.shape; p=np.flatnonzero(mask)
    mapping=np.full(h*w,-1,np.int32); mapping[p]=np.arange(len(p))
    labels=np.full(h*w,-1,np.int32)
    if len(p):
        graph=coo_matrix((np.ones(len(i),np.uint8),(mapping[i],mapping[j])),shape=(len(p),len(p))).tocsr()
        _,lab=connected_components(graph,directed=False)
        labels[p]=lab
    return labels.reshape(h,w)


def adjacency(h,w,neighborhood):
    grid=np.arange(h*w).reshape(h,w)
    pairs=[(grid[:,:-1].ravel(),grid[:,1:].ravel()),(grid[:-1].ravel(),grid[1:].ravel())]
    if neighborhood==8:
        pairs += [(grid[:-1,:-1].ravel(),grid[1:,1:].ravel()),(grid[:-1,1:].ravel(),grid[1:,:-1].ravel())]
    return np.concatenate([p[0] for p in pairs]),np.concatenate([p[1] for p in pairs])


def cluster_organized(xyz, valid, trusted, c, current_labels=None, current_valid=None):
    h,w=valid.shape; flat=xyz.reshape(-1,3)
    origin=np.asarray(c['acquisition']['sensor_origin_xyz'])
    rel=flat-origin; r=np.linalg.norm(rel,axis=-1)
    u=np.divide(rel,r[:,None],out=np.zeros_like(rel),where=(r>0)[:,None])
    i,j=adjacency(h,w,c['clustering']['neighborhood'])
    pair=valid.ravel()[i] & valid.ravel()[j]
    i,j=i[pair],j[pair]
    alpha=np.arccos(np.clip(np.einsum('ij,ij->i',u[i],u[j]),-1,1))
    near=np.minimum(r[i],r[j]); far=np.maximum(r[i],r[j])
    beta=np.arctan2(near*np.sin(alpha),far-near*np.cos(alpha))
    dist=np.linalg.norm(flat[i]-flat[j],axis=1)
    reason=np.zeros(len(i),np.uint8)
    reason[beta<np.radians(c['clustering']['beta_threshold_deg'])] |= EDGE_HOLD['ANGLE']
    reason[dist>c['clustering']['max_edge_distance_m']] |= EDGE_HOLD['DISTANCE']
    geometry=(~np.isfinite(alpha))|(~np.isfinite(beta))|(alpha<1e-8)|(alpha>=np.pi/2)
    reason[geometry] |= EDGE_HOLD['GEOMETRY']
    jump=np.abs(r[i]-r[j])>=c['clustering']['boundary_jump_m']
    boundary=np.zeros(h*w,bool); boundary[i[jump]]=True; boundary[j[jump]]=True
    reason[jump] |= EDGE_HOLD['BOUNDARY']
    if c['clustering']['hold_boundary_points']:
        reason[boundary[i]|boundary[j]] |= EDGE_HOLD['BOUNDARY']
    reason[~trusted.ravel()[i]|~trusted.ravel()[j]] |= EDGE_HOLD['LOW_CONFIDENCE']
    pre=components(valid,i[reason==0],j[reason==0])
    bridges=[]
    if current_labels is not None and c['clustering']['prevent_temporal_bridges']:
        pl=pre.ravel(); cl=current_labels.ravel(); cv=current_valid.ravel()
        # Any component joining distinct current components through newly adopted samples is held.
        bridge_regions=[]
        member_ids=np.flatnonzero(pl>=0)
        ordered=member_ids[np.argsort(pl[member_ids],kind='stable')]
        groups=np.split(ordered,np.flatnonzero(np.diff(pl[ordered]))+1) if len(ordered) else []
        for members in groups:
            label=pl[members[0]]
            seeds=np.unique(cl[members[cv[members]]]); seeds=seeds[seeds>=0]
            if len(seeds)>1:
                bridge_regions.append(int(label))
                bridges.append({'candidate_component':int(label),'current_fragments':seeds.tolist(),
                                'temporally_added_pixels':members[~cv[members]].tolist(),
                                'decision':'hold_temporal_edges; no automatic merge'})
        if bridge_regions:
            region=np.isin(pl[i],bridge_regions)
            cross=region & ((~cv[i])|(~cv[j])|(cl[i]!=cl[j])) & (reason==0)
            reason[cross] |= EDGE_HOLD['TEMPORAL_BRIDGE']
    labels=components(valid,i[reason==0],j[reason==0])
    edges={'pixel_i':i,'pixel_j':j,'alpha_rad':alpha,'beta_rad':beta,'distance_m':dist,
           'hold_reason':reason,'accepted':reason==0}
    return labels,edges,boundary.reshape(h,w),bridges


def pca_obb(points):
    pts=np.asarray(points); mean=pts.mean(axis=0)
    if len(pts)<2:
        axes=np.eye(3)
    else:
        _,axes=np.linalg.eigh((pts-mean).T@(pts-mean)); axes=axes[:,::-1]
        if np.linalg.det(axes)<0: axes[:,-1]*=-1
    local=(pts-mean)@axes; low=local.min(axis=0); high=local.max(axis=0)
    return {'center':mean+axes@((low+high)/2),'extent':high-low,'rotation':axes,
            'method':'PCA enclosing OBB; degeneracies allowed; not a minimum-volume guarantee'}


def export_clusters(folder, xyz, valid, labels, source, times, min_points, extra=None):
    folder=Path(folder); folder.mkdir(parents=True,exist_ok=False)
    flatxyz=xyz.reshape(-1,3); ll=labels.ravel(); h,w=labels.shape
    source=source.ravel(); times=times.ravel()
    records=[]
    member_ids=np.flatnonzero(ll>=0)
    ordered=member_ids[np.argsort(ll[member_ids],kind='stable')]
    groups=np.split(ordered,np.flatnonzero(np.diff(ll[ordered]))+1) if len(ordered) else []
    for pixels in groups:
        label=ll[pixels[0]]; pts=flatxyz[pixels]
        small=len(pixels)<min_points; name=f'fragment_{int(label):05d}'
        save_pcd(folder/(name+'.pcd'),pts)
        records.append({'id':int(label),'kind':'small_fragment' if small else 'fragment',
                        'point_count':len(pixels),'source_pixels':np.column_stack(np.divmod(pixels,w)).tolist(),
                        'CURRENT_MEASURED':int((source[pixels]==1).sum()),
                        'TEMPORAL_MEASURED':int((source[pixels]==2).sum()),'MODEL_INFERRED':0,
                        'pcd':name+'.pcd','obb':pca_obb(pts)})
    np.savez_compressed(folder/'pixel_correspondence.npz',xyz=xyz,valid=valid,labels=labels,
                        source_type=source.reshape(h,w),source_time_ns=times.reshape(h,w),
                        pixel_row=np.indices((h,w))[0],pixel_column=np.indices((h,w))[1])
    unassigned=np.flatnonzero(valid.ravel() & (ll<0))
    save_pcd(folder/'unassigned.pcd',flatxyz[unassigned])
    result={'clusters':records,'unassigned_pixels':np.column_stack(np.divmod(unassigned,w)).tolist(),
            'counts':{'points':int(valid.sum()),'clusters':len(records),
                      'main_fragments':sum(r['kind']=='fragment' for r in records),
                      'small_fragments':sum(r['kind']=='small_fragment' for r in records),
                      'small_fragment_points':sum(r['point_count'] for r in records if r['kind']=='small_fragment'),
                      'unassigned_points':len(unassigned)},
            'metadata':extra or {}}
    write_json(folder/'clusters.json',result)
    return result


def load_frozen(backend):
    if backend=='disabled':
        return None
    name='cluster_obb_html_phase2_fixed_B0.py' if backend=='fixed_B0' else 'adaptive_clustering_V2.py'
    path=Path(__file__).resolve().parent.parent/'frozen_reference'/name
    spec=importlib.util.spec_from_file_location('ylm_frozen_'+backend,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def structure_mask(legacy, integrated, c, mod):
    h,w=legacy['valid'].shape; cfg=c['structure']; info={'mode':cfg['mode'],'shared_by':['A','B','C','D','current_only']}
    if cfg['mode']=='none':
        return np.zeros((h,w),bool),dict(info,status='diagnostic_only; structure removal pending')
    if cfg['mode']=='pixel_mask':
        with np.load(cfg['mask_npz'],allow_pickle=False) as z:
            if 'structure_mask' not in z or z['structure_mask'].shape!=(h,w):
                raise ValueError('structure_mask[H,W] required; do not map unordered PCD by guessed pixel indices')
            mask=z['structure_mask'].astype(bool)
        return mask,dict(info,status='provided shared pixel mask',basis=cfg['mask_basis'])
    if mod is None:
        raise ValueError('legacy_planes requires a frozen backend and Open3D/Plotly dependencies')
    import open3d as o3d
    use=legacy['valid'] & (legacy['range']<=cfg['max_processing_range_m'])
    cloud=o3d.geometry.PointCloud(); cloud.points=o3d.utility.Vector3dVector(legacy['xyz'][use])
    if not use.any():
        return np.zeros((h,w),bool),dict(info,status='no valid legacy points; no planes fitted')
    cloud=cloud.voxel_down_sample(mod.VOXEL_SIZE)
    pts=np.asarray(cloud.points); lo=np.percentile(pts,1,axis=0); hi=np.percentile(pts,99,axis=0)
    planes=mod.extract_plane_candidates(cloud)
    floor=mod.select_floor(planes,lo); ceil=mod.select_ceiling(planes,floor,hi)
    floors=([floor] if floor is not None else [])+mod.select_floor_fragments(planes,floor)
    ceils=([ceil] if ceil is not None else [])+mod.select_ceiling_fragments(planes,ceil)
    walls=mod.select_walls(planes,lo,hi)
    # Freeze one pixel mask from legacy representatives. If no legacy sample exists,
    # use an observed current/integrated sample, never an interpolated point.
    query=np.where(legacy['valid'][...,None],legacy['xyz'],integrated['xyz'])
    finite=np.isfinite(query).all(axis=-1); mask=np.zeros((h,w),bool); saved=[]
    for role,items,band,margin in [('floor',floors,mod.FLOOR_BAND,mod.FLOOR_FOOTPRINT_MARGIN),
                                  ('ceiling',ceils,mod.CEILING_BAND,mod.CEILING_FOOTPRINT_MARGIN),
                                  ('wall',walls,mod.WALL_BAND,mod.WALL_FOOTPRINT_MARGIN)]:
        for plane in items:
            mask[finite] |= mod.finite_plane_band_mask(query[finite],plane,band,margin)
            saved.append({'role':role,'band_m':band,'footprint_margin_m':margin,
                          'plane':plane})
    return mask,dict(info,status='frozen legacy finite-plane model projected to original pixels',
                     fitted_on='legacy temporal representative / legacy voxel',
                     mask_coordinate_source='legacy XYZ first; observed integrated XYZ only at legacy-absent pixels',
                     planes=saved,voxel_size=mod.VOXEL_SIZE)


def frozen_cluster(xyz, valid, c, mod):
    """Exact frozen clustering functions on shared masked, voxelized input.
    This controlled A is not a byte-for-byte rerun of the historical full pipeline.
    """
    import open3d as o3d
    p=np.flatnonzero(valid); pts=xyz.reshape(-1,3)[p]
    h,w=valid.shape
    if not len(pts):
        return np.full((h,w),-1,np.int32),{'voxel_points':0,'voxel_pixel_offsets':[0],'voxel_source_pixels':[]},np.empty((0,3)),np.array([],int)
    cloud=o3d.geometry.PointCloud(); cloud.points=o3d.utility.Vector3dVector(pts)
    size=mod.VOXEL_SIZE
    vox,_,traces=cloud.voxel_down_sample_and_trace(size,cloud.get_min_bound()-size*.5,cloud.get_max_bound()+size*.5,False)
    if c['legacy']['backend']=='fixed_B0':
        primary=mod.euclidean_clustering(vox,mod.CLUSTER_TOLERANCE,mod.MIN_CLUSTER_POINTS)
    else:
        primary=mod.adaptive_core_expand_clustering(vox,mod.MIN_CLUSTER_POINTS,max_hops=2)
    final=mod.adaptive_recluster(vox,primary)
    vl=np.full(len(vox.points),-1,np.int32)
    for i,indices in enumerate(final): vl[np.asarray(indices,dtype=int)]=i
    labels=np.full(h*w,-1,np.int32); offsets=[0]; src=[]
    for k,trace in enumerate(traces):
        ids=p[np.asarray(trace,dtype=int)]; labels[ids]=vl[k]
        src.extend(ids.tolist()); offsets.append(len(src))
    return labels.reshape(h,w),{'voxel_points':len(vl),'voxel_pixel_offsets':offsets,'voxel_source_pixels':src},np.asarray(vox.points),vl
