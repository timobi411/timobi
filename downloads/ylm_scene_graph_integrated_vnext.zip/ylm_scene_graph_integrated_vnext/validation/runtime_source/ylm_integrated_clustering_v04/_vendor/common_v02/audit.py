from pathlib import Path
import numpy as np
from .io import read_json,read_npz,sha_file,sha_array

def relocate(path,base,relative_to):
    p=Path(path).expanduser()
    if not p.is_absolute():return (Path(relative_to)/p).resolve()
    if p.exists():return p
    if base and 'real_experiment' in p.parts:
        return Path(base).joinpath(*p.parts[p.parts.index('real_experiment')+1:])
    return p

def resolve_source(case,plan_dir,base=None):
    value=case.get('source_dir');p=relocate(value,base,plan_dir) if value else None
    if case.get('source_manifest'):
        mp=relocate(case['source_manifest'],base,plan_dir);m=read_json(mp)
        if p is None:p=relocate(m['source_directory'],base,mp.parent)
    return p

def source_audit(source,c,base=None,expected=None):
    if source is None:return {'status':'new_history_input','original_input_recheck':'no_previous_manifest','mode_check':'not_applicable'}
    essentials=['config.json','history.npz','pixel_statistics.npz','integrated_observation.npz','sample_surface_modes.npz',
                'structure_mask.npz','C/pixel_correspondence.npz','C_edges.npz','fragment_relations.json',
                'missingness.npz','surface_hypotheses.json','structure_metadata.json','run_manifest.json']
    hashes={p:sha_file(source/p) for p in essentials if (source/p).is_file()}
    if expected:
        for name,value in expected.items():
            if not (source/name).is_file() or sha_file(source/name)!=value:raise ValueError('Source SHA256 mismatch: '+name)
    originals=[]
    manifest=source/'run_manifest.json'
    if manifest.exists():
        rm=read_json(manifest)
        for item in rm.get('input_hashes',[]):
            p=relocate(item['path'],base,source);actual=sha_file(p) if p.is_file() else None
            originals.append({'recorded_path':item['path'],'resolved_path':str(p),'expected_sha256':item['sha256'],
                              'actual_sha256':actual,'status':'missing' if actual is None else 'match' if actual==item['sha256'] else 'mismatch'})
            if actual is not None and actual!=item['sha256']:raise ValueError('Original input SHA256 mismatch: '+str(p))
    return {'source_directory':str(source),'source_hashes':hashes,'expected_snapshot_hashes_checked':bool(expected),
            'original_inputs':originals,'original_input_recheck':'passed' if originals and all(x['status']=='match' for x in originals) else 'not_fully_verifiable',
            'mode_check':'pending','status':'snapshot_hashed'}

def validate_source_modes(a,modes,source_stats,c):
    f,h,w=a['valid'].shape
    if modes.shape!=(f,h,w) or modes.dtype.kind not in 'iu':raise ValueError('Mode history shape/dtype')
    if not np.array_equal(modes>=0,a['valid']):raise ValueError('Modes/valid mismatch')
    if not np.array_equal(source_stats['valid_count'],a['valid'].sum(axis=0)):raise ValueError('Mode counts differ from history')
    # Recompute splitting, including mode ID order, from each pixel's actual ranges.
    for y,x in np.argwhere(a['valid'].any(axis=0)):
        ids=np.flatnonzero(a['valid'][:,y,x]);ids=ids[np.argsort(a['range'][ids,y,x],kind='stable')]
        vals=a['range'][ids,y,x];gap=c['temporal']['mode_gap_m']+c['temporal']['mode_gap_per_m']*np.median(vals)
        expected=np.r_[0,np.cumsum(np.diff(vals)>gap)]
        if not np.array_equal(modes[ids,y,x],expected):raise ValueError(f'Surface mode mismatch at pixel {y},{x}')
        if source_stats['mode_count'][y,x]!=expected[-1]+1:raise ValueError('Mode count mismatch')
    if np.any(source_stats['mode_count'][~a['valid'].any(axis=0)]!=0):raise ValueError('Unobserved pixel has mode')
    return {'status':'passed','sample_mode_recomputed_from_ranges':True,'valid_count_checked':True}

def validate_provenance(a,integ):
    v=integ['valid'];y,x=np.where(v);s=integ['source_sample_index'][v];f=a['valid'].shape[0]
    if np.any((s<0)|(s>=f)) or not a['valid'][s,y,x].all():raise ValueError('Non-measured integrated point source')
    if not np.array_equal(integ['xyz'][v],a['xyz'][s,y,x]):raise ValueError('Point geometry not source sample')
    for k,hk in [('source_time_ns','bag_time_ns'),('source_header_time_ns','header_time_ns'),('source_frame_index','frame_index')]:
        if k in integ and not np.array_equal(integ[k][v],a[hk][s]):raise ValueError('Point source time/frame mismatch')
    if np.any(~np.isin(integ['source_type'][v],[1,2])):raise ValueError('Inferred point in measured output')
    return {'measured_points_checked':int(v.sum()),'inferred_point_count':0,'status':'passed'}

def saved_equivalence(source,integ,labels,edges,relations):
    if source is None:return {'status':'no_saved_baseline'}
    old=read_npz(source/'integrated_observation.npz');corr=read_npz(source/'C/pixel_correspondence.npz')
    from .edges import partition_comparison
    p=partition_comparison(corr['labels'],labels)
    oldedges=read_npz(source/'C_edges.npz')
    keys=edges['pixel_i'].astype(np.int64)*labels.size+edges['pixel_j'];oldkeys=oldedges['pixel_i'].astype(np.int64)*labels.size+oldedges['pixel_j']
    order=np.argsort(keys);index=order[np.searchsorted(keys[order],oldkeys)]
    edge_match=np.array_equal(edges['accepted'][index],oldedges['accepted'])
    geom=np.array_equal(integ['xyz'],old['xyz'],equal_nan=True)
    relold=read_json(source/'fragment_relations.json')['relations'];relnew=relations['relations']
    endpoint_match=len(relold)==len(relnew) and all(x['endpoint_pixels']==y['endpoint_pixels'] and x['gap_pixels']==y['gap_pixels'] for x,y in zip(relold,relnew))
    partition=p['merge_count']==0 and p['split_count']==0 and p['old_only_labeled_pixels']==0 and p['new_only_labeled_pixels']==0
    return {'status':'passed' if geom and partition and edge_match and endpoint_match else 'differences_recorded',
        'integrated_xyz_equal':geom,'partition_equal_by_pixel':partition,'edge_decisions_equal':bool(edge_match),
        'relation_endpoints_equal':endpoint_match,'old_relation_count':len(relold),'new_relation_count':len(relnew),
        'label_numbers_required_equal':False,'changes':p}
