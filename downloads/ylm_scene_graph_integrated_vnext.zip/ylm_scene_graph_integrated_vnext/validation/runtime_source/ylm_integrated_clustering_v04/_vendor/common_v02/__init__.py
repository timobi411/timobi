"""YLM common observation diagnostics. No object association is adopted."""
__version__ = '0.2.0'
