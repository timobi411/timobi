"""Row-block execution of the frozen rules, with one whole-window gate."""
from copy import deepcopy
import numpy as np
from ylm_integrated_clustering_v04._vendor.organized_v01.temporal import analyze_history, HOLD
from ylm_integrated_clustering_v04._vendor.organized_v01.util import summary
from .io import allocate, finish_store, npz_write, json_write

def global_metadata_reasons(a):
    reasons=[]
    for k in ('layout_id','frame_id','setting_id'):
        if len(np.unique(a[k]))!=1:reasons.append(k+' changed within window')
    for k in ('bag_time_ns','header_time_ns'):
        if np.any(a[k]<=0) or np.any(np.diff(a[k])<=0):reasons.append(k+' missing/duplicate/reversed')
    return reasons

def integrate(a,ref,c,out,rows):
    f,h,w=a['valid'].shape; block_c=deepcopy(c)
    block_c['scene']['global_dynamic_fraction']=1.0
    stats={}; integ={};legacy={};gate=None
    mode_dir=out/'surface_mode_samples';mode_dir.mkdir()
    modes=allocate(mode_dir,'sample_mode',(f,h,w),np.int32)
    for y in range(0,h,rows):
        stop=min(h,y+rows)
        b={k:(v[:,y:stop] if v.ndim>=3 and v.shape[:3]==(f,h,w) else v) for k,v in a.items()}
        s,i,l,m,_,g=analyze_history(b,ref,block_c);gate=g
        for dst,src in ((stats,s),(integ,i),(legacy,l)):
            for k,v in src.items():
                if k not in dst:dst[k]=np.empty((h,w)+v.shape[2:],v.dtype)
                dst[k][y:stop]=v
        modes[:,y:stop]=m
    for d in (stats,integ):d['pixel_row'],d['pixel_column']=np.indices((h,w))
    dynamic=(stats['mode_count']>1)|stats['time_change_candidate']|stats['ray_change_candidate']
    denom=int((stats['valid_count']>=2).sum())
    fraction=float((dynamic & (stats['valid_count']>=2)).sum()/denom) if denom else 0.
    reasons=list(gate['hold_reasons'])+global_metadata_reasons(a)
    if fraction>c['scene']['global_dynamic_fraction']:reasons.append('distance/ray history contradicts static assumption')
    reasons=list(dict.fromkeys(reasons));allowed=not reasons
    if not allowed:
        integ['hold_reason']|=HOLD['GLOBAL_GATE'];integ['representative_accepted'][:]=False
        v=a['valid'][ref];integ.update(xyz=np.where(v[...,None],a['xyz'][ref],np.nan),
            range=np.where(v,a['range'][ref],np.nan),valid=v.copy(),source_type=np.where(v,1,0).astype(np.uint8),
            source_sample_index=np.where(v,ref,-1).astype(np.int32),source_frame_index=np.where(v,a['frame_index'][ref],-1),
            source_time_ns=np.where(v,a['bag_time_ns'][ref],-1),source_header_time_ns=np.where(v,a['header_time_ns'][ref],-1),
            source_time_valid=v.copy(),representative_sample_index=np.full((h,w),-1,np.int32))
    gate.update(temporal_adoption_allowed=allowed,hold_reasons=reasons,dynamic_fraction=fraction,
                scene_static_assumption=c['scene'],global_dynamic_denominator=denom,
                all_window_gates_rechecked=True,row_block_size=rows)
    stats['all_history_range_mad_m']=stats['range_mad'].copy()
    for bit,name in [(1,'nonfinite'),(2,'zero_xyz'),(4,'analysis_range_filter'),(8,'driver_sentinel'),(16,'status'),(32,'source_invalid')]:
        stats['invalid_reason_'+name+'_count']=np.count_nonzero(a['invalid_reason']&bit,axis=0).astype(np.int32)
    integ['adopted_mode_range_mad_m']=np.where(integ['representative_accepted'],stats['range_mad'],np.nan)
    integ['adopted_mode_id']=np.where(integ['representative_accepted'],0,-1).astype(np.int32)
    integ['measurement_confident']=(stats['valid_count']>=c['clustering']['min_confidence_support']) & (stats['range_mad']<=c['temporal']['max_mad_m']) & (stats['mode_count']==1) & ~stats['time_change_candidate'] & ~stats['ray_change_candidate']
    integ['recovered_current_missing']=~a['valid'][ref] & integ['valid']
    # Intensity distributions only use distance-valid observations; zero stays a value.
    if 'intensity' in a:
        import warnings
        iq=np.full((3,h,w),np.nan);count=np.zeros((h,w),np.int32)
        for y in range(0,h,rows):
            sl=np.s_[:,y:y+rows];ok=a['valid'][sl]&a['intensity_valid'][sl]
            with warnings.catch_warnings():
                warnings.simplefilter('ignore',RuntimeWarning)
                iq[:,y:y+rows]=np.nanquantile(np.where(ok,a['intensity'][sl],np.nan),[.05,.5,.95],axis=0)
            count[y:y+rows]=ok.sum(axis=0)
        stats.update(distance_valid_intensity_q05=iq[0],distance_valid_intensity_median=iq[1],
                     distance_valid_intensity_q95=iq[2],distance_valid_intensity_count=count)
    finish_store(mode_dir,{'sample_mode':modes},frame_indices=a['frame_index'],reference_sample_index=ref)
    npz_write(out/'pixel_statistics.npz',**stats);npz_write(out/'integrated_observation.npz',**integ)
    npz_write(out/'legacy_temporal_observation.npz',**legacy)
    json_write(out/'temporal_gates.json',gate)
    mode_summary(a,modes,stats,ref,c,out)
    json_write(out/'intensity_diagnostics.json',intensity_diagnostics(a,stats,c))
    return stats,integ,legacy,modes,gate

def mode_summary(a,modes,stats,ref,c,out):
    f,h,w=a['valid'].shape;fields={k:[] for k in ('pixel_id','mode_id','support_count','support_fraction_received',
        'support_fraction_valid','range_median_m','range_mad_m','first_time_ns','last_time_ns',
        'latest_age_at_reference_s','nearest_age_s','intensity_count','intensity_q05','intensity_median','intensity_q95')}
    offsets=[0];sample=[];times=a['bag_time_ns'];ref_time=int(times[ref])
    for y,x in np.argwhere(stats['valid_count']>0):
        for mode in range(int(stats['mode_count'][y,x])):
            ids=np.flatnonzero(modes[:,y,x]==mode);r=a['range'][ids,y,x];med=np.median(r)
            iv=np.array([],float)
            if 'intensity' in a:
                ok=a['intensity_valid'][ids,y,x]&a['valid'][ids,y,x]
                iv=a['intensity'][ids[ok],y,x]
            iq=np.quantile(iv,[.05,.5,.95]) if len(iv) else np.full(3,np.nan)
            vals=[int(y*w+x),mode,len(ids),len(ids)/f,len(ids)/stats['valid_count'][y,x],med,np.median(abs(r-med)),
                  int(times[ids].min()),int(times[ids].max()),(ref_time-int(times[ids].max()))/1e9,
                  float(np.min(np.abs(times[ids]-ref_time))/1e9),len(iv),*iq]
            for k,v in zip(fields,vals):fields[k].append(v)
            sample.extend(ids.tolist());offsets.append(len(sample))
    integer={'pixel_id','mode_id','support_count','first_time_ns','last_time_ns','intensity_count'}
    arrays={k:np.asarray(v,np.int64 if k in integer else np.float64) for k,v in fields.items()}
    ss=np.asarray(sample,np.int32)
    arrays.update(support_offsets=np.asarray(offsets,np.int64),support_sample_index=ss,
                  support_frame_index=a['frame_index'][ss],support_time_ns=times[ss])
    npz_write(out/'surface_modes.npz',**arrays)
    json_write(out/'surface_modes.json',{'mode_count':len(fields['pixel_id']),'storage':'surface_modes.npz',
        'samples':'surface_mode_samples/sample_mode.npy','support_denominators':['received frames','valid measurements at pixel'],
        'latest_age_note':'reference minus latest time; negative means a future sample in the offline symmetric window',
        'adoption':'multi-mode pixels held; no averaged geometry','intensity_definition':'distance-valid finite intensity, including zero'})

def intensity_diagnostics(a,stats,c):
    f,h,w=a['valid'].shape;result={'raw_available':'intensity_raw' in a,
        'raw_dtype':a['intensity_raw'].dtype.str if 'intensity_raw' in a else None,
        'physical_unit':None,'saturation':None,'zero_excluded':False,'shape_generated_from_intensity':0,
        'intensity_affects_clustering':False,'by_range':[],'by_observation_count':[]}
    result['no_return_count_definition']='distance-invalid observations in received frames; includes analysis range filters. See pixel_statistics invalid_reason_*_count. Physical cause is unknown.'
    if 'intensity' not in a:return {**result,'status':'intensity_absent'}
    for lo,hi in zip(c['evaluation']['range_bins_m'][:-1],c['evaluation']['range_bins_m'][1:]):
        ok=a['valid'] & a['intensity_valid'] & (a['range']>=lo)&(a['range']<hi)
        pix=(stats['range_median']>=lo)&(stats['range_median']<hi)&(stats['valid_count']>0)
        result['by_range'].append({'range_m':[lo,hi],'intensity':summary(a['intensity'][ok]),
            'distance_MAD':summary(stats['all_history_range_mad_m'][pix]),'pixel_count':int(pix.sum()),
            'no_return_count':int((f-stats['valid_count'][pix]).sum()),'received_sample_pixel_denominator':int(f*pix.sum()),
            'pixel_range_assignment':'all-history median; never-observed pixels unassigned'})
    for n in np.unique(stats['valid_count']):
        pix=stats['valid_count']==n;ok=a['valid'] & a['intensity_valid'] & pix[None]
        result['by_observation_count'].append({'valid_count':int(n),'pixel_count':int(pix.sum()),
            'intensity':summary(a['intensity'][ok]),'distance_MAD':summary(stats['all_history_range_mad_m'][pix]),
            'no_return_count':int((f-n)*pix.sum()),'received_sample_pixel_denominator':int(f*pix.sum())})
    return result
