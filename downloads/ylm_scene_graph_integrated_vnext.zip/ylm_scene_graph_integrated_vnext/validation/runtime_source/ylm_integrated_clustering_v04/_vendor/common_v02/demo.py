from pathlib import Path
import numpy as np
from ylm_integrated_clustering_v04._vendor.organized_v01.demo import fixture,config
from ylm_integrated_clustering_v04._vendor.organized_v01.input import validity
from .io import npz_write,json_write

def create(folder):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False)
    original,gt=fixture();c=config();f=31;ref=15
    # Extend acquisition with repeated real synthetic samples; retain the central 11 window.
    take=np.r_[np.zeros(10,int),np.arange(11),np.full(10,10,int)]
    a={k:(v[take].copy() if v.ndim and v.shape[0]==11 else v.copy()) for k,v in original.items()}
    a['frame_index']=np.arange(f,dtype=np.int64)
    times=np.arange(f,dtype=np.int64)*100000000+1791430000000000000
    a['bag_time_ns']=times;a['header_time_ns']=times-1000000
    a['range'],a['valid'],a['invalid_reason']=validity(a['xyz'],c,a['valid'])
    # Synthetic raw amplitude covers zero, 8190, and the uint16 maximum without deleting them.
    raw=np.nan_to_num(a['intensity'],nan=0).astype(np.uint16)
    raw[:,1,1]=0;raw[:,1,2]=8190;raw[:,1,3]=65535
    a['intensity_raw']=raw;a['intensity']=raw.astype(float);a['intensity_present']=np.ones(raw.shape,bool)
    a['intensity_valid']=np.ones(raw.shape,bool)
    a['pixel_row'],a['pixel_column']=np.indices(a['valid'].shape[1:]);a['reference_sample_index']=np.asarray(ref)
    npz_write(folder/'history.npz',**a);npz_write(folder/'instance_labels.npz',instance_id=gt)
    c['evaluation']['instance_labels_npz']=None
    json_write(folder/'config.json',c)
    json_write(folder/'cases.json',{'version':'0.2.0','cases':[{'name':'synthetic_panel_and_fragments',
        'history':'history.npz','history_is_complete_acquisition':True,'config':'config.json',
        'reference_frame_index':ref,'dataset_role':'synthetic'}],
        'windows':['fixed11','all'],'boundary_values':[True,False],'rows_per_chunk':4,'max_working_mb':2048,'disk_budget_gib':2})
    print('Demo input:',folder/'cases.json')
