from pathlib import Path
import zipfile
import numpy as np
from .io import read_json,read_npz,open_store,sha_file,json_write
from .audit import validate_provenance,validate_source_modes,relocate
from .io import validate_history

def verify(root):
    root=Path(root).resolve();errors=[];npz_count=0;json_count=0;history_count=0
    for p in root.rglob('*.json'):
        try:read_json(p);json_count+=1
        except Exception as e:errors.append({'file':str(p.relative_to(root)),'error':str(e)})
    for p in root.rglob('*.npz'):
        try:
            with zipfile.ZipFile(p) as z:
                bad=z.testzip()
                if bad:raise ValueError('CRC failed '+bad)
            with np.load(p,allow_pickle=False) as z:
                for k in z.files:
                    if z[k].dtype.hasobject:raise ValueError('Object dtype')
            npz_count+=1
        except Exception as e:errors.append({'file':str(p.relative_to(root)),'error':str(e)})
    for mp in root.rglob('manifest.json'):
        try:
            meta=read_json(mp)
            for k,v in meta.get('arrays',{}).items():
                p=mp.parent/v['file']
                if sha_file(p)!=v['sha256']:raise ValueError('Store hash mismatch '+k)
                a=np.load(p,mmap_mode='r',allow_pickle=False)
                if list(a.shape)!=v['shape'] or a.dtype.str!=v['dtype']:raise ValueError('Store schema mismatch '+k)
        except Exception as e:errors.append({'file':str(mp.relative_to(root)),'error':str(e)})
    manifest=read_json(root/'run_manifest.json')
    for k,v in manifest['code_sha256'].items():
        if sha_file(root/'code_snapshot'/k)!=v:errors.append({'file':k,'error':'Code snapshot mismatch'})
    for wp in root.glob('cases/*/*/history/manifest.json'):
        wd=wp.parent.parent
        try:
            a,hm=open_store(wp.parent);ref=hm['reference_sample_index'];integ=read_npz(wd/'integrated_observation.npz')
            validate_provenance(a,integ);history_count+=1
            conds=list(wd.glob('boundary_*/config.json'))
            if not conds:raise ValueError('No completed condition')
            c=read_json(conds[0]);validate_history(a,c)
            modes,_=open_store(wd/'surface_mode_samples');stats=read_npz(wd/'pixel_statistics.npz')
            validate_source_modes(a,modes['sample_mode'],stats,c)
            m,_=open_store(wd/'measured')
            if m['target_valid'][ref].any() or np.any(m['classification'][ref]!=0):raise ValueError('B reference self comparison')
            if np.any((m['classification']!=0)&~m['target_valid']):raise ValueError('Invalid B target included')
            for cp in conds:
                cd=cp.parent;corr=read_npz(cd/'pixel_correspondence.npz');v=corr['valid'];mask=read_npz(wd/'structure_mask.npz')['structure_mask']
                if np.any(v&mask) or np.any((corr['labels']>=0)!=v):raise ValueError('Mask/cluster coverage mismatch')
                if not np.array_equal(corr['xyz'][v],integ['xyz'][v]):raise ValueError('Cluster contains non-measured geometry')
                rel=read_json(cd/'fragment_relations.json')
                if rel['automatic_merges']!=0:raise ValueError('Automatic relation adoption')
                for record in rel['relations']:
                    if record['automatic_adoption'] or record['object_identity']!='UNKNOWN':raise ValueError('Identity/adoption violation')
                    ends=np.asarray(record['endpoint_pixels']);actual=sorted(corr['labels'][ends[:,0],ends[:,1]].tolist())
                    if actual!=record['original_fragment_ids']:raise ValueError('Relation/label mismatch')
        except Exception as e:errors.append({'file':str(wd.relative_to(root)),'error':str(e)})
    for p in root.glob('cases/*/input_audit.json'):
        audit=read_json(p);source=Path(audit['source_directory']) if audit.get('source_directory') else None
        if source and source.exists():
            for k,v in audit.get('source_hashes',{}).items():
                if sha_file(source/k)!=v:errors.append({'file':str(source/k),'error':'Original source hash changed'})
        for item in audit.get('original_inputs',[]):
            original=Path(item['resolved_path'])
            if original.exists() and sha_file(original)!=item['expected_sha256']:errors.append({'file':str(original),'error':'Original input hash mismatch'})
    for p in root.glob('cases/*/input_manifest.json'):
        for file,expected in read_json(p).get('raw_input_hashes',{}).items():
            if Path(file).is_file() and sha_file(file)!=expected:errors.append({'file':file,'error':'Raw input changed'})
    result={'status':'passed' if not errors else 'failed','errors':errors,'npz_archives_checked':npz_count,
            'strict_json_files_checked':json_count,'history_provenance_checks':history_count,
            'verification_scope':'generated output integrity, mode and provenance; absent original inputs remain unverified'}
    json_write(root/'verification.json',result);return result
