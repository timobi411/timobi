from pathlib import Path
from collections import Counter
import numpy as np
from ylm_integrated_clustering_v04._vendor.occlusion_v01.config import resolve
from ylm_integrated_clustering_v04._vendor.occlusion_v01.geometry import ray_geometry,RAY_HOLD
from ylm_integrated_clustering_v04._vendor.occlusion_v01.measured import diagnose_measured
from ylm_integrated_clustering_v04._vendor.occlusion_v01.hypotheses import stage_a_records,diagnose_hypotheses
from ylm_integrated_clustering_v04._vendor.occlusion_v01.common import counts_rates,CLASS,compare_distance,flags
from ylm_integrated_clustering_v04._vendor.organized_v01.relations import fragment_relations
from .io import allocate,finish_store,npz_write,json_write,sha_array
from .temporal import global_metadata_reasons

def measured_diagnostic(a,ref,stats,modes,source,cfg,out,rows):
    f,h,w=a['valid'].shape;folder=out/'measured';folder.mkdir()
    arrays={};rays_all={};global_info={}
    for y in range(0,h,rows):
        stop=min(y+rows,h)
        hist={k:(v[:,y:stop] if v.ndim>=3 and v.shape[:3]==(f,h,w) else v) for k,v in a.items()}
        data={'history':hist,'reference':ref,'origin':np.asarray(source['acquisition']['sensor_origin_xyz']),
              'source_config':source,'statistics':{k:v[y:stop] for k,v in stats.items()},
              'modes':{'sample_mode':modes[:,y:stop]},'corr':{'labels':np.full((stop-y,w),-1,np.int32)}}
        ray=ray_geometry(data,cfg)
        extra=global_metadata_reasons(a)
        if extra:
            ray['ray_hold_reason']|=RAY_HOLD['GLOBAL_ASSUMPTION'];ray['ray_valid'][:]=False
            ray['global_gate_passed']=False;ray['global_hold_reasons']+=extra
        for k,v in ray.items():
            if isinstance(v,np.ndarray):
                if k not in rays_all:rays_all[k]=np.empty((h,w)+v.shape[2:],v.dtype)
                rays_all[k][y:stop]=v
            else:global_info[k]=v
        measured,_=diagnose_measured(data,cfg,ray)
        for k in ('classification','target_valid','projection_valid','comparison_valid','range_difference_m','target_range_m','target_mode_id','projection_hold_reason'):
            v=measured[k]
            if k not in arrays:arrays[k]=allocate(folder,k,(f,h,w),np.int32 if k=='target_mode_id' else v.dtype)
            arrays[k][:,y:stop]=v
    arrays['frame_index']=allocate(folder,'frame_index',(f,),np.int64);arrays['frame_index'][:]=a['frame_index']
    arrays['bag_time_ns']=allocate(folder,'bag_time_ns',(f,),np.int64);arrays['bag_time_ns'][:]=a['bag_time_ns']
    arrays['header_time_ns']=allocate(folder,'header_time_ns',(f,),np.int64);arrays['header_time_ns'][:]=a['header_time_ns']
    finish_store(folder,arrays,reference_sample_index=ref,reference_frame_index=int(a['frame_index'][ref]),
                 self_comparisons_excluded=True,target_unit='sample x pixel',class_codes=CLASS)
    rays_all.update(global_info);npz_write(out/'ray_mapping.npz',**{k:v for k,v in rays_all.items() if isinstance(v,np.ndarray)})
    summary=counts_rates(arrays['classification'],arrays['target_valid'])
    summary.update(reference_sample_index=ref,reference_frame_index=int(a['frame_index'][ref]),
        target_observed_pixels=int(np.any(arrays['target_valid'],axis=0).sum()),
        unique_pixel_counts={k:int(np.any(arrays['classification']==v,axis=0).sum()) for k,v in CLASS.items() if v},
        foreground_candidate_unique_pixels=int(np.any(arrays['classification']==CLASS['foreground_occlusion_candidate'],axis=0).sum()),
        reference_self_comparisons=int(arrays['target_valid'][ref].sum()),candidate_count=None,
        unit='sample x pixel',unique_pixel_denominator=h*w,epsilon_m=cfg['distance_tolerance']['resolved_epsilon_m'],
        epsilon_verified=cfg['distance_tolerance']['verified'],classification_sha256=sha_array(arrays['classification']),**flags())
    json_write(out/'measured_summary.json',summary)
    return arrays,rays_all,summary

def relations_diagnostic(a,ref,stats,integ,modes,corr,source,diag,measured,rays,out):
    cfg=resolve(diag,source)
    rel=fragment_relations(corr['xyz'],corr['labels'],a['range'][ref],a['valid'][ref],stats,source)
    data={'history':a,'reference':ref,'statistics':stats,'integrated':integ,'modes':{'sample_mode':modes},
        'corr':corr,'source_config':source,'origin':np.asarray(source['acquisition']['sensor_origin_xyz']),
        'source_relations':rel,'label_sha256':sha_array(corr['labels']),'relations_regenerated':True}
    stage_a,asummary=stage_a_records(data)
    inferred,records,planes,cs=diagnose_hypotheses(data,cfg,rays,measured,stage_a)
    npz_write(out/'hypothesized_projection.npz',**inferred)
    json_write(out/'local_planes.json',{'planes':planes,'kind':'hypothesized'},compact=True)
    ph=plane_history(a,modes,inferred,cfg,out)
    for record in records:
        i=record['candidate_id'];record['plane_history']=ph['candidates'][i]
        evidence=record['stage_A']['evidence_class']
        # Evidence rejection concerns this relation hypothesis, never object existence.
        record['state']=('REJECTED_BY_EVIDENCE' if evidence=='depth_contradiction_candidate' else
                         'RELATION_CANDIDATE' if evidence=='occlusion_candidate' else 'HOLD')
        record['object_identity']='UNKNOWN';record['automatic_adoption']=False
    result={'relations':records,'candidate_count':len(records),'label_sha256':data['label_sha256'],
        'search':{k:rel[k] for k in ('candidate_limit','overflow_endpoint_pairs','complete_within_configured_search','search_scope')},
        'state_counts':dict(Counter(r['state'] for r in records)),
        'automatic_merges':0,'object_identity':'UNKNOWN','A':asummary,'C':cs,
        'plane_history':{k:v for k,v in ph.items() if k!='candidates'}}
    json_write(out/'fragment_relations.json',result,compact=True)
    json_write(out/'endpoint_linear_baseline.json',rel,compact=True)
    return result,inferred,planes

def plane_history(a,modes,p,cfg,out):
    """All valid samples, including reference, versus each independent plane hypothesis."""
    folder=out/'plane_history';folder.mkdir();f=a['valid'].shape[0];g=len(p['pixel_row'])
    shape=(2,f,g);arrays={k:allocate(folder,k,shape,dt) for k,dt in
        [('range_difference_m',np.float64),('comparison_valid',bool),('classification',np.uint8)]}
    close_counts=np.zeros((2,g),np.int32);support={k:[] for k in ('side','gap_index','sample_index','mode_id','frame_index','time_ns')}
    eps=cfg['distance_tolerance']['resolved_epsilon_m']
    for lo in range(0,g,256):
        hi=min(g,lo+256);yy=p['pixel_row'][lo:hi];xx=p['pixel_column'][lo:hi]
        actual=a['range'][:,yy,xx];valid=a['valid'][:,yy,xx]
        for side in range(2):
            target=np.broadcast_to(p['target_range_m'][side+1,lo:hi],actual.shape)
            pv=np.broadcast_to(p['projection_valid'][side+1,lo:hi],actual.shape)
            cls,delta,ok=compare_distance(target,actual,valid,pv,eps,target_valid=np.ones_like(valid))
            arrays['range_difference_m'][side,:,lo:hi]=delta;arrays['comparison_valid'][side,:,lo:hi]=ok
            arrays['classification'][side,:,lo:hi]=cls;near=cls==CLASS['observed_consistent']
            close_counts[side,lo:hi]=near.sum(axis=0)
            ss,gg=np.where(near)
            vals={'side':np.full(len(ss),side),'gap_index':gg+lo,'sample_index':ss,
                'mode_id':modes[ss,yy[gg],xx[gg]],'frame_index':a['frame_index'][ss],'time_ns':a['bag_time_ns'][ss]}
            for k,v in vals.items():support[k].extend(v.tolist())
    finish_store(folder,arrays,sign='observed range minus plane range',reference_included=True,
        epsilon_m=eps,epsilon_verified=cfg['distance_tolerance']['verified'],
        axes=['left/right local plane','sample','candidate gap occurrence'],class_codes=CLASS)
    npz_write(folder/'near_support.npz',**{k:np.asarray(v,np.int64) for k,v in support.items()},
              close_count=close_counts,pixel_row=p['pixel_row'],pixel_column=p['pixel_column'],
              candidate_offsets=p['candidate_offsets'])
    records=[]
    for i,(lo,hi) in enumerate(zip(p['candidate_offsets'][:-1],p['candidate_offsets'][1:])):
        methods=[]
        for side in range(2):
            cls=arrays['classification'][side,:,lo:hi]
            counts=counts_rates(cls,np.ones(cls.shape,bool));near=cls==CLASS['observed_consistent']
            counts.update(near_sample_pixel_count=int(near.sum()),near_unique_pixels=int(near.any(axis=0).sum()),
                projected_gap_pixels=int(p['projection_valid'][side+1,lo:hi].sum()),
                all_valid_history_in_front=bool(np.any(arrays['comparison_valid'][side,:,lo:hi])) and
                    bool(np.all(cls[arrays['comparison_valid'][side,:,lo:hi]]==CLASS['foreground_occlusion_candidate'])),
                support_records='plane_history/near_support.npz',plane_existence_confirmed=False)
            methods.append(counts)
        records.append({'candidate_id':i,'left':methods[0],'right':methods[1]})
    return {'candidates':records,'all_gap_occurrences':g,'all_received_samples_in_window':f,
        'near_sample_pixel_occurrences':int(close_counts.sum()),
        'near_unique_pixels':len(set(zip(p['pixel_row'][np.any(close_counts>0,axis=0)].tolist(),p['pixel_column'][np.any(close_counts>0,axis=0)].tolist()))),
        'unit_note':'sample x gap occurrence per side; repeated gap pixels may belong to multiple candidates',
        'reference_included':True,'no_plane_geometry_written_to_measured':True}
