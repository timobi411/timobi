from pathlib import Path
from copy import deepcopy
import os,sys,shutil,time,resource,traceback
import numpy as np
from ylm_integrated_clustering_v04._vendor.organized_v01.config import load_config,validate as validate_config
from ylm_integrated_clustering_v04._vendor.organized_v01.clustering import export_clusters
from ylm_integrated_clustering_v04._vendor.organized_v01.temporal import classify_missingness,HOLD
from ylm_integrated_clustering_v04._vendor.occlusion_v01.config import read as diagnostic_config,resolve
from .io import *
from .audit import *
from .temporal import integrate
from .structure import evaluate_structure
from .edges import audited_cluster,compare_edges,partition_comparison,HOLD_BITS
from .relations import measured_diagnostic,relations_diagnostic

POINT_STATE={'CURRENT_MEASURED':1,'HISTORY_MEASURED':2,'HOLD':3,'UNKNOWN':4,'STRUCTURE_MASKED':5}

def enforce_budget(mb):
    if mb<256:raise ValueError('At least 256 MiB working budget required')
    if Path('/proc/self/statm').exists():
        baseline=int(Path('/proc/self/statm').read_text().split()[0])*os.sysconf('SC_PAGE_SIZE')
        soft,hard=resource.getrlimit(resource.RLIMIT_AS);limit=baseline+int(mb*1024**2)
        if hard!=resource.RLIM_INFINITY:limit=min(limit,hard)
        if soft!=resource.RLIM_INFINITY:limit=min(limit,soft)
        resource.setrlimit(resource.RLIMIT_AS,(limit,hard))
        return {'enforced':True,'additional_address_space_mb':mb,'address_space_bytes':limit}
    return {'enforced':False,'allocation_checks_only':True}

def prepare_config(source,case,plan_dir,base):
    path=relocate(case['config'],base,plan_dir) if case.get('config') else source/'config.json' if source else None
    if path is None:raise ValueError('config or source_dir is required')
    c=load_config(path);old=deepcopy(c)
    # v0.2 changes intensity interpretation only; never point validity or connectivity.
    c['intensity'].update(invalid_values=[],saturation_value=None,
        definition='Raw signal; unit/saturation/invalid value unverified. Zero is retained. No intensity-only removal or connection.')
    c['evaluation']['dataset_role']=case.get('dataset_role','development')
    c['projection'].update(npz=None,verified=False,free_space_model_verified=False)
    validate_config(c)
    return c,old,path

def process_case(case,plan,plan_dir,out,base):
    start=time.perf_counter();name=case['name'];dest=out/'cases'/name;dest.mkdir(parents=True)
    source=resolve_source(case,plan_dir,base)
    c,old_config,config_path=prepare_config(source,case,plan_dir,base)
    expected=case.get('expected_source_hashes')
    if case.get('source_manifest'):
        expected=expected or read_json(relocate(case['source_manifest'],base,plan_dir)).get('input_hashes')
    audit=source_audit(source,old_config,base,expected);json_write(dest/'input_audit.json',audit)
    raw_source=None;raw_hashes={};ref_frame=case.get('reference_frame_index');fixed_frames=case.get('fixed_frame_indices')
    source_a=None;canonical=None
    if source:
        print(name+': checking saved history and surface modes',flush=True)
        source_a=unpack_history(source/'history.npz',dest/'source_history',int(plan['disk_budget_gib']*1024**3))
        validate_history(source_a,old_config,plan['rows_per_chunk'])
        sm=read_npz(source/'sample_surface_modes.npz');st=read_npz(source/'pixel_statistics.npz')
        if not np.array_equal(sm['frame_index'],source_a['frame_index']):raise ValueError('Mode/history frame index mismatch')
        audit['mode_check']=validate_source_modes(source_a,sm['sample_mode'],st,old_config)
        canonical=read_npz(source/'integrated_observation.npz');audit['point_provenance']=validate_provenance(source_a,canonical)
        ref_frame=int(source_a['frame_index'][int(source_a['reference_sample_index'])]) if ref_frame is None else ref_frame
        fixed_frames=source_a['frame_index'].tolist() if fixed_frames is None else fixed_frames
        json_write(dest/'input_audit.json',audit)
    bag=case.get('bag');history=case.get('history');complete=False;received=None
    if not bag and source and (source/'run_manifest.json').exists():
        m=read_json(source/'run_manifest.json')
        if m.get('input_kind')=='bag':bag=str(relocate(m['input'],base,source))
    if bag and relocate(bag,base,plan_dir).exists():
        raw_source=relocate(bag,base,plan_dir);print(name+': extracting all received raw PointFields',flush=True)
        raw_hashes=hash_input(raw_source)
        a,hm=extract_bag(raw_source,c,dest/'raw_history',int(plan['disk_budget_gib']*1024**3))
        complete=True;received=hm['received_frame_count']
    elif history:
        raw_source=relocate(history,base,plan_dir)
        raw_hashes=hash_input(raw_source)
        a=unpack_history(raw_source,dest/'raw_history',int(plan['disk_budget_gib']*1024**3))
        complete=bool(case.get('history_is_complete_acquisition',False));received=len(a['frame_index']) if complete else None
    elif source_a is not None:a=source_a
    else:raise ValueError('No usable bag or history for '+name)
    schema=validate_history(a,c,plan['rows_per_chunk']);f,h,w=a['valid'].shape
    if ref_frame is None:ref_frame=int(a['frame_index'][f//2])
    if np.count_nonzero(a['frame_index']==ref_frame)!=1:raise ValueError('Reference frame absent')
    ref=int(np.flatnonzero(a['frame_index']==ref_frame)[0])
    if fixed_frames is None:
        if f<11 or ref<5 or ref+5>=f:raise ValueError('Eleven-frame window around reference unavailable')
        fixed_frames=a['frame_index'][ref-5:ref+6].tolist()
    if len(fixed_frames)!=11 or len(set(fixed_frames))!=11:raise ValueError('Baseline must contain 11 distinct received frames')
    index={int(v):i for i,v in enumerate(a['frame_index'])}
    if not all(int(v) in index for v in fixed_frames):raise ValueError('Baseline frames absent from raw history')
    ids=[index[int(v)] for v in fixed_frames]
    if ids!=sorted(ids) or ref not in ids:raise ValueError('Fixed window order/reference invalid')
    if source_a is not None:
        # Equal frame/time/XYZ/valid verifies source selected history against full raw acquisition.
        aligns=[]
        for j,fi in enumerate(source_a['frame_index']):
            if int(fi) not in index:continue
            k=index[int(fi)]
            ok=all(np.array_equal(a[key][k],source_a[key][j],equal_nan=True) for key in ('xyz','valid','bag_time_ns','header_time_ns'))
            aligns.append(ok)
        if aligns and not all(aligns):raise ValueError('Full acquisition and saved window disagree')
        audit['full_history_saved_window_alignment']=bool(aligns) and all(aligns) if complete else None
    json_write(dest/'input_audit.json',audit)
    diag=diagnostic_config();diag['evaluation']['dataset_role']=c['evaluation']['dataset_role']
    if plan.get('diagnostic_config'):
        diag=diagnostic_config(relocate(plan['diagnostic_config'],base,plan_dir))
    metadata={'source_directory':source,'raw_source':raw_source,'reference_frame_index':ref_frame,
        'reference_bag_time_ns':int(a['bag_time_ns'][ref]),'received_frame_count':received,
        'received_count_status':'verified_from_complete_acquisition' if complete else 'not_available_from_selected_history',
        'source_schema':schema,'source_audit':'input_audit.json','fixed_frame_indices':fixed_frames,'raw_input_hashes':raw_hashes,
        'config_source':config_path,'source_hashes':audit.get('source_hashes',{}),'complete_acquisition':complete}
    json_write(dest/'input_manifest.json',metadata);json_write(dest/'original_config.json',old_config)
    summaries={};comparisons=[];window_results={}
    for window in plan['windows']:
        if window=='all' and not complete:
            summaries[window]={'status':'not_run','reason':'Complete received history/bag is unavailable; selected 11 frames are not relabeled as all frames'};continue
        idx=ids if window=='fixed11' else list(range(f));wd=dest/window;wd.mkdir()
        aw,rw=select_history(a,idx,wd/'history',ref_frame)
        hm=read_json(wd/'history/manifest.json')
        hm.update(intensity_field_name=c['intensity']['field'],
            intensity_raw_dtype=aw['intensity_raw'].dtype.str if 'intensity_raw' in aw else None,
            intensity_physical_unit=None,intensity_saturation_value=None,received_frame_count=received,
            acquisition_setting_id=c['acquisition']['setting_id'],frame_layout_metadata='../../raw_history/frame_metadata.json' if complete and bag else None)
        json_write(wd/'history/manifest.json',hm)
        validate_history(aw,c,plan['rows_per_chunk'])
        # Bound workspaces by row blocks. Full history stays memory-mapped on disk.
        estimate=len(idx)*plan['rows_per_chunk']*w*400+h*w*1600+128*1024**2
        if estimate>plan['max_working_mb']*1024**2:raise MemoryError('Chunk estimate exceeds working budget; lower rows_per_chunk')
        print(f'{name}/{window}: {len(idx)} frames; temporal modes and intensity',flush=True)
        stats,integ,legacy,modes,gates=integrate(aw,rw,c,wd,plan['rows_per_chunk'])
        provenance=validate_provenance(aw,integ)
        mp=relocate(case['structure_metadata'],base,plan_dir) if case.get('structure_metadata') else None
        structure,sinfo=evaluate_structure(source,integ,canonical,c,mp)
        npz_write(wd/'structure_mask.npz',**structure);json_write(wd/'structure_metadata.json',sinfo)
        resolved=resolve(diag,c)
        measured,rays,bsummary=measured_diagnostic(aw,rw,stats,modes,c,resolved,wd,plan['rows_per_chunk'])
        runs={};small={}
        for boundary in plan['boundary_values']:
            bc=deepcopy(c);bc['clustering']['hold_boundary_points']=boundary
            label='boundary_true' if boundary else 'boundary_false';cd=wd/label;cd.mkdir()
            print(name+'/'+window+'/'+label+': edges, components and fragment evidence',flush=True)
            r=run_condition(aw,rw,stats,integ,modes,structure,bc,diag,measured,rays,cd)
            if window=='fixed11' and boundary==old_config['clustering']['hold_boundary_points'] and source:
                r['summary']['saved_baseline_reproduction']=saved_equivalence(source,integ,r['labels'],r['edges'],r['relations'])
                json_write(cd/'evaluation.json',r['summary'])
            runs[label]=r
            small[label]=r['summary']
            # Large per-candidate JSON is already written; keep only comparison arrays.
            r.pop('relations',None)
        if len(runs)==2:
            x=runs['boundary_true'];y=runs['boundary_false'];comp=wd/'boundary_comparison';comp.mkdir()
            edge=compare_edges(x['edges'],y['edges'],comp,'C');current=compare_edges(x['current_edges'],y['current_edges'],comp,'current')
            p=partition_comparison(x['labels'],y['labels']);json_write(comp/'cluster_overlap.json',p)
            compare={'kind':'boundary_only','same_history':True,'same_integrated_xyz':True,'same_structure_mask':True,
                'B_content_identical':x['summary']['B_classification_sha256']==y['summary']['B_classification_sha256'],
                'C_edges':edge,'current_edges':current,'clusters':p,'object_identity':'UNKNOWN','false_merge_evaluation':None}
            json_write(comp/'comparison.json',compare);comparisons.append({'window':window,**compare})
        summaries[window]={'status':'completed_diagnostic','selected_count':len(idx),'received_count':received,
            'reference_frame_index':ref_frame,'reference_sample_index':rw,
            'time_span_s':float((int(aw['bag_time_ns'][-1])-int(aw['bag_time_ns'][0]))/1e9),
            'gates':gates,'raw_intensity_available':'intensity_raw' in aw,'structure_metadata':sinfo,
            'provenance':provenance,'B':bsummary,'conditions':small}
        window_results[window]={'runs':runs,'integ':integ,'mask':structure['structure_mask'],'reference':ref_frame}
    if len(window_results)==2:
        first=window_results['fixed11'];second=window_results['all'];comp=dest/'window_comparison';comp.mkdir()
        for key in first['runs'].keys() & second['runs'].keys():
            x=first['runs'][key];y=second['runs'][key];cc=comp/key;cc.mkdir()
            edge=compare_edges(x['edges'],y['edges'],cc,'C');p=partition_comparison(x['labels'],y['labels'])
            item={'kind':'window_only','boundary':key,'reference_unchanged':first['reference']==second['reference'],
                'clustering_config_unchanged':True,'recovery_thresholds_unchanged':True,'B_count_change_expected':True,
                'structure_mask_differences':int((first['mask']!=second['mask']).sum()),
                'integrated_xyz_equal':np.array_equal(first['integ']['xyz'],second['integ']['xyz'],equal_nan=True),
                'C_edges':edge,'clusters':p}
            json_write(cc/'comparison.json',item);comparisons.append(item)
    unchanged=not source or all(sha_file(source/k)==v for k,v in audit['source_hashes'].items())
    raw_unchanged=hash_input(raw_source)==raw_hashes if raw_source else None
    if not unchanged:raise RuntimeError('Source was modified during run')
    if raw_unchanged is False:raise RuntimeError('Original raw input was modified during run')
    result={'case':name,'status':'completed_diagnostic','windows':summaries,'comparisons':comparisons,
        'original_inputs_recheck':audit['original_input_recheck'],'all_saved_source_files_unchanged':unchanged,
        'automatic_merges':0,'raw_schema':schema,'raw_inputs_unchanged':raw_unchanged,'dataset_role':c['evaluation']['dataset_role'],
        'accuracy':None,'false_merge_rate':None,'seconds':time.perf_counter()-start}
    json_write(dest/'evaluation.json',result)
    (dest/'checkpoint.txt').write_text('Completed diagnostic case '+name+'\nOriginal source unchanged. No automatic fragment merges.\nSee evaluation.json for missing inputs and unverified conditions.\n',encoding='utf8')
    return result

def run_condition(a,ref,stats,integ,modes,structure,c,diag,measured,rays,out):
    h,w=integ['valid'].shape;conf=integ['measurement_confident'];mask=structure['structure_mask'];unknown=structure['structure_evaluation_unknown']
    maxr=c['structure']['max_processing_range_m'];cv=a['valid'][ref]&~mask&~unknown&(a['range'][ref]<=maxr)
    current_source=np.where(cv,1,0).astype(np.uint8)
    cl,ce,cc,cb=audited_cluster(a['xyz'][ref],cv,conf,c,current_source)
    valid=integ['valid']&~mask&~unknown&(integ['range']<=maxr)
    labels,edges,components,bridges=audited_cluster(integ['xyz'],valid,conf,c,integ['source_type'],cl,cv)
    npz_write(out/'edges.npz',**edges);npz_write(out/'current_edges.npz',**ce)
    npz_write(out/'components.npz',**components);npz_write(out/'current_components.npz',**cc)
    json_write(out/'bridge_candidates.json',bridges,compact=True)
    clusters=export_clusters(out/'measured',integ['xyz'],valid,labels,integ['source_type'],integ['source_time_ns'],c['clustering']['min_cluster_points'],
        {'small_fragments_retained':True,'MODEL_INFERRED':0,'point_state_source':'../point_states.npz'})
    corr={'xyz':integ['xyz'],'valid':valid,'labels':labels,'source_type':integ['source_type'],'source_time_ns':integ['source_time_ns']}
    npz_write(out/'pixel_correspondence.npz',**corr,source_sample_index=integ['source_sample_index'],
        source_frame_index=integ['source_frame_index'],source_header_time_ns=integ['source_header_time_ns'],
        pixel_row=np.indices((h,w))[0],pixel_column=np.indices((h,w))[1])
    missing=classify_missingness(a,ref,stats,integ,mask,c)
    npz_write(out/'missingness.npz',**missing)
    state=np.full((h,w),POINT_STATE['UNKNOWN'],np.uint8)
    state[stats['valid_count']>0]=POINT_STATE['HOLD']
    state[integ['valid']]=np.where(integ['source_type'][integ['valid']]==1,1,2)
    state[unknown]=POINT_STATE['HOLD'];state[mask]=POINT_STATE['STRUCTURE_MASKED']
    npz_write(out/'point_states.npz',state=state,measurement_confident=conf,
        temporal_hold_reason=integ['hold_reason'],structure_evaluation_unknown=unknown,
        processing_range_excluded=integ['valid']&(integ['range']>maxr),cluster_eligible=valid)
    rel,inf,planes=relations_diagnostic(a,ref,stats,integ,modes,corr,c,diag,measured,rays,out)
    npz_write(out/'condition_maps.npz',range=integ['range'],intensity=stats.get('distance_valid_intensity_median',np.full((h,w),np.nan)),
        observation_count=stats['valid_count'],history_mad=stats['all_history_range_mad_m'],source_type=integ['source_type'],
        structure_mask=mask,state=state,labels=labels)
    summary={'status':'completed_diagnostic','boundary_hold':c['clustering']['hold_boundary_points'],
        'boundary_false_is_trial':not c['clustering']['hold_boundary_points'],'point_counts':clusters['counts'],
        'current_cluster_count':int(cl.max()+1),'eligible_pixel_sha256':sha_array(valid),'xyz_sha256':sha_array(integ['xyz']),
        'structure_mask_sha256':sha_array(mask),'B_classification_sha256':sha_array(measured['classification']),
        'edge_count':len(edges['pixel_i']),'connected_edges':int(edges['accepted'].sum()),
        'edge_hold_counts':{k:int(((edges['hold_reason']&v)!=0).sum()) for k,v in HOLD_BITS.items()},
        'temporal_hold_counts':{k:int(((integ['hold_reason']&v)!=0).sum()) for k,v in HOLD.items()},
        'recovered_current_missing_pixels':int(integ['recovered_current_missing'].sum()),
        'point_state_counts':{k:int((state==v).sum()) for k,v in POINT_STATE.items()},
        'relations':{k:rel[k] for k in ('candidate_count','search','state_counts','C','plane_history')},
        'no_return_is_free_space':False,'automatic_merges':0,'object_identity':'UNKNOWN','false_merge_rate':None,
        'structure_identity_evaluation':'requires instance annotation; geometric removal masks retained'}
    from .annotations import evaluate_annotations
    annotations=evaluate_annotations(c['evaluation']['instance_labels_npz'],labels,stats,integ,structure,c)
    json_write(out/'annotation_evaluation.json',annotations)
    summary['annotation_evaluation']={k:annotations.get(k) for k in ('status','annotation_sha256','all_cluster_sizes_included')}
    json_write(out/'config.json',c);json_write(out/'diagnostic_config.json',resolve(diag,c));json_write(out/'evaluation.json',summary)
    from .viewer import condition_viewer
    condition_viewer(out,a,ref,stats,integ,structure,labels,edges,state,rel,c)
    return {'labels':labels,'edges':edges,'current_edges':ce,'relations':rel,'summary':summary}

def run(plan_path,out,base=None):
    plan_path=Path(plan_path).resolve();plan=read_json(plan_path)
    defaults={'windows':['fixed11','all'],'boundary_values':[True,False],'rows_per_chunk':8,'max_working_mb':2048,'disk_budget_gib':20}
    for k,v in defaults.items():plan.setdefault(k,v)
    if not set(plan['windows'])<=set(['fixed11','all']) or not plan['windows']:raise ValueError('Invalid windows')
    if any(type(x)!=bool for x in plan['boundary_values']) or len(set(plan['boundary_values']))!=len(plan['boundary_values']):raise ValueError('boundary_values must be distinct booleans')
    if not 1<=plan['rows_per_chunk']<=256:raise ValueError('rows_per_chunk out of bounds')
    names=[x['name'] for x in plan['cases']]
    import re
    if not names or len(set(names))!=len(names) or any(not re.fullmatch(r'[A-Za-z0-9_-]+',n) for n in names):raise ValueError('Case names must be nonempty unique safe path components')
    out=Path(out).resolve()
    roots=[resolve_source(case,plan_path.parent,base) for case in plan['cases']]
    roots += [relocate(case[key],base,plan_path.parent) for case in plan['cases'] for key in ('bag','history') if case.get(key)]
    for p in [x for x in roots if x is not None]:
        if out==p or (p.is_dir() and p in out.parents):raise ValueError('Output must be outside all inputs')
    out.mkdir(parents=True,exist_ok=False);json_write(out/'config.json',plan)
    root=Path(__file__).resolve().parent.parent;code={}
    snap=out/'code_snapshot';snap.mkdir()
    for pkg in ('ylm_common','ylm_organized','ylm_occlusion','frozen_reference'):
        (snap/pkg).mkdir()
        for p in (root/pkg).glob('*.py'):
            shutil.copyfile(p,snap/pkg/p.name);code[pkg+'/'+p.name]=sha_file(p)
    manifest={'version':'0.2.0','status':'started','code_sha256':code,'plan_sha256':sha_file(plan_path),
        'memory':enforce_budget(plan['max_working_mb']),'python':sys.version,'numpy':np.__version__,
        'automatic_fragment_merges':0,'ICP_changed':False,'boundary_default':True,'case_order':names}
    json_write(out/'run_manifest.json',manifest);results={};begin=time.perf_counter()
    for case in plan['cases']:
        try:results[case['name']]=process_case(case,plan,plan_path.parent,out,base)
        except Exception as e:
            results[case['name']]={'status':'failed','error':str(e),'traceback':traceback.format_exc()}
            json_write(out/'cases'/case['name']/'failure.json',results[case['name']])
        json_write(out/'evaluation.json',{'cases':results,'automatic_merges':0})
    manifest.update(status='completed_diagnostic' if all(x['status']!='failed' for x in results.values()) else 'completed_with_failures',
        seconds=time.perf_counter()-begin,peak_rss_mib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024)
    json_write(out/'run_manifest.json',manifest)
    from .viewer import comparison_viewer
    comparison_viewer(out,results)
    (out/'checkpoint.txt').write_text('YLM common v0.2\nSource plan: '+str(plan_path)+'\nStatus: '+manifest['status']+
        '\nNever overwrite existing output. Re-run into a new directory.\nSee evaluation.json and each input_audit.json for verification coverage.\n',encoding='utf8')
    return results
