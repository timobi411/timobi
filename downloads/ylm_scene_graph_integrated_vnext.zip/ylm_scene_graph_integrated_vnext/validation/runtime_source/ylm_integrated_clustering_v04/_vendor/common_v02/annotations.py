"""Optional evaluation labels are never inputs to connection or association rules."""
import numpy as np
from ylm_integrated_clustering_v04._vendor.organized_v01.evaluation import instance_metrics
from .io import read_npz,sha_file

def evaluate_annotations(path,labels,stats,integ,structure,c):
    if not path:return {'status':'not_evaluated_no_instance_ground_truth','metrics':instance_metrics(labels,None),
        'small_fragment_mismerges':None,'separate_tabletop_merges':None,'structure_merges':None}
    ann=read_npz(path);gt=ann.get('instance_id')
    if gt is None or gt.shape!=labels.shape or gt.dtype.kind not in 'iu':raise ValueError('instance_id[H,W] integer required')
    roles=ann.get('semantic_role')
    if roles is not None and (roles.shape!=labels.shape or roles.dtype.kind not in 'US'):raise ValueError('semantic_role must be HxW non-object strings')
    if roles is not None:roles=roles.astype(str)
    metrics=instance_metrics(labels,gt);mixed=metrics.get('false_merge_clusters',[])
    for r in mixed:
        mask=labels==r['cluster'];r['cluster_point_count']=int(mask.sum());r['small_fragment']=r['cluster_point_count']<c['clustering']['min_cluster_points']
        if roles is not None:r['annotated_roles']=np.unique(roles[mask&(gt>=0)]).tolist()
    masked=[]
    for inst in np.unique(gt[gt>=0]):
        p=gt==inst;removed=p&structure['structure_mask']
        dist=structure['floor_distance_m'][removed];finite=dist[np.isfinite(dist)]
        masked.append({'instance_id':int(inst),'annotated_pixels':int(p.sum()),'structure_removed_pixels':int(removed.sum()),
            'removed_floor_distance_median':float(np.median(finite)) if len(finite) else None,
            'distance_available_pixels':len(finite),'leg_identity_requires_annotation':True})
    strata={}
    fields=[('range',integ['range'],c['evaluation']['range_bins_m']),
            ('observation_fraction',stats['valid_fraction'],c['evaluation']['valid_fraction_bins'])]
    if c['evaluation']['intensity_bins'] is not None and 'distance_valid_intensity_median' in stats:
        fields.append(('intensity',stats['distance_valid_intensity_median'],c['evaluation']['intensity_bins']))
    for name,value,bins in fields:
        if len(bins)<2 or np.any(np.diff(bins)<=0):raise ValueError('Invalid evaluation bins')
        strata[name]=[{'low_inclusive':lo,'high_exclusive':hi,'metrics':instance_metrics(labels,gt,(value>=lo)&(value<hi))} for lo,hi in zip(bins[:-1],bins[1:])]
    return {'status':'annotated_evaluation','annotation_sha256':sha_file(path),'evaluation_only':True,
        'metrics':metrics,'all_cluster_sizes_included':True,'structure_removal_by_instance':masked,'strata':strata,
        'semantic_role_available':roles is not None,'true_occlusion_rate_strata':None,'independent_performance_evaluation':False}
