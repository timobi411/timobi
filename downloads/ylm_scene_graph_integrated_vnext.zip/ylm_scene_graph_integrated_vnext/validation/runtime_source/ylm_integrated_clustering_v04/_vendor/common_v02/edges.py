"""Keep the frozen connection decisions and expose every condition and component."""
import numpy as np
from ylm_integrated_clustering_v04._vendor.organized_v01.clustering import cluster_organized, adjacency, components, EDGE_HOLD
from ylm_integrated_clustering_v04._vendor.occlusion_v01.common import sha_array

HOLD_BITS={**EDGE_HOLD,'INVALID_ENDPOINT':64}

def audited_cluster(xyz,valid,trusted,c,source,current_labels=None,current_valid=None):
    labels,old,boundary,bridges=cluster_organized(xyz,valid,trusted,c,current_labels,current_valid)
    h,w=valid.shape;i,j=adjacency(h,w,c['clustering']['neighborhood']);n=len(i)
    pair=valid.ravel()[i]&valid.ravel()[j];pos=np.flatnonzero(pair)
    if not np.array_equal(old['pixel_i'],i[pos]) or not np.array_equal(old['pixel_j'],j[pos]):raise AssertionError('Frozen edge universe changed')
    arrays={'pixel_i':i,'pixel_j':j,'endpoint_valid_i':valid.ravel()[i],'endpoint_valid_j':valid.ravel()[j],
            'endpoint_source_i':source.ravel()[i],'endpoint_source_j':source.ravel()[j],
            'measurement_confident_i':trusted.ravel()[i],'measurement_confident_j':trusted.ravel()[j],
            'endpoint_boundary_i':boundary.ravel()[i],'endpoint_boundary_j':boundary.ravel()[j]}
    reason=np.full(n,HOLD_BITS['INVALID_ENDPOINT'],np.uint16);reason[pos]=old['hold_reason']
    for k in ('alpha_rad','beta_rad','distance_m'):
        arrays[k]=np.full(n,np.nan);arrays[k][pos]=old[k]
    r=np.linalg.norm(xyz-c['acquisition']['sensor_origin_xyz'],axis=-1).ravel()
    arrays.update(range_i_m=r[i],range_j_m=r[j],range_jump_m=abs(r[i]-r[j]),
        beta_threshold_deg=np.full(n,c['clustering']['beta_threshold_deg']),
        distance_limit_m=np.full(n,c['clustering']['max_edge_distance_m']),
        jump_limit_m=np.full(n,c['clustering']['boundary_jump_m']),
        boundary_point_hold_enabled=np.full(n,c['clustering']['hold_boundary_points'],bool))
    arrays['expected_spacing_near_m']=2*np.minimum(r[i],r[j])*np.sin(arrays['alpha_rad']/2)
    arrays['expected_spacing_far_m']=2*np.maximum(r[i],r[j])*np.sin(arrays['alpha_rad']/2)
    arrays['pair_jump_pass']=pair&(arrays['range_jump_m']<c['clustering']['boundary_jump_m'])
    arrays['boundary_vertex_pass']=pair & (~(boundary.ravel()[i]|boundary.ravel()[j]) | ~np.full(n,c['clustering']['hold_boundary_points'],bool))
    for name,bit in HOLD_BITS.items():arrays['pass_'+name.lower()]=pair & ((reason&bit)==0)
    before=reason.copy();before&=np.uint16(~HOLD_BITS['TEMPORAL_BRIDGE']&65535)
    pre=components(valid,i[before==0],j[before==0])
    arrays.update(hold_reason=reason,pre_bridge_hold_reason=before,accepted=reason==0,
        state=np.where(reason==0,1,2).astype(np.uint8),pre_bridge_component_i=pre.ravel()[i],
        pre_bridge_component_j=pre.ravel()[j],final_component_i=labels.ravel()[i],final_component_j=labels.ravel()[j])
    cl=np.full((h,w),-1,np.int32) if current_labels is None else current_labels
    cv=valid if current_valid is None else current_valid
    arrays.update(current_label_i=cl.ravel()[i],current_label_j=cl.ravel()[j],
                  current_valid_i=cv.ravel()[i],current_valid_j=cv.ravel()[j],
                  temporal_bridge_quality_evaluated=(before==0)&(current_labels is not None)&c['clustering']['prevent_temporal_bridges'])
    components_data={'pre_bridge_labels':pre,'final_labels':labels,'current_labels':cl,
                     'current_valid':cv,'source_type':source,'eligible':valid}
    return labels,arrays,components_data,bridges

def compare_edges(a,b,folder,name):
    from .io import npz_write,json_write
    same=np.array_equal(a['pixel_i'],b['pixel_i']) and np.array_equal(a['pixel_j'],b['pixel_j'])
    if not same:raise ValueError('Edge universe differs; pair alignment required')
    lost=a['accepted']&~b['accepted'];gained=~a['accepted']&b['accepted']
    changed=(a['hold_reason']!=b['hold_reason'])|lost|gained
    # Full context for every lost edge; pre/post component IDs refer to component NPZs.
    payload={'edge_index':np.flatnonzero(lost)}
    for prefix,e in (('before',a),('after',b)):
        for k,v in e.items():payload[prefix+'_'+k]=v[lost]
    npz_write(folder/(name+'_lost_edges.npz'),**payload)
    fields=['pair_jump_pass','boundary_vertex_pass']+['pass_'+k.lower() for k in HOLD_BITS]
    result={'same_edge_universe':True,'edge_count':len(a['pixel_i']),'lost_adopted_edges':int(lost.sum()),
        'gained_adopted_edges':int(gained.sum()),'changed_reason_edges':int(changed.sum()),
        'condition_changes':{k:int((a[k]!=b[k]).sum()) for k in fields},
        'lost_edge_audit':name+'_lost_edges.npz','monotonicity_assumed':False,
        'label_ids_are_local_to_condition':True,'final_merge_correctness':None}
    json_write(folder/(name+'_edge_comparison.json'),result);return result

def partition_comparison(old,new,min_size=50):
    """Count every overlap, including one-point fragments. IDs never imply identity."""
    a=old.ravel();b=new.ravel();valid=(a>=0)&(b>=0)
    pairs,counts=np.unique(np.column_stack([a[valid],b[valid]]),axis=0,return_counts=True)
    sizes_a=dict(zip(*np.unique(a[a>=0],return_counts=True)));sizes_b=dict(zip(*np.unique(b[b>=0],return_counts=True)))
    merges=[];splits=[]
    for target in np.unique(pairs[:,1]) if len(pairs) else []:
        ids=pairs[pairs[:,1]==target,0]
        if len(ids)>1:merges.append({'to':int(target),'from':ids.tolist(),'from_sizes':[int(sizes_a[x]) for x in ids],
            'large_source_count':int(sum(sizes_a[x]>=min_size for x in ids)),'small_source_count':int(sum(sizes_a[x]<min_size for x in ids)),
            'semantic_identity':'UNKNOWN','false_merge':None})
    for src in np.unique(pairs[:,0]) if len(pairs) else []:
        ids=pairs[pairs[:,0]==src,1]
        if len(ids)>1:splits.append({'from':int(src),'to':ids.tolist(),'source_size':int(sizes_a[src])})
    return {'overlap_pairs':pairs,'overlap_counts':counts,'merges':merges,'splits':splits,
        'all_sizes_included':True,'shared_labeled_pixels':int(valid.sum()),
        'old_only_labeled_pixels':int(((a>=0)&(b<0)).sum()),'new_only_labeled_pixels':int(((b>=0)&(a<0)).sum()),
        'merge_count':len(merges),'split_count':len(splits),
        'multiple_large_sources_merge_count':sum(x['large_source_count']>=2 for x in merges),
        'small_to_large_merge_count':sum(x['small_source_count']>0 and x['large_source_count']>0 for x in merges),
        'annotation_required_for_separate_tabletops_and_structure_identity':True}
