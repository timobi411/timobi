"""Bounded, pickle-free history storage and preservation of raw PointFields."""
from pathlib import Path
import json, shutil, zipfile, os
import numpy as np
from ylm_integrated_clustering_v04._vendor.occlusion_v01.common import json_write, npz_write, sha_file, sha_array
from ylm_integrated_clustering_v04._vendor.organized_v01.input import (decode_fields, extract_frame, metadata, inspect_bag,
                                 bag_messages, validity)

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf8'),
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError('Nonfinite JSON: '+x)))

def read_npz(path):
    with np.load(path, allow_pickle=False) as z:
        return {k:z[k] for k in z.files}

def open_store(folder):
    folder=Path(folder); meta=read_json(folder/'manifest.json')
    return {k:np.load(folder/v['file'],mmap_mode='r',allow_pickle=False)
            for k,v in meta['arrays'].items()},meta

def finish_store(folder, arrays, **metadata_extra):
    for a in arrays.values():
        if hasattr(a,'flush'): a.flush()
    meta={'format':'ylm_history_npy_v02','allow_pickle':False,'arrays':{},**metadata_extra}
    for k,a in arrays.items():
        p=Path(folder)/(k+'.npy')
        meta['arrays'][k]={'file':p.name,'dtype':a.dtype.str,'shape':a.shape,'sha256':sha_file(p)}
    json_write(Path(folder)/'manifest.json',meta)
    return meta

def allocate(folder,k,shape,dtype):
    return np.lib.format.open_memmap(Path(folder)/(k+'.npy'),mode='w+',dtype=dtype,shape=shape)

def unpack_history(path,folder,max_bytes):
    """Stream each .npy from ZIP to disk, never decompress the full history into RAM."""
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False)
    path=Path(path)
    if path.is_dir():
        src,meta=open_store(path)
        for k,v in meta['arrays'].items():
            if sha_file(path/v['file'])!=v['sha256']:raise ValueError('History store hash mismatch: '+k)
            shutil.copyfile(path/v['file'],folder/(k+'.npy'))
        a={k:np.load(folder/(k+'.npy'),mmap_mode='r+',allow_pickle=False) for k in src}
        finish_store(folder,a,source=str(path),source_manifest=meta)
        return a
    with zipfile.ZipFile(path) as z:
        if sum(x.file_size for x in z.infolist())>max_bytes:raise MemoryError('History exceeds disk storage budget')
        a={}
        for info in z.infolist():
            p=Path(info.filename)
            if p.name!=info.filename or p.suffix!='.npy':raise ValueError('Unsafe/non-NPY history member')
            if p.stem in a:raise ValueError('Duplicate NPZ key')
            with z.open(info) as src, (folder/p.name).open('wb') as dst:shutil.copyfileobj(src,dst,1024**2)
            a[p.stem]=np.load(folder/p.name,mmap_mode='r+',allow_pickle=False)
    finish_store(folder,a,source=str(path),source_sha256=sha_file(path))
    return a

def raw_frame(msg,c):
    a=extract_frame(msg,c); raw=decode_fields(msg)
    name=c['intensity']['field']
    if name and name.lower() in ('rgb','rgba'):raise ValueError('RGB is not intensity')
    # Explicit known name, or the observed YLM field. No RGB fallback.
    if not name and 'intensities' in raw.dtype.names:name='intensities'
    present=bool(name and name in raw.dtype.names)
    if present:
        if raw[name].shape!=a['valid'].shape:raise ValueError('Intensity must be scalar')
        a['intensity_raw']=np.array(raw[name],copy=True)
        a['intensity']=a['intensity_raw'].astype(np.float64)
        a['intensity_valid']=np.isfinite(a['intensity'])
    a['intensity_present']=np.full(a['valid'].shape,present,bool)
    return a, {'field_name':name if present else None,'source_dtype':raw[name].dtype.str if present else None,
               'raw_preserved':present,'physical_units':None,'saturation_value':None,'invalid_value_definition':None}

def extract_bag(path,c,folder,disk_limit):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False)
    before=hash_input(path);inspection=inspect_bag(path,c)
    json_write(folder/'frame_metadata.json',inspection)
    if inspection['errors'] or inspection['layout_changed']:raise ValueError('Malformed or changing layout: inspect frame_metadata.json')
    frames=inspection['frames'];f=len(frames);h,w=frames[0]['height'],frames[0]['width']
    if f*h*w*80>disk_limit:raise MemoryError('History exceeds disk budget')
    arrays={}; imeta=None; seen=[]
    for i,stamp,msg in bag_messages(path,c):
        actual=metadata(msg,stamp,i,c)
        if any(actual[k]!=frames[i][k] for k in ('layout_id','bag_time_ns','header_time_ns','data_size_bytes')):raise ValueError('Bag changed between passes')
        a,im=raw_frame(msg,c)
        if not arrays:
            arrays={k:allocate(folder,k,(f,)+v.shape,v.dtype) for k,v in a.items()};imeta=im
        if im!=imeta or set(a)!=set(arrays):raise ValueError('Raw field schema changed')
        for k,v in a.items(): arrays[k][i]=v
        seen.append(i)
    if len(seen)!=f:raise ValueError('Received count changed')
    vals={'frame_index':np.arange(f,dtype=np.int64),'bag_time_ns':np.array([m['bag_time_ns'] for m in frames],np.int64),
          'header_time_ns':np.array([m['header_time_ns'] for m in frames],np.int64),
          'frame_id':np.array([m['frame_id'] for m in frames]),'layout_id':np.array([m['layout_id'] for m in frames]),
          'setting_id':np.array([m['acquisition_setting_id'] for m in frames]),
          'pixel_row':np.indices((h,w))[0],'pixel_column':np.indices((h,w))[1]}
    for k,v in vals.items(): arrays[k]=allocate(folder,k,v.shape,v.dtype);arrays[k][...]=v
    if before!=hash_input(path):raise ValueError('Bag bytes changed during extraction')
    meta=finish_store(folder,arrays,received_frame_count=f,complete_acquisition=True,intensity=imeta,source_hashes=before)
    return arrays,meta

def hash_input(path):
    p=Path(path)
    return {str(q.resolve()):sha_file(q) for q in ([p] if p.is_file() else sorted(x for x in p.rglob('*') if x.is_file()))}

def validate_history(a,c,rows=16):
    xyz=a['xyz'];f,h,w,d=xyz.shape
    if d!=3 or h<2 or f<1:raise ValueError('Organized xyz[F,H,W,3] required')
    for k in ('frame_index','bag_time_ns','header_time_ns','frame_id','setting_id','layout_id'):
        if k not in a or a[k].shape!=(f,):raise ValueError('Missing frame metadata '+k)
    for k in ('frame_index','bag_time_ns','header_time_ns'):
        if a[k].dtype.kind not in 'iu':raise ValueError('Integer frame/time required')
    if np.any(np.diff(a['frame_index'])<=0):raise ValueError('Frame indices must increase')
    for k in ('valid','range','invalid_reason'):
        if k not in a or a[k].shape!=(f,h,w):raise ValueError('History shape '+k)
    if a['valid'].dtype!=bool or a['invalid_reason'].dtype.kind not in 'iu':raise ValueError('Validity schema')
    for k in ('intensity_raw','intensity','intensity_present'):
        if k in a and a[k].shape!=(f,h,w):raise ValueError('Intensity shape')
    if 'intensity_raw' in a and a['intensity_raw'].dtype.kind not in 'iuf':raise ValueError('Intensity must be numeric raw field')
    if 'intensity_present' in a and a['intensity_present'].dtype!=bool:raise ValueError('intensity_present must be bool')
    for y in range(0,h,rows):
        sl=np.s_[:,y:y+rows];v=a['valid'][sl];r=a['range'][sl]
        geom=np.linalg.norm(a['xyz'][sl].astype(float)-c['acquisition']['sensor_origin_xyz'],axis=-1)
        if not np.isfinite(geom[v]).all() or (r[v]<=0).any() or not np.allclose(geom[v],r[v],atol=1e-5,rtol=0):raise ValueError('range/XYZ/valid mismatch')
        if np.any(v & (a['invalid_reason'][sl]!=0)):raise ValueError('valid/invalid_reason mismatch')
        if 'intensity_raw' in a and 'intensity' in a:
            if not np.array_equal(a['intensity_raw'][sl].astype(float),a['intensity'][sl],equal_nan=True):raise ValueError('Raw intensity values differ from diagnostic copy')
    for k,g in zip(('pixel_row','pixel_column'),np.indices((h,w))):
        if k in a and not np.array_equal(a[k],g):raise ValueError('Pixel coordinates changed')
    return {'shape':[f,h,w],'layout_count':len(np.unique(a['layout_id'])),
            'raw_intensity_available':'intensity_raw' in a,
            'raw_intensity_dtype':a['intensity_raw'].dtype.str if 'intensity_raw' in a else None,
            'legacy_float_intensity_not_recast_to_raw':'intensity' in a and 'intensity_raw' not in a}

def select_history(a,indices,folder,ref_index):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False)
    f,h,w=a['valid'].shape;idx=np.asarray(indices,int); out={}
    for k,v in a.items():
        if k=='reference_sample_index':continue
        framewise=v.ndim>0 and v.shape[0]==f and k not in ('pixel_row','pixel_column')
        shape=(len(idx),)+v.shape[1:] if framewise else v.shape
        out[k]=allocate(folder,k,shape,v.dtype)
        if framewise:
            for j,i in enumerate(idx):out[k][j]=v[i]
        else:out[k][...]=v
    ref=int(np.flatnonzero(out['frame_index']==ref_index)[0])
    out['reference_sample_index']=allocate(folder,'reference_sample_index',(),np.int64);out['reference_sample_index'][...]=ref
    # Legacy float data are retained as legacy; absence of raw bytes is never repaired by casting.
    if 'intensity' in out and 'intensity_present' not in out:
        out['intensity_present']=allocate(folder,'intensity_present',(len(idx),h,w),bool);out['intensity_present'][:]=True
    if 'intensity' in out:
        if 'intensity_valid' not in out:out['intensity_valid']=allocate(folder,'intensity_valid',(len(idx),h,w),bool)
        for j in range(len(idx)):out['intensity_valid'][j]=np.isfinite(out['intensity'][j]) & out['intensity_present'][j]
    for k,v in zip(('pixel_row','pixel_column'),np.indices((h,w))):
        if k not in out:out[k]=allocate(folder,k,v.shape,v.dtype);out[k][...]=v
    finish_store(folder,out,selected_count=len(idx),reference_frame_index=ref_index,
                 reference_sample_index=ref,raw_intensity_available='intensity_raw' in out)
    return out,ref
