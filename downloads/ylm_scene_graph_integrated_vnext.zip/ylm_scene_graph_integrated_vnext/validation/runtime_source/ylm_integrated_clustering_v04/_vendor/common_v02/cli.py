from pathlib import Path
import argparse,sys
from .io import read_json,json_write

def discover(base,out):
    """Discover by manifests/history; never choose among ambiguous histories silently."""
    base=Path(base).expanduser().resolve();cases=[];unresolved=[]
    for exp,folder in [('exp01','organized_runs/exp01_boundary_comparison_kz_uq42l'),('exp02','organized_runs/exp02_structure_temporal_irxiwli3')]:
        root=base/folder
        candidates=[]
        if root.exists():
            for h in root.rglob('history.npz'):
                c=h.parent/'config.json'
                if c.exists() and (h.parent/'C/pixel_correspondence.npz').exists():
                    cfg=read_json(c)
                    if cfg['clustering']['hold_boundary_points']:candidates.append(h.parent)
        if exp=='exp01':
            from .audit import relocate
            diagnostics=base/'organized_runs/exp01_boundary_occlusion_um2ffve7/diagnostics'
            for mp in diagnostics.rglob('input_manifest.json') if diagnostics.exists() else []:
                meta=read_json(mp)
                if not meta.get('source_directory'):continue
                src=relocate(meta['source_directory'],base,mp.parent)
                if (src/'history.npz').exists() and (src/'config.json').exists() and read_json(src/'config.json')['clustering']['hold_boundary_points']:
                    if src not in candidates:candidates.append(src)
        for time in ('t0','t1'):
            matches=[p for p in candidates if any(part==time or part.startswith(time+'_') for part in p.parts)]
            if len(matches)!=1:
                unresolved.append({'case':exp+'_'+time,'candidates':[str(p) for p in matches],'reason':'requires exact source_dir'});continue
            cases.append({'name':exp+'_'+time,'source_dir':str(matches[0]),'dataset_role':'development'})
    json_write(out,{'version':'0.2.0','cases':cases,'unresolved_cases':unresolved,
        'windows':['fixed11','all'],'boundary_values':[True,False],'rows_per_chunk':8,'max_working_mb':2048,'disk_budget_gib':20})
    print(str(out));print('Resolved:',len(cases),'Unresolved:',len(unresolved))
    return unresolved

def main():
    ap=argparse.ArgumentParser(description='YLM v0.2 common observation diagnostics; no automatic fragment merging')
    sub=ap.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('discover');p.add_argument('--base',required=True);p.add_argument('--out',required=True)
    p=sub.add_parser('run');p.add_argument('--plan',required=True);p.add_argument('--out',required=True);p.add_argument('--base')
    p=sub.add_parser('verify');p.add_argument('output')
    p=sub.add_parser('demo');p.add_argument('--out',required=True)
    args=ap.parse_args()
    if args.cmd=='discover':
        if Path(args.out).exists():ap.error('Output already exists')
        if discover(args.base,Path(args.out)):sys.exit(2)
    elif args.cmd=='run':
        from .runner import run
        plan=read_json(args.plan)
        if plan.get('unresolved_cases'):ap.error('Resolve unresolved_cases in plan before execution')
        result=run(args.plan,args.out,args.base)
        if any(x['status']=='failed' for x in result.values()):sys.exit(1)
        print('Completed:',args.out)
    elif args.cmd=='verify':
        from .verify import verify
        result=verify(Path(args.output));print(result)
        if result['errors']:sys.exit(1)
    elif args.cmd=='demo':
        from .demo import create
        create(Path(args.out))
