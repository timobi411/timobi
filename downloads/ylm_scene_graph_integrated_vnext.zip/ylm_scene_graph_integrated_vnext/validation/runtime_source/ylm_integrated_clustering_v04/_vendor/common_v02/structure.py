import numpy as np
from .io import read_json,read_npz,sha_file

def plane_test(xyz,entry):
    p=entry['plane'];model=np.asarray(p['model'],float);model=model/np.linalg.norm(model[:3]);normal=model[:3];d=model[3]
    pts=np.asarray(p['points'],float);center=pts.mean(axis=0);origin=center-(center@normal+d)*normal
    reference=np.array([0.,0.,1.]) if abs(normal[2])<.90 else np.array([1.,0.,0.])
    u=np.cross(normal,reference);u/=np.linalg.norm(u);v=np.cross(normal,u);v/=np.linalg.norm(v)
    uv=np.column_stack([(pts-origin)@u,(pts-origin)@v]);margin=entry['footprint_margin_m']
    query=np.stack([(xyz-origin)@u,(xyz-origin)@v],axis=-1)
    dist=abs(xyz@normal+d);foot=((query>=uv.min(axis=0)-margin)&(query<=uv.max(axis=0)+margin)).all(axis=-1)
    return np.isfinite(xyz).all(axis=-1)&(dist<=entry['band_m'])&foot,dist,model

def evaluate_structure(source,integ,canonical,config,model_path=None):
    h,w=integ['valid'].shape
    frozen=read_npz(source/'structure_mask.npz')['structure_mask'].astype(bool) if source is not None else np.zeros((h,w),bool)
    if frozen.shape!=(h,w):raise ValueError('Structure pixel grid mismatch')
    model_path=model_path or (source/'structure_metadata.json' if source else None)
    meta=read_json(model_path) if model_path and model_path.exists() else None
    models=meta.get('planes') if meta else None
    observed=canonical['valid'] if canonical is not None else np.zeros((h,w),bool)
    newly_eligible=integ['valid'] & ~observed
    model_mask=np.zeros((h,w),bool);role=np.zeros((h,w),np.uint8);distance=np.full((h,w),np.nan)
    floor_distance=np.full((h,w),np.nan);per_plane=[];query_valid=np.zeros((h,w),bool)
    no_structure=config['structure']['mode']=='none'
    if models is not None:
        query_valid=integ['valid'].copy()
        for e in models:
            mask,dist,coef=plane_test(integ['xyz'],e);mask &= integ['valid']
            model_mask|=mask;role[mask]|={'floor':1,'wall':2,'ceiling':4}.get(e['role'],8)
            distance=np.fmin(distance,dist)
            if e['role']=='floor':floor_distance=np.fmin(floor_distance,dist)
            per_plane.append({'role':e['role'],'coefficients':coef,'band_m':e['band_m'],
                'footprint_margin_m':e['footprint_margin_m'],'removed_current_query_pixels':int(mask.sum())})
    elif no_structure:query_valid=integ['valid'].copy()
    # Keep canonical mask for the controlled comparison, evaluate new measured recovery
    # through the same saved finite-plane model. Unknown model => explicit HOLD.
    mask=frozen | (newly_eligible & model_mask)
    unknown=newly_eligible & ~query_valid & ~frozen
    result={'structure_mask':mask,'canonical_structure_mask':frozen,'model_query_mask':model_mask,
        'model_query_valid':query_valid,'structure_evaluation_unknown':unknown,'removal_role_bits':role,
        'nearest_plane_distance_m':distance,'floor_distance_m':floor_distance,
        'current_query_model_disagrees_with_canonical':query_valid&(model_mask!=frozen),
        'pixel_row':np.indices((h,w))[0],'pixel_column':np.indices((h,w))[1]}
    info={'coordinate_frame':'same as history.frame_id','policy':'canonical pixel mask plus finite-plane evaluation of newly recovered pixels',
        'planes':models,'plane_summary':per_plane,'source_model':str(model_path) if meta else None,
        'source_model_sha256':sha_file(model_path) if meta else None,'model_metadata_available':meta is not None,
        'saved_mask_sha256':sha_file(source/'structure_mask.npz') if source else None,
        'new_recovery_without_model_is_held':True,'canonical_model_disagreement_is_diagnostic_only':True,
        'new_pixel_structure_unknown_count':int(unknown.sum()),'z_only_leg_classification':False,
        'structure_unconfigured':no_structure}
    return result,info
