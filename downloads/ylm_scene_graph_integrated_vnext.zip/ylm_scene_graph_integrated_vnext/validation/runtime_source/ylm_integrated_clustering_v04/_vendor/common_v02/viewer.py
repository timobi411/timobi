"""Offline HTML: linked pixel maps and a rotatable measured-point view."""
import json,html
import numpy as np
from ylm_integrated_clustering_v04._vendor.occlusion_v01.common import clean

STYLE='''body{margin:24px;background:#101a25;color:#e5edf5;font:15px system-ui}h1{font-size:23px}a{color:#77d4e4}select,button,input{background:#203344;color:white;padding:7px;border:1px solid #527086;border-radius:5px}canvas{background:#08111a;border:1px solid #345;margin:8px 0;max-width:100%}.grid{display:flex;gap:24px;flex-wrap:wrap}.panel{flex:1;min-width:340px}pre{white-space:pre-wrap;max-height:430px;overflow:auto;font-size:12px;background:#162635;padding:12px}table{border-collapse:collapse;width:100%}td,th{border-bottom:1px solid #345;padding:9px;text-align:left}small{color:#adc3d3}.tag{color:#ffd58a}.note{max-width:1000px;line-height:1.7}'''

def condition_viewer(out,a,ref,stats,integ,structure,labels,edges,state,rel,c):
    h,w=labels.shape;pixels=np.flatnonzero(integ['valid']);step=max(1,int(np.ceil(len(pixels)/20000)));pixels=pixels[::step]
    edge_hold=np.zeros(h*w,np.int32)
    for key in ('pixel_i','pixel_j'):np.add.at(edge_hold,edges[key][~edges['accepted']],1)
    maps={'range':integ['range'],'intensity':stats.get('distance_valid_intensity_median',np.full((h,w),np.nan)),
          'observations':stats['valid_count'],'MAD':stats['all_history_range_mad_m'],'source':integ['source_type'],
          'structure':structure['structure_mask'].astype(int),'floor_distance':structure['floor_distance_m'],
          'edge_holds':edge_hold.reshape(h,w),'state':state,'cluster':labels}
    records=[]
    for r in rel['relations']:
        endpoints=np.asarray(r['endpoint_pixels']);y,x=endpoints.T
        b=r['stage_B_measured_gap'];ph=r['plane_history']
        selected_history={side:{k:ph[side][k] for k in ('counts','valid_comparison_count','near_sample_pixel_count','near_unique_pixels','projected_gap_pixels','all_valid_history_in_front','plane_existence_confirmed')} for side in ('left','right')}
        records.append({'id':r['candidate_id'],'evidence':r['stage_A']['evidence_class'],'state':r['state'],
            'endpoints':r['endpoint_pixels'],'points':integ['xyz'][y,x],'gaps':r['gap_pixels'],
            'A':{k:r['stage_A'][k] for k in ('foreground_support_count','depth_order_contradiction_count','no_return_count','valid_comparison_count','local_surface_compatibility')},
            'B':{k:b[k] for k in ('counts','valid_comparison_count','total_target_evaluations','unique_gap_pixels_with_historical_target')},
            'C':{k:r['dual_plane_comparison'][k] for k in ('both_projected_pixels','range_agreement_pixels','maximum_range_disagreement_m')},
            'plane_history':selected_history,'hold_reasons':r['hold_reasons'],'object_identity':'UNKNOWN'})
    data={'h':h,'w':w,'maps':{k:v.ravel().tolist() for k,v in maps.items()},
        'point_pixels':pixels,'points':integ['xyz'].reshape(-1,3)[pixels],
        'full_measured_count':int(integ['valid'].sum()),'display_measured_count':len(pixels),
        'records':records,'reference_frame_index':int(a['frame_index'][ref]),
        'search':rel['search'],'source_sample_index':integ['source_sample_index'].ravel(),
        'source_frame_index':integ['source_frame_index'].ravel(),
        # Time strings preserve int64 nanoseconds in JavaScript.
        'source_time_ns':[str(v) if v>=0 else None for v in integ['source_time_ns'].ravel()]}
    body='''<!doctype html><meta charset="utf-8"><title>YLM v0.2 診断</title><style>STYLE</style>
<h1>YLM v0.2 — 観測・接続・断片関係</h1><p class="note">実測点と仮説線を分離して表示。断片自動結合は0件、物体同一性はUNKNOWN。距離許容幅は暫定値です。<br>左の画素をクリックすると元フレームと時刻を確認できます。3Dはドラッグで回転、ホイールで拡大。</p>
<label>表示 <select id="layer"></select></label> <span id="legend"></span>
<div class="grid"><div class="panel"><canvas id="map" width="640" height="458"></canvas><pre id="pixel">画素を選択</pre></div><div class="panel"><canvas id="cloud" width="680" height="510"></canvas><small id="counts"></small></div></div>
<label>証拠分類 <select id="filter"><option value="all">全候補</option></select></label>
<label>候補 <select id="candidate"></select></label><button id="clear">選択解除</button>
<pre id="record"></pre><p><a href="fragment_relations.json">全候補の詳細JSON</a> / <a href="evaluation.json">集計JSON</a></p><p id="scope"></p>
<script id="data" type="application/json">DATA</script><script>
const d=JSON.parse(document.getElementById('data').textContent),$=id=>document.getElementById(id),map=$('map'),mc=map.getContext('2d'),cloud=$('cloud'),cc=cloud.getContext('2d');
let layer='range',chosen=null,angle=.3,tilt=-.35,zoom=1,drag=null;
const names={range:'距離 [m]',intensity:'有効距離時の強度（生値相当）',observations:'距離観測回数',MAD:'全履歴MAD [m]',source:'点の由来',structure:'構造除去mask',floor_distance:'床平面までの距離 [m]',edge_holds:'保留辺の接続数',state:'点状態',cluster:'クラスタ'};
for(const k of Object.keys(d.maps)){$('layer').add(new Option(names[k],k));}
for(const e of [...new Set(d.records.map(r=>r.evidence))])$('filter').add(new Option(e,e));
function color(v,lo,hi){if(v===null||!Number.isFinite(v)||(layer==='cluster'&&v<0))return '#15212b';if(layer==='cluster')return `hsl(${(v*137.5)%360},65%,60%)`;const t=Math.max(0,Math.min(1,(v-lo)/(hi-lo||1)));return `hsl(${220-210*t},70%,${35+25*t}%)`;}
function scale(){const v=d.maps[layer].filter(x=>x!==null&&Number.isFinite(x));v.sort((a,b)=>a-b);return [v[Math.floor(v.length*.02)]??0,v[Math.min(v.length-1,Math.floor(v.length*.98))]??1];}
function drawMap(){const v=d.maps[layer],[lo,hi]=scale(),sx=map.width/d.w,sy=map.height/d.h;mc.clearRect(0,0,map.width,map.height);for(let p=0;p<v.length;p++){mc.fillStyle=color(v[p],lo,hi);mc.fillRect((p%d.w)*sx,Math.floor(p/d.w)*sy,Math.ceil(sx),Math.ceil(sy));}if(chosen){mc.strokeStyle='#fff';mc.lineWidth=2;mc.beginPath();chosen.endpoints.forEach(([y,x],i)=>i?mc.lineTo((x+.5)*sx,(y+.5)*sy):mc.moveTo((x+.5)*sx,(y+.5)*sy));mc.stroke();}$('legend').textContent=`表示尺度: ${lo.toPrecision(4)} ～ ${hi.toPrecision(4)}（上下2%を色範囲に使用・値と集計は変更なし）`;}
const center=[0,1,2].map(k=>d.points.reduce((s,p)=>s+p[k],0)/(d.points.length||1));const extent=Math.max(1,...[0,1,2].map(k=>{const v=d.points.map(p=>p[k]);return v.length?Math.max(...v)-Math.min(...v):1;}));
function project(p){let x=p[0]-center[0],y=p[1]-center[1],z=p[2]-center[2],u=x*Math.cos(angle)-y*Math.sin(angle),q=x*Math.sin(angle)+y*Math.cos(angle),v=q*Math.sin(tilt)+z*Math.cos(tilt);return [cloud.width/2+u*450/extent*zoom,cloud.height/2-v*450/extent*zoom];}
function drawCloud(){cc.clearRect(0,0,cloud.width,cloud.height);const [lo,hi]=scale();for(let j=0;j<d.points.length;j++){const q=project(d.points[j]);cc.fillStyle=color(d.maps[layer][d.point_pixels[j]],lo,hi);cc.fillRect(q[0],q[1],2,2);}if(chosen){const a=project(chosen.points[0]),b=project(chosen.points[1]);cc.strokeStyle='#fff';cc.lineWidth=2;cc.setLineDash([7,5]);cc.beginPath();cc.moveTo(...a);cc.lineTo(...b);cc.stroke();cc.setLineDash([]);} }
function draw(){drawMap();drawCloud();}
function choose(){chosen=d.records.find(r=>r.id===Number($('candidate').value))||null;$('record').textContent=chosen?JSON.stringify(chosen,null,2):'候補を選択。白破線は端点間の仮説関係で、実測表面ではありません。';draw();}
function refill(){const list=d.records.filter(r=>$('filter').value==='all'||r.evidence===$('filter').value);$('candidate').replaceChildren(new Option('選択してください','-1'));for(const r of list)$('candidate').add(new Option(`${r.id} / ${r.state}`,r.id));choose();}
$('layer').onchange=()=>{layer=$('layer').value;draw();};$('filter').onchange=refill;$('candidate').onchange=choose;$('clear').onclick=()=>{$('candidate').value='-1';choose();};
map.onclick=e=>{const b=map.getBoundingClientRect(),x=Math.floor((e.clientX-b.left)/b.width*d.w),y=Math.floor((e.clientY-b.top)/b.height*d.h),p=y*d.w+x;if(x<0||x>=d.w||y<0||y>=d.h)return;$('pixel').textContent=JSON.stringify({pixel_id:p,row:y,column:x,value:d.maps[layer][p],source_sample:d.source_sample_index[p],source_frame:d.source_frame_index[p],source_time_ns:d.source_time_ns[p]},null,2);};
cloud.onpointerdown=e=>{drag=[e.clientX,e.clientY];cloud.setPointerCapture(e.pointerId);};cloud.onpointermove=e=>{if(!drag)return;angle+=(e.clientX-drag[0])*.01;tilt+=(e.clientY-drag[1])*.01;drag=[e.clientX,e.clientY];drawCloud();};cloud.onpointerup=()=>drag=null;cloud.onwheel=e=>{e.preventDefault();zoom=Math.max(.1,Math.min(10,zoom*Math.exp(-e.deltaY*.001)));drawCloud();};
$('counts').textContent=`実測 ${d.full_measured_count}点 / 3D表示 ${d.display_measured_count}点。集計は全点。基準frame ${d.reference_frame_index}。`;$('scope').textContent='候補探索範囲: '+JSON.stringify(d.search);refill();
</script>'''
    (out/'index.html').write_text(body.replace('STYLE',STYLE).replace('DATA',json.dumps(clean(data),ensure_ascii=False,allow_nan=False,separators=(',',':')).replace('</','<\\/')),encoding='utf8')

def comparison_viewer(out,results):
    rows=[]
    for name,result in results.items():
        if result['status']=='failed':rows.append(f'<tr><td>{html.escape(name)}</td><td colspan="8">失敗: {html.escape(result["error"])}</td></tr>');continue
        for window,w in result['windows'].items():
            if w['status']=='not_run':rows.append(f'<tr><td>{html.escape(name)}</td><td>{window}</td><td colspan="7">未実行: {html.escape(w["reason"])}</td></tr>');continue
            for cond,s in w['conditions'].items():
                url=f'cases/{name}/{window}/{cond}/index.html';p=s['point_counts'];fg=w['B']['counts']['foreground_occlusion_candidate'];g=w['gates']['temporal_adoption_allowed']
                rows.append(f'<tr><td>{html.escape(name)}</td><td>{window} ({w["selected_count"]})</td><td><a href="{url}">{cond}</a></td><td>{p["clusters"]}</td><td>{p["small_fragments"]}</td><td>{s["recovered_current_missing_pixels"]}</td><td>{s["relations"]["candidate_count"]}</td><td>{fg}</td><td>{"通過" if g else "保留"}</td></tr>')
    page='<!doctype html><meta charset="utf-8"><title>YLM v0.2 全条件比較</title><style>'+STYLE+'</style><h1>YLM v0.2 — 全条件比較</h1><p class="note">開発データの診断です。物体同一性・認識精度・誤結合率は未確定。境界falseは試験設定、断片自動結合は全条件0件。前景候補はsample×pixel件数で、物体数ではありません。</p><p><a href="evaluation.json">全条件JSON</a> / <a href="run_manifest.json">実行manifest</a> / <a href="checkpoint.txt">再開メモ</a></p><table><thead><tr><th>ケース</th><th>時間窓 / 選択数</th><th>境界</th><th>クラスタ</th><th>小断片</th><th>回収画素</th><th>関係候補</th><th>B前景候補</th><th>統合gate</th></tr></thead><tbody>'+''.join(rows)+'</tbody></table><p class="note">各ケースのinput_audit.jsonに元入力のSHA256再照合とモード照合を保存。原始bagがない場合、SHA256再照合済みとは表示しません。境界比較のC_lost_edges.npzとcomponents.npzで採用辺の喪失を追跡できます。50点未満を含む全クラスタの合流・分割はcluster_overlap.jsonに保存しています。</p>'
    (out/'index.html').write_text(page,encoding='utf8')
