import argparse,json
from .util import *
from .config import default_config,import_plan

def configure(common_results,out,base=None):
 root=Path(common_results).expanduser().resolve();c=default_config()
 if Path(out).exists():raise FileExistsError(out)
 from ._vendor.common_v02.audit import relocate
 for p in sorted((root/'cases').iterdir()):
  if not (p/'input_manifest.json').exists():continue
  m=read(p/'input_manifest.json');item={'name':p.name,'input':{'kind':'v02_case','path':str(p)},'dataset_role':'development','reference_frame_index':m['reference_frame_index'],'fixed_frame_indices':m['fixed_frame_indices']}
  source=relocate(m['source_directory'],base,p) if m.get('source_directory') else None;bag=relocate(m['raw_source'],base,p) if m.get('raw_source') else None
  if bag is None and source and (source/'run_manifest.json').exists():
   sm=read(source/'run_manifest.json')
   if sm.get('input_kind')=='bag':bag=relocate(sm['input'],base,source)
  if bag and bag.exists() and ((bag.is_dir() and (bag/'metadata.yaml').exists()) or bag.suffix=='.mcap'):
   item['input']={'kind':'bag','path':str(bag)};item['config']=str(p/'original_config.json')
   if source and source.exists():item['baseline_dir']=str(source)
  c['cases'].append(item)
 if not c['cases']:raise ValueError('No v0.2 cases found')
 write(out,c);return {'config':str(out),'inputs':[{'case':x['name'],**x['input']} for x in c['cases']]}

def demo(folder):
 folder=Path(folder).resolve()
 from ._vendor.common_v02.demo import create
 create(folder);c=default_config();c['cases']=[{'name':'synthetic_panel_and_fragments','input':{'kind':'history','path':'history.npz','complete_acquisition':True},'config':'config.json','reference_frame_index':15,'dataset_role':'synthetic'}];c['resources']['disk_budget_gib']=2;c['resources']['rows_per_chunk']=4;write(folder/'integrated_config.json',c);return {'config':str(folder/'integrated_config.json'),'synthetic':True}

def main(argv=None):
 p=argparse.ArgumentParser(description='YLM-X001 v0.4 integrated bag processing');s=p.add_subparsers(dest='command',required=True)
 q=s.add_parser('run');q.add_argument('--config',required=True);q.add_argument('--out',required=True);q.add_argument('--base')
 q=s.add_parser('verify');q.add_argument('output');q.add_argument('--offline',action='store_true')
 q=s.add_parser('configure');q.add_argument('--common-results',required=True);q.add_argument('--out',required=True);q.add_argument('--base')
 q=s.add_parser('import-plan');q.add_argument('--plan',required=True);q.add_argument('--out',required=True);q.add_argument('--base')
 q=s.add_parser('demo');q.add_argument('--out',required=True)
 q=s.add_parser('compare');q.add_argument('output');a=p.parse_args(argv)
 if a.command=='run':
  from .runner import run
  r=run(a.config,a.out,a.base);print(json.dumps({k:r[k] for k in ('status','completed_conditions','expected_conditions','bag_message_scans')},ensure_ascii=False));return 0 if r['status']=='COMPLETED_ALL' else 2
 if a.command=='verify':
  from .verify import verify
  r=verify(a.output,not a.offline);print(json.dumps({k:r[k] for k in ('status','completed_conditions','expected_conditions','external_sources_all_checked_and_matched','errors')},ensure_ascii=False));return 0 if r['status']=='PASS' else 1
 if a.command=='configure':r=configure(a.common_results,a.out,a.base)
 elif a.command=='import-plan':import_plan(a.plan,a.out,a.base);r={'config':a.out}
 elif a.command=='demo':r=demo(a.out)
 else:
  from .viewer import comparison
  root=Path(a.output);m=read(root/'run_manifest.json');comparison(root,m)
  for key in ('index.html','comparison.json'):m['output_sha256'][key]=sha(root/key)
  write(root/'run_manifest.json',m);r={'html':str((root/'index.html').resolve())}
 print(json.dumps(r,ensure_ascii=False));return 0
