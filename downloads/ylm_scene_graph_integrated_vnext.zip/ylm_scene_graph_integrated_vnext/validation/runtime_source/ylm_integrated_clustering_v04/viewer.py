"""Join frontend maps/held edges with backend evidence in a single offline canvas UI."""
import html,json
from .util import *

def condition_view(folder,d,entry,max_points):
 folder=Path(folder);page=(folder/'relations_v03/comparison.html').read_text();start=page.index('const D=')+len('const D=');data,end=json.JSONDecoder().raw_decode(page[start:]);maps=npz(folder/'condition_maps.npz');states=npz(folder/'point_states.npz');pix=np.asarray(data['pixels'],int)
 for key,arr in [('range',maps['range']),('intensity',maps['intensity']),('observations',maps['observation_count']),('mad',maps['history_mad']),('state',maps['state']),('hold',states['temporal_hold_reason'])]:data[key]=clean(arr.ravel()[pix])
 edges=d.edges;held=np.flatnonzero(~edges['accepted']);stride=max(1,int(np.ceil(len(held)/2000)));data['held_edges']=[[int(edges['pixel_i'][i]),int(edges['pixel_j'][i]),int(edges['hold_reason'][i])] for i in held[::stride]]
 data['held_edge_count']=len(held);data['held_display_stride']=stride;data['point_display_stride']=max(1,int(np.ceil(len(pix)/max_points)));data['reference_frame']=entry['reference_frame_index'];data['selected_frames']=entry['selected_frame_count'];data['received_frames']=entry['received_frame_count']
 payload=json.dumps(data,ensure_ascii=False,separators=(',',':'),allow_nan=False).replace('<','\\u003c');page=page[:start]+payload+page[start+end:]
 page=page.replace('YLM-X001 comparison','YLM-X001 v0.4 integrated').replace('YLM-X001 / 観測断片と関係仮説','YLM-X001 v0.4 / 観測・接続・断片関係')
 options=''.join(f'<option value="{key}">{label}</option>' for key,label in [('range','距離 m'),('intensity','強度（未校正）'),('observations','有効観測回数'),('mad','全履歴距離MAD m'),('state','点状態'),('hold','時間保留 bit')])
 page=page.replace('</select>\n<label><input type="checkbox" id="measured"',options+'</select>\n<label><input type="checkbox" id="held">辺保留</label><label><input type="checkbox" id="measured"',1)
 page=page.replace('<p id="status"></p>','<p id="status"></p><p id="legend"></p><p>点状態 1 CURRENT / 2 HISTORY / 3 HOLD / 4 UNKNOWN / 5 STRUCTURE_MASKED。構造除去はorganized上のマスクで表示。強度の物理単位は未確認。</p><a href="stage_contract.json">データ契約</a> / <a href="index.html">前段の詳細</a>')
 page=page.replace('let eligible=D.pixels.map((_,i)=>i).filter(i=>!current||D.source[i]===1);',"let eligible=D.pixels.map((_,i)=>i).filter(i=>i%D.point_display_stride===0&&(!current||D.source[i]===1));let layer=$('labelMode').value,cont=['range','intensity','observations','mad'].includes(layer),lo=Infinity,hi=-Infinity;for(let v of lab)if(v!==null){lo=Math.min(lo,v);hi=Math.max(hi,v)}if(lo===Infinity){lo=0;hi=0}function shade(v){return v===null?'#777':cont?`hsl(${240-240*(v-lo)/Math.max(hi-lo,1e-9)} 80% 60%)`:color(v)}$('legend').textContent=(cont?`${layer}: ${lo.toPrecision(5)} → ${hi.toPrecision(5)}; null=灰色 / `:'')+`ref ${D.reference_frame}; selected ${D.selected_frames}; received ${D.received_frames??'unknown'}; 点表示stride ${D.point_display_stride}; 保留辺表示stride ${D.held_display_stride}`;")
 page=page.replace(':color(lab[i]);',':shade(lab[i]);')
 needle="if(chosen&&$('candidate').checked)"
 addition="if($('held').checked){ctx.strokeStyle='#ff547c88';for(let [i,j,reason] of D.held_edges){if(!lookup.has(i)||!lookup.has(j))continue;let a=screen(pts[lookup.get(i)]),b=screen(pts[lookup.get(j)]);ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke()}}\n"
 page=page.replace(needle,addition+needle);page=page.replace("['labelMode','measured'","['held','labelMode','measured'")
 page=page.replace("['image','space','xy','xz','yz']","['image','space','xy','xz','yz']")
 (folder/'viewer.html').write_text(page,encoding='utf8')

def comparison(root,m):
 root=Path(root);rows=[];evaluations=[];bycase={}
 for c in m['conditions']:
  link=''
  if c['status']=='COMPLETED_DIAGNOSTIC':
   link='<button data-view="'+html.escape(c['output']+'/viewer.html',quote=True)+'">表示</button>';a=npz(root/c['output']/'pixel_correspondence.npz');bycase.setdefault(c['case'],[]).append((c['output'],a['valid']))
   evaluations.append({'condition':c,'front_end':read(root/c['output']/'evaluation.json'),'fragment':read(root/c['output']/'relations_v03/evaluation.json')})
  else:evaluations.append({'condition':c,'front_end':None,'fragment':None})
  rows.append('<tr>'+''.join('<td>'+html.escape(str(c.get(k,'')))+'</td>' for k in ('case','window','boundary','status','selected_frames','fragment_count','candidate_count','trial_group_count'))+'<td>'+link+'</td></tr>')
 common={name:{'conditions':[x[0] for x in group],'common_valid_pixels':int(np.logical_and.reduce([x[1] for x in group]).sum()),'denominator_pixels':int(group[0][1].size),'same_bag_pixel_comparison_only':True} for name,group in bycase.items()}
 write(root/'comparison.json',{'schema_version':SCHEMA,'conditions':evaluations,'common_pixels':common,'completed_conditions':m['completed_conditions'],'expected_conditions':m['expected_conditions'],'independent_accuracy_evaluation':False,'accuracy':None,'false_merge_rate':None})
 page='''<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>YLM v0.4 全条件比較</title><style>body{font:14px system-ui;margin:22px;background:#101923;color:#edf4fa}h1{font-size:24px}table{border-collapse:collapse;width:100%}td,th{padding:9px;border-bottom:1px solid #46596c;text-align:left}button{padding:7px;background:#64c7f0;color:#072035;border:0;cursor:pointer}a{color:#88d5fa}iframe{width:100%;height:1650px;border:1px solid #46596c;margin-top:20px}.note{color:#efcb7d}.table{overflow:auto}</style><h1>YLM-X001 v0.4 / 全条件比較</h1>'''
 page+=f'<p>処理完了 {m["completed_conditions"]} / {m["expected_conditions"]} 条件。bagメッセージ走査 {m.get("bag_message_scans",0)} 回。</p>'
 page+='<p class="note">exp01 / exp02 は開発データ。物体同一性 UNKNOWN。未実行・失敗を成功に含めません。試験グループと物体採用は別です。</p><p><a href="comparison.json">全条件比較JSON</a> / <a href="verification.json">統合検査</a> / <a href="input_registry.json">共有履歴</a></p><div class="table"><table><tr>'+''.join('<th>'+x+'</th>' for x in ('case','window','boundary','status','frames','fragments','candidates','trial groups','表示'))+'</tr>'+''.join(rows)+'</table></div><iframe id="view" title="統合表示"></iframe><script>const buttons=[...document.querySelectorAll("[data-view]")];for(const b of buttons)b.addEventListener("click",()=>{document.getElementById("view").src=b.dataset.view});if(buttons.length)buttons[0].click();</script></html>'
 (root/'index.html').write_text(page,encoding='utf8')
