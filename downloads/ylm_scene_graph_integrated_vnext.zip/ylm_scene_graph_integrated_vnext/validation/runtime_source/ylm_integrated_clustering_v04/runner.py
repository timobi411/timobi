"""Isolated bounded internal workers. One acquisition registry, one public run."""
import os,sys,shutil,subprocess,time,platform,signal
from .util import *
from .config import load
from .ingest import registry

def worker(jobpath,logpath,res,seconds,root):
 env=dict(os.environ);env['PYTHONPATH']=str(Path(__file__).resolve().parent.parent)
 for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):env[k]='1'
 start=time.monotonic();peak=0;reason=None;disk_next=0
 with Path(logpath).open('w',encoding='utf8') as log:
  p=subprocess.Popen([sys.executable,'-m','ylm_integrated_clustering_v04._worker',str(jobpath)],stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  while p.poll() is None:
   elapsed=time.monotonic()-start;stat=Path(f'/proc/{p.pid}/status')
   if stat.exists():
    try:
     rss=next((int(line.split()[1])*1024 for line in stat.read_text().splitlines() if line.startswith('VmRSS:')),0);peak=max(peak,rss)
     if rss>res['max_working_mb']*1024**2:reason='RSS_LIMIT'
    except FileNotFoundError:pass
   if elapsed>seconds:reason='WALL_TIME_LIMIT'
   if elapsed>=disk_next:
    disk_next=elapsed+2
    if directory_bytes(root)>res['disk_budget_gib']*1024**3:reason='DISK_LIMIT'
   if reason:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    p.wait();break
   time.sleep(.1)
 if directory_bytes(root)>res['disk_budget_gib']*1024**3:reason='DISK_LIMIT'
 rp=Path(jobpath).with_suffix('.resources.json');own=read(rp) if rp.exists() else {}
 reason=reason or own.get('resource_failure')
 failure=Path(read(jobpath)['out'])/'failure.json'
 if not reason and failure.exists() and read(failure).get('status')=='FAILED_RESOURCE':reason='WORKER_RESOURCE_ERROR'
 return {'returncode':p.returncode,'resource_failure':reason,'elapsed_seconds':time.monotonic()-start,'peak_observed_rss_mib':max(peak/1024**2,own.get('peak_rss_mib',0)) or None,'worker_resource_report':own,'rss_sampling_seconds':.2,'disk_sampling_seconds':2,'disk_budget_semantics':'monitored cap; in-flight write may temporarily overshoot','hard_virtual_allocation_guard':own.get('guard',{}).get('enforced',False),'log':str(Path(logpath).relative_to(root))}

def run(config_path,out,base=None):
 c=load(config_path,base);out=Path(out).resolve();items,bindings=registry(c)
 for case in c['cases']:
  for value in (case['input']['path'],case.get('baseline_dir')):
   if value and (out==Path(value).resolve() or out.is_relative_to(Path(value).resolve())):raise ValueError('Output must be outside inputs')
 out.mkdir(parents=True,exist_ok=False);write(out/'config.json',c);write(out/'input_registry.json',{'inputs':items,'bindings':bindings})
 snap=out/'code_snapshot';shutil.copytree(Path(__file__).parent,snap,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 m={'schema_version':SCHEMA,'version':'0.4.0','status':'RUNNING','created_utc':utc(),'output_root_at_creation':str(out),'config_sha256':sha(out/'config.json'),'code_hashes':{str(p.relative_to(snap)):sha(p) for p in sorted(snap.rglob('*.py'))},'imports':check_private_imports(),'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':__import__('scipy').__version__},'resource_policy':c['resources'],'scope':c['scope'],'inputs':{},'conditions':[],'workers':[],'object_identity':'UNKNOWN','automatic_object_merges':0,'unmeasured_points_generated':0,'independent_accuracy_evaluation':False}
 write(out/'run_manifest.json',m);jobs=out/'_jobs';jobs.mkdir()
 for name in ('logs','inputs','cases'):(out/name).mkdir()
 for key,item in items.items():
  j=jobs/('input_'+key+'.json');write(j,{'kind':'ingest','item':item,'out':str(out/'inputs'/key),'resources':c['resources']});print('Acquire once:',key,item['kind'],flush=True)
  wr=worker(j,out/'logs'/(key+'.log'),c['resources'],c['resources']['max_ingest_seconds'],out);m['workers'].append(wr);report=out/'inputs'/key/'acquisition.json'
  m['inputs'][key]=read(report) if wr['returncode']==0 and not wr['resource_failure'] and report.exists() else {'status':'FAILED_ACQUISITION','worker':wr,'source_path':item['path']};write(out/'run_manifest.json',m)
 stop=False
 for case in c['cases']:
  key=bindings[case['name']];dest=out/'cases'/case['name'];wr=None
  if not stop and m['inputs'][key]['status']=='READY':
   j=jobs/('case_'+case['name']+'.json');write(j,{'kind':'case','case':case,'config':c,'out':str(dest),'cache':str(out/'inputs'/key),'resources':c['resources']});print('Process:',case['name'],flush=True)
   wr=worker(j,out/'logs'/(case['name']+'.log'),c['resources'],c['resources']['max_case_seconds'],out);m['workers'].append(wr)
  success=wr is not None and wr['returncode']==0 and not wr['resource_failure'] and (dest/'evaluation.json').exists()
  if success:entries=read(dest/'evaluation.json')['conditions']
  else:
   entries=[]
   for w in c['windows']:
    for b in c['boundary_values']:
     name='boundary_'+str(b).lower();saved=dest/w/name/'integrated_evaluation.json'
     if saved.exists():entries.append(read(saved));continue
     entries.append({'case':case['name'],'window':w,'boundary':name,'status':'NOT_RUN_STOP_AFTER_FAILURE' if stop else 'FAILED_RESOURCE' if wr and wr['resource_failure'] else 'FAILED_PROCESSING' if wr else 'FAILED_ACQUISITION','worker':wr,'failure_record':str((dest/'failure.json').relative_to(out)) if (dest/'failure.json').exists() else None})
   if not c['execution']['continue_on_error']:stop=True
  m['conditions'].extend(entries);write(out/'run_manifest.json',m)
 complete=sum(x['status']=='COMPLETED_DIAGNOSTIC' for x in m['conditions']);expected=len(c['cases'])*len(c['windows'])*len(c['boundary_values'])
 m.update(status='COMPLETED_ALL' if complete==expected else 'COMPLETED_PARTIAL',completed_conditions=complete,expected_conditions=expected,bag_message_scans=sum(x.get('message_scan_count',0) for x in m['inputs'].values()),distinct_bags=sum(x['kind']=='bag' for x in items.values()),finished_utc=utc());write(out/'run_manifest.json',m)
 from .viewer import comparison
 comparison(out,m);(out/'checkpoint.txt').write_text('YLM integrated v0.4\n'+m['status']+f' {complete}/{expected}\nVerify before index.html. Missing is not successful. Rerun into a new directory.\nObject identity UNKNOWN. No ICP/motion update.\n')
 m['output_sha256']={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p!=out/'run_manifest.json'};m['storage_bytes']=directory_bytes(out);write(out/'run_manifest.json',m)
 if c['execution']['verify_at_end']:
  from .verify import verify
  r=verify(out);print('Verification:',r['status'],flush=True)
  if r['status']!='PASS':raise ValueError('See verification.json')
 return m
