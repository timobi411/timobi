"""Non-destructive export of verified partial checkpoints; no extra ICP or GT."""
import shutil
from pathlib import Path
import numpy as np
from .core import *
from .pipeline import verify,hashes
from .observation import load_observation
from .assignment import assign
from .graph import proposal
from .viewer import render

def finalize(source,out):
 source=Path(source).resolve();out=Path(out).resolve();verify(source);require(not out.exists(),'Finalization output must be new');require(not out.is_relative_to(source),'Export outside original run');c=read(source/'resolved_config.json');m=read(source/'run_manifest.json')
 require(all((source/f'observation_{i}/complete.json').exists() for i in range(2)),'Both observation stages must be complete; resume original processing first')
 out.mkdir(parents=True);stages=[];observations=[]
 for name in ['inputs','observation_0','observation_1']:
  shutil.copytree(source/name,out/name)
 for name in ['resolved_config.json','input_manifest.json','source_inventory.json','environment.json','non_destructive_verification.json']:
  if (source/name).exists():shutil.copy2(source/name,out/name)
 write(out/'parent_run_manifest.json',m);write(out/'parent_artifact_hashes.json',read(source/'artifact_hashes.json'));write(out/'finalization_source_inventory.json',sources());write(out/'finalization_environment.json',environment())
 for i,o in enumerate(c['observations']):
  obs=load_observation(o,out);folder=out/f'observation_{i}';obs['arrays']['structure_mask']=load(folder/'masks.npz')['combined'];observations.append(obs);stages.append({'fragments':read(folder/'fragments.json'),'candidates':[json.loads(s) for s in (folder/'candidates.jsonl').read_text().splitlines()],'audit':read(folder/'candidate_audit.json'),'labels':load(folder/'labels.npz')})
 sc=[x for x in stages[0]['candidates'] if x['registration_eligible']];tc=[x for x in stages[1]['candidates'] if x['registration_eligible']];status=np.zeros((len(sc),len(tc)),np.uint8)
 for i,s in enumerate(sc):
  for j,t in enumerate(tc):
   if c['gates']['obb_center']['enabled'] and np.linalg.norm(np.array(s['obb']['center'])-t['obb']['center'])>c['gates']['obb_center']['threshold']:status[i,j]=1
 cp=read(source/'registration_checkpoint.json') if (source/'registration_checkpoint.json').exists() else {'completed':[]};pairs=[];newcp=[];imported=[]
 for item in cp['completed']:
  path=source/item['path'];require(sha(path)==item['sha256'],'Checkpoint pair changed');p=read(path);i,j=item['source_index'],item['target_index'];require(p['source_candidate_key']==sc[i]['candidate_key'] and p['target_candidate_key']==tc[j]['candidate_key'],'Checkpoint candidate mismatch');require(status[i,j]!=2,'Duplicate checkpoint pair');status[i,j]=2
  semantic=digest(p);write_compact(out/item['path'],p);require(digest(read(out/item['path']))==semantic,'Compaction changed JSON values');newcp.append({**item,'sha256':sha(out/item['path'])});imported.append({'path':item['path'],'source_file_sha256':item['sha256'],'export_file_sha256':sha(out/item['path']),'canonical_json_sha256':semantic,'values_identical':True});pairs.append({k:v for k,v in p.items() if k!='hypotheses'})
 write(out/'registration_checkpoint.json',{'completed':newcp});write(out/'checkpoint_import.json',{'source_run':m['run_id'],'source_manifest_sha256':sha(source/'run_manifest.json'),'no_registration_recomputed':True,'pairs':imported})
 complete=bool(not (status==0).any());candidate_complete=all(s['audit']['generation_complete'] for s in stages);budget=Budget({'wall_seconds':300,'rss_mib':4096});cands=[x for s in stages for x in s['candidates']];assignment=assign(pairs,cands,c['assignment'],complete and candidate_complete,budget);graph=proposal(c,out,observations,cands,pairs,assignment,m['run_id']);lines(out/'pairs.jsonl',pairs);write(out/'assignment.json',assignment);write(out/'graph_proposal.json',graph);npz(out/'pair_inventory.npz',status=status)
 counts={'candidate_processing_complete':candidate_complete,'requested_pair_evaluation_complete':complete,'total_pairs':int(status.size),'enumerated_pairs':int(status.size),'evaluated_pairs':int((status==2).sum()),'excluded_by_profile':int((status==1).sum()),'not_evaluated':int((status==0).sum()),'source_candidates':len(sc),'target_candidates':len(tc),'source_evaluated_counts':[int((r==2).sum()) for r in status],'source_index':[x['candidate_key'] for x in sc],'target_index':[x['candidate_key'] for x in tc],'status_codes':{'0':'NOT_EVALUATED_BUDGET','1':'EXCLUDED_BY_PROFILE_OBB_CENTER','2':'EVALUATED_SEE_PAIR_RECORD'},'reservation_fulfilled':[int((r==2).sum())>=min(c['registration']['per_source_reservation'],int((r!=1).sum())) for r in status],'selected_pairs':len(assignment['selected']),'stop_reason':m.get('stop_reason'),'automatic_identity_accuracy':None,'graph_modified':False,'source_processing_resources':m['attempts'][-1]['resources'],'export_resources':budget.stats(),'no_extra_icp_performed':True}
 write(out/'evaluation.json',counts);render(out,observations,stages,pairs,assignment,c);write(out/'run_manifest.json',{**m,'status':'COMPLETE' if complete and candidate_complete and assignment['optimality_proven'] else 'PARTIAL','derived_finalization':True,'candidate_processing_complete':candidate_complete,'requested_pair_evaluation_complete':complete,'resume_policy':'Resume original run under its recorded runtime, or start a new current-version run','finalization_provenance':'checkpoint_import.json'});write(out/'artifact_hashes.json',hashes(out));verify(out);return counts
