import copy,shutil,time
from pathlib import Path
import numpy as np
from .core import *
from .config import resolve
from .observation import input_paths,load_observation
from .walls import detect
from .fragments import cluster
from .candidates import generate
from .registration import register
from .assignment import assign
from .graph import proposal

def hashes(out):
 return {str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ['artifact_hashes.json','run.lock'] and not p.name.endswith('.tmp')}
def verify(out):
 out=Path(out);manifest=read(out/'artifact_hashes.json')
 for path,h in manifest.items():require((out/path).is_file() and sha(out/path)==h,'Artifact changed: '+path)
 c=read(out/'resolved_config.json')
 from .verification import check_claims
 check_claims(c,out)
 for p in input_paths(c,out):require(p.is_file(),'Snapshot missing: '+str(p))
 return {'passed':True,'files':len(manifest),'run_id':read(out/'run_manifest.json')['run_id']}
def snapshot(c,base,out):
 paths=input_paths(c,base);mapped={};inventory=[]
 for p in paths:
  require(p.is_file(),'Missing input: '+str(p));h=sha(p);dest=out/'inputs'/(h[:20]+'_'+p.name);dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest);mapped[str(p)]=str(dest.relative_to(out));inventory.append({'source_path':str(p),'snapshot':str(dest.relative_to(out)),'sha256':h,'bytes':p.stat().st_size})
 def path(v):return mapped[str((base/v).resolve())]
 result=copy.deepcopy(c)
 for o in result['observations']:
  for k in ['observation','mask','edges','edge_config','labels','history','history_config']:
   if o.get(k):o[k]=path(o[k])
 for section,key in [('frame','evidence'),('gravity','evidence'),('calibration','record'),('graph','path')]:
  if result[section].get(key):result[section][key]=path(result[section][key])
 for m in result['object_models']:m['path']=path(m['path'])
 write(out/'input_manifest.json',inventory);return result

def assert_budget(out,budget):
 budget.check()
 if sum(p.stat().st_size for p in out.rglob('*') if p.is_file())>budget.c['max_output_mib']*1024**2:raise Stop('OUTPUT_MIB')

def run(config_path,out,resume=False,additional_pairs=None):
 import fcntl
 out=Path(out).resolve();original=resolve(read(config_path));base=Path(config_path).resolve().parent
 from .verification import check_claims
 check_claims(original,base)
 originals={str(p):sha(p) for p in input_paths(original,base)};source=sources();fingerprint=digest({'config':original,'inputs':originals,'sources':source})
 if out.exists():
  require(resume,'Output already exists; use --resume');m=read(out/'run_manifest.json')
  require(not m.get('derived_finalization'),'Resume the original run, not a finalized export')
  if (out/'artifact_hashes.json').exists():verify(out)
  require(m['fingerprint']==fingerprint,'Resume input/config/code mismatch')
 else:
  out.mkdir(parents=True);c=snapshot(original,base,out);write(out/'resolved_config.json',c);write(out/'source_inventory.json',source);write(out/'environment.json',environment());write(out/'run_manifest.json',{'schema':'ylm.next.run.v1','run_id':'run:'+fingerprint[:20],'fingerprint':fingerprint,'status':'RUNNING','units':'m','seed':c['seed'],'attempts':[]})
 with (out/'run.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  c=read(out/'resolved_config.json');check_claims(c,out);m=read(out/'run_manifest.json');runid=m['run_id'];budget=Budget(c['resources']);observations=[load_observation(o,out) for o in c['observations']];stage_data=[];stop_reason=None
  reserve=out/'.diagnostic_reserve'
  reserve.write_bytes(bytes(1024*1024))
  try:
   for index,obs in enumerate(observations):
    folder=out/f'observation_{index}';folder.mkdir(exist_ok=True)
    if (folder/'complete.json').exists():
     stage_checkpoint=read(folder/'complete.json')
     for filename,h in stage_checkpoint['hashes'].items():require(sha(folder/filename)==h,'Stage checkpoint changed: '+filename)
     rows=read(folder/'fragments.json');cands=[json.loads(x) for x in (folder/'candidates.jsonl').read_text().splitlines()];audit=read(folder/'candidate_audit.json');labels=load(folder/'labels.npz');masked=load(folder/'masks.npz')['combined'];obs['arrays']['structure_mask']=masked
    else:
     assert_budget(out,budget);additional,wall_report=detect(obs['arrays'],c['wall'],c['gravity'],c['seed'],budget);original_mask=obs['arrays']['structure_mask'].copy();combined=original_mask|additional
     npz(folder/'observation.npz',**obs['arrays']);npz(folder/'masks.npz',original=original_mask,additional=additional,combined=combined);write(folder/'walls.json',wall_report)
     rows,labels,edges,lineage=cluster(obs,combined,c['clustering'],runid);obs['arrays']['structure_mask']=combined
     npz(folder/'edges.npz',**edges);npz(folder/'labels.npz',**labels);write(folder/'fragments.json',rows);write(folder/'lineage.json',lineage)
     cands,audit=generate(obs,rows,labels['final'],c['candidate'],c['boundary'],c['manual_candidates'],runid,budget)
     from .candidates import spatial_diagnostic
     spatial,spatial_lineage=spatial_diagnostic(labels['final'],audit)
     labels['spatial_proposal']=spatial;npz(folder/'labels.npz',**labels);lineage['spatial_proposal']=spatial_lineage;write(folder/'lineage.json',lineage)
     if c['object_models']:
      from .models import assess
      for cand in cands:cand['model_info']=assess(cand,obs['arrays']['xyz'].reshape(-1,3)[cand['pixel_ids']],c['object_models'],out)
     lines(folder/'candidates.jsonl',cands);write(folder/'candidate_audit.json',audit);write(folder/'complete.json',{'candidate_processing_complete':audit['generation_complete'],'run_id':runid,'hashes':{str(p.relative_to(folder)):sha(p) for p in folder.rglob('*') if p.is_file() and p.name!='complete.json'}})
    stage_data.append({'fragments':rows,'candidates':cands,'audit':audit,'labels':labels})
   source_c=[x for x in stage_data[0]['candidates'] if x['registration_eligible']];target_c=[x for x in stage_data[1]['candidates'] if x['registration_eligible']];candidate_complete=all(x['audit']['generation_complete'] for x in stage_data)
   # Matrix codes preserve every pair without serializing a million repeated keys.
   status=np.zeros((len(source_c),len(target_c)),np.uint8);queues=[]
   for i,s in enumerate(source_c):
    center=np.asarray(s['obb']['center']);distance=np.array([np.linalg.norm(center-t['obb']['center']) for t in target_c]);order=np.argsort(distance,kind='stable');excluded=(distance>c['gates']['obb_center']['threshold']) if c['gates']['obb_center']['enabled'] else np.zeros(len(distance),bool);status[i,excluded]=1;queues.append([int(j) for j in order if not excluded[j]])
   pairs=[]
   checkpoint=out/'registration_checkpoint.json'
   if checkpoint.exists():
    cp=read(checkpoint)
    for row in cp['completed']:
     p=read(out/row['path']);require(sha(out/row['path'])==row['sha256'],'Pair checkpoint changed');pairs.append(p);status[row['source_index'],row['target_index']]=2
   completed=read(checkpoint)['completed'] if checkpoint.exists() else [];executed=0;limit=additional_pairs or c['registration']['max_pairs']
   sa=observations[0]['arrays']['xyz'].reshape(-1,3);ta=observations[1]['arrays']['xyz'].reshape(-1,3)
   # Round-robin reserves one slot per source before allocating a second.
   rounds=max((len(q) for q in queues),default=0)
   for rank in range(rounds):
    for i,q in enumerate(queues):
     if rank>=len(q):continue
     j=q[rank]
     if status[i,j]==2:continue
     if executed>=limit:stop_reason='PAIR_BUDGET';break
     assert_budget(out,budget);p=register(source_c[i],target_c[j],sa,ta,c,budget);p.update(source_index=i,target_index=j);filename='registration/'+p['pair_id'].replace(':','_')+'.json';write_compact(out/filename,p);completed.append({'source_index':i,'target_index':j,'path':filename,'sha256':sha(out/filename)});write(checkpoint,{'completed':completed});pairs.append(p);status[i,j]=2;executed+=1
    if stop_reason:break
   pair_complete=not (status==0).any();all_candidates=[r for d in stage_data for r in d['candidates']];assignment=assign(pairs,all_candidates,c['assignment'],pair_complete and candidate_complete,budget);graph=proposal(c,out,observations,all_candidates,pairs,assignment,runid)
   lines(out/'pairs.jsonl',[{k:v for k,v in p.items() if k!='hypotheses'} for p in pairs]);write(out/'assignment.json',assignment);write(out/'graph_proposal.json',graph);npz(out/'pair_inventory.npz',status=status)
   counts={'candidate_processing_complete':candidate_complete,'requested_pair_evaluation_complete':pair_complete,'source_candidates':len(source_c),'target_candidates':len(target_c),'total_pairs':int(status.size),'enumerated_pairs':int(status.size),'evaluated_pairs':int((status==2).sum()),'excluded_by_profile':int((status==1).sum()),'not_evaluated':int((status==0).sum()),'source_evaluated_counts':[int((r==2).sum()) for r in status],'per_source_reservation_requested':c['registration']['per_source_reservation'],'reservation_fulfilled':[int((r==2).sum())>=min(c['registration']['per_source_reservation'],int((r!=1).sum())) for r in status],'status_codes':{'0':'NOT_EVALUATED_BUDGET','1':'EXCLUDED_BY_PROFILE_OBB_CENTER','2':'EVALUATED_SEE_PAIR_RECORD'},'source_index':[x['candidate_key'] for x in source_c],'target_index':[x['candidate_key'] for x in target_c],'selected_pairs':len(assignment['selected']),'automatic_identity_accuracy':None,'manual_pairs_evaluated':sum(p['manual_origin'] for p in pairs),'graph_modified':False,'stop_reason':stop_reason,'resources':budget.stats()}
   write(out/'evaluation.json',counts)
   from .viewer import render
   render(out,observations,stage_data,pairs,assignment,c)
   m.update(status='COMPLETE' if pair_complete and candidate_complete and assignment['optimality_proven'] else 'PARTIAL',candidate_processing_complete=candidate_complete,requested_pair_evaluation_complete=pair_complete,stop_reason=stop_reason)
  except (Stop,OSError) as exc:
   if isinstance(exc,OSError) and exc.errno not in [12,28]:raise
   reserve.unlink(missing_ok=True)
   stop_reason=str(exc) if isinstance(exc,Stop) else 'OS_RESOURCE:'+str(exc.errno)
   candidates_done=len(stage_data)==2 and all(x['audit']['generation_complete'] for x in stage_data)
   m.update(status='PARTIAL',stop_reason=stop_reason,candidate_processing_complete=candidates_done,requested_pair_evaluation_complete=False)
   write(out/'evaluation.json',{'candidate_processing_complete':candidates_done,'requested_pair_evaluation_complete':False,'not_evaluated_reason':stop_reason,'completed_pair_count':len(read(out/'registration_checkpoint.json')['completed']) if (out/'registration_checkpoint.json').exists() else 0,'graph_modified':False,'resources':budget.stats()})
   write(out/'interruption.json',{'reason':stop_reason,'completed_observation_stages':len(stage_data),'resume':'Completed stages and per-pair checkpoints are reused','resources':budget.stats()})
  reserve.unlink(missing_ok=True)
  m['attempts'].append({'budget_pairs':additional_pairs or c['registration']['max_pairs'],'resources':budget.stats(),'stop_reason':stop_reason});write(out/'run_manifest.json',m)
  require(all(sha(p)==h for p,h in originals.items()),'Original input changed during run');write(out/'non_destructive_verification.json',{'passed':True,'source_hashes':originals});write(out/'artifact_hashes.json',hashes(out))
 return m
