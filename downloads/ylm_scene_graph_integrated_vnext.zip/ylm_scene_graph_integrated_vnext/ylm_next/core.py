import hashlib,json,os,time,resource,platform,importlib.metadata
from pathlib import Path
import numpy as np

def clean(x):
 if isinstance(x,np.ndarray):return clean(x.tolist())
 if isinstance(x,np.generic):return clean(x.item())
 if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [clean(v) for v in x]
 if isinstance(x,float) and not np.isfinite(x):raise ValueError('Non-finite JSON value')
 return x

def read(p):return json.loads(Path(p).read_text(),parse_constant=lambda s:(_ for _ in ()).throw(ValueError(s)))
def write(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp')
 tmp.write_text(json.dumps(clean(x),ensure_ascii=False,indent=2,allow_nan=False));os.replace(tmp,p)
def lines(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp')
 tmp.write_text(''.join(json.dumps(clean(v),ensure_ascii=False,allow_nan=False)+'\n' for v in x));os.replace(tmp,p)
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def digest(x):return hashlib.sha256(json.dumps(clean(x),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def npz(p,**kw):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.with_name(p.name+'.tmp').open('wb') as f:np.savez_compressed(f,**kw)
 os.replace(p.with_name(p.name+'.tmp'),p)
def load(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def require(v,s):
 if not v:raise ValueError(s)
def transform(p,t):return np.asarray(p)@np.asarray(t)[:3,:3].T+np.asarray(t)[:3,3]
def matrix(t):
 t=np.asarray(t,float);require(t.shape==(4,4) and np.isfinite(t).all(),'Finite 4x4 transform required')
 require(np.allclose(t[3],[0,0,0,1]) and np.allclose(t[:3,:3].T@t[:3,:3],np.eye(3),atol=1e-6) and abs(np.linalg.det(t[:3,:3])-1)<1e-6,'Rigid transform required');return t

def obb(p):
 p=np.asarray(p,float);n=len(p)
 if not n:return {'method':'DEGENERATE','point_count':0,'rank':0,'center':None,'rotation':None,'extent':None,'vertices':[]}
 require(np.isfinite(p).all(),'Non-finite OBB points');mean=p.mean(0);rank=int(np.linalg.matrix_rank(p-mean,tol=1e-9));r=np.eye(3)
 if rank==3:
  _,r=np.linalg.eigh((p-mean).T@(p-mean));r=r[:,::-1]
  if np.linalg.det(r)<0:r[:,-1]*=-1
 q=(p-mean)@r;lo=q.min(0);hi=q.max(0);center=mean+r@((lo+hi)/2);extent=hi-lo
 corners=np.array([[a,b,c] for a in [-.5,.5] for b in [-.5,.5] for c in [-.5,.5]])*extent
 return clean({'method':'PCA_OBB' if rank==3 else 'AABB_FALLBACK','rank':rank,'point_count':n,'center':center,'rotation':r,'extent':extent,'vertices':corners@r.T+center})

class Stop(RuntimeError):pass
class Budget:
 def __init__(self,c):self.c=c;self.start=time.monotonic()
 def check(self):
  if time.monotonic()-self.start>=self.c['wall_seconds']:raise Stop('WALL_SECONDS')
  if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024>self.c['rss_mib']:raise Stop('RSS_MIB')
 def stats(self):return {'wall_seconds':time.monotonic()-self.start,'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024}
def environment():
 return {'python':platform.python_version(),'platform':platform.platform(),'packages':{k:importlib.metadata.version(k) for k in ['numpy','scipy','open3d','plotly','jsonschema']},'numeric_threads':{k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']}}
def sources():
 root=Path(__file__).resolve().parents[1]
 return {str(p.relative_to(root)):sha(p) for package in ['ylm_next','ylm06','ylm_integrated_clustering_v04'] for p in sorted((root/package).rglob('*')) if p.is_file() and p.suffix in ['.py','.json']}

def write_compact(p,x):
 """Identical JSON values; avoid megabytes of indentation in per-trial point IDs."""
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp')
 tmp.write_text(json.dumps(clean(x),ensure_ascii=False,separators=(',',':'),allow_nan=False));os.replace(tmp,p)
