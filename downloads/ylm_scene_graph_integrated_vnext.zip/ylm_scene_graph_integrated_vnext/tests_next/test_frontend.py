import unittest,tempfile
from pathlib import Path
import numpy as np
from ylm_next.core import *
class FrontendTests(unittest.TestCase):
 def test_finite_wall_support_not_infinite_plane(self):
  from ylm_next.walls import finite_support_mask,fit
  y,z=np.meshgrid(np.linspace(-.8,.8,24),np.linspace(0,1.6,24));wall=np.column_stack([np.zeros(y.size),y.ravel(),z.ravel()]);points=np.vstack([wall,[[.01,10,10],[1,0,0]]]);center,normal,residual,basis=fit(wall);mask=finite_support_mask(points,wall,center,normal,basis,.04,.18);self.assertEqual(int(mask.sum()),len(wall));self.assertFalse(mask[-2]);self.assertFalse(mask[-1])
 def test_history_measured_provenance(self):
  from ylm_integrated_clustering_v04._vendor.organized_v01.demo import fixture,config
  from ylm_next.temporal import integrate_history
  a,_=fixture();a['range']=np.linalg.norm(a['xyz'],axis=-1);a['invalid_reason']=np.where(a['valid'],0,1).astype(np.uint16)
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);npz(root/'history.npz',**a);write(root/'config.json',config());r=integrate_history(root/'history.npz',root/'config.json',5,root/'out');self.assertEqual(r['status'],'COMPLETE');b=load(root/'out/integrated_observation.npz');y,x=np.where(b['valid']);np.testing.assert_array_equal(b['xyz'][y,x],a['xyz'][b['source_sample_index'][y,x],y,x]);self.assertTrue((root/'out/missing_classification.npz').exists())
if __name__=='__main__':unittest.main()
