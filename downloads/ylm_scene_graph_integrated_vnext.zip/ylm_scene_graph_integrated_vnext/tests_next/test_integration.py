import unittest,tempfile,json,copy
from pathlib import Path
import numpy as np
from ylm_next.core import *
from ylm_next.config import defaults,resolve
from ylm_next.registration import register
from ylm_next.assignment import assign
from ylm_next.fragments import cluster
from ylm_next.candidates import boundary,generate
from ylm_next.observation import load_observation

def candidate(key,pts,parts=None,origin='AUTO_SINGLE'):
 ids=list(range(len(pts)));return {'candidate_key':key,'observation_id':key,'fragment_keys':list(parts or {key:ids}),'fragment_labels':[0],'pixel_ids':ids,'point_count':len(pts),'parts':parts or {key:ids},'obb':obb(pts),'origin':origin,'boundary_state':'SINGLETON'}
def cfg():
 c=defaults();c['registration'].update(voxel_m=0.,iterations=60,yaw_degrees=[0]);c['gates']['assignment_size']['enabled']=False;c['gates']['obb_size']['enabled']=False;return c
class TestRegistration(unittest.TestCase):
 def setUp(self):self.rng=np.random.default_rng(42);self.a=self.rng.uniform(-.3,.3,(180,3));self.c=cfg()
 def runpair(self,a,b,c=None,parts=None):return register(candidate('a',a,parts),candidate('b',b),a,b,c or self.c,Budget((c or self.c)['resources']))
 def test_identity(self):
  p=self.runpair(self.a,self.a);self.assertTrue(p['valid']);self.assertLess(p['motion']['estimated_center_movement_m'],1e-8);self.assertEqual(p['motion_status'],'UNKNOWN')
 def test_known_translation(self):
  b=self.a+[.2,-.1,.05];p=self.runpair(self.a,b);self.assertLess(np.linalg.norm(np.array(p['motion']['estimated_center_displacement_m'])-[.2,-.1,.05]),1e-5)
 def test_partial(self):
  b=self.a[:130]+[.15,0,0];p=self.runpair(self.a,b);self.assertLess(abs(p['motion']['estimated_center_movement_m']-.15),.02)
 def test_zero_correspondence_rmse_null(self):
  from ylm_next.registration import support
  m=support(self.a,self.a+100,np.eye(4),.01);self.assertIsNone(m['rmse_m']);self.assertEqual(m['reason'],'NO_CORRESPONDENCE')
 def test_degenerate(self):
  for a in [np.empty((0,3)),np.zeros((1,3)),np.column_stack([np.arange(20),np.zeros((20,2))])]:
   p=self.runpair(a,a);self.assertFalse(p['valid']);self.assertEqual(p['evaluation_status'],'DEGENERATE')
 def test_nan_rejected(self):
  from ylm_next.core import obb
  with self.assertRaises(ValueError):obb(np.array([[float('nan'),0,0]]))
 def test_large_tilt_gate(self):
  t=np.eye(4);theta=np.radians(75);t[1:3,1:3]=[[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]]
  from ylm_next.registration import evidence,component_support,support
  b=transform(self.a,t);sa=candidate('a',self.a);sb=candidate('b',b);parts=component_support(sa,sb,self.a,b,t,.08);g,m=evidence(sa,sb,support(self.a,b,t,.08),t,parts,self.c,self.c['gravity']);self.assertFalse(g['pose']['pass']);self.assertTrue(g['shape']['pass'])
 def test_small_part_absorption(self):
  a=np.vstack([self.a,[[2,0,0],[2,.1,0],[2,0,.1]]]);parts={'main':list(range(180)),'small':[180,181,182]};p=self.runpair(a,self.a,parts=parts);self.assertFalse(p['gates']['part_support']['pass']);self.assertEqual(p['component_support']['source'][1]['coverage'],0.)
 def test_normalize_old_invalid(self):
  from ylm06.registration import normalize_legacy
  p=normalize_legacy({'valid':False,'evaluation_status':'NOT_EVALUATED','transformation':np.eye(4).tolist()});self.assertFalse(p['legacy_valid']);self.assertEqual(p['evaluation_status'],'NOT_EVALUATED');self.assertNotEqual(p['motion_status'],'MOVED')
 def test_diagnostic_4dof_requires_gravity(self):
  c=defaults();c['observations']=[{'observation_id':'a'},{'observation_id':'b'}];c['registration']['route']='diagnostic_4dof'
  with self.assertRaises(ValueError):resolve(c)
class TestAssignment(unittest.TestCase):
 def test_overlap_both_sides_and_top2(self):
  p=np.random.default_rng(5).normal(size=(10,3));a=candidate('a',p);b=candidate('b',p);aa=copy.deepcopy(a);aa['candidate_key']='aa';bb=copy.deepcopy(b);bb['candidate_key']='bb';rows=[]
  for i,s,t in [(1,'a','b'),(2,'aa','bb')]:rows.append({'pair_id':str(i),'source_candidate_key':s,'target_candidate_key':t,'valid':True,'candidate_status':'ELIGIBLE','utility':.2})
  c=defaults();r=assign(rows,[a,b,aa,bb],c['assignment'],True,Budget(c['resources']));self.assertEqual(len(r['selected']),1);self.assertEqual(len(r['second']['selected']),1);self.assertEqual(r['utility_gap'],0.);self.assertEqual(r['status'],'AMBIGUOUS')
 def test_budget_hold(self):
  c=defaults();r=assign([],[],c['assignment'],False,Budget(c['resources']));self.assertEqual(r['status'],'AMBIGUOUS')
class TestFragment(unittest.TestCase):
 def test_local_only_relaxes_two_flags(self):
  xyz=np.array([[[0,0,1],[.02,0,1],[.04,0,1],[.06,0,1]]]);v=np.ones((1,4),bool);a={'valid':v,'xyz':xyz,'xyz_observation':xyz,'support_count':np.ones_like(v,int),'source_type':np.ones_like(v,int)};e={'pixel_i':np.array([0,1,2]),'pixel_j':np.array([1,2,3]),'hold_reason':np.array([8,32,4]),'accepted':np.zeros(3,bool),'alpha_rad':np.full(3,.02),'beta_rad':np.full(3,1.),'distance_m':np.full(3,.02),'pass_geometry':np.zeros(3,bool)};c=defaults()['clustering'];obs={'arrays':a,'metadata':{'observation_id':'o'},'edges':e,'edge_config':{'clustering':c},'parent_labels':None};f,l,ee,line=cluster(obs,np.zeros_like(v),c,'r');self.assertEqual(l['local'][0,0],l['local'][0,2]);self.assertNotEqual(l['local'][0,2],l['local'][0,3]);self.assertEqual(int(ee['relaxed'].sum()),2)
 def test_missing_boundary_held(self):
  v=np.array([[True,False,True]]);a={'range':np.ones((1,3)),'valid':v,'structure_mask':np.zeros_like(v),'xyz':np.zeros((1,3,3))};r=boundary(a,0,1,np.array([[0,-1,1]]),defaults()['boundary']);self.assertEqual(r['status'],'UNRESOLVED_INSUFFICIENT_BOUNDARY_SUPPORT')
 def test_strong_boundary(self):
  labels=np.tile(np.repeat([0,1],12),(12,1));v=np.ones_like(labels,bool);ranges=np.where(labels==0,2.,2.3);xyz=np.stack([np.indices(v.shape)[1]*.01,np.indices(v.shape)[0]*.01,ranges],-1);a={'range':ranges,'valid':v,'structure_mask':~v,'xyz':xyz};r=boundary(a,0,1,labels,defaults()['boundary']);self.assertEqual(r['status'],'HELD_DEPTH_BOUNDARY')
 def test_manual_union_and_labels_unchanged(self):
  xyz=np.array([[[0,0,1],[.02,0,1],[.04,0,1],[.06,0,1]]]);labels=np.array([[0,0,1,1]]);a={'valid':np.ones((1,4),bool),'range':np.ones((1,4)),'xyz':xyz,'structure_mask':np.zeros((1,4),bool)};obs={'arrays':a,'metadata':{'observation_id':'o'}};fs=[]
  for k in [0,1]:
   ids=np.flatnonzero(labels.ravel()==k).tolist();fs.append({'label':k,'fragment_key':'f'+str(k),'pixel_ids':ids,'point_count':2,'center':xyz.reshape(-1,3)[ids].mean(0).tolist()})
  c=defaults();rows,audit=generate(obs,fs,labels,c['candidate'],c['boundary'],[{'observation_id':'o','labels':[0,1],'specified_by':'tester','specified_at':'2026-10-23','reason':'fixture'}],'run',Budget(c['resources']));manual=rows[-1];self.assertEqual(manual['pixel_ids'],[0,1,2,3]);self.assertEqual(manual['origin'],'MANUAL_COMPOSITE');np.testing.assert_array_equal(labels,[[0,0,1,1]])
 def test_coplanar_fallback(self):self.assertEqual(obb(np.array([[0,0,0],[1,0,0],[0,1,0]]))['method'],'AABB_FALLBACK')
class TestContracts(unittest.TestCase):
 def test_json_nan(self):
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaises(ValueError):write(Path(d)/'bad.json',{'v':float('nan')})
 def test_boundary_boolean(self):
  c=defaults();c['observations']=[{'observation_id':'a'},{'observation_id':'b'}];c['clustering']['hold_boundary_points']='false'
  with self.assertRaises(ValueError):resolve(c)
if __name__=='__main__':unittest.main()
