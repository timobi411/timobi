import unittest,tempfile,copy,shutil
from pathlib import Path
import numpy as np
from ylm_next.core import *
from ylm_next.pipeline import run,verify
from examples.next.make_fixture import make
class PipelineTests(unittest.TestCase):
 def test_resume_relocation_no_mutation(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);config=make(root/'input');before={str(p):sha(p) for p in (root/'input').rglob('*') if p.is_file()};first=run(config,root/'run');self.assertEqual(first['status'],'PARTIAL');cp=read(root/'run/registration_checkpoint.json');self.assertEqual(len(cp['completed']),1);pairhash=cp['completed'][0]['sha256'];second=run(config,root/'run',True,100);self.assertTrue(second['requested_pair_evaluation_complete']);self.assertEqual(read(root/'run/registration_checkpoint.json')['completed'][0]['sha256'],pairhash);self.assertTrue(verify(root/'run')['passed']);self.assertEqual(before,{str(p):sha(p) for p in (root/'input').rglob('*') if p.is_file()});shutil.copytree(root/'run',root/'relocated');self.assertTrue(verify(root/'relocated')['passed']);p=read(root/'run/graph_proposal.json');self.assertFalse(p['graph_modified']);self.assertFalse(p['can_request_apply']);self.assertTrue(all(x['state']=='UNKNOWN' for x in p['states']))
 def test_tamper_resume_refused(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);config=make(root/'input');run(config,root/'run');p=root/'run/observation_0/fragments.json';p.write_text('[]')
   with self.assertRaises(ValueError):run(config,root/'run',True)
 def test_wall_budget_recoverable(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);config=make(root/'input');c=read(config);c['resources']={'wall_seconds':.000001};write(config,c);result=run(config,root/'run');self.assertEqual(result['status'],'PARTIAL');self.assertEqual(result['stop_reason'],'WALL_SECONDS');self.assertTrue((root/'run/evaluation.json').exists());self.assertTrue(verify(root/'run')['passed'])
 def test_invalid_mask_dtype_rejected(self):
  from ylm_next.observation import load_observation
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);config=make(root);c=read(config);np.savez_compressed(root/'t0/mask.npz',structure_mask=np.zeros((12,20),np.uint8))
   with self.assertRaises(ValueError):load_observation(c['observations'][0],root)
if __name__=='__main__':unittest.main()

class GraphApplyTests(unittest.TestCase):
 def test_explicit_review_duplicate_rollback(self):
  from ylm_next.config import resolve
  from ylm_next.verification import decision_fingerprint
  from ylm_next.graph import apply,rollback
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);config=make(root/'input');c=read(config);c['registration']['max_pairs']=100;c['assignment']={'margin':0.,'motion_threshold_m':.05};c['gates']['obb_center']={'threshold':.5};c['frame']={'status':'FRAME_VERIFIED','evidence':'frame.json'};c['gravity']={'status':'VERIFIED','axis':[0,0,1],'evidence':'gravity.json'};c['calibration']={'status':'VALIDATED','record':'calibration.json'};c['graph']={'path':'graph.json'};c['observations'][0]['graph_node_map']={'0':'node:0','1':'node:1'}
   write(root/'input/frame.json',{'status':'VERIFIED','method':'KNOWN_SYNTHETIC_COORDINATES','transforms':{o['observation_id']:o['observation_to_common'] for o in c['observations']}});write(root/'input/gravity.json',{'status':'VERIFIED','method':'SYNTHETIC_AXIS','axis':[0,0,1]});write(root/'input/calibration.json',{'status':'VALIDATED','decision_fingerprint':decision_fingerprint(resolve(c)),'independent_case_ids':['synthetic_fixture_for_transaction_test_only']});graph={'nodes':[{'id':'node:'+str(i),'pose':np.eye(4).tolist(),'shape':{'tag':'old'},'custom':'preserved'} for i in range(2)],'edges':[{'source':'node:0','target':'node:1','kind':'spatial'}]};write(root/'input/graph.json',graph);write(config,c);before=sha(root/'input/graph.json');run(config,root/'run');p=read(root/'run/graph_proposal.json');self.assertTrue(p['can_request_apply'],p['hold_reasons']);write(root/'review.json',{'approved':True,'proposal_sha256':sha(root/'run/graph_proposal.json'),'reviewer':'test','reviewed_at':'2026-10-24','reason':'synthetic transaction fixture','confirmed_pairs':[x['pair_id'] for x in p['operations']]});result=apply(root/'run',root/'review.json',root/'store');self.assertEqual(result['status'],'APPLIED');self.assertEqual(sha(root/'input/graph.json'),before);new=read(result['path']);self.assertTrue(all(n['custom']=='preserved' for n in new['nodes']));self.assertTrue(any(n.get('shape',{}).get('representation')=='CURRENT_MEASURED_UNION' for n in new['nodes']))
   with self.assertRaises(ValueError):apply(root/'run',root/'review.json',root/'store')
   self.assertEqual(rollback(root/'store',p['run_id'])['status'],'ROLLED_BACK')

class ResourceCompletionTests(unittest.TestCase):
 def test_pair_resource_stop_preserves_candidate_completion(self):
  from unittest.mock import patch
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);config=make(root/'input')
   with patch('ylm_next.pipeline.assert_budget',side_effect=[None,None,Stop('TEST_PAIR_RESOURCE')]):result=run(config,root/'run')
   self.assertEqual(result['status'],'PARTIAL');self.assertTrue(result['candidate_processing_complete']);self.assertFalse(result['requested_pair_evaluation_complete']);self.assertTrue(read(root/'run/evaluation.json')['candidate_processing_complete']);self.assertFalse((root/'run/.diagnostic_reserve').exists())
 def test_enospc_releases_diagnostic_reserve(self):
  from unittest.mock import patch
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);config=make(root/'input')
   with patch('ylm_next.pipeline.assert_budget',side_effect=[None,None,OSError(28,'capacity fault injection')]):result=run(config,root/'run')
   self.assertEqual(result['stop_reason'],'OS_RESOURCE:28');self.assertTrue(verify(root/'run')['passed']);self.assertFalse((root/'run/.diagnostic_reserve').exists())

class FinalizeTests(unittest.TestCase):
 def test_partial_checkpoint_export_values_and_original_preserved(self):
  from ylm_next.finalize import finalize
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);config=make(root/'input');run(config,root/'run');before=sha(root/'run/artifact_hashes.json');result=finalize(root/'run',root/'export');self.assertEqual(result['evaluated_pairs'],1);self.assertFalse(result['requested_pair_evaluation_complete']);self.assertEqual(sha(root/'run/artifact_hashes.json'),before);self.assertTrue((root/'export/index.html').exists());self.assertTrue(verify(root/'export')['passed']);record=read(root/'export/checkpoint_import.json')['pairs'][0];self.assertTrue(record['values_identical']);self.assertEqual(read(root/'run'/record['path']),read(root/'export'/record['path']))
