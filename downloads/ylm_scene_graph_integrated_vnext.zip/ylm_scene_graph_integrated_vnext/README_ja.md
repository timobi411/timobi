# YLM vNext 統合改修版（パッケージ版 0.7.0）

2026-10-23 の `vNext-design-1` 仕様書に基づく、organized観測→壁除去→断片→複合候補→OBB→登録→競合割当→グラフ更新案の実装です。受領した研究室PC版 v0.6.1 と v0.4 のコードを残し、新規 `ylm_next` に接続しました。

実データ用設定は開発比較値です。正式校正・共通座標・重力・物理的同一性の確認を代替しません。既定では `PROPOSAL_ONLY` で、元入力・既存グラフを書き換えません。今回の実データ結果も適用保留です。

## ダウンロードと展開

本体ZIPを保存して展開してください。別配布の実験結果ZIPは、同じ場所へ展開すると `ylm_scene_graph_integrated_vnext/validation/real/` に合流します。move_clearの詳細は2つのZIPに分かれています。両方を同じ場所へ展開してください。それぞれ独立したZIPなので、ファイルの連結は不要です。GitHub上のZIPプレビューは不要です。各ZIPに対応する `.sha256` も配布します。

```bash
cd ylm_scene_graph_integrated_vnext
python3 examples/next/verify_release.py
```

本体にコード・小規模の検証・正式保存観測の実行例・回収した研究記録を同梱しています。約1.12GBの受領アーカイブ全体は再配布していません。43パートのSHA256と結合SHA256、元run・コードの証拠索引は保存しています。

## 環境

検証環境は Ubuntu 22.04 / Python 3.10、NumPy 1.26.4、SciPy 1.11.4、Open3D 0.19.0、Plotly 6.3.1、jsonschema 4.25.1 です。

```bash
sudo apt-get update
sudo apt-get install -y python3.10-venv libgl1 libgomp1 libx11-6 libglib2.0-0 libxext6 libxrender1
python3.10 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install .
python -m pip check
python -m unittest discover -s tests_next -v
python -m unittest discover -s tests -v
```

数値スレッドは `python -m ylm_next` が1に固定します。Python APIを直接使う場合は、NumPyのimport前に `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1` を設定してください。

## 実データを実行する

```bash
python -m ylm_next inspect --config examples/next/exp01/config.json
python -m ylm_next run --config examples/next/exp01/config.json --out runs/exp01
python -m ylm_next verify runs/exp01
python -m ylm_next run --config examples/next/move_clear/config.json --out runs/move_clear
```

実行後は `runs/exp01/index.html` をブラウザーで開きます。単独HTMLで表示でき、外部配信先へ点群を送信しません。環境によってローカルHTMLのWebGL表示が制限される場合は、`python -m http.server 8000 --directory runs` を起動して `http://localhost:8000/exp01/` を開いてください。

終了コード0は処理完了、2は予算等による部分完了、1は入力・実行エラーです。コード0でも同一性の確認や実グラフ更新の完了を意味しません。

既定例は各512組の詳細評価です。全候補の処理完了と全要求ペアの評価完了を別々に記録します。sourceごとに一組ずつ巡回し、次の巡回へ進みます。source数より予算が小さいときは、予約未達のsourceを記録します。

```bash
python -m ylm_next run --config examples/next/exp01/config.json --out runs/exp01 --resume --additional-pairs 512
```

完了済み観測段階と登録ペアを再利用します。入力・コード・設定が異なる場合は拒否します。場所を移した成果物の `verify` は可能ですが、`--resume` は初回の入力パスも含むfingerprintを照合します。別PCで再計算する場合は、コピーした `resolved_config.json` を指定し、別の新規runへ出力してください。

15→16cm比較は `examples/next/exp01/config_16cm.json`、move_clearの25cm・各側5点・15点以上の提案条件は `examples/next/move_clear/config_proposal25.json` です。16cmや25cmを一般的な推奨値とはしていません。

## 時間履歴から開始する

既存の正式v0.4保存観測を読む経路に加え、元の履歴NPZを凍結v0.4規則で時間統合できます。

```bash
python -m ylm_next integrate-history --history history.npz --config original_frontend_config.json --reference 5 --rows 32 --out runs/temporal
```

履歴は `xyz[F,H,W,3]`, `valid`, `range`, `invalid_reason`, frame/time/layout/setting情報を含む元v0.4契約です。出力は実測サンプルの選択で、欠測座標の補間はしません。`integrated_observation.npz` を観測設定に指定し、同じ画素配置の構造マスクを用意します。ROS bagの再取得やSLAMは今回の必須範囲に含みません。

## 登録経路と候補

`registration.route` は次の4種類です。

- `frozen_B0`: SHA256を照合した元4DOFの関数と定数。旧割当を含む再現は後述の別コマンドで実行します。
- `recovered_local_6dof`: exp02で数値再現した旧local経路。元スコア・元優勝試行と、新しいゲート判定を併記します。
- `diagnostic_6dof`: voxel0.02m、coarse0.35m、fine0.08m、80反復、yaw[-30,0,30]等の開発比較。
- `diagnostic_4dof`: 重力軸の検証記録がある場合のみ。合成例は `examples/next/synthetic/config_4dof.json`。

新診断では試行ごとに姿勢・移動・Shape・サイズ・部品支持等を評価し、通過した試行を優先します。元の互換スコアと、`minimum_coverage_minus_0.75` は別項目です。対応なしのRMSEはnullです。旧経路の生出力は再現目的でそのまま残し、旧RMSE=0を新しい良好判定に流用しません。

各断片の元画素を保持し、自動複合候補は別レイヤーです。平面／非平面の混合、非平行面を提案から除外しません。境界の支持不足は保留です。元ラベル、BASE、LOCAL、同面・境界支持付きの空間結合表示案を `labels.npz` と `lineage.json` に保存します。空間結合表示案は自動的な物体確定ではありません。

`manual_candidates` では当該runの `observation_id`, `labels`, `specified_by`, `specified_at`, `reason` を明示します。指定した断片の点集合の和だけを使い、OBB内の背景点を足しません。別runの同じ番号を同じ断片とは扱わず、先に画素系譜を確認してください。手動候補は自動成功率から除外します。

## 出力と表示

主要ファイルは `run_manifest.json`, `resolved_config.json`, `input_manifest.json`, `environment.json`, `source_inventory.json`, `artifact_hashes.json` です。

`observation_0/1` に元観測、元・追加・合成マスク、壁の全採否、保存辺、ラベル系譜、断片、候補、方向別境界証拠を保存します。`registration/` に全試行と部品別支持、`pairs.jsonl` に各ペアの採用試行、`pair_inventory.npz` に全ペアの評価／除外／未評価を保存します。行列のsource・target索引とコードの意味は `evaluation.json` にあります。

`assignment.json` は共有断片と共有画素の両方を禁止した集合選択です。最良案、異なる対応組合せの次点、utility差、探索打切り・最適性を残します。差の閾値が未校正なら `AMBIGUOUS`、未評価ペアが残る場合も保留します。

HTMLはT0、T1、全体、登録後、案1／案2、部品／複合OBBを切り替えられます。登録後は選択sourceの点だけを変換します。図間の軸範囲・カメラ・点サイズを共有し、対応線とICP推定移動の矢印を区別します。

## 旧経路の再現

```bash
python -m ylm06.legacy --inputs validation/legacy_inputs --out runs/replay_B0
python examples/run_compatibility_validation.py --out runs/replay_local
```

B0は固定30組・240項目とvalidを比較します。localはscore・fitness・RMSE・中心移動・yawの5指標を1e-6で比較し、同一ペアバンクでサイズ／ShapeゲートのON/OFFと旧割当順序を比較します。旧経路の結果を実グラフへ自動適用しません。

## 評価とグラフの明示適用

独立した注釈は推論入力から分離して評価します。

```bash
python examples/next/evaluate_annotations.py --run runs/exp01 --annotations ground_truth.json --out evaluations/exp01.json
```

注釈には `role`（INDEPENDENT_GTまたはDEVELOPMENT_REVIEW）、`annotator`, `created_at`, `method`, `objects` を指定します。各objectは `observation_id`, 共通の `object_id`, `pixel_ids` を持ちます。同一物体の候補包含と別物体を含む候補を別々に出力します。未注釈・混在・手動の対応を分母から区別します。参照例は `validation/synthetic_annotations.json` です。

グラフ適用には旧graph、source候補から持続nodeへの明示対応、照合できる座標・重力の検証記録、独立ケースで校正した設定fingerprint、解決済み割当が必要です。例の検証状態を書き換えるだけでは不足します。`ylm_next/verification.py` に検証記録の契約があります。

```bash
python -m ylm_next apply --run runs/approved_run --review review.json --store graph_versions
python -m ylm_next rollback --store graph_versions --run-id 'run:実際のID'
```

reviewには `approved: true`, `proposal_sha256`, `reviewer`, `reviewed_at`, `reason`, 全操作の `confirmed_pairs` が必要です。別バージョンへ保存し、元graph・変更前graph・確認記録を保持します。STATICは履歴形状を保持、MOVEDは設定に従い現在観測の形状を別記録へ保存します。関係を再計算していない辺は有効な最新関係と偽らずSTALE等を付けます。ロールバックは現在のHEADのみが対象です。

## 検証結果と残課題

`validation/REPORT_ja.md` と `docs/ACCEPTANCE_MATRIX_ja.md` を参照してください。手動椅子の数値回収、move_clearの3物体領域の候補包含・評価・選択追跡は、独立GTとは区別しています。正式profileの採用には、調整に用いていない独立データと座標・重力の検証根拠が引き続き必要です。

## 容量停止後の仕上げと記録版

容量等で止まったrunでも、両観測の候補段階と登録チェックポイントが保存されていれば、計算済みの結果から別フォルダーへ割当・更新案・HTMLを出力できます。

```bash
python -m ylm_next finalize --run runs/stopped --out exports/stopped_review
```

元runを変更せず、追加のICPも行いません。`checkpoint_import.json` で各ペアのJSON値が保存前後で一致したことを確認できます。未評価は未評価のままです。仕上げた出力は `derived_finalization: true` となり、そこへ `--resume` はできません。継続計算には元runと同じ記録版を使うか、現行版で新しいrunを作成してください。

今回同梱する実データの登録数値は `validation/runtime_source/` の記録版で計算し、現行版で保存形式とHTMLを整理しました。現行版は容量停止時の診断用領域を確保し、完了済み候補の状態を保持し、詳細JSONの余分な字下げとHTML内の重複データを減らしています。登録・候補の数値計算モジュールは記録版から変更していません。記録版のコードSHA256、現行仕上げ処理のSHA256、元の実行manifestを別々に保存しています。

候補だけの比較は `examples/next/candidate_sensitivity.py` で同じ保存マスク・断片に15/16cmまたは15/25cm条件を適用します。move_clearの元実行は複合候補200件の上限に達していますが、追加した候補のみの比較では上限1000で15cm条件の全205件を保存しています。これを326組の登録計算が全205候補を評価したという意味にはしません。
