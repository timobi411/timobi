import copy
import tempfile
import unittest
from pathlib import Path
import numpy as np
from ylm06.compatibility import gate_defaults, gate_evidence, validate_gates, local_icp, register_compat
from ylm06.compat_prepare import prepare
from ylm06.profiles import defaults, validate
from ylm06.util import Invalid, read, write, sha
from examples.make_fixture import create

class CompatibilityTests(unittest.TestCase):
    def setUp(self):
        self.a={'center':[0,0,0], 'extent':[1,1,1], 'points':100}
        self.b={'center':[.9,0,0], 'extent':[.38,.38,.38], 'points':34}
        self.r={'icp_translation_m':.925,'t0_coverage':.503,'t1_coverage':.977,'rmse':.0275,'score':.762,'fitness':.503}
    def test_size_and_shape_have_independent_evidence(self):
        for size in (True,False):
            for shape in (True,False):
                p=dict(gate_defaults(),assignment_size_gate=size,shape_gate=shape)
                e=gate_evidence(self.a,self.b,self.r,p)
                self.assertEqual(set(e['rejected_by']), ({'assignment_size'} if size else set())|({'moved_shape'} if shape else set()))
    def test_obb_gate_separate_from_assignment(self):
        p=dict(gate_defaults(),obb_size_gate=True,assignment_size_gate=False,shape_gate=False)
        self.assertEqual(gate_evidence(self.a,self.b,self.r,p)['rejected_by'],['obb_size'])
    def test_thresholds_and_switches_explicit(self):
        p=gate_defaults();p.pop('shape_gate')
        with self.assertRaises(Invalid):validate_gates(p)
        p=gate_defaults();p['shape_gate']=0
        with self.assertRaises(Invalid):validate_gates(p)
    def test_no_correspondences_cannot_pass(self):
        r=dict(self.r,fitness=0,score=.3,rmse=0,t0_coverage=0,t1_coverage=0)
        e=gate_evidence(self.a,self.b,r,dict(gate_defaults(),assignment_size_gate=False,shape_gate=False))
        self.assertIn('legacy_icp_validity',e['rejected_by'])
    def test_strict_solver_contract(self):
        p=defaults();p['solver'].update(mode='LEGACY_LOCAL_6DOF_COMPAT',dof='6DOF',voxel_m=.01,fine_m=.08)
        validate(p,'REAL_DEVELOPMENT')
        p['solver']['yaw_degrees']=[0]
        with self.assertRaises(Invalid):validate(p,'REAL_DEVELOPMENT')
    def test_prepare_preserves_original_and_relocates(self):
        with tempfile.TemporaryDirectory()as d:
            p=Path(d);create(p/'source');source=p/'source/integration.json';h=sha(source)
            prepare(source,p/'new/compat.json')
            from ylm06.contracts import load
            c,*_=load(p/'new/compat.json')
            self.assertEqual(sha(source),h)
            self.assertEqual(c['profiles']['solver']['dof'],'6DOF')
            with self.assertRaises(Invalid):prepare(source,p/'new/compat.json')
    def test_small_input_explicitly_invalid(self):
        result,_,_=local_icp(np.zeros((1,3)),np.zeros((1,3)))
        self.assertIsNone(result)
    def test_recovered_real_pair_regression(self):
        import open3d as o3d
        p=Path(__file__).resolve().parents[1]/'validation/legacy_inputs'
        a,b=[np.asarray(o3d.io.read_point_cloud(str(p/t/'cloud_0001.pcd')).points)for t in ('t0_clouds','t1_clouds')]
        r,h,prep=local_icp(a,b)
        expected={'score':.7623697607151957,'fitness':.5033088235294118,'rmse':.02754564129188709,'icp_translation_m':.9251164488535741,'yaw_deg':-23.954172727822904}
        for k,v in expected.items():self.assertAlmostEqual(r[k],v,delta=1e-6)
        self.assertEqual(len(h),7);self.assertEqual(r['start_yaw_deg'],10)
    def test_integrated_compatibility_never_confirms_identity(self):
        rng=np.random.default_rng(17);a=rng.normal(size=(70,3))*.07
        r,h=register_compat(a,a+.01,{'initialization_limit':7,'pair_id':'fixture','frame_status':'FRAME_UNVERIFIED','reference_point':[0,0,0]})
        self.assertEqual(r['identity_status'],'UNRESOLVED')
        self.assertEqual(r['motion_status'],'UNKNOWN_MOTION')
        self.assertEqual(r['integration_validity'],'NOT_EVALUATED')
        self.assertEqual(len(h),7)
    def test_worker_small_input_no_crash(self):
        r,h=register_compat(np.zeros((0,3)),np.ones((2,3)),{'initialization_limit':7,'pair_id':'small','frame_status':'FRAME_UNVERIFIED','reference_point':[0,0,0]})
        self.assertEqual(r['evaluation_status'],'INVALID_INPUT');self.assertEqual(h,[])
