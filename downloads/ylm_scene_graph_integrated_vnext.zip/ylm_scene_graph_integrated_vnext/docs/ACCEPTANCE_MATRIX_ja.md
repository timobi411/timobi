# 仕様書との対応

|ID|実装・証拠|結果の意味|
|---|---|---|
|A01|`validation/b0_replay/comparison.json`|固定30組、240数値項目、validの再現。物理的正解とは区別|
|A02|`validation/local_replay/local_reproduction.json`|旧localの5指標を1e-6以内で比較|
|A03|`tests_next/test_integration.py`、既存`tests/test_registration.py`、合成run|恒等・既知変換・部分観測。全形状への精度保証ではない|
|A04|空・1点・共線・非有限値・対応なし試験|不適格入力は採用しない。未定義RMSEはnull|
|A05|旧正規化の契約試験、全ペア状態行列|valid/status/transformを保持。未評価はMOVEDにならない|
|A06|候補生成ループと実データの候補監査|全対象へ同一条件。手動指定を自動提案に注入しない|
|A07|両側の共有画素／断片を使う集合選択試験|重複する候補の二重採用を禁止|
|A08|大傾き試験、全試行の姿勢ゲート|高coverageでも別理由で保留。未検証軸はセンサ軸と明示|
|A09|小部品不支持試験、手動椅子部品別結果|大部品だけの支持を複合全体の支持としない|
|A10|途中再開・改変拒否・時間停止試験、512組実行|完了段階とペアを再利用。source別配分・未評価理由を保存|
|A11|`validation/browser/result.json` と画像|点重複なし、4表示切替、sourceのみ変換、外部通信・JSエラーなし|
|A12|各runの`non_destructive_verification.json`、入力ハッシュ|元入力とグラフを保持。復元元43パートも保持|
|A13|手動union試験と`validation/manual_comparison`|指定点集合の和だけ。自動成功には算入しない|
|A14|未検証runの保留試験、明示適用・重複拒否・rollback試験|標準PROPOSAL_ONLY。独立校正と明示レビューが必要|

原仕様書は `specification_vnext.md`。比較値は全て開発値であり、実データの正解率・正式運用profileを今回の実装だけから確定しません。

追加契約：壁除去は有限の投影支持近傍に限定し、平面群の統合はcomplete-linkと統合残差を検査します。LOCALは低confidence・temporal bridgeだけを近距離で緩和し、保存`pass_geometry`の集約フラグを再利用しません。原始alpha/beta・距離・境界・有効端点で判定します。

最適性が未証明の割当、未評価ペア、未校正の次点差がある場合は、表示する最良案があっても同一性確定を保留します。手動由来の解は別集計です。独立GTが未提供の実ケースでは精度をnullとします。
