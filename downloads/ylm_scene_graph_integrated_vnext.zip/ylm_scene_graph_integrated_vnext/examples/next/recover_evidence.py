"""Read-only post-hoc index of user supplied development evidence, never inference input."""
import json,shutil
from pathlib import Path

def recover(bundle,out):
 out=Path(out);out.mkdir(parents=True,exist_ok=True);root=Path(bundle)/'real_experiment/organized_runs';report={'status':'RECOVERED_DEVELOPMENT_EVIDENCE_NOT_INDEPENDENT_GT','runs':{},'unresolved':['independent physical identity ground truth','verified common coordinates and gravity','independent calibration cases']}
 for pattern in ['baseline_B0_validation_*','baseline_B0_degenerate_*','assignment_graph_contract_audit_*','exp02_m1_m1_route_replay_*','exp02_assignment_route_comparison_*','exp02_assignment_size_gate_ablation_*','exp01_composite_candidate_audit_*','exp01_manual_chair_registration_*','move_clear_three_objects_icp_*','C219_C350_icp_comparison_*','move_clear_cluster_color_material_*','move_clear_black_arrows_*']:
  for source in sorted(root.glob(pattern)):
   dest=out/source.name;dest.mkdir(exist_ok=True);files=[]
   for p in sorted(source.glob('*.json'))+sorted(source.glob('*.jsonl')):
    shutil.copy2(p,dest/p.name);files.append(p.name)
   report['runs'][source.name]={'original_absolute_path':'/home/cslab/122M043/Scene_Graph/real_experiment/organized_runs/'+source.name,'files':files}
 chair=root/'exp01_manual_chair_registration_6s8pd4m0';selected=json.loads((chair/'assignment.json').read_text())['selected'];matched=next(x for x in selected if x['t0']==440 and x['t1']==410)
 report['manual_chair']={'run':chair.name,'selected':True,'manual_not_automatic':True,'metrics':{k:v for k,v in matched['best'].items() if k!='transformation'},'components':json.loads((chair/'chair_component_coverage.json').read_text())}
 report['exp01_radius_sensitivity']=json.loads((root/'exp01_composite_candidate_audit_yklip4me/proposal_comparison.json').read_text())
 (out/'recovery_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));return report
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--bundle',required=True);p.add_argument('--out',required=True);a=p.parse_args();recover(a.bundle,a.out)
