import json
from pathlib import Path
import numpy as np

def make(out):
 out=Path(out);out.mkdir(parents=True,exist_ok=True);rng=np.random.default_rng(9);h,w=12,20;y,x=np.indices((h,w));xyz=np.stack([x*.025+(x>=10)*.6,y*.025,2.+.025*np.sin(x*.8)+.015*np.cos(y*.7)],-1);xyz+=rng.normal(0,.0001,xyz.shape);observations=[]
 for t in ['t0','t1']:
  p=xyz.copy()
  if t=='t1':p[x<10]+=[.15,-.06,.03]
  dst=out/t;dst.mkdir(exist_ok=True);valid=np.ones((h,w),bool)
  np.savez_compressed(dst/'observation.npz',xyz=p,range=np.linalg.norm(p,axis=-1),valid=valid,source_type=np.ones((h,w),np.uint8),support_count=np.full((h,w),3,np.int32),source_time_ns=np.full((h,w),10 if t=='t0' else 20,np.int64),measurement_confident=valid)
  np.savez_compressed(dst/'mask.npz',structure_mask=np.zeros((h,w),bool))
  observations.append({'observation_id':'fixture:'+t,'observation':t+'/observation.npz','mask':t+'/mask.npz','time':t,'case':'synthetic','adapter_version':'native-v1','observation_to_common':np.eye(4).tolist()})
 c={'schema':'ylm.next.config.v1','case':'synthetic','observations':observations,'wall':{'enabled':False},'registration':{'max_pairs':1,'voxel_m':0.,'yaw_degrees':[-30,0,30]},'candidate':{'max_composites':0},'gates':{'assignment_size':{'enabled':False}}}
 (out/'config.json').write_text(json.dumps(c,indent=2));return out/'config.json'
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();print(make(a.out))
