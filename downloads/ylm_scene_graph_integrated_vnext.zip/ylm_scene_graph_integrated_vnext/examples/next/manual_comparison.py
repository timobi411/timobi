"""Controlled manual union comparison; supplied old IDs never enter auto generation."""
import argparse,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import numpy as np
from ylm_next.core import *
from ylm_next.config import defaults
from ylm_next.registration import register

def main(bundle,out):
 root=Path(bundle)/'real_experiment/organized_runs/exp01_obb_registration_yvmwcxv4';out=Path(out);out.mkdir(parents=True,exist_ok=False);c=defaults();c['gates']['assignment_size']['enabled']=False;c['gates']['obb_center']['threshold']=2.5;arrays=[];candidates=[];source={}
 for t,labs in [('t0',[13,145]),('t1',[10,35,101])]:
  path=root/t/'pixels.npz';a=load(path);source[str(path)]=sha(path);flat=a['xyz'].reshape(-1,3);ll=a['labels'].ravel();ids=np.flatnonzero(np.isin(ll,labs));parts={t+':old:'+str(l):np.flatnonzero(ll==l).tolist() for l in labs}
  cand={'candidate_key':t+':manual:'+','.join(map(str,labs)),'observation_id':t,'fragment_keys':list(parts),'fragment_labels':labs,'pixel_ids':ids.tolist(),'point_count':len(ids),'parts':parts,'obb':obb(flat[ids]),'origin':'MANUAL_COMPOSITE','boundary_state':'MANUAL_REVIEW_NOT_AUTOMATIC','manual_provenance':{'specified_by':'USER_SPECIFIED_IN_SUPPLIED_RESEARCH_RECORD','specified_at':'2026-10-23','reason':'Controlled reproduction of specified chair union','source_sha256':sha(path)}};arrays.append(flat);candidates.append(cand)
 pair=register(*candidates,*arrays,c,Budget(c['resources']));write(out/'pair.json',pair);write(out/'candidates.json',candidates);write(out/'resolved_config.json',c);write(out/'source_inventory.json',sources());write(out/'input_manifest.json',source);write(out/'evaluation.json',{'status':'MANUAL_DIAGNOSTIC','automatic_success_count':0,'graph_modified':False,'valid':pair['valid'],'metrics':pair.get('metrics'),'motion':pair.get('motion'),'identity_accuracy':None,'source_condition':'SUPPLIED_OLD_OBB_PARTITION_EXACT_UNION_NO_BOX_FILL'})
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--bundle',required=True);p.add_argument('--out',required=True);a=p.parse_args();main(a.bundle,a.out)
