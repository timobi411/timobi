from pathlib import Path
import json
from ylm_next.config import defaults

def convert(x):
 if isinstance(x,bool):return {'type':'boolean'}
 if isinstance(x,str):return {'type':'string'}
 if isinstance(x,int):return {'type':'integer'}
 if isinstance(x,float):return {'type':'number'}
 if isinstance(x,list):return {'type':'array','items':convert(x[0]) if x else {}}
 if isinstance(x,dict):return {'type':'object','additionalProperties':False,'properties':{k:convert(v) for k,v in x.items()},'required':list(x)}
 return {'type':['null','string','number','object']}
r=convert(defaults());r.update({'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'ylm.next.config.v1'})
o={'type':'object','required':['observation_id','observation','mask','time','case','adapter_version','observation_to_common'],'additionalProperties':False,'properties':{k:{'type':'string'} for k in ['observation_id','observation','mask','edges','edge_config','labels','time','case','adapter_version']}}
o['properties']['observation_to_common']={'type':'array','minItems':4,'maxItems':4,'items':{'type':'array','minItems':4,'maxItems':4,'items':{'type':'number'}}};o['properties']['graph_node_map']={'type':'object','additionalProperties':{'type':'string'}}
r['properties']['observations'].update(minItems=2,maxItems=2,items=o)
r['properties']['assignment']['properties']['margin']={'type':['null','number'],'minimum':0}
r['properties']['manual_candidates']['items']={'type':'object','required':['observation_id','labels','specified_by','specified_at','reason'],'properties':{'labels':{'type':'array','items':{'type':'integer'},'minItems':2,'uniqueItems':True},**{k:{'type':'string','minLength':1} for k in ['observation_id','specified_by','specified_at','reason']}},'additionalProperties':False}
r['properties']['object_models']['items']={'type':'object','required':['path'],'properties':{'path':{'type':'string'}},'additionalProperties':False}
p=Path('ylm_next/schemas');p.mkdir(exist_ok=True);(p/'config.json').write_text(json.dumps(r,indent=2))
for name,properties,required in [('pair',{'pair_id':{'type':'string'},'evaluation_status':{'enum':['INVALID_INPUT','DEGENERATE','EVALUATED','NO_CORRESPONDENCE']},'valid':{'type':'boolean'},'transform_source_to_target':{'type':['array','null']},'motion_status':{'enum':['UNKNOWN','STATIC','MOVED']},'hypotheses':{'type':'array'}},['pair_id','evaluation_status','valid','transform_source_to_target','motion_status']),('candidate',{'candidate_key':{'type':'string'},'pixel_ids':{'type':'array','items':{'type':'integer','minimum':0},'uniqueItems':True},'origin':{'enum':['AUTO_SINGLE','AUTO_COMPOSITE','MANUAL_COMPOSITE']},'fragment_keys':{'type':'array','items':{'type':'string'},'minItems':1},'point_count':{'type':'integer','minimum':1}},['candidate_key','pixel_ids','fragment_keys','origin','point_count'])]:
 (p/(name+'.json')).write_text(json.dumps({'$schema':'https://json-schema.org/draft/2020-12/schema','type':'object','required':required,'properties':properties},indent=2))
