"""Post-hoc supplied three-object region coverage, never an inference constraint."""
import argparse,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import numpy as np
from ylm_next.core import *

def main(bundle,run,out):
 run=Path(run);root=Path(bundle)/'real_experiment/organized_runs/move_clear_geometry_merge_mwe4auid';rows=[];pairs=[json.loads(s) for s in (run/'pairs.jsonl').read_text().splitlines()];selected=set(read(run/'assignment.json')['selected'])
 for index,t,labels in [(0,'t0',[80,84,159]),(1,'t1',[12,21,72])]:
  path=root/t/'pixels.npz';a=load(path);cands=[json.loads(s) for s in (run/f'observation_{index}/candidates.jsonl').read_text().splitlines()]
  for label in labels:
   pixels=set(np.flatnonzero(a['labels'].ravel()==label).tolist());matches=[]
   for cand in cands:
    overlap=len(pixels&set(cand['pixel_ids']))
    if not overlap:continue
    covered=overlap/len(pixels);purity=overlap/cand['point_count'];matches.append({'candidate_key':cand['candidate_key'],'region_coverage':covered,'region_fraction_of_candidate':purity,'origin':cand['origin']})
   matches.sort(key=lambda x:(-x['region_coverage'],-x['region_fraction_of_candidate'],x['candidate_key']));keys={x['candidate_key'] for x in matches if x['region_coverage']>=.95};key='source_candidate_key' if index==0 else 'target_candidate_key';evaluated=[p['pair_id'] for p in pairs if p[key] in keys];rows.append({'observation':t,'old_region_label':label,'old_region_pixels':len(pixels),'source_sha256':sha(path),'top_candidate_containment':matches[:10],'at_least_95_percent_contained':bool(keys),'evaluated_pairs':evaluated,'selected_pairs':[k for k in evaluated if k in selected],'physical_identity':'NOT_INDEPENDENT_GT'})
 write(out,{'role':'POSTHOC_DEVELOPMENT_REVIEW','regions':rows,'threshold_for_trace_only':.95,'inference_unchanged':True,'force_three_moved':False})
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--bundle',required=True);p.add_argument('--run',required=True);p.add_argument('--out',required=True);a=p.parse_args();main(a.bundle,a.run,a.out)
