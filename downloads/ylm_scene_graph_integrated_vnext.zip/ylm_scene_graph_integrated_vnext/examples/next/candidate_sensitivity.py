"""Controlled candidate-only sweeps on identical saved masks/edges/fragments."""
import argparse,sys,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from ylm_next.core import *
from ylm_next.observation import load_observation
from ylm_next.candidates import generate

def main(run,out,kind):
 run=Path(run);out=Path(out);out.mkdir(parents=True,exist_ok=False);c=read(run/'resolved_config.json');summary=[]
 variants=[('15cm',.15,3,5),('16cm',.16,3,5)] if kind=='exp01' else [('15cm_uncapped',.15,3,5),('25cm_proposal',.25,5,15)]
 for i in range(2):
  stage=run/f'observation_{i}';obs=load_observation(c['observations'][i],run);obs['arrays']['structure_mask']=load(stage/'masks.npz')['combined'];fragments=read(stage/'fragments.json');labels=load(stage/'labels.npz')['final'];baseline=None
  for name,radius,support,minimum in variants:
   cp=copy.deepcopy(c['candidate']);cp.update(radius_m=radius,sensitivity_radius_m=radius,min_support_each=support,min_fragment_points=minimum,max_composites=1000);budget=Budget({'wall_seconds':300,'rss_mib':4096});rows,audit=generate(obs,fragments,labels,cp,c['boundary'],[],read(run/'run_manifest.json')['run_id']+':'+name,budget);sets={tuple(r['fragment_labels']) for r in rows};base=baseline if baseline is not None else sets;added=sets-base;dest=out/f'observation_{i}'/name;dest.mkdir(parents=True);write(dest/'config.json',cp);write(dest/'audit.json',audit);lines(dest/'candidates_compact.jsonl',[{k:v for k,v in r.items() if k not in ['pixel_ids','parts']} for r in rows]);write(dest/'added_groups.json',[list(g) for g in sorted(added)]);summary.append({'observation':i,'variant':name,'candidate_count':len(rows),'composite_count':audit['composite_count'],'candidate_processing_complete':audit['generation_complete'],'added_over_first_variant':len(added),'source_fragments_sha256':sha(stage/'fragments.json'),'mask_sha256':sha(stage/'masks.npz'),'resources':budget.stats(),'no_registration_or_adoption_performed':True});baseline=sets if baseline is None else baseline
 write(out/'comparison.json',{'kind':kind,'source_run':read(run/'run_manifest.json')['run_id'],'conditions':summary,'source_code_hashes':sources(),'manual_ids_in_generation':False})
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--out',required=True);p.add_argument('--kind',choices=['exp01','move_clear'],required=True);a=p.parse_args();main(a.run,a.out,a.kind)
