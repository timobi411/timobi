"""Post-hoc ground-truth scoring. Never imported by inference or used for tuning."""
import argparse,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from ylm_next.core import *
from ylm_next.pipeline import verify

def evaluate(run,annotations,out):
 run=Path(run);verify(run);before=sha(run/'artifact_hashes.json');gt=read(annotations);require(gt.get('role') in ['INDEPENDENT_GT','DEVELOPMENT_REVIEW'],'Annotation role must be explicit');require(all(gt.get(k) for k in ['annotator','created_at','method']),'Annotation provenance required');objects=gt['objects'];truth={}
 for o in objects:
  key=o['observation_id'];ids=set(o['pixel_ids']);require(len(ids)==len(o['pixel_ids']) and all(type(i) is int and i>=0 for i in ids),'Unique nonnegative integer annotation pixels required')
  used=truth.setdefault(key,{})
  for i in ids:require(i not in used,'Ground truth objects overlap');used[i]=o['object_id']
 candidates=[]
 for p in sorted(run.glob('observation_*/candidates.jsonl')):candidates.extend(json.loads(s) for s in p.read_text().splitlines())
 bykey={c['candidate_key']:c for c in candidates};formation=[]
 for o in objects:
  pixels=set(o['pixel_ids']);auto=[c for c in candidates if c['observation_id']==o['observation_id'] and c['origin']!='MANUAL_COMPOSITE'];contained=[c['candidate_key'] for c in auto if pixels and pixels<=set(c['pixel_ids'])];formation.append({'observation_id':o['observation_id'],'object_id':o['object_id'],'automatic_candidate_contains_all_annotated_parts':bool(contained),'candidate_keys':contained,'annotation_points':len(pixels)})
 mixed=[]
 for c in candidates:
  if c['origin']=='MANUAL_COMPOSITE':continue
  labels={truth.get(c['observation_id'],{}).get(i) for i in c['pixel_ids']}-{None}
  if len(labels)>1:mixed.append({'candidate_key':c['candidate_key'],'ground_truth_objects':sorted(labels),'state':c['status']})
 pairs={p['pair_id']:p for p in [json.loads(s) for s in (run/'pairs.jsonl').read_text().splitlines()]};assignment=read(run/'assignment.json');checks=[];excluded=[]
 for pid in assignment['selected']:
  p=pairs[pid]
  if p['manual_origin']:excluded.append({'pair_id':pid,'reason':'MANUAL'});continue
  labels=[]
  for name in ['source_candidate_key','target_candidate_key']:
   c=bykey[p[name]];labels.append({truth.get(c['observation_id'],{}).get(i) for i in c['pixel_ids']}-{None})
  if any(len(s)!=1 for s in labels):excluded.append({'pair_id':pid,'reason':'UNLABELED_OR_MIXED_GT'});continue
  checks.append({'pair_id':pid,'same_object':labels[0]==labels[1]})
 result={'annotation_role':gt['role'],'automatic_part_formation':formation,'separate_object_mixed_proposals':mixed,'diagnostic_selected_pair_checks':checks,'excluded':excluded,'independent_identity_accuracy':sum(x['same_object'] for x in checks)/len(checks) if checks and gt['role']=='INDEPENDENT_GT' else None,'denominator':len(checks),'graph_update_accuracy':None,'automatic_adoption_accuracy':None,'manual_candidates_excluded':True,'input_annotation_sha256':sha(annotations),'evaluation_code_sha256':sha(__file__),'run_id':read(run/'run_manifest.json')['run_id']}
 require(sha(run/'artifact_hashes.json')==before,'Inference artifacts mutated');out=Path(out);require(not out.exists(),'Evaluation output already exists');write(out,result);return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--annotations',required=True);p.add_argument('--out',required=True);a=p.parse_args();evaluate(a.run,a.annotations,a.out)
