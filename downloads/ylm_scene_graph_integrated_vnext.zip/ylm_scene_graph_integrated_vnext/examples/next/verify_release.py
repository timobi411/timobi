"""Verify a release manifest with only the Python standard library."""
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--manifest',default='release_manifest.json');a=p.parse_args();root=Path(__file__).resolve().parents[2];manifest=root/a.manifest;data=json.loads(manifest.read_text());errors=[]
for item in data['files']:
 f=root/item['path']
 if not f.is_file():errors.append('missing '+item['path']);continue
 h=hashlib.sha256()
 with f.open('rb') as stream:
  for block in iter(lambda:stream.read(1048576),b''):h.update(block)
 if f.stat().st_size!=item['bytes'] or h.hexdigest()!=item['sha256']:errors.append('changed '+item['path'])
print(json.dumps({'passed':not errors,'files':len(data['files']),'errors':errors},ensure_ascii=False,indent=2));raise SystemExit(bool(errors))
