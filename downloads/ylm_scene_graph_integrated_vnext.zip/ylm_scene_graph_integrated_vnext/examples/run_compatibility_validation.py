"""Replay the recovered exp02 pair, then hold all other pairs fixed for gate ablation."""
import argparse
from pathlib import Path
import sys
# Also support direct invocation before an editable install.
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import open3d as o3d
from ylm06.compatibility import local_icp
from ylm06.compat_compare import compare
from ylm06.util import write,sha


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--legacy-inputs')
    args=p.parse_args();project=Path(__file__).resolve().parents[1];out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=False)
    original=project/'validation/legacy_inputs'
    paths=[original/t/'cloud_0001.pcd'for t in ('t0_clouds','t1_clouds')]
    a,b=[np.asarray(o3d.io.read_point_cloud(str(f)).points)for f in paths]
    r,h,pre=local_icp(a,b)
    reference={'score':.7623697607151957,'fitness':.5033088235294118,'rmse':.02754564129188709,
        'icp_translation_m':.9251164488535741,'yaw_deg':-23.954172727822904}
    checks={k:{'actual':r[k],'reference':v,'absolute_difference':abs(r[k]-v),'pass':abs(r[k]-v)<=1e-6}for k,v in reference.items()}
    write(out/'local_reproduction.json',{'checks':checks,'hypotheses':h,'preprocessing':pre,
        'source_hashes':{str(f):sha(f)for f in paths},'identity_accuracy':'NOT_EVALUATED'})
    if not all(c['pass']for c in checks.values()):
        print('Numerical replay differs; see local_reproduction.json');return 1
    write(out/'recovered_pair.json',{'t0_id':1,'t1_id':1,'result':r})
    result=compare(args.legacy_inputs or original,out/'gate_comparison',
        original/'reference_partial_icp_results.json',out/'recovered_pair.json')
    print(result)
    print('Viewer:',out/'gate_comparison/index.html')
    return 2 if result['partial']else 0

if __name__=='__main__':raise SystemExit(main())
